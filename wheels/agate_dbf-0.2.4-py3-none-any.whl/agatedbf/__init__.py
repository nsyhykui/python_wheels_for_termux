import agatedbf.table
