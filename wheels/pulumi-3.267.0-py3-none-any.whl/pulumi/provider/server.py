# Copyright 2016, Pulumi Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Define gRPC plumbing to expose a custom user-defined `Provider`
instance as a gRPC server so that it can be used as a Pulumi plugin.

"""

from typing import Optional, Any, cast, Union
import types
import argparse
import asyncio
import sys
import traceback

import grpc
import grpc.aio

from google.protobuf import empty_pb2, struct_pb2
from pulumi.provider.provider import InvokeResult, Provider, CallResult, ConstructResult
from pulumi.resource import (
    ProviderResource,
    Resource,
    DependencyResource,
    DependencyProviderResource,
    _parse_resource_reference,
)
from pulumi.runtime import known_types, proto, rpc
from pulumi.runtime.proto import (
    provider_pb2_grpc,
    ResourceProviderServicer,
    status_pb2,
    errors_pb2,
    alias_pb2,
)
from pulumi.runtime.resource_hooks import _binding_from_proto
from pulumi.runtime.stack import wait_for_rpcs
import pulumi
import pulumi.resource
import pulumi.runtime.config
import pulumi.runtime.settings
from pulumi.output import _OutputData
from pulumi.runtime._grpc_settings import _GRPC_CHANNEL_OPTIONS
from pulumi.errors import (
    InputPropertiesError,
    InputPropertyError,
    InputPropertyErrorDetails,
    RunError,
)


class ComponentInitError(Exception):
    """
    ComponentInitError signals an error raised from within the __init__ method
    of a component. This allows us to distinguish between a user error and a
    system error.
    """

    def __init__(self, inner: Exception) -> None:
        super().__init__(str(inner))
        self.inner = inner


class ProviderServicer(ResourceProviderServicer):
    """Implements a subset of `ResourceProvider` methods to support
    `Construct` and other methods invoked by the engine when the user
    program creates a remote `ComponentResource` (with `remote=true`
    in the constructor).

    See `ResourceProvider` defined in `provider.proto`.

    """

    engine_address: str
    provider: Provider
    args: list[str]

    def create_grpc_invalid_properties_status(
        self, message: str, errors: Optional[list[InputPropertyErrorDetails]]
    ):
        status = grpc.Status()
        # We don't care about the exact status code here, since they are pretty web centric, and don't
        # necessarily make sense in this context.  Pick one that's close enough.
        status.code = grpc.StatusCode.INVALID_ARGUMENT
        status.details = message

        if errors is not None:
            s = status_pb2.Status()
            # This code needs to match the code above.
            s.code = grpc.StatusCode.INVALID_ARGUMENT.value[0]
            s.message = message

            error_details = errors_pb2.InputPropertiesError()
            for error in errors:
                property_error = errors_pb2.InputPropertiesError.PropertyError()
                property_error.property_path = error["property_path"]
                property_error.reason = error["reason"]
                error_details.errors.append(property_error)

            details_container = s.details.add()
            details_container.Pack(error_details)

            status.trailing_metadata = (
                ("grpc-status-details-bin", s.SerializeToString()),
            )

        return status

    async def Construct(
        self, request: proto.ConstructRequest, context
    ) -> proto.ConstructResponse:
        try:
            return await self._construct(request, context)
        except Exception as e:  # noqa
            if isinstance(e, RunError):
                raise
            if isinstance(e, InputPropertiesError):
                status = self.create_grpc_invalid_properties_status(e.message, e.errors)
                await context.abort_with_status(status)
                # We already aborted at this point
                raise
            elif isinstance(e, InputPropertyError):
                status = self.create_grpc_invalid_properties_status(
                    "", [{"property_path": e.property_path, "reason": e.reason}]
                )
                await context.abort_with_status(status)
                # We already aborted at this point
                raise
            else:
                if isinstance(e, ComponentInitError):
                    stack = traceback.extract_tb(e.inner.__traceback__)[:]
                    # Drop the internal frame for `self._construct`.
                    stack = stack[1:]
                else:
                    stack = traceback.extract_tb(e.__traceback__)[:]
                pretty_stack = "".join(traceback.format_list(stack))
                raise Exception(f"{str(e)}:\n{pretty_stack}")

    async def _construct(
        self, request: proto.ConstructRequest, context
    ) -> proto.ConstructResponse:
        assert isinstance(request, proto.ConstructRequest), (
            f"request is not ConstructRequest but is {type(request)} instead"
        )

        organization = request.organization if request.organization else "organization"
        pulumi.runtime.settings.reset_options(
            organization=organization,
            project=_empty_as_none(request.project),
            stack=_empty_as_none(request.stack),
            parallel=_zero_as_none(request.parallel),
            engine_address=self.engine_address,
            monitor_address=_empty_as_none(request.monitorEndpoint),
            preview=request.dryRun,
        )
        await pulumi.runtime.settings._load_monitor_feature_support()

        pulumi.runtime.config.set_all_config(
            dict(request.config), list(request.configSecretKeys)
        )
        inputs = await self._construct_inputs(request.inputs, request.inputDependencies)

        result = self.provider.construct(
            name=request.name,
            resource_type=request.type,
            inputs=inputs,
            options=self._construct_options(request),
        )

        response = await self._construct_response(result)

        # Wait for outstanding RPCs such as more provider Construct
        # calls. This can happen if i.e. provider creates child
        # resources but does not await their URN promises.
        #
        # Do not await all tasks as that starts hanging waiting for
        # indefinite grpc.aio servier tasks.
        await wait_for_rpcs(await_all_outstanding_tasks=False)

        return response

    @staticmethod
    async def _construct_inputs(
        inputs: struct_pb2.Struct, input_dependencies: Any
    ) -> dict[str, pulumi.Input[Any]]:
        def deps(key: str) -> set[str]:
            return {
                urn
                for urn in input_dependencies.get(
                    key, proto.ConstructRequest.PropertyDependencies()
                ).urns
            }

        return {
            k: await ProviderServicer._select_value(the_input, deps=deps(k))
            for k, the_input in rpc.deserialize_properties(
                inputs, keep_unknowns=True
            ).items()
        }

    @staticmethod
    async def _select_value(the_input: Any, deps: set[str]) -> Any:
        is_secret = rpc.is_rpc_secret(the_input)

        # If the input isn't a secret and either doesn't have any dependencies, already contains Outputs (from
        # deserialized output values), or is a resource reference, then return it directly without wrapping it
        # as an output.
        if not is_secret and (
            len(deps) == 0
            or _contains_outputs(the_input)
            or await _is_resource_reference(the_input, deps)
        ):
            return the_input

        # Otherwise, wrap it as an output so we can handle secrets
        # and/or track dependencies.
        # Note: If the value is or contains an unknown value, the Output will mark its value as
        # unknown automatically, so we just pass true for is_known here.
        data_future: asyncio.Future[_OutputData[Any]] = asyncio.Future()
        data_future.set_result(
            _OutputData(
                resources={DependencyResource(urn) for urn in deps},
                value=rpc.unwrap_rpc_secret(the_input),
                is_known=True,
                is_secret=is_secret,
            )
        )
        return pulumi.Output._from_data(data_future)

    @staticmethod
    def _alias_from_proto(alias: alias_pb2.Alias) -> Union[str | pulumi.Alias]:
        if alias.urn:
            return alias.urn
        else:
            spec = alias.spec
            name: Union[str, types.EllipsisType] = ...
            resource_type: Union[str, types.EllipsisType] = ...
            parent_urn: Union[str, types.EllipsisType] = ...
            stack: Union[str, types.EllipsisType] = ...
            project: Union[str, types.EllipsisType] = ...

            if spec.name:
                name = spec.name
            if spec.type:
                resource_type = spec.type
            if spec.parentUrn:
                parent_urn = spec.parentUrn
            if spec.stack:
                stack = spec.stack
            if spec.project:
                project = spec.project
            no_parent = spec.noParent

            return pulumi.Alias(
                name=name,  # type: ignore
                type_=resource_type,  # type: ignore
                parent=None if no_parent else parent_urn,  # type: ignore
                stack=stack,  # type: ignore
                project=project,  # type: ignore
            )

    @staticmethod
    def _construct_options(request: proto.ConstructRequest) -> pulumi.ResourceOptions:
        parent = None
        if request.parent:
            parent = DependencyResource(request.parent)

        deleted_with = None
        if request.deletedWith != "":
            deleted_with = DependencyResource(request.deletedWith)

        replace_with: Optional[list[pulumi.Resource]] = None
        if request.replace_with:
            replace_with = [DependencyResource(urn) for urn in request.replace_with]

        replacement_trigger: Optional[Any] = None
        if request.HasField("replacement_trigger"):
            from pulumi.runtime.resource import _struct_value_to_python

            replacement_trigger = _struct_value_to_python(request.replacement_trigger)

        custom_timeouts = None
        if request.customTimeouts:
            pulumi.resource.CustomTimeouts(
                request.customTimeouts.create,
                request.customTimeouts.update,
                request.customTimeouts.delete,
                request.customTimeouts.read,
            )

        resource_hooks = _binding_from_proto(request.resource_hooks)

        return pulumi.ResourceOptions(
            aliases=[ProviderServicer._alias_from_proto(a) for a in request.aliases],
            depends_on=[DependencyResource(urn) for urn in request.dependencies],
            protect=request.protect,
            providers={
                pkg: _create_provider_resource(ref)
                for pkg, ref in request.providers.items()
            },
            parent=parent,
            custom_timeouts=custom_timeouts,
            ignore_changes=list(request.ignoreChanges),
            replace_on_changes=list(request.replaceOnChanges),
            retain_on_delete=request.retainOnDelete,
            deleted_with=deleted_with,
            replace_with=replace_with,
            replacement_trigger=replacement_trigger,
            hooks=resource_hooks,
        )

    async def _construct_response(
        self, result: ConstructResult
    ) -> proto.ConstructResponse:
        urn = await pulumi.Output.from_input(result.urn).future()
        assert urn is not None

        # Note: property_deps is populated by rpc.serialize_properties.
        property_deps: dict[str, list[pulumi.resource.Resource]] = {}
        state = await rpc.serialize_properties(
            inputs={k: v for k, v in result.state.items() if k not in ["id", "urn"]},
            property_deps=property_deps,
        )

        deps: dict[str, proto.ConstructResponse.PropertyDependencies] = {}
        for k, resources in property_deps.items():
            urns = await asyncio.gather(*(r.urn.future() for r in resources))
            # filter out any unknowns
            knownUrns = [u for u in urns if u is not None]
            deps[k] = proto.ConstructResponse.PropertyDependencies(urns=knownUrns)

        return proto.ConstructResponse(urn=urn, state=state, stateDependencies=deps)

    async def Call(self, request: proto.CallRequest, context):
        try:
            return await self._call(request, context)
        except InputPropertiesError as e:
            status = self.create_grpc_invalid_properties_status(e.message, e.errors)
            await context.abort_with_status(status)
            # We already aborted at this point
            raise
        except InputPropertyError as e:
            status = self.create_grpc_invalid_properties_status(
                "", [{"property_path": e.property_path, "reason": e.reason}]
            )
            await context.abort_with_status(status)
            # We already aborted at this point
            raise
        except RunError:
            raise
        except Exception as e:  # noqa
            stack = traceback.extract_tb(e.__traceback__)[:]
            pretty_stack = "".join(traceback.format_list(stack))
            raise Exception(f"{str(e)}:\n{pretty_stack}")

    async def _call(self, request: proto.CallRequest, context):
        assert isinstance(request, proto.CallRequest), (
            f"request is not CallRequest but is {type(request)} instead"
        )

        organization = request.organization if request.organization else "organization"
        pulumi.runtime.settings.reset_options(
            organization=organization,
            project=_empty_as_none(request.project),
            stack=_empty_as_none(request.stack),
            parallel=_zero_as_none(request.parallel),
            engine_address=self.engine_address,
            monitor_address=_empty_as_none(request.monitorEndpoint),
            preview=request.dryRun,
        )

        pulumi.runtime.config.set_all_config(
            dict(request.config),
            list(request.configSecretKeys),
        )

        args = await self._call_args(request)

        result = self.provider.call(token=request.tok, args=args)

        response = await self._call_response(result)

        # Wait for outstanding RPCs such as more provider Construct
        # calls. This can happen if i.e. provider creates child
        # resources but does not await their URN promises.
        #
        # Do not await all tasks as that starts hanging waiting for
        # indefinite grpc.aio servier tasks.
        await wait_for_rpcs(await_all_outstanding_tasks=False)

        return response

    @staticmethod
    async def _call_args(request: proto.CallRequest) -> dict[str, pulumi.Input[Any]]:
        def deps(key: str) -> set[str]:
            return {
                urn
                for urn in request.argDependencies.get(
                    key, proto.CallRequest.ArgumentDependencies()
                ).urns
            }

        return {
            k: await ProviderServicer._select_value(the_input, deps=deps(k))
            for k, the_input in
            # We need to keep_internal, to keep the `__self__` that would normally be filtered because
            # it starts with "__".
            rpc.deserialize_properties(
                request.args, keep_unknowns=True, keep_internal=True
            ).items()
        }

    async def _call_response(self, result: CallResult) -> proto.CallResponse:
        # Note: ret_deps is populated by rpc.serialize_properties.
        ret_deps: dict[str, list[pulumi.resource.Resource]] = {}
        ret = await rpc.serialize_properties(
            inputs=result.outputs, property_deps=ret_deps
        )

        deps: dict[str, proto.CallResponse.ReturnDependencies] = {}
        for k, resources in ret_deps.items():
            urns = await asyncio.gather(*(r.urn.future() for r in resources))
            # filter out any unknowns
            knownUrns = [u for u in urns if u is not None]
            deps[k] = proto.CallResponse.ReturnDependencies(urns=knownUrns)

        failures = None
        if result.failures:
            failures = [
                proto.CheckFailure(property=f.property, reason=f.reason)
                for f in result.failures
            ]
        resp = proto.CallResponse(returnDependencies=deps, failures=failures)
        # Since `return` is a keyword, we need to use getattr: https://developers.google.com/protocol-buffers/docs/reference/python-generated#keyword-conflicts
        getattr(resp, "return").CopyFrom(ret)
        return resp

    async def _invoke_response(self, result: InvokeResult) -> proto.InvokeResponse:
        # Note: ret_deps is populated by rpc.serialize_properties but unused
        ret_deps: dict[str, list[pulumi.resource.Resource]] = {}
        ret = await rpc.serialize_properties(
            inputs=result.outputs, property_deps=ret_deps
        )
        # Since `return` is a keyword, we need to pass the args to `InvokeResponse` using a dictionary.
        resp: dict[str, Any] = {
            "return": ret,
        }
        if result.failures:
            resp["failures"] = [
                proto.CheckFailure(property=f.property, reason=f.reason)
                for f in result.failures
            ]
        return proto.InvokeResponse(**resp)

    async def Invoke(
        self, request: proto.InvokeRequest, context
    ) -> proto.InvokeResponse:
        try:
            args = rpc.deserialize_properties(request.args, keep_unknowns=False)
            result = self.provider.invoke(token=request.tok, args=args)
            response = await self._invoke_response(result)
            return response
        except RunError:
            raise
        except Exception as e:  # noqa
            stack = traceback.extract_tb(e.__traceback__)[:]
            pretty_stack = "".join(traceback.format_list(stack))
            raise Exception(f"{str(e)}:\n{pretty_stack}")

    async def Configure(self, request, context) -> proto.ConfigureResponse:
        return proto.ConfigureResponse(
            acceptSecrets=True, acceptResources=True, acceptOutputs=True
        )

    async def List(self, request, context):
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("List is not implemented by the provider")
        raise NotImplementedError("List is not implemented by the provider")

    async def Cancel(self, request, context):
        self.provider.cancel()
        return empty_pb2.Empty()

    async def GetPluginInfo(self, request, context) -> proto.PluginInfo:
        if self.provider.version is None:
            return proto.PluginInfo(version="")
        return proto.PluginInfo(version=self.provider.version)

    async def GetSchema(
        self, request: proto.GetSchemaRequest, context
    ) -> proto.GetSchemaResponse:
        if request.version != 0:
            raise Exception(f"unsupported schema version {request.version}")
        schema = self.provider.schema if self.provider.schema else "{}"
        return proto.GetSchemaResponse(schema=schema)

    def __init__(
        self, provider: Provider, args: list[str], engine_address: str
    ) -> None:
        super().__init__()
        self.provider = provider
        self.args = args
        self.engine_address = engine_address


def main(provider: Provider, args: list[str]) -> None:  # args not in use?
    """For use as the `main` in programs that wrap a custom Provider
    implementation into a Pulumi-compatible gRPC server.

    :param provider: an instance of a Provider subclass

    :args: command line arguiments such as os.argv[1:]

    """

    argp = argparse.ArgumentParser(description="Pulumi provider plugin (gRPC server)")
    argp.add_argument("engine", help="Pulumi engine address")
    argp.add_argument("--logflow", action="store_true", help="Currently ignored")
    argp.add_argument("--logtostderr", action="store_true", help="Currently ignored")

    known_args, _ = argp.parse_known_args()
    engine_address: str = known_args.engine

    async def serve() -> None:
        server = grpc.aio.server(options=_GRPC_CHANNEL_OPTIONS)
        servicer = ProviderServicer(provider, args, engine_address=engine_address)
        provider_pb2_grpc.add_ResourceProviderServicer_to_server(servicer, server)
        port = server.add_insecure_port(address="127.0.0.1:0")
        await server.start()
        sys.stdout.buffer.write(f"{port}\n".encode())
        sys.stdout.buffer.flush()
        await server.wait_for_termination()

    try:
        asyncio.run(serve())
    except KeyboardInterrupt:
        pass


def _empty_as_none(text: str) -> Optional[str]:
    return None if text == "" else text


def _zero_as_none(value: int) -> Optional[int]:
    return None if value == 0 else value


async def _is_resource_reference(the_input: Any, deps: set[str]) -> bool:
    """
    Returns True if `the_input` is a Resource and only depends on itself.
    """
    return (
        known_types.is_resource(the_input)
        and len(deps) == 1
        and next(iter(deps)) == await cast(Resource, the_input).urn.future()
    )


def _contains_outputs(the_input: Any) -> bool:
    """
    Returns true if the input contains Outputs (deeply).
    """
    if known_types.is_output(the_input):
        return True

    if isinstance(the_input, list):
        for e in the_input:
            if _contains_outputs(e):
                return True
    elif isinstance(the_input, dict):
        for k in the_input:
            if _contains_outputs(the_input[k]):
                return True

    return False


def _create_provider_resource(ref: str) -> ProviderResource:
    """
    Rehydrate the provider reference into a registered ProviderResource,
    otherwise return an instance of DependencyProviderResource.
    """
    urn, _ = _parse_resource_reference(ref)
    urn_parts = pulumi.urn._parse_urn(urn)
    resource_package = rpc.get_resource_package(urn_parts.typ_name, version="")
    if resource_package is not None:
        return resource_package.construct_provider(
            urn_parts.urn_name, urn_parts.typ, urn
        )

    return DependencyProviderResource(ref)
