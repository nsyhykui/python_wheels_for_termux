# Copyright 2026, Pulumi Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar


_ACTIVE_STATE_MIGRATION_URN: ContextVar[str | None] = ContextVar(
    "active_state_migration_urn", default=None
)


@contextmanager
def _state_migration_callback(urn: str) -> Iterator[None]:
    """Marks Pulumi runtime calls made by a state migration callback."""
    token = _ACTIVE_STATE_MIGRATION_URN.set(urn)
    try:
        yield
    finally:
        _ACTIVE_STATE_MIGRATION_URN.reset(token)


def _ensure_not_in_state_migration(operation: str) -> None:
    """Rejects runtime operations that could re-enter the waiting resource monitor."""
    urn = _ACTIVE_STATE_MIGRATION_URN.get()
    if urn is None:
        return

    raise RuntimeError(
        f"Pulumi runtime operation {operation!r} is not allowed inside the state "
        f"migration callback for {urn!r}. State migration callbacks must only "
        "transform the supplied state."
    )
