NAME = "traceml"
VERSION = "1.4.0"
DESC = (
    "Engine for ML/Data tracking, visualization, dashboards, and model UI for Polyaxon."
)
URL = "https://github.com/polyaxon/traceml"
AUTHOR = "Polyaxon authors"
EMAIL = "contact@polyaxon.com"
LICENSE = "Apache 2.0"
