"""
This module exposes the :class:`OrderedSet` class, which is a collection of
unique items that maintains the order in which the items were added. An
:class:`OrderedSet` (or its alias :class:`oset`) behaves very similarly to
Python's builtin :class:`set` object, the main difference being that an
:class:`OrderedSet` can efficiently lookup its items by index.


Example:
    >>> import ubelt as ub
    >>> ub.oset([1, 2, 3])
    OrderedSet([1, 2, 3])
    >>> (ub.oset([1, 2, 3]) - {2}) | {2}
    OrderedSet([1, 3, 2])
    >>> [ub.oset([1, 2, 3])[i] for i in [1, 0, 2]]
    [2, 1, 3]


As of version (0.8.5), `ubelt` contains its own internal copy of
:class:`OrderedSet` in order to reduce external dependencies.  The original
standalone implementation lives in
https://github.com/LuminosoInsight/ordered-set.

The original documentation is as follows:

An OrderedSet is a custom MutableSet that remembers its order, so that every
entry has an index that can be looked up.

Based on a recipe originally posted to ActiveState Recipes by Raymond Hettiger,
and released under the MIT license.
"""

from __future__ import annotations

import itertools as it
import typing
from collections.abc import Iterable
from collections import deque
from typing import MutableSet, Sequence

if typing.TYPE_CHECKING:
    from collections.abc import Iterator

T = typing.TypeVar('T')


__all__ = ['OrderedSet', 'oset']


SLICE_ALL: slice = slice(None)
__version__ = '3.2'


def is_iterable(obj: object) -> bool:
    """
    Are we being asked to look up a list of things, instead of a single thing?
    We check for the `__iter__` attribute so that this can cover types that
    don't have to be known by this module, such as NumPy arrays.

    Strings, however, should be considered as atomic values to look up, not
    iterables. The same goes for tuples, since they are immutable and therefore
    valid entries.

    We don't need to check for the Python 2 `unicode` type, because it doesn't
    have an `__iter__` attribute anyway.

    Returns:
        bool
    """
    return (
        hasattr(obj, '__iter__')
        and not isinstance(obj, str)
        and not isinstance(obj, tuple)
    )


class OrderedSet(MutableSet[T], Sequence[T]):
    """
    An OrderedSet is a custom MutableSet that remembers its order, so that
    every entry has an index that can be looked up.

    Attributes:
        items (List[T]): internal ordered representation.
        map (Dict[T, int]): internal mapping from items to indices.

    Example:
        >>> OrderedSet([1, 1, 2, 3, 2])
        OrderedSet([1, 2, 3])
    """

    items: list[T]
    map: dict[T, int]

    def __init__(self, iterable: Iterable[T] | None = None) -> None:
        """
        Args:
            iterable (None | Iterable): input data
        """
        self.items = []
        self.map = {}
        if iterable is not None:
            self.update(iterable)
            # self |= iterable

    def __len__(self) -> int:
        """
        Returns the number of unique elements in the ordered set

        Example:
            >>> len(OrderedSet([]))
            0
            >>> len(OrderedSet([1, 2]))
            2

        Returns:
            int
        """
        return len(self.items)

    @typing.overload
    def __getitem__(self, index: int) -> T: ...

    @typing.overload
    def __getitem__(self, index: slice) -> Sequence[T]: ...

    @typing.overload
    def __getitem__(self, index: Sequence[int]) -> OrderedSet[T]: ...

    def __getitem__(
        self, index: int | slice | Sequence[int]
    ) -> Sequence[T] | OrderedSet[T] | T:
        """
        Get the item at a given index.

        If ``index`` is a slice, you will get back that slice of items, as a
        new OrderedSet.

        If ``index`` is a list or a similar iterable, you'll get a list of
        items corresponding to those indices. This is similar to NumPy's
        "fancy indexing". The result is not an OrderedSet because you may ask
        for duplicate indices, and the number of elements returned should be
        the number of elements asked for.

        Args:
            index (int | slice | Sequence[int]):
                a simple or fancy index

        Returns:
            T | OrderedSet | List[T] : item or items

        Example:
            >>> oset = OrderedSet([1, 2, 3])
            >>> oset[1]
            2
        """
        if isinstance(index, slice) and index == SLICE_ALL:
            return self.copy()
        elif is_iterable(index):
            return [self.items[i] for i in index]  # type: ignore
        elif hasattr(index, '__index__') or isinstance(index, slice):
            result = self.items[index]  # type: ignore
            if isinstance(result, list):
                return self.__class__(result)
            else:
                return result
        else:
            raise TypeError(
                "Don't know how to index an OrderedSet by %r" % index
            )

    def copy(self) -> OrderedSet:
        """
        Return a shallow copy of this object.

        Example:
            >>> this = OrderedSet([1, 2, 3])
            >>> other = this.copy()
            >>> this == other
            True
            >>> this is other
            False
        """
        return self.__class__(self)

    def __getstate__(self) -> tuple[None] | list[T]:
        if len(self) == 0:
            # The state can't be an empty list.
            # We need to return a truthy value, or else __setstate__ won't be run.
            #
            # This could have been done more gracefully by always putting the state
            # in a tuple, but this way is backwards- and forwards- compatible with
            # previous versions of OrderedSet.
            return (None,)
        else:
            return list(self)

    def __setstate__(self, state: tuple[None] | list[T]) -> None:
        self.items = []
        self.map = {}
        if isinstance(state, tuple):
            return
        self.update(state)

    def __contains__(self, value: object) -> bool:
        """
        Test if the item is in this ordered set

        Args:
            value (T): check if this item exists in the set

        Example:
            >>> 1 in OrderedSet([1, 3, 2])
            True
            >>> 5 in OrderedSet([1, 3, 2])
            False
        """
        return value in self.map

    def add(self, value: T) -> int:  # type: ignore
        """
        Add ``value`` as an item to this OrderedSet, then return its index.

        If ``value`` is already in the OrderedSet, return the index it already
        had.

        Args:
            value (T): the item to add

        Returns:
            the index of the items. Note, violates the Liskov Substitution
            Principle and might be changed.

        Example:
            >>> oset = OrderedSet()
            >>> oset.append(3)
            0
            >>> print(oset)
            OrderedSet([3])
        """
        if value not in self.map:
            self.map[value] = len(self.items)
            self.items.append(value)
        return self.map[value]

    append = add

    def update(self, sequence: Iterable[T]) -> int | None:
        """
        Update the set with the given iterable sequence, then return the index
        of the last element inserted.

        Args:
            sequence (Iterable): items to add to this set

        Example:
            >>> oset = OrderedSet([1, 2, 3])
            >>> oset.update([3, 1, 5, 1, 4])
            4
            >>> print(oset)
            OrderedSet([1, 2, 3, 5, 4])
        """
        item_index = None
        try:
            for item in sequence:
                item_index = self.add(item)
        except TypeError:
            raise ValueError(
                'Argument needs to be an iterable, got %s' % type(sequence)
            )
        return item_index

    @typing.overload
    def index(
        self, value: T, start: int = 0, stop: int | None = None
    ) -> int: ...

    @typing.overload
    def index(
        self, value: list[T], start: int = 0, stop: int | None = None
    ) -> list[int]: ...

    def index(
        self, value: T | list[T], start: int = 0, stop: int | None = None
    ) -> int | list[int]:
        """
        Get the index of a given entry, raising an IndexError if it's not
        present.

        `value` can be a non-string iterable of entries, in which case this
        returns a list of indices.

        Args:
            value (T | List[T]): item to find the position of

            start (int): not supported yet

            stop (int | None): not supported yet

        Returns:
            The ``index`` in ``self`` such that ``self[index] == value``

        Example:
            >>> oset = OrderedSet([1, 2, 3])
            >>> oset.index(2)
            1
            >>> oset.index([1, 3])
            [0, 2]
        """
        if isinstance(value, list):
            return [self.index(subkey) for subkey in value]
        return self.map[value]

    # Provide some compatibility with pd.Index
    get_loc = index
    get_indexer = index

    def pop(self) -> T:
        """
        Remove and return the last element from the set.

        Raises KeyError if the set is empty.

        Returns:
            The value that was removed

        Example:
            >>> oset = OrderedSet([1, 2, 3])
            >>> oset.pop()
            3
        """
        if not self.items:
            raise KeyError('Set is empty')

        elem = self.items[-1]
        del self.items[-1]
        del self.map[elem]
        return elem

    def __delitem__(self, index: int) -> None:
        """
        Remove an item at a position

        Example:
            >>> oset = OrderedSet([1, 2, 3])
            >>> del oset[1]
            >>> print(oset)
            OrderedSet([1, 3])
        """
        elem = self.items[index]
        del self.items[index]
        del self.map[elem]

    def discard(self, value: T) -> None:
        """
        Remove an element.  Do not raise an exception if absent.

        The MutableSet mixin uses this to implement the .remove() method, which
        *does* raise an error when asked to remove a non-existent item.

        Args:
            value (T): item to remove.

        Example:
            >>> oset = OrderedSet([1, 2, 3])
            >>> oset.discard(2)
            >>> print(oset)
            OrderedSet([1, 3])
            >>> oset.discard(2)
            >>> print(oset)
            OrderedSet([1, 3])
        """
        if value in self:
            i = self.map[value]
            del self.items[i]
            del self.map[value]
            for k, v in self.map.items():
                if v >= i:
                    self.map[k] = v - 1

    def clear(self) -> None:
        """
        Remove all items from this OrderedSet.
        """
        del self.items[:]
        self.map.clear()

    def __iter__(self) -> Iterator:
        """
        Standard iterator over items in this set

        Example:
            >>> list(iter(OrderedSet([1, 2, 3])))
            [1, 2, 3]
        """
        return iter(self.items)

    def __reversed__(self) -> Iterator:
        """
        Returns:
            Iterator

        Example:
            >>> list(reversed(OrderedSet([1, 2, 3])))
            [3, 2, 1]
        """
        return reversed(self.items)

    def __repr__(self) -> str:
        """
        Returns:
            str
        """
        if not self:
            return '%s()' % (self.__class__.__name__,)
        return '%s(%r)' % (self.__class__.__name__, list(self))

    def __eq__(self, other: object) -> bool:
        """
        Returns true if the containers have the same items. If `other` is a
        Sequence, then order is checked, otherwise it is ignored.

        Args:
            other: item to compare against

        Returns:
            If they share the same items, and - if ``other`` is ordered - if
            they have the same order.

        Example:
            >>> oset = OrderedSet([1, 3, 2])
            >>> oset == [1, 3, 2]
            True
            >>> oset == [1, 2, 3]
            False
            >>> oset == [2, 3]
            False
            >>> oset == OrderedSet([3, 2, 1])
            False
        """
        # In Python 2 deque is not a Sequence, so treat it as one for
        # consistent behavior with Python 3.
        if isinstance(other, (Sequence, deque)):
            # Check that this OrderedSet contains the same elements, in the
            # same order, as the other object.
            return list(self) == list(other)
        if not isinstance(other, Iterable):
            # If `other` can't be converted into a set, it's not equal.
            return False
        return set(self) == set(other)

    def union(self, *sets: Iterable[T]) -> OrderedSet[T]:
        """
        Combines all unique items.
        Each items order is defined by its first appearance.

        Args:
            *sets : zero or more other iterables to operate on

        Returns:
            OrderedSet

        Example:
            >>> oset = OrderedSet.union(OrderedSet([3, 1, 4, 1, 5]), [1, 3], [2, 0])
            >>> print(oset)
            OrderedSet([3, 1, 4, 5, 2, 0])
            >>> oset.union([8, 9])
            OrderedSet([3, 1, 4, 5, 2, 0, 8, 9])
            >>> oset | {10}
            OrderedSet([3, 1, 4, 5, 2, 0, 10])
        """
        cls = self.__class__ if isinstance(self, OrderedSet) else OrderedSet
        containers = map(list, it.chain([self], sets))
        items = it.chain.from_iterable(containers)
        return cls(items)

    def __and__(self, other: Iterable[T]) -> OrderedSet[T]:
        # the parent implementation of this is backwards
        return self.intersection(other)

    def intersection(self, *sets: Iterable[T]) -> OrderedSet[T]:
        """
        Returns elements in common between all sets. Order is defined only
        by the first set.

        Args:
            *sets : zero or more other iterables to operate on

        Returns:
            OrderedSet

        Example:
            >>> from ubelt.orderedset import *  # NOQA
            >>> oset = OrderedSet.intersection(OrderedSet([0, 1, 2, 3]), [1, 2, 3])
            >>> print(oset)
            OrderedSet([1, 2, 3])
            >>> oset.intersection([2, 4, 5], [1, 2, 3, 4])
            OrderedSet([2])
            >>> oset.intersection()
            OrderedSet([1, 2, 3])
        """
        cls = self.__class__ if isinstance(self, OrderedSet) else OrderedSet
        if sets:
            common = set.intersection(*map(set, sets))
            items: typing.Iterable[T] = (
                item for item in self if item in common
            )
        else:
            items = typing.cast(typing.Iterable[T], self)
        return cls(items)

    def difference(self, *sets: Iterable[T]) -> OrderedSet[T]:
        """
        Returns all elements that are in this set but not the others.

        Args:
            *sets : zero or more other iterables to operate on

        Returns:
            OrderedSet

        Example:
            >>> OrderedSet([1, 2, 3]).difference(OrderedSet([2]))
            OrderedSet([1, 3])
            >>> OrderedSet([1, 2, 3]).difference(OrderedSet([2]), OrderedSet([3]))
            OrderedSet([1])
            >>> OrderedSet([1, 2, 3]) - OrderedSet([2])
            OrderedSet([1, 3])
            >>> OrderedSet([1, 2, 3]).difference()
            OrderedSet([1, 2, 3])
        """
        cls = self.__class__
        if sets:
            other = set.union(*map(set, sets))
            items: typing.Iterable[T] = (
                item for item in self if item not in other
            )
        else:
            items = typing.cast(typing.Iterable[T], self)
        return cls(items)

    def issubset(self, other: Sequence) -> bool:
        """
        Report whether another set contains this set.

        Args:
            other (Sequence): check if items in other are all contained in self.

        Returns:
            bool

        Example:
            >>> OrderedSet([1, 2, 3]).issubset({1, 2})
            False
            >>> OrderedSet([1, 2, 3]).issubset({1, 2, 3, 4})
            True
            >>> OrderedSet([1, 2, 3]).issubset({1, 4, 3, 5})
            False
        """
        if len(self) > len(other):  # Fast check for obvious cases
            return False
        return all(item in other for item in self)

    # todo: contiguous subset / subsequence_index?

    def issuperset(self, other: Sequence) -> bool:
        """
        Report whether this set contains another set.

        Args:
            other (Sequence): check all items in self are contained in other.

        Returns:
            bool

        Example:
            >>> OrderedSet([1, 2]).issuperset([1, 2, 3])
            False
            >>> OrderedSet([1, 2, 3, 4]).issuperset({1, 2, 3})
            True
            >>> OrderedSet([1, 4, 3, 5]).issuperset({1, 2, 3})
            False
        """
        if len(self) < len(other):  # Fast check for obvious cases
            return False
        return all(item in self for item in other)

    def symmetric_difference(self, other: Iterable) -> OrderedSet:
        """
        Return the symmetric difference of two OrderedSets as a new set.
        That is, the new set will contain all elements that are in exactly
        one of the sets.

        Their order will be preserved, with elements from `self` preceding
        elements from `other`.

        Args:
            other (Iterable): items to operate on

        Returns:
            OrderedSet

        Example:
            >>> this = OrderedSet([1, 4, 3, 5, 7])
            >>> other = OrderedSet([9, 7, 1, 3, 2])
            >>> this.symmetric_difference(other)
            OrderedSet([4, 5, 9, 2])
        """
        cls = self.__class__ if isinstance(self, OrderedSet) else OrderedSet
        diff1 = cls(self).difference(other)
        diff2 = cls(other).difference(self)
        return diff1.union(diff2)

    def _update_items(self, items: list[T]) -> None:
        """
        Replace the 'items' list of this OrderedSet with a new one, updating
        self.map accordingly.
        """
        self.items = items
        self.map = {item: idx for (idx, item) in enumerate(items)}

    def difference_update(self, *sets: Iterable[T]) -> None:
        """
        Update this OrderedSet to remove items from one or more other sets.

        Example:
            >>> this = OrderedSet([1, 2, 3])
            >>> this.difference_update(OrderedSet([2, 4]))
            >>> print(this)
            OrderedSet([1, 3])

            >>> this = OrderedSet([1, 2, 3, 4, 5])
            >>> this.difference_update(OrderedSet([2, 4]), OrderedSet([1, 4, 6]))
            >>> print(this)
            OrderedSet([3, 5])
        """
        items_to_remove = set()
        for other in sets:
            items_to_remove |= set(other)
        self._update_items(
            [item for item in self.items if item not in items_to_remove]
        )

    def intersection_update(self, other: Iterable) -> None:
        """
        Update this OrderedSet to keep only items in another set, preserving
        their order in this set.

        Args:
            other (Iterable): items to operate on

        Example:
            >>> this = OrderedSet([1, 4, 3, 5, 7])
            >>> other = OrderedSet([9, 7, 1, 3, 2])
            >>> this.intersection_update(other)
            >>> print(this)
            OrderedSet([1, 3, 7])
        """
        other = set(other)
        self._update_items([item for item in self.items if item in other])

    def symmetric_difference_update(self, other: Iterable) -> None:
        """
        Update this OrderedSet to remove items from another set, then
        add items from the other set that were not present in this set.

        Args:
            other (Iterable): items to operate on

        Example:
            >>> this = OrderedSet([1, 4, 3, 5, 7])
            >>> other = OrderedSet([9, 7, 1, 3, 2])
            >>> this.symmetric_difference_update(other)
            >>> print(this)
            OrderedSet([4, 5, 9, 2])
        """
        items_to_add = [item for item in other if item not in self]
        items_to_remove = set(other)
        self._update_items(
            [item for item in self.items if item not in items_to_remove]
            + items_to_add
        )


oset = OrderedSet
