# BSD 2-Clause License
#
# Apprise - Push Notification Library.
# Copyright (c) 2026, Chris Caron <lead2gold@gmail.com>
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
# 1. Redistributions of source code must retain the above copyright notice,
#    this list of conditions and the following disclaimer.
#
# 2. Redistributions in binary form must reproduce the above copyright notice,
#    this list of conditions and the following disclaimer in the documentation
#    and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

from json import dumps
import logging
import re
from typing import Optional, Union

import requests

from .. import exception
from ..common import NotifyFormat, NotifyType
from ..exception import AppriseImproperlyConfigured
from ..locale import gettext_lazy as _
from ..url import PrivacyMode
from ..utils.parse import URL_PATH_SAFE_CHARS, parse_list, validate_regex
from ..utils.sanitize import sanitize_payload
from .base import NotifyBase


class AppriseAPIMethod:
    """Defines the method used to post to the remote server."""

    JSON = "json"
    FORM = "form"


APPRISE_API_METHODS = (
    AppriseAPIMethod.FORM,
    AppriseAPIMethod.JSON,
)


class AppriseAPIVersion:
    """Defines how the configuration ID is sent to Apprise API."""

    V1 = "1"
    V2 = "2"


APPRISE_API_VERSIONS = (
    AppriseAPIVersion.V1,
    AppriseAPIVersion.V2,
)


class NotifyAppriseAPI(NotifyBase):
    """A wrapper for Apprise (Persistent) API Notifications."""

    # The default descriptive name associated with the Notification
    service_name = "Apprise API"

    # The services URL
    service_url = "https://github.com/caronc/apprise-api"

    # The default protocol
    protocol = "apprise"

    # The default secure protocol
    secure_protocol = "apprises"

    # A URL that takes you to the setup/help of the specific protocol
    setup_url = "https://appriseit.com/services/apprise_api/"

    # Support attachments
    attachment_support = True

    # Relay content unchanged; the downstream Apprise server converts it.
    notify_format = (
        NotifyFormat.TEXT,
        NotifyFormat.HTML,
        NotifyFormat.MARKDOWN,
    )

    # Depending on the number of transactions/notifications taking place, this
    # could take a while. 30 seconds should be enough to perform the task
    socket_read_timeout = 30.0

    # Disable throttle rate for Apprise API requests since they are normally
    # local anyway
    request_rate_per_sec = 0.0

    # Define object templates
    templates = (
        "{schema}://{host}/{token}",
        "{schema}://{host}:{port}/{token}",
        "{schema}://:{password}@{host}/{token}",
        "{schema}://:{password}@{host}:{port}/{token}",
        "{schema}://{user}@{host}/{token}",
        "{schema}://{user}@{host}:{port}/{token}",
        "{schema}://{user}:{password}@{host}/{token}",
        "{schema}://{user}:{password}@{host}:{port}/{token}",
    )

    # Define our tokens; these are the minimum tokens required required to
    # be passed into this function (as arguments). The syntax appends any
    # previously defined in the base package and builds onto them
    template_tokens = dict(
        NotifyBase.template_tokens,
        **{
            "host": {
                "name": _("Hostname"),
                "type": "string",
                "required": True,
            },
            "port": {
                "name": _("Port"),
                "type": "int",
                "min": 1,
                "max": 65535,
            },
            "user": {
                "name": _("Username"),
                "type": "string",
            },
            "password": {
                "name": _("Password"),
                "type": "string",
                "private": True,
            },
            "token": {
                "name": _("Token"),
                "type": "string",
                "required": True,
                "private": True,
                "regex": (r"^[A-Z0-9_-]{1,128}$", "i"),
            },
        },
    )

    # Define our template arguments
    template_args = dict(
        NotifyBase.template_args,
        **{
            "tags": {
                "name": _("Tags"),
                "type": "string",
            },
            "method": {
                "name": _("Query Method"),
                "type": "choice:string",
                "values": APPRISE_API_METHODS,
                "default": APPRISE_API_METHODS[0],
            },
            "version": {
                "name": _("Apprise API Version"),
                "type": "choice:string",
                "values": APPRISE_API_VERSIONS,
                "default": AppriseAPIVersion.V2,
            },
            "to": {
                "alias_of": "token",
            },
        },
    )

    # Define any kwargs we're using
    template_kwargs = {
        "headers": {
            "name": _("HTTP Header"),
            "prefix": "+",
        },
    }

    def __init__(
        self,
        token=None,
        tags=None,
        method=None,
        version=None,
        headers=None,
        **kwargs,
    ):
        """Initialize Apprise API Object.

        headers can be a dictionary of key/value pairs that you want to
        additionally include as part of the server headers to post with
        """
        super().__init__(**kwargs)

        self.token = validate_regex(
            token, *self.template_tokens["token"]["regex"]
        )
        if not self.token:
            msg = f"The Apprise API token specified ({token}) is invalid."
            self.logger.warning(msg)
            raise AppriseImproperlyConfigured(msg)

        self.method = (
            self.template_args["method"]["default"]
            if not isinstance(method, str)
            else method.lower()
        )

        if self.method not in APPRISE_API_METHODS:
            msg = f"The method specified ({method}) is invalid."
            self.logger.warning(msg)
            raise AppriseImproperlyConfigured(msg)

        # Version 2 keeps the configuration ID out of the HTTP URL. Version 1
        # remains available for older Apprise API servers.
        self.version = (
            self.template_args["version"]["default"]
            if not isinstance(version, str)
            else version
        )
        if self.version not in APPRISE_API_VERSIONS:
            msg = f"The Apprise API version specified ({version}) is invalid."
            self.logger.warning(msg)
            raise AppriseImproperlyConfigured(msg)

        # Build list of tags
        self.__tags = parse_list(tags)

        self.headers = {}
        if headers:
            # Store our extra headers
            self.headers.update(headers)

        return

    def url(self, privacy=False, *args, **kwargs):
        """Returns the URL built dynamically based on specified arguments."""

        # Define any URL parameters
        params = {
            "method": self.method,
            "version": self.version,
        }

        # Extend our parameters
        params.update(self.url_parameters(privacy=privacy, *args, **kwargs))

        # Append our headers into our parameters
        params.update({f"+{k}": v for k, v in self.headers.items()})

        if self.__tags:
            params["tags"] = ",".join(list(self.__tags))

        # Determine Authentication
        auth = ""
        if self.password:
            auth = "{user}:{password}@".format(
                user=NotifyAppriseAPI.quote(self.user or "", safe=""),
                password=self.pprint(
                    self.password, privacy, mode=PrivacyMode.Secret, safe=""
                ),
            )
        elif self.user:
            auth = "{user}@".format(
                user=NotifyAppriseAPI.quote(self.user, safe=""),
            )

        default_port = 443 if self.secure else 80

        fullpath = self.fullpath.strip("/")
        return (
            "{schema}://{auth}{hostname}{port}{fullpath}{token}"
            "/?{params}".format(
                schema=self.secure_protocol if self.secure else self.protocol,
                auth=auth,
                # never encode hostname since we're expecting it to be a
                # valid one
                hostname=self.host,
                port=(
                    ""
                    if self.port is None or self.port == default_port
                    else f":{self.port}"
                ),
                fullpath=(
                    "/{}/".format(
                        NotifyAppriseAPI.quote(
                            fullpath, safe=URL_PATH_SAFE_CHARS
                        )
                    )
                    if fullpath
                    else "/"
                ),
                token=self.pprint(self.token, privacy, safe=""),
                params=NotifyAppriseAPI.urlencode(params),
            )
        )

    def resolve_format(
        self, body_format: Optional[Union[str, NotifyFormat]] = None
    ) -> NotifyFormat:
        """Keep the caller's format so this relay does not convert content.

        The downstream Apprise server performs the required conversion. With
        no source format, normal passthrough rules apply.
        """
        if body_format in self._formats():
            # Target the source format so no conversion takes place
            return NotifyFormat(body_format)

        # No source format; fall back to the normal resolution
        return super().resolve_format(body_format)

    def send(
        self,
        body,
        title="",
        notify_type=NotifyType.INFO,
        attach=None,
        body_format=None,
        body_passthrough=None,
        **kwargs,
    ):
        """Perform Apprise API Notification."""

        # Prepare HTTP Headers
        headers = {
            "User-Agent": self.app_id,
        }

        # Apply any/all header over-rides defined
        headers.update(self.headers)

        attachments = []
        files = []
        if attach and self.attachment_support:
            for no, attachment in enumerate(attach, start=1):
                # Perform some simple error checking
                if not attachment:
                    # We could not access the attachment
                    self.logger.error(
                        "Could not access Apprise API attachment"
                        f" {attachment.url(privacy=True)}."
                    )
                    return False

                try:
                    # Our Attachment filename
                    filename = (
                        attachment.name
                        if attachment.name
                        else f"file{no:03}.dat"
                    )

                    if self.method == AppriseAPIMethod.JSON:
                        # Output must be in a DataURL format (that's what
                        # PushSafer calls it):
                        attachments.append(
                            {
                                "filename": filename,
                                "base64": attachment.base64(),
                                "mimetype": attachment.mimetype,
                            }
                        )

                    else:  # AppriseAPIMethod.FORM
                        files.append(
                            (
                                f"file{no:02d}",
                                (
                                    filename,
                                    # file handle safely closed in
                                    # `finally`; inline open intentional
                                    open(attachment.path, "rb"),  # noqa: SIM115
                                    attachment.mimetype,
                                ),
                            )
                        )

                except (TypeError, OSError, exception.AppriseException):
                    # We could not access the attachment
                    self.logger.error(
                        "Could not access AppriseAPI attachment"
                        f" {attachment.url(privacy=True)}."
                    )
                    return False

                self.logger.debug(
                    "Appending AppriseAPI attachment"
                    f" {attachment.url(privacy=True)}"
                )

        # prepare Apprise API Object
        payload = {
            # Apprise API Payload
            "title": title,
            "body": body,
            "type": notify_type.value,
        }

        if body_passthrough:
            # For passthrough content, relay an explicit URL format only.
            if self._format_override is not None:
                payload["format"] = self._format_override.value

        elif body_format is not None:
            # Label unchanged content with its declared source format.
            payload["format"] = body_format.value

        if self.__tags:
            payload["tag"] = self.__tags

        if self.method == AppriseAPIMethod.JSON:
            headers["Content-Type"] = "application/json"

            if attachments:
                payload["attachments"] = attachments

            payload = dumps(payload)

        auth = None
        if self.user or self.password:
            # An empty username is valid for password-only Apprise API
            # administrator accounts.
            auth = (self.user or "", self.password)

        # Set our schema
        schema = "https" if self.secure else "http"

        url = f"{schema}://{self.host}"
        if isinstance(self.port, int):
            url += f":{self.port}"

        fullpath = self.fullpath.strip("/")
        url += "{}".format("/" + fullpath) if fullpath else ""
        url += "/notify"

        if self.version == AppriseAPIVersion.V1:
            # Version 1 places the configuration ID in the request path.
            url += f"/{self.token}"

        else:
            # Version 2 keeps the ID out of the request URL and access logs.
            headers["X-Apprise-Config-ID"] = self.token

        # Some entries can not be over-ridden
        headers.update(
            {
                # Our response to be in JSON format always
                "Accept": "application/json",
                # Pass our Source UUID4 Identifier
                "X-Apprise-ID": self.asset._uid,
                # Pass our current recursion count to our upstream server
                "X-Apprise-Recursion-Count": str(self.asset._recursion + 1),
            }
        )

        # Some Debug Logging
        if self.logger.isEnabledFor(logging.DEBUG):
            # Due to attachments; output can be quite heavy and io intensive
            # To accommodate this, we only show our debug payload information
            # if required.
            self.logger.debug(
                "Apprise API POST URL:"
                f" {url} (cert_verify={self.verify_certificate!r})"
            )
            self.logger.debug(
                "Apprise API Payload: %s", sanitize_payload(payload)
            )

        # Always call throttle before any remote server i/o is made
        self.throttle()

        try:
            r = requests.post(
                url,
                data=payload,
                headers=headers,
                auth=auth,
                files=files if files else None,
                verify=self.verify_certificate,
                timeout=self.request_timeout,
                allow_redirects=self.redirects,
            )
            if r.status_code != requests.codes.ok:
                # We had a problem
                status_str = NotifyAppriseAPI.http_response_code_lookup(
                    r.status_code
                )

                self.logger.warning(
                    "Failed to send Apprise API notification: "
                    "{}{}error={}.".format(
                        status_str, ", " if status_str else "", r.status_code
                    )
                )

                self.logger.debug(
                    "Response Details:\r\n%r", (r.content or b"")[:2000]
                )

                # Return; we're done
                return False

            else:
                self.logger.info(
                    "Sent Apprise API notification; method=%s.", self.method
                )

        except requests.RequestException as e:
            self.logger.warning(
                "A Connection error occurred sending Apprise API "
                f"notification to {self.host}."
            )
            self.logger.debug(f"Socket Exception: {e!s}")

            # Return; we're done
            return False

        except OSError as e:
            self.logger.warning(
                "An I/O error occurred while reading one of the "
                "attached files."
            )
            self.logger.debug(f"I/O Exception: {e!s}")
            return False

        finally:
            for file in files:
                # Ensure all files are closed
                file[1][1].close()

        return True

    @staticmethod
    def parse_native_url(url):
        """
        Support http://hostname/notify/token and
                http://hostname/path/notify/token
        """

        result = re.match(
            r"^http(?P<secure>s?)://(?P<hostname>[A-Z0-9._-]+)"
            r"(:(?P<port>[0-9]+))?"
            r"(?P<path>/[^?]+?)?/notify/(?P<token>[A-Z0-9_-]{1,32})/?"
            r"(?P<params>\?.+)?$",
            url,
            re.I,
        )

        if result:
            results = NotifyAppriseAPI.parse_url(
                "{schema}://{hostname}{port}{path}/{token}/{params}".format(
                    schema=(
                        NotifyAppriseAPI.secure_protocol
                        if result.group("secure")
                        else NotifyAppriseAPI.protocol
                    ),
                    hostname=result.group("hostname"),
                    port=(
                        ""
                        if not result.group("port")
                        else ":{}".format(result.group("port"))
                    ),
                    path=(
                        ""
                        if not result.group("path")
                        else result.group("path")
                    ),
                    token=result.group("token"),
                    # The "params" group already includes its own leading
                    # "?" (it's captured by the regex), so it's used as-is.
                    params=result.group("params") or "",
                )
            )

            if results and not results.get("version"):
                # A /notify/{token} URL is the Version 1 endpoint shape, so
                # default to it unless the URL already specified a version.
                results["version"] = AppriseAPIVersion.V1

            return results

        return None

    @staticmethod
    def parse_url(url):
        """Parses the URL and returns enough arguments that can allow us to re-
        instantiate this object."""
        results = NotifyBase.parse_url(url)
        if not results:
            # We're done early as we couldn't load the results
            return results

        # Add our headers that the user can potentially over-ride if they wish
        # to to our returned result set and tidy entries by unquoting them
        results["headers"] = {
            NotifyAppriseAPI.unquote(x): NotifyAppriseAPI.unquote(y)
            for x, y in results["qsd+"].items()
        }

        # Support the passing of tags in the URL
        if "tags" in results["qsd"] and len(results["qsd"]["tags"]):
            results["tags"] = NotifyAppriseAPI.parse_list(
                results["qsd"]["tags"]
            )

        # Support the 'to' & 'token' variable so that we can support rooms
        # this way too.
        if "token" in results["qsd"] and len(results["qsd"]["token"]):
            results["token"] = NotifyAppriseAPI.unquote(
                results["qsd"]["token"]
            )

        elif "to" in results["qsd"] and len(results["qsd"]["to"]):
            results["token"] = NotifyAppriseAPI.unquote(results["qsd"]["to"])

        else:
            # Start with a list of path entries to work with
            entries = NotifyAppriseAPI.split_path(results["fullpath"])
            if entries:
                # use our last entry found
                results["token"] = entries[-1]

                # pop our last entry off
                entries = entries[:-1]

                # re-assemble our full path
                results["fullpath"] = "/".join(entries)

        # Set method if specified
        if "method" in results["qsd"] and len(results["qsd"]["method"]):
            results["method"] = NotifyAppriseAPI.unquote(
                results["qsd"]["method"]
            )

        # Support the same long and short version arguments as Matrix.
        if "version" in results["qsd"] and len(results["qsd"]["version"]):
            results["version"] = NotifyAppriseAPI.unquote(
                results["qsd"]["version"]
            )

        elif "v" in results["qsd"] and len(results["qsd"]["v"]):
            results["version"] = NotifyAppriseAPI.unquote(results["qsd"]["v"])

        return results
