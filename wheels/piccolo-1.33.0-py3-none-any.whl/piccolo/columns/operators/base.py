class Operator:
    template = ""
