import datetime  # noqa: F401
from typing import Any, Callable, Dict, Mapping, Optional, Union  # noqa: F401

from typing_extensions import Unpack

from posthog.args import (
    ID_TYPES as ID_TYPES,
    ExceptionArg,
    OptionalCaptureArgs,
    OptionalSetArgs,
)
from posthog.capture_compression import CaptureCompression as CaptureCompression
from posthog.capture_mode import CaptureMode as CaptureMode
from posthog.client import Client
from posthog.tracing.span import Span as Span
from posthog.async_client import AsyncClient as AsyncClient
from posthog.async_client import AsyncPosthog as AsyncPosthog
from posthog.exception_capture import ExceptionCapture
from posthog.contexts import (
    identify_context as inner_identify_context,
)
from posthog.contexts import (
    new_context as inner_new_context,
)
from posthog.contexts import (
    scoped as inner_scoped,
)
from posthog.contexts import (
    set_capture_exception_code_variables_context as inner_set_capture_exception_code_variables_context,
)
from posthog.contexts import (
    set_code_variables_ignore_patterns_context as inner_set_code_variables_ignore_patterns_context,
)
from posthog.contexts import (
    set_code_variables_mask_patterns_context as inner_set_code_variables_mask_patterns_context,
)
from posthog.contexts import (
    set_code_variables_mask_url_credentials_context as inner_set_code_variables_mask_url_credentials_context,
)
from posthog.contexts import (
    set_code_variables_detect_secrets_context as inner_set_code_variables_detect_secrets_context,
)
from posthog.contexts import (
    set_context_device_id as inner_set_context_device_id,
)
from posthog.contexts import (
    set_context_session as inner_set_context_session,
)
from posthog.contexts import (
    tag as inner_tag,
)
from posthog.contexts import (
    get_tags as inner_get_tags,
)
from posthog.exception_utils import (
    DEFAULT_CODE_VARIABLES_DETECT_SECRETS,
    DEFAULT_CODE_VARIABLES_IGNORE_PATTERNS,
    DEFAULT_CODE_VARIABLES_MASK_PATTERNS,
    DEFAULT_CODE_VARIABLES_MASK_URL_CREDENTIALS,
)
from posthog.feature_flag_evaluations import (
    FeatureFlagEvaluations as FeatureFlagEvaluations,
)
from posthog.feature_flags import (
    InconclusiveMatchError as InconclusiveMatchError,
)
from posthog.feature_flags import (
    RequiresServerEvaluation as RequiresServerEvaluation,
)
from posthog.flag_definition_cache import (
    FlagDefinitionCacheData as FlagDefinitionCacheData,
    FlagDefinitionCacheProvider as FlagDefinitionCacheProvider,
)
from posthog.request import (
    disable_connection_reuse as disable_connection_reuse,
    enable_keep_alive as enable_keep_alive,
    set_socket_options as set_socket_options,
    SocketOptions as SocketOptions,
)
from posthog.types import (
    BeforeSendCallback as BeforeSendCallback,
    FeatureFlag as FeatureFlag,
    FeatureFlagEvaluationRuntime as FeatureFlagEvaluationRuntime,
    FlagValue as FlagValue,
    FlagsAndPayloads as FlagsAndPayloads,
)
from posthog.types import (
    FeatureFlagResult as FeatureFlagResult,
)
from posthog.version import VERSION

__version__ = VERSION

"""Context management."""


def new_context(
    fresh: bool = False,
    capture_exceptions: Optional[bool] = None,
    client: Optional[Client] = None,
):
    """
    Create a new context scope that will be active for the duration of the with block.

    Args:
        fresh: Whether to start with a fresh context (default: False)
        capture_exceptions: Whether to capture exceptions raised within the context. If omitted, defaults to the relevant client's exception autocapture setting.
        client: Optional Posthog client instance to use for this context (default: None)

    Examples:
        ```python
        from posthog import new_context, tag, capture
        with new_context():
            tag("request_id", "123")
            capture("event_name", properties={"property": "value"})
        ```

    Category:
        Contexts
    """
    return inner_new_context(
        fresh=fresh, capture_exceptions=capture_exceptions, client=client
    )


def scoped(fresh=False, capture_exceptions: Optional[bool] = None):
    """
    Decorator that creates a new context for the function.

    Args:
        fresh: Whether to start with a fresh context (default: False)
        capture_exceptions: Whether to capture and track exceptions with posthog error tracking. If omitted, defaults to the global exception autocapture setting.

    Examples:
        ```python
        from posthog import scoped, tag, capture
        @scoped()
        def process_payment(payment_id):
            tag("payment_id", payment_id)
            capture("payment_started")
        ```

    Category:
        Contexts
    """
    return inner_scoped(fresh=fresh, capture_exceptions=capture_exceptions)


def set_context_session(session_id: str):
    """
    Set the session ID for the current context.

    Args:
        session_id: The session ID to associate with the current context and its children

    Examples:
        ```python
        from posthog import set_context_session
        set_context_session("session_123")
        ```

    Category:
        Contexts
    """
    return inner_set_context_session(session_id)


def set_context_device_id(device_id: str):
    """
    Set the device ID for the current context, associating all feature flag requests
    in this or child contexts with the given device ID.

    Args:
        device_id: The device ID to associate with the current context and its children

    Examples:
        ```python
        from posthog import set_context_device_id
        set_context_device_id("device_123")
        ```

    Category:
        Contexts
    """
    return inner_set_context_device_id(device_id)


def identify_context(distinct_id: str):
    """
    Identify the current context with a distinct ID.

    Args:
        distinct_id: The distinct ID to associate with the current context and its children

    Examples:
        ```python
        from posthog import identify_context
        identify_context("user_123")
        ```

    Category:
        Identification
    """
    return inner_identify_context(distinct_id)


def set_capture_exception_code_variables_context(enabled: bool):
    """
    Override code-variable capture for exceptions in the current context.

    Args:
        enabled: Whether exceptions captured in this context should include local
            variable values from stack frames.

    Category:
        Contexts
    """
    return inner_set_capture_exception_code_variables_context(enabled)


def set_code_variables_mask_patterns_context(mask_patterns: list[str]):
    """
    Override code-variable mask patterns for exceptions in the current context.

    Args:
        mask_patterns: Variable-name patterns whose values should be replaced
            with ``***`` when code variables are captured.

    Category:
        Contexts
    """
    return inner_set_code_variables_mask_patterns_context(mask_patterns)


def set_code_variables_ignore_patterns_context(ignore_patterns: list[str]):
    """
    Override code-variable ignore patterns for exceptions in the current context.

    Args:
        ignore_patterns: Variable-name patterns that should be omitted entirely
            when code variables are captured.

    Category:
        Contexts
    """
    return inner_set_code_variables_ignore_patterns_context(ignore_patterns)


def set_code_variables_mask_url_credentials_context(enabled: bool):
    """
    Whether to scrub credentials embedded in URLs/DSNs (e.g. user:pass@host) from
    captured code variables for the current context.
    """
    return inner_set_code_variables_mask_url_credentials_context(enabled)


def set_code_variables_detect_secrets_context(enabled: bool):
    """
    Whether to apply entropy-based secret detection as a last-resort redaction of
    high-entropy values (API keys, tokens, strong passwords) in captured code
    variables for the current context.

    Category:
        Contexts
    """
    return inner_set_code_variables_detect_secrets_context(enabled)


def tag(name: str, value: Any):
    """
    Add a tag to the current context.

    Args:
        name: The tag key
        value: The tag value

    Examples:
        ```python
        from posthog import tag
        tag("user_id", "123")
        ```

    Category:
        Contexts
    """
    return inner_tag(name, value)


def get_tags() -> Dict[str, Any]:
    """
    Get all tags from the current context.

    Returns:
        Dict of all tags in the current context

    Category:
        Contexts
    """
    return inner_get_tags()


"""Settings.

These module-level settings configure the legacy global PostHog client used by
functions such as ``posthog.capture()``. Set them before your first SDK call.
For new code, prefer creating an explicit ``Posthog``/``Client`` instance with
the corresponding constructor arguments.

Attributes:
    api_key: Deprecated legacy alias for ``project_api_key``.
    project_api_key: Preferred project API key setting. It takes precedence when
        both it and ``api_key`` are configured; missing or blank values create a
        disabled no-op global client.
    host: PostHog ingestion host. Defaults to the US ingestion endpoint when not
        set.
    on_error: Optional callback invoked by background consumers when event upload
        fails. Keep it short and non-blocking. Lifecycle methods can be called
        directly and will be deferred, but the callback must not wait for another
        thread or task that calls ``flush()``, ``join()``, or ``shutdown()``.
    debug: Enable verbose SDK logging and re-raise errors from public APIs.
    send: If False, queueing succeeds but events are not sent to PostHog.
    sync_mode: If True, send events synchronously instead of using background
        worker threads. This blocks the calling thread; in asyncio applications
        such as FastAPI, use ``AsyncPosthog`` instead.
    disabled: If True, disable captures and API requests. Useful in tests.
    secret_key: A Personal API Key or Project Secret API Key used for local
        feature flag evaluation and remote config payloads.
    personal_api_key: Deprecated alias for secret_key.
    poll_interval: Seconds between local feature flag definition refreshes.
    disable_geoip: Whether to disable server-side GeoIP enrichment. Defaults to
        True.
    is_server: Whether events are emitted from a server-side runtime. Defaults to
        True; set to False when using the SDK as a client/CLI so the device OS is
        attributed to the person normally.
    feature_flags_request_timeout_seconds: Timeout in seconds for feature flag
        and remote config requests.
    feature_flags_request_max_retries: Number of retries for feature flag
        requests after network, transport, or timeout failures. Defaults to 1.
        Set to 0 to disable retries.
    super_properties: Properties merged into every captured event.
    metrics: Config dict for the ``client.metrics`` API (``service_name``,
        ``service_version``, ``environment``, ``flush_interval``, ...). Applied
        when ``setup()`` builds the global client, or on a later ``setup()``
        call if the metrics API hasn't been used yet.
    traces: Config dict for distributed tracing: ``service_name``,
        ``service_version``, ``environment``, ``resource_attributes``,
        ``flush_interval`` (5 s), ``max_queue_size`` (2048),
        ``max_export_batch_size`` (512), ``max_live_spans`` (10000),
        ``max_span_age`` (3600 s), ``max_attributes_per_span`` (128),
        ``max_events_per_span`` (128), ``max_attribute_value_length`` (8192).
        ``before_span_send`` is a callable, or a list run in order,
        that receives each finished span as a dict (``trace_id``, ``span_id``
        and ``parent_span_id`` are read-only) and returns it, edited, or
        ``None`` to drop it; a hook that raises drops the span. Tracing is off
        until set. Spans export on a background timer even with ``sync_mode``;
        serverless handlers should call ``flush()`` before returning. Applied
        when ``setup()`` builds the global client, or on a later ``setup()``
        call if no span has been started yet.
    enable_exception_autocapture: Automatically capture uncaught exceptions.
    log_captured_exceptions: Also log exceptions captured by error tracking.
    project_root: Root path used to determine in-app exception stack frames.
    privacy_mode: Capture AI usage metadata without prompt inputs or outputs.
    before_send: Optional callback that can modify or drop events before upload.
        Return ``None`` to drop an event.
    enable_local_evaluation: Whether to poll feature flag definitions for local
        evaluation when a personal API key is configured.
    flag_definition_cache_provider: Optional external cache provider for sharing
        feature flag definitions across workers.
    capture_exception_code_variables: Capture local variable values on exception
        stack frames.
    capture_trace_context: When OpenTelemetry is installed and a valid span is
        active at capture time, add its trace and span IDs as ``$trace_id`` and
        ``$span_id`` properties to events captured with ``capture()`` and
        ``capture_ai()``. Explicit ``$trace_id``/``$span_id`` values passed in
        ``properties`` win. Exception events always attach these IDs regardless
        of this setting. Defaults to False.
    code_variables_mask_patterns: Variable-name patterns to mask when capturing
        code variables.
    code_variables_ignore_patterns: Variable-name patterns to omit when capturing
        code variables.
    code_variables_detect_secrets: Last-resort entropy-based redaction of
        high-entropy secret-looking values (API keys, tokens, strong passwords)
        in captured code variables. Defaults to True.
    in_app_modules: Module/package prefixes treated as in-app frames in captured
        exceptions.
    enable_exception_autocapture_rate_limiting: Rate limit autocaptured
        exceptions client-side with a token bucket per exception type. Disabled
        by default.
    exception_autocapture_bucket_size: Maximum burst of autocaptured exceptions
        allowed per exception type (token bucket size, clamped to 0-100).
    exception_autocapture_refill_rate: Tokens restored per refill interval for
        each exception type's bucket.
    exception_autocapture_refill_interval_seconds: Seconds between token refills
        for autocaptured exception rate limiting.
"""
# Deprecated legacy alias for project_api_key. Kept for backwards compatibility.
api_key = None  # type: Optional[str]
host = None  # type: Optional[str]
on_error = None  # type: Optional[Callable]
debug = False  # type: bool
send = True  # type: bool
sync_mode = False  # type: bool
disabled = False  # type: bool
secret_key = None  # type: Optional[str]
personal_api_key = None  # type: Optional[str]  # Deprecated: use secret_key
# Preferred project token setting; takes precedence over the legacy api_key alias.
project_api_key = None  # type: Optional[str]
poll_interval = 30  # type: int
disable_geoip = True  # type: bool
is_server = True  # type: bool
feature_flags_request_timeout_seconds = 3  # type: int
feature_flags_request_max_retries = 1  # type: int
super_properties = None  # type: Optional[Dict]
metrics = None  # type: Optional[Dict]
traces = None  # type: Optional[Dict]
enable_exception_autocapture = False  # type: bool
log_captured_exceptions = False  # type: bool
# Used to determine in app paths for exception autocapture. Defaults to the current working directory
project_root = None  # type: Optional[str]
# Used for our AI observability feature to not capture any prompt or output just usage + metadata
privacy_mode = False  # type: bool
before_send = None  # type: Optional[BeforeSendCallback]
# Whether to enable feature flag polling for local evaluation by default. Defaults to True.
# We recommend setting this to False if you are only using the personalApiKey for evaluating remote config payloads via `get_remote_config_payload` and not using local evaluation.
enable_local_evaluation = True  # type: bool
flag_definition_cache_provider = None  # type: Optional[FlagDefinitionCacheProvider]
# Capture wire protocol for the global client. None defers to POSTHOG_CAPTURE_MODE
# then CaptureMode.V0. See posthog.capture_mode.CaptureMode.
capture_mode = None  # type: Optional[CaptureMode]
# Routes AI SDK wrapper events through the dedicated AI capture lane, skips
# truncation, and passes media unredacted. `privacy_mode` always wins.
enable_full_ai_capture = False  # type: bool
# Deprecated aliases for `enable_full_ai_capture`.
_use_ai_lane = False  # type: bool
_enable_multimodal_capture = False  # type: bool

default_client = None  # type: Optional[Client]

capture_trace_context = False
capture_exception_code_variables = False
code_variables_mask_patterns = DEFAULT_CODE_VARIABLES_MASK_PATTERNS
code_variables_ignore_patterns = DEFAULT_CODE_VARIABLES_IGNORE_PATTERNS
code_variables_mask_url_credentials = DEFAULT_CODE_VARIABLES_MASK_URL_CREDENTIALS
code_variables_detect_secrets = DEFAULT_CODE_VARIABLES_DETECT_SECRETS
in_app_modules = None  # type: Optional[list[str]]
enable_exception_autocapture_rate_limiting = False  # type: bool
exception_autocapture_bucket_size = ExceptionCapture.DEFAULT_BUCKET_SIZE  # type: int
exception_autocapture_refill_rate = ExceptionCapture.DEFAULT_REFILL_RATE  # type: int
exception_autocapture_refill_interval_seconds = (
    ExceptionCapture.DEFAULT_REFILL_INTERVAL_SECONDS
)  # type: float


# NOTE - this and following functions take unpacked kwargs because we needed to make
# it impossible to write `posthog.capture(distinct-id, event-name)` - basically, to enforce
# the breaking change made between 5.3.0 and 6.0.0. This decision can be unrolled in later
# versions, without a breaking change, to get back the type information in function signatures
def capture(event: str, **kwargs: Unpack[OptionalCaptureArgs]) -> Optional[str]:
    """
    Capture anything a user does within your system.

    Args:
        event: The event name to specify the event
        **kwargs: Optional arguments including:
            distinct_id: Unique identifier for the user
            properties: Dict of event properties
            timestamp: When the event occurred. UTC is preferred; non-UTC
                datetimes and parseable ISO timestamp strings are converted to UTC.
            uuid: Unique identifier for this event. If omitted, one is generated
                and returned. If provided, it must be a valid UUID string or
                uuid.UUID instance; invalid values are ignored and replaced with
                a newly generated UUID.
            groups: Dict of group types and IDs
            flags: A FeatureFlagEvaluations snapshot from evaluate_flags(). The
                exact values from the snapshot are attached with no extra /flags
                request.
            send_feature_flags: Deprecated. Prefer flags=... from
                evaluate_flags(). When truthy, evaluates flags during capture and
                attaches them to the event.
            disable_geoip: Whether to disable GeoIP lookup

    Details:
        Capture allows you to capture anything a user does within your system, which you can later use in PostHog to find patterns in usage, work out which features to improve or where people are giving up. A capture call requires an event name to specify the event. We recommend using [verb] [noun], like `movie played` or `movie updated` to easily identify what your events mean later on. Capture takes a number of optional arguments, which are defined by the `OptionalCaptureArgs` type.

    Examples:
        ```python
        # Context and capture usage
        from posthog import new_context, identify_context, tag_context, capture
        # Enter a new context (e.g. a request/response cycle, an instance of a background job, etc)
        with new_context():
            # Associate this context with some user, by distinct_id
            identify_context('some user')

            # Capture an event, associated with the context-level distinct ID ('some user')
            capture('movie started')

            # Capture an event associated with some other user (overriding the context-level distinct ID)
            capture('movie joined', distinct_id='some-other-user')

            # Capture an event with some properties
            capture('movie played', properties={'movie_id': '123', 'category': 'romcom'})

            # Capture an event with some properties
            capture('purchase', properties={'product_id': '123', 'category': 'romcom'})
            # Capture an event with some associated group
            capture('purchase', groups={'company': 'id:5'})

            # Adding a tag to the current context will cause it to appear on all subsequent events
            tag_context('some-tag', 'some-value')

            capture('another-event') # Will be captured with `'some-tag': 'some-value'` in the properties dict
        ```
        ```python
        # Set event properties
        from posthog import capture
        capture(
            "user_signed_up",
            distinct_id="distinct_id_of_the_user",
            properties={
                "login_type": "email",
                "is_free_trial": "true"
            }
        )
        ```
    Category:
        Events
    """

    return _proxy("capture", event, **kwargs)


def capture_ai(event: str, **kwargs: Unpack[OptionalCaptureArgs]) -> Optional[str]:
    """
    Capture an AI event on the dedicated AI capture endpoint.

    Beta: the signature is stable; operational limits (per-event size cap,
    batching, endpoint) may change without notice.

    Takes the same arguments and returns the same value as `capture()`: the
    event UUID, or None when the event was not admitted (disabled client, or
    dropped by `before_send`). The event is delivered on an isolated queue
    with its own consumer pool and a higher per-event size cap, posting to
    the dedicated AI ingestion endpoint. The payload is sent as given — no
    redaction or truncation is applied here.

    Args:
        event: The event name, normally one of the `$ai_*` event names.
        **kwargs: Same optional arguments as `capture()`.

    Examples:
        ```python
        from posthog import capture_ai

        uuid = capture_ai(
            "$ai_generation",
            distinct_id="user_123",
            properties={"$ai_model": "gpt-5"},
        )
        ```

    Category:
        Events
    """
    return _proxy("capture_ai", event, **kwargs)


def set(**kwargs: Unpack[OptionalSetArgs]) -> Optional[str]:
    """
    Set properties on a user record.

    Args:
        **kwargs: Optional arguments including:
            distinct_id: Unique identifier for the user. Falls back to the
                context distinct ID; if none exists, this call does nothing.
            properties: Dict of person properties to set.
            timestamp: When the properties were set. UTC is preferred; non-UTC
                datetimes and parseable ISO timestamp strings are converted to UTC.
            uuid: Unique identifier for this operation. If omitted, one is
                generated and returned. If provided, it must be a valid UUID
                string or uuid.UUID instance; invalid values are ignored and
                replaced with a newly generated UUID.
            disable_geoip: Whether to disable GeoIP lookup.

    Details:
        This will overwrite previous people property values. Generally operates similar to `capture`, with distinct_id being an optional argument, defaulting to the current context's distinct ID. If there is no context-level distinct ID, and no override distinct_id is passed, this function will do nothing. Context tags are folded into $set properties, so tagging the current context and then calling `set` will cause those tags to be set on the user (unlike capture, which causes them to just be set on the event).

    Examples:
        ```python
        # Set person properties
        from posthog import set
        set(distinct_id='distinct_id', properties={'name': 'Max Hedgehog'})
        ```
    Category:
        Identification
    """

    return _proxy("set", **kwargs)


def set_once(**kwargs: Unpack[OptionalSetArgs]) -> Optional[str]:
    """
    Set properties on a user record, only if they do not yet exist.

    Args:
        **kwargs: Optional arguments including:
            distinct_id: Unique identifier for the user. Falls back to the
                context distinct ID; if none exists, this call does nothing.
            properties: Dict of person properties to set only once.
            timestamp: When the properties were set. UTC is preferred; non-UTC
                datetimes and parseable ISO timestamp strings are converted to UTC.
            uuid: Unique identifier for this operation. If omitted, one is
                generated and returned. If provided, it must be a valid UUID
                string or uuid.UUID instance; invalid values are ignored and
                replaced with a newly generated UUID.
            disable_geoip: Whether to disable GeoIP lookup.

    Details:
        This will not overwrite previous people property values, unlike `set`. Otherwise, operates in an identical manner to `set`.

    Examples:
        ```python
        # Set property once
        from posthog import set_once
        set_once(distinct_id='distinct_id', properties={'initial_url': '/blog'})

        ```
    Category:
        Identification
    """
    return _proxy("set_once", **kwargs)


def group_identify(
    group_type: str,
    group_key: str,
    properties: Optional[Dict[str, Any]] = None,
    timestamp: Optional[Union[datetime.datetime, str]] = None,
    uuid: Optional[str] = None,
    disable_geoip: Optional[bool] = None,
    distinct_id: Optional[ID_TYPES] = None,
) -> Optional[str]:
    """
    Set properties on a group.

    Args:
        group_type: Type of your group. Required - the call is dropped with a
            warning if it is missing or empty.
        group_key: Unique identifier of the group. Required - the call is
            dropped with a warning if it is missing or empty.
        properties: Properties to set on the group
        timestamp: Optional timestamp for the event. UTC is preferred; non-UTC
            datetimes and parseable ISO timestamp strings are converted to UTC.
        uuid: Optional UUID for the event
        disable_geoip: Whether to disable GeoIP lookup
        distinct_id: Optional distinct ID of the user performing the action

    Examples:
        ```python
        # Group identify
        from posthog import group_identify
        group_identify('company', 'company_id_in_your_db', {
            'name': 'Awesome Inc.',
            'employees': 11
        })
        ```
    Category:
        Identification
    """

    return _proxy(
        "group_identify",
        group_type=group_type,
        group_key=group_key,
        properties=properties,
        timestamp=timestamp,
        uuid=uuid,
        disable_geoip=disable_geoip,
        distinct_id=distinct_id,
    )


def alias(
    previous_id: ID_TYPES,
    distinct_id: str,
    timestamp: Optional[Union[datetime.datetime, str]] = None,
    uuid: Optional[str] = None,
    disable_geoip: Optional[bool] = None,
) -> Optional[str]:
    """
    Associate user behaviour before and after they e.g. register, login, or perform some other identifying action.

    Args:
        previous_id: The unique ID of the user before
        distinct_id: The current unique id
        timestamp: Optional timestamp for the event. UTC is preferred; non-UTC
            datetimes and parseable ISO timestamp strings are converted to UTC.
        uuid: Optional UUID for the event
        disable_geoip: Whether to disable GeoIP lookup

    Details:
        To marry up whatever a user does before they sign up or log in with what they do after you need to make an alias call. This will allow you to answer questions like "Which marketing channels leads to users churning after a month?" or "What do users do on our website before signing up?". Particularly useful for associating user behaviour before and after they e.g. register, login, or perform some other identifying action.

    Examples:
        ```python
        # Alias user
        from posthog import alias
        alias(previous_id='distinct_id', distinct_id='alias_id')
        ```
    Category:
        Identification
    """

    return _proxy(
        "alias",
        previous_id=previous_id,
        distinct_id=distinct_id,
        timestamp=timestamp,
        uuid=uuid,
        disable_geoip=disable_geoip,
    )


def capture_exception(
    exception: Optional[ExceptionArg] = None,
    **kwargs: Unpack[OptionalCaptureArgs],
) -> Optional[str]:
    """
    Capture exceptions that happen in your code.

    Args:
        exception: The exception to capture. If not provided, the current exception is captured via `sys.exc_info()`
        **kwargs: Optional capture arguments including distinct_id, properties,
            timestamp, uuid, groups, flags, send_feature_flags, and disable_geoip.

    Details:
        Capture exception is idempotent - if it is called twice with the same exception instance, only a occurrence will be tracked in posthog. This is because, generally, contexts will cause exceptions to be captured automatically. However, to ensure you track an exception, if you catch and do not re-raise it, capturing it manually is recommended, unless you are certain it will have crossed a context boundary (e.g. by existing a `with posthog.new_context():` block already). If the passed exception was raised and caught, the captured stack trace will consist of every frame between where the exception was raised and the point at which it is captured (the "traceback"). If the passed exception was never raised, e.g. if you call `posthog.capture_exception(ValueError("Some Error"))`, the stack trace captured will be the full stack trace at the moment the exception was captured. Note that heavy use of contexts will lead to truncated stack traces, as the exception will be captured by the context entered most recently, which may not be the point you catch the exception for the final time in your code. It's recommended to use contexts sparingly, for this reason. `capture_exception` takes the same set of optional arguments as `capture`.

    Examples:
        ```python
        # Capture exception
        from posthog import capture_exception
        try:
            risky_operation()
        except Exception as e:
            capture_exception(e)
        ```
    Category:
        Events
    """

    return _proxy("capture_exception", exception=exception, **kwargs)


def feature_enabled(
    key: str,
    distinct_id: ID_TYPES,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    send_feature_flag_events: bool = True,
    disable_geoip: Optional[bool] = None,
    device_id: Optional[str] = None,
) -> Optional[bool]:
    """
    Use feature flags to enable or disable features for users.

    Args:
        key: The feature flag key
        distinct_id: The user's distinct ID
        groups: Groups mapping
        person_properties: Person properties
        group_properties: Group properties
        only_evaluate_locally: Whether to evaluate only locally
        send_feature_flag_events: Whether to send feature flag events
        disable_geoip: Whether to disable GeoIP lookup
        device_id: Optional device ID override for experience-continuity flags

    Details:
        You can call `posthog.load_feature_flags()` before to make sure you're not doing unexpected requests.

    Examples:
        ```python
        # Boolean feature flag
        from posthog import feature_enabled, get_feature_flag_payload
        is_my_flag_enabled = feature_enabled('flag-key', 'distinct_id_of_your_user')
        if is_my_flag_enabled:
            matched_flag_payload = get_feature_flag_payload('flag-key', 'distinct_id_of_your_user')
        ```
    Category:
        Feature flags
    """
    return _proxy(
        "feature_enabled",
        key=key,
        distinct_id=distinct_id,
        groups=groups or {},
        person_properties=person_properties or {},
        group_properties=group_properties or {},
        only_evaluate_locally=only_evaluate_locally,
        send_feature_flag_events=send_feature_flag_events,
        disable_geoip=disable_geoip,
        device_id=device_id,
    )


def get_feature_flag(
    key: str,
    distinct_id: ID_TYPES,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    send_feature_flag_events: bool = True,
    disable_geoip: Optional[bool] = None,
    device_id: Optional[str] = None,
) -> Optional[FlagValue]:
    """
    Get feature flag variant for users. Used with experiments.

    Args:
        key: The feature flag key
        distinct_id: The user's distinct ID
        groups: Groups mapping from group type to group key
        person_properties: Person properties
        group_properties: Group properties in format { group_type_name: { group_properties } }
        only_evaluate_locally: Whether to evaluate only locally
        send_feature_flag_events: Whether to send feature flag events
        disable_geoip: Whether to disable GeoIP lookup
        device_id: Optional device ID override for experience-continuity flags

    Details:
        `groups` are a mapping from group type to group key. So, if you have a group type of "organization" and a group key of "5", you would pass groups={"organization": "5"}. `group_properties` take the format: { group_type_name: { group_properties } }. So, for example, if you have the group type "organization" and the group key "5", with the properties name, and employee count, you'll send these as: group_properties={"organization": {"name": "PostHog", "employees": 11}}.

    Examples:
        ```python
        # Multivariate feature flag
        from posthog import get_feature_flag, get_feature_flag_payload
        enabled_variant = get_feature_flag('flag-key', 'distinct_id_of_your_user')
        if enabled_variant == 'variant-key':
            matched_flag_payload = get_feature_flag_payload('flag-key', 'distinct_id_of_your_user')
        ```
    Category:
        Feature flags
    """
    return _proxy(
        "get_feature_flag",
        key=key,
        distinct_id=distinct_id,
        groups=groups or {},
        person_properties=person_properties or {},
        group_properties=group_properties or {},
        only_evaluate_locally=only_evaluate_locally,
        send_feature_flag_events=send_feature_flag_events,
        disable_geoip=disable_geoip,
        device_id=device_id,
    )


def get_all_flags(
    distinct_id: ID_TYPES,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    disable_geoip: Optional[bool] = None,
    device_id: Optional[str] = None,
    flag_keys_to_evaluate: Optional[list[str]] = None,
) -> Optional[dict[str, FlagValue]]:
    """
    Get all flags for a given user.

    Args:
        distinct_id: The user's distinct ID
        groups: Groups mapping
        person_properties: Person properties
        group_properties: Group properties
        only_evaluate_locally: Whether to evaluate only locally
        disable_geoip: Whether to disable GeoIP lookup
        device_id: Optional device ID override for experience-continuity flags
        flag_keys_to_evaluate: Optional list of flag keys to evaluate (evaluates all if None)

    Details:
        Flags are key-value pairs where the key is the flag key and the value is the flag variant, or True, or False.

    Examples:
        ```python
        # All flags for user
        from posthog import get_all_flags
        get_all_flags('distinct_id_of_your_user')
        ```
    Category:
        Feature flags
    """
    return _proxy(
        "get_all_flags",
        distinct_id=distinct_id,
        groups=groups or {},
        person_properties=person_properties or {},
        group_properties=group_properties or {},
        only_evaluate_locally=only_evaluate_locally,
        disable_geoip=disable_geoip,
        device_id=device_id,
        flag_keys_to_evaluate=flag_keys_to_evaluate,
    )


def get_feature_flag_result(
    key: str,
    distinct_id: ID_TYPES,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    send_feature_flag_events: bool = True,
    disable_geoip: Optional[bool] = None,
    device_id: Optional[str] = None,
) -> Optional[FeatureFlagResult]:
    """
    Get a FeatureFlagResult object which contains the flag result and payload.

    This method evaluates a feature flag and returns a FeatureFlagResult object containing:
    - enabled: Whether the flag is enabled
    - variant: The variant value if the flag has variants
    - payload: The payload associated with the flag (automatically deserialized from JSON)
    - key: The flag key
    - reason: Why the flag was enabled/disabled

    Args:
        key: The feature flag key.
        distinct_id: The user's distinct ID.
        groups: Mapping of group type to group key.
        person_properties: Person properties to use for evaluation.
        group_properties: Group properties keyed by group type.
        only_evaluate_locally: Whether to evaluate only locally.
        send_feature_flag_events: Whether to send a $feature_flag_called event.
        disable_geoip: Whether to disable GeoIP lookup.
        device_id: Optional device ID override for experience-continuity flags.

    Example:
    ```python
    result = posthog.get_feature_flag_result('beta-feature', 'distinct_id')
    if result and result.enabled:
        # Use the variant and payload
        print(f"Variant: {result.variant}")
        print(f"Payload: {result.payload}")
    ```
    """
    return _proxy(
        "get_feature_flag_result",
        key=key,
        distinct_id=distinct_id,
        groups=groups or {},
        person_properties=person_properties or {},
        group_properties=group_properties or {},
        only_evaluate_locally=only_evaluate_locally,
        send_feature_flag_events=send_feature_flag_events,
        disable_geoip=disable_geoip,
        device_id=device_id,
    )


def get_feature_flag_payload(
    key: str,
    distinct_id: ID_TYPES,
    match_value: Optional[FlagValue] = None,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    send_feature_flag_events: bool = True,
    disable_geoip: Optional[bool] = None,
    device_id: Optional[str] = None,
) -> Optional[object]:
    """
    Get the payload associated with a feature flag value.

    Deprecated for new code. Prefer ``evaluate_flags()`` and
    ``flags.get_flag_payload(key)`` so flag evaluation happens once per request.

    Args:
        key: The feature flag key.
        distinct_id: The user's distinct ID.
        match_value: Optional flag value to use when selecting a payload.
        groups: Mapping of group type to group key.
        person_properties: Person properties to use for evaluation.
        group_properties: Group properties keyed by group type.
        only_evaluate_locally: Whether to evaluate only locally.
        send_feature_flag_events: Whether to send a $feature_flag_called event.
        disable_geoip: Whether to disable GeoIP lookup.
        device_id: Optional device ID override for experience-continuity flags.

    Returns:
        The payload associated with the matched feature flag value, or None.
        This function returns the payload only, not the FeatureFlagResult wrapper
        used internally to compute it.

    Category:
        Feature flags
    """
    return _proxy(
        "get_feature_flag_payload",
        key=key,
        distinct_id=distinct_id,
        match_value=match_value,
        groups=groups or {},
        person_properties=person_properties or {},
        group_properties=group_properties or {},
        only_evaluate_locally=only_evaluate_locally,
        send_feature_flag_events=send_feature_flag_events,
        disable_geoip=disable_geoip,
        device_id=device_id,
    )


def get_remote_config_payload(
    key: str,
):
    """Get the payload for a remote config feature flag.

    Args:
        key: The key of the feature flag

    Returns:
        The payload associated with the feature flag. If payload is encrypted, the return value will be decrypted

    Note:
        Requires secret_key to be set for authentication
    """
    return _proxy(
        "get_remote_config_payload",
        key=key,
    )


def get_all_flags_and_payloads(
    distinct_id: ID_TYPES,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    disable_geoip: Optional[bool] = None,
    device_id: Optional[str] = None,
    flag_keys_to_evaluate: Optional[list[str]] = None,
) -> FlagsAndPayloads:
    """
    Get all feature flag values and payloads for a user.

    Args:
        distinct_id: The user's distinct ID.
        groups: Mapping of group type to group key.
        person_properties: Person properties to use for evaluation.
        group_properties: Group properties keyed by group type.
        only_evaluate_locally: Whether to evaluate only locally.
        disable_geoip: Whether to disable GeoIP lookup.
        device_id: Optional device ID override for experience-continuity flags.
        flag_keys_to_evaluate: Optional list of flag keys to evaluate. Evaluates
            all flags when omitted.

    Returns:
        A dict with ``featureFlags`` and ``featureFlagPayloads`` entries.

    Category:
        Feature flags
    """
    return _proxy(
        "get_all_flags_and_payloads",
        distinct_id=distinct_id,
        groups=groups or {},
        person_properties=person_properties or {},
        group_properties=group_properties or {},
        only_evaluate_locally=only_evaluate_locally,
        disable_geoip=disable_geoip,
        device_id=device_id,
        flag_keys_to_evaluate=flag_keys_to_evaluate,
    )


def evaluate_flags(
    distinct_id: Optional[ID_TYPES] = None,
    groups: Optional[Mapping[str, Union[str, int]]] = None,
    person_properties: Optional[Dict[str, Any]] = None,
    group_properties: Optional[Dict[str, Dict[str, Any]]] = None,
    only_evaluate_locally: bool = False,
    disable_geoip: Optional[bool] = None,
    flag_keys: Optional[list[str]] = None,
    device_id: Optional[str] = None,
) -> FeatureFlagEvaluations:
    """Evaluate all feature flags for a user in a single call and return a
    :class:`FeatureFlagEvaluations` snapshot. Branch on ``.is_enabled()`` /
    ``.get_flag()`` and pass the same snapshot to ``capture()`` via the
    ``flags`` option so events carry the exact flag values the code branched on.

    Prefer this over repeated ``get_feature_flag()`` calls and over
    ``capture(send_feature_flags=True)`` — it consolidates flag evaluation into
    a single ``/flags`` request per incoming request.

    Args:
        distinct_id: The user's distinct ID. If ``None``, falls back to the context
            distinct_id. If still unresolvable, returns an empty snapshot.
        groups: Mapping of group type to group key.
        person_properties: Person properties to use for evaluation.
        group_properties: Group properties keyed by group type.
        only_evaluate_locally: If ``True``, never fall back to remote evaluation and
            omit flags that cannot be evaluated locally.
        disable_geoip: Whether to disable GeoIP lookup.
        flag_keys: Optional list that scopes local evaluation, the underlying ``/flags``
            request, and the returned snapshot. When omitted or ``None``, all flags are evaluated.
            An empty list returns an empty snapshot without evaluating flags. A requested key
            absent from loaded local definitions is included in one remote fallback per
            ``evaluate_flags`` call unless ``only_evaluate_locally`` is ``True``. If the server
            also does not know the key, it is omitted from the snapshot.
        device_id: Optional device ID override. If not provided, falls back to the
            context device_id (which may be set via tracing headers). Used by
            experience-continuity flags to match users across distinct_id changes.

    Examples:
        ```python
        from posthog import evaluate_flags, capture
        flags = evaluate_flags("user_123", person_properties={"plan": "enterprise"})
        if flags.is_enabled("new-dashboard"):
            render_new_dashboard()
        capture("page_viewed", distinct_id="user_123", flags=flags)
        ```

    Category:
        Feature flags
    """
    return _proxy(
        "evaluate_flags",
        distinct_id=distinct_id,
        groups=groups,
        person_properties=person_properties,
        group_properties=group_properties,
        only_evaluate_locally=only_evaluate_locally,
        disable_geoip=disable_geoip,
        flag_keys=flag_keys,
        device_id=device_id,
    )


def feature_flag_definitions():
    """
    Returns loaded feature flags.

    Details:
        Returns loaded feature flags, if any. Helpful for debugging what flag information you have loaded.

    Examples:
        ```python
        from posthog import feature_flag_definitions
        definitions = feature_flag_definitions()
        ```

    Category:
        Feature flags
    """
    return _proxy("feature_flag_definitions")


def get_feature_flag_evaluation_runtime(
    key: str,
) -> Optional[FeatureFlagEvaluationRuntime]:
    """
    Return where a locally loaded feature flag is meant to be evaluated.

    Details:
        Reads the `evaluation_runtime` each flag definition carries, so no extra
        request is made. Returns `None` when local evaluation has not loaded a
        definition for this key. A definition that carries no runtime reports
        `FeatureFlagEvaluationRuntime.ALL`, the default PostHog applies.

    Examples:
        ```python
        from posthog import FeatureFlagEvaluationRuntime, get_feature_flag_evaluation_runtime
        runtime = get_feature_flag_evaluation_runtime("my-flag")
        ```

    Category:
        Feature flags
    """
    return _proxy("get_feature_flag_evaluation_runtime", key)


def get_feature_flag_keys_by_evaluation_runtime(
    evaluation_runtime: Union[FeatureFlagEvaluationRuntime, str],
) -> list[str]:
    """
    Return the keys of locally loaded flags that a runtime can evaluate.

    Details:
        A flag set to `FeatureFlagEvaluationRuntime.ALL` suits either runtime, so
        it is returned for `CLIENT` and for `SERVER`. Use this to decide which
        flags to hand to a browser when a backend serves flags to its own
        frontend.

    Examples:
        ```python
        from posthog import FeatureFlagEvaluationRuntime, get_feature_flag_keys_by_evaluation_runtime
        client_keys = get_feature_flag_keys_by_evaluation_runtime(FeatureFlagEvaluationRuntime.CLIENT)
        ```

    Category:
        Feature flags
    """
    return _proxy("get_feature_flag_keys_by_evaluation_runtime", evaluation_runtime)


def load_feature_flags():
    """
    Load feature flag definitions from PostHog.

    Examples:
        ```python
        from posthog import load_feature_flags
        load_feature_flags()
        ```

    Category:
        Feature flags
    """
    return _proxy("load_feature_flags")


def flush(timeout_seconds: Optional[float] = 10) -> None:
    """
    Tell the client to flush all queued events.

    Args:
        timeout_seconds: Maximum seconds to wait for the queue to flush.
            Defaults to 10 seconds. Pass ``None`` to wait indefinitely.

    Examples:
        ```python
        from posthog import flush
        flush()
        ```

    Category:
        Client management
    """
    _proxy("flush", timeout_seconds=timeout_seconds)


def join() -> None:
    """
    Attempt to process queued events and stop the client's background workers. Use `shutdown()` directly in most cases.

    Failed or undrainable events may be dropped and reported through logging or
    ``on_error``; returning does not guarantee server receipt. Lifecycle cleanup
    is attempted once, and cleanup failures are logged without retry.

    Examples:
        ```python
        from posthog import join
        join()
        ```

    Category:
        Client management
    """
    _proxy("join")


def start_span(
    name: str,
    *,
    kind: Optional[str] = None,
    attributes: Optional[Mapping[str, Any]] = None,
    parent: Union[Span, str, None] = None,
    tracestate: Optional[str] = None,
    start_time: Union[datetime.datetime, float, None] = None,
) -> Span:
    """
    Start a span for distributed tracing. Alpha.

    Returns a span handle. Use it as a context manager to make it the active
    span for the block and end it on exit (recording a raised exception on the
    way out); or call ``end()`` yourself for a span that cannot wrap a block.
    Spans started inside the block nest under it automatically. Always returns
    a usable handle, even when tracing is off, so calling code never branches.

    Args:
        name: A low-cardinality operation name, e.g. ``GET /users/:id``.
            Variable values belong in attributes, not the name.
        kind: ``internal`` (default), ``server``, ``client``, ``producer`` or
            ``consumer``.
        attributes: Initial attributes.
        parent: A span handle, or an inbound W3C ``traceparent`` header value
            to continue a remote trace. Defaults to the active span.
        tracestate: The inbound ``tracestate`` header accompanying a
            ``traceparent`` string ``parent``; preserved and propagated.
        start_time: A ``datetime`` or epoch seconds, to backdate the span.

    Examples:
        ```python
        import posthog
        posthog.traces = {"service_name": "checkout-api"}

        with posthog.start_span("POST /checkout", parent=request.headers.get("traceparent")) as span:
            span.set_attribute("plan", user.plan)
            with posthog.start_span("db.query", kind="client"):
                ...
            outgoing_headers = {"traceparent": span.traceparent()}
        ```

    Category:
        Tracing
    """
    return _proxy(
        "start_span",
        name,
        kind=kind,
        attributes=attributes,
        parent=parent,
        tracestate=tracestate,
        start_time=start_time,
    )


def get_active_span() -> Optional[Span]:
    """
    The span that is active in the current context, or ``None``. Alpha.

    Only entering a span (``with posthog.start_span(...) as span:``) makes it
    active; a span started manually is not. Use it to propagate the trace to
    the next service: ``span.traceparent()`` is the header value.

    Examples:
        ```python
        span = posthog.get_active_span()
        if span is not None:
            headers["traceparent"] = span.traceparent()
        ```

    Category:
        Tracing
    """
    return _proxy("get_active_span")


def shutdown() -> None:
    """
    Flush all messages and cleanly shutdown the client.

    This normally blocks until queued events have been attempted and cleanup
    finishes. Failed or undrainable events may be dropped and reported through
    logging or ``on_error``; returning does not guarantee server receipt.
    Lifecycle cleanup is attempted once, and cleanup failures are logged without
    retry. Calls made directly from SDK callbacks such as ``on_error`` are deferred
    to avoid deadlocking the worker. If blocking completion is required, signal an application-owned
    thread, return from the callback, and call ``shutdown()`` from that thread.
    Do not wait inside a callback for another thread or task calling a lifecycle
    method.

    Examples:
        ```python
        from posthog import shutdown
        shutdown()
        ```

    Category:
        Client management
    """
    _proxy("shutdown")


def setup() -> Client:
    """
    Create or return the global PostHog client configured by module settings.

    Most applications should either instantiate ``Posthog`` directly or set
    ``posthog.api_key``/other module settings before calling top-level helpers.
    ``setup()`` is called automatically by global APIs such as ``capture()``.

    Returns:
        The global ``Client`` instance. If both ``api_key`` and
        ``project_api_key`` are missing or blank, the client is disabled and
        module-level calls become no-ops.

    Category:
        Initialization
    """
    global default_client
    if not default_client:
        configured_api_key = (project_api_key or "").strip() or (api_key or "").strip()
        default_client = Client(
            configured_api_key,
            host=host,
            debug=debug,
            on_error=on_error,
            send=send,
            sync_mode=sync_mode,
            secret_key=secret_key,
            personal_api_key=personal_api_key,
            poll_interval=poll_interval,
            disabled=disabled,
            disable_geoip=disable_geoip,
            is_server=is_server,
            feature_flags_request_timeout_seconds=feature_flags_request_timeout_seconds,
            feature_flags_request_max_retries=feature_flags_request_max_retries,
            super_properties=super_properties,
            metrics=metrics,
            traces=traces,
            # TODO: Currently this monitoring begins only when the Client is initialised (which happens when you do something with the SDK)
            # This kind of initialisation is very annoying for exception capture. We need to figure out a way around this,
            # or deprecate this proxy option fully (it's already in the process of deprecation, no new clients should be using this method since like 5-6 months)
            enable_exception_autocapture=enable_exception_autocapture,
            log_captured_exceptions=log_captured_exceptions,
            project_root=project_root,
            privacy_mode=privacy_mode,
            before_send=before_send,
            enable_local_evaluation=enable_local_evaluation,
            flag_definition_cache_provider=flag_definition_cache_provider,
            capture_exception_code_variables=capture_exception_code_variables,
            capture_trace_context=capture_trace_context,
            code_variables_mask_patterns=code_variables_mask_patterns,
            code_variables_ignore_patterns=code_variables_ignore_patterns,
            code_variables_mask_url_credentials=code_variables_mask_url_credentials,
            code_variables_detect_secrets=code_variables_detect_secrets,
            in_app_modules=in_app_modules,
            enable_exception_autocapture_rate_limiting=enable_exception_autocapture_rate_limiting,
            exception_autocapture_bucket_size=exception_autocapture_bucket_size,
            exception_autocapture_refill_rate=exception_autocapture_refill_rate,
            exception_autocapture_refill_interval_seconds=exception_autocapture_refill_interval_seconds,
            capture_mode=capture_mode,
        )

    # Always set in case user changes it. Preserve Client's auto-disabled state
    # for API keys that become empty after trimming.
    default_client.disabled = disabled or not default_client.api_key
    default_client.debug = debug
    default_client.privacy_mode = bool(privacy_mode)
    default_client._set_before_send(before_send)
    default_client.enable_full_ai_capture = (
        bool(enable_full_ai_capture)
        or bool(_use_ai_lane)
        or bool(_enable_multimodal_capture)
    )
    # Metrics config is consumed lazily on first `.metrics` access, so late
    # module-attr assignment (e.g. a Django ready() hook running after something
    # already forced setup()) still applies until the metrics API is first used.
    if default_client._metrics is None:
        default_client._metrics_config = metrics
    # traces=None means off, so the module option applies only where the client
    # has none; False is the latch of an init that failed and stays off.
    if traces is not None and default_client._traces_config is None:
        default_client._traces_config = traces

    return default_client


def _proxy(method, *args, **kwargs):
    """Create an analytics client if one doesn't exist and send to it."""
    setup()

    fn = getattr(default_client, method)
    return fn(*args, **kwargs)


class Posthog(Client):
    """
    Public PostHog SDK client.

    ``Posthog`` is the customer-facing alias for ``Client`` and accepts the same
    constructor arguments. Use it to create an explicit SDK instance instead of
    relying on module-level global configuration.
    """

    pass
