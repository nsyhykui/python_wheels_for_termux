import contextlib
import logging
import asyncio
import subprocess
import sys
import textwrap
import threading
import time
import unittest
import warnings
from concurrent.futures import Executor, ProcessPoolExecutor, ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from unittest import mock
from uuid import UUID, uuid4

from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags, use_span
from parameterized import parameterized
import pytest

from posthog.capture_compression import CaptureCompression
from posthog.client import Client
from posthog.contexts import get_context_session_id, new_context, set_context_session
from posthog.request import APIError, GetResponse
from posthog.test.logging_helpers import capture_message_only_logs
from posthog.test.test_utils import FAKE_TEST_API_KEY
from posthog.types import FeatureFlag, FeatureFlagResult, LegacyFlagMetadata
from posthog.version import VERSION
from posthog.contexts import tag


# Legacy single-flag behavior remains covered here; warning emission itself is
# asserted in test_evaluate_flags.py.
def _wait_until(predicate, timeout=3):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(0.01)
    return predicate()


pytestmark = [
    pytest.mark.filterwarnings(
        r"ignore:`(feature_enabled|get_feature_flag|get_feature_flag_payload)` is deprecated:DeprecationWarning"
    ),
    pytest.mark.filterwarnings(
        r"ignore:`send_feature_flags` is deprecated:DeprecationWarning"
    ),
]


class TestClient(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # This ensures no real HTTP POST requests are made
        cls.client_post_patcher = mock.patch("posthog.client.batch_post")
        cls.consumer_post_patcher = mock.patch("posthog.consumer.batch_post")
        cls.client_post_patcher.start()
        cls.consumer_post_patcher.start()

    @classmethod
    def tearDownClass(cls):
        cls.client_post_patcher.stop()
        cls.consumer_post_patcher.stop()

    def set_fail(self, e, batch):
        """Mark the failure handler"""
        print("FAIL", e, batch)  # noqa: T201
        self.failed = True

    def setUp(self):
        self.failed = False
        self.client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail)

    def test_requires_api_key(self):
        self.assertRaises(TypeError, Client)

    @parameterized.expand(
        [
            ("valid_key", " \nphc_validkey\t ", "phc_validkey", False, False),
            ("whitespace_only", " \n\t ", "", True, True),
            ("empty_string", "", "", True, True),
        ]
    )
    def test_trims_api_key_whitespace(
        self, _, raw_api_key, expected_api_key, expected_disabled, expect_error_log
    ):
        with mock.patch.object(Client.log, "error") as mock_error:
            client = Client(raw_api_key, send=False)

        self.assertEqual(client.api_key, expected_api_key)
        self.assertEqual(client.disabled, expected_disabled)
        if expect_error_log:
            mock_error.assert_called_once_with(
                "api_key is empty after trimming whitespace; check your project API key"
            )
        else:
            mock_error.assert_not_called()

    def test_trims_host_and_personal_api_key_whitespace(self):
        with self.assertWarnsRegex(DeprecationWarning, "personal_api_key"):
            client = Client(
                FAKE_TEST_API_KEY,
                host=" \nhttps://eu.posthog.com/\t ",
                personal_api_key=" \n\t ",
                send=False,
            )

        self.assertEqual(client.raw_host, "https://eu.posthog.com/")
        self.assertEqual(client.host, "https://eu.i.posthog.com")
        self.assertIsNone(client.personal_api_key)

    @parameterized.expand(
        [
            ("secret_key_only", "phx_secret", None, "phx_secret", False),
            ("personal_api_key_alias", None, "phx_legacy", "phx_legacy", True),
            ("secret_key_wins", "phx_secret", "phx_legacy", "phx_secret", False),
        ]
    )
    def test_secret_key_resolution(
        self, _, secret_key, personal_api_key, expected, expect_deprecation
    ):
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            client = Client(
                FAKE_TEST_API_KEY,
                secret_key=secret_key,
                personal_api_key=personal_api_key,
                send=False,
            )

        self.assertEqual(client.secret_key, expected)
        self.assertEqual(client.personal_api_key, expected)
        deprecations = [w for w in caught if issubclass(w.category, DeprecationWarning)]
        self.assertEqual(bool(deprecations), expect_deprecation)

    def test_client_with_empty_api_key_is_noop(self):
        client = Client("", send=False)

        self.assertIsNone(client.capture("event", distinct_id="distinct_id"))

    def _reset_duplicate_client_registry(self):
        Client._client_registry.clear()
        Client._duplicate_client_warnings.clear()

    def test_warns_once_on_duplicate_async_client_same_key_and_host(self):
        self._reset_duplicate_client_registry()
        self.addCleanup(self._reset_duplicate_client_registry)
        host = "https://us.i.posthog.com"
        registry_key = (FAKE_TEST_API_KEY, host)

        with (
            mock.patch("posthog.client.atexit.register"),
            mock.patch("posthog.client.Consumer.start"),
            mock.patch.object(Client.log, "warning") as mock_warning,
        ):
            first = Client(FAKE_TEST_API_KEY, host=host)
            second = Client(FAKE_TEST_API_KEY, host=host)
            third = Client(FAKE_TEST_API_KEY, host=host)

            self.assertIsNot(first, second)
            self.assertIsNot(second, third)
            mock_warning.assert_called_once_with(
                "Multiple active PostHog clients detected for the same project "
                "API key and host. Reuse one Posthog instance per app or "
                "process when possible to avoid competing background queues "
                "and missed shutdown flushes. Multiple clients are supported "
                "when intentional."
            )

            first.shutdown()
            second.shutdown()
            third.shutdown()

            self.assertNotIn(registry_key, Client._client_registry)
            self.assertNotIn(registry_key, Client._duplicate_client_warnings)

            fourth = Client(FAKE_TEST_API_KEY, host=host)
            fifth = Client(FAKE_TEST_API_KEY, host=host)

            self.assertEqual(mock_warning.call_count, 2)

            fourth.shutdown()
            fifth.shutdown()

    @parameterized.expand(
        [
            ("different_host", {"host": "https://two.example.com"}),
            ("sync_mode", {"host": "https://one.example.com", "sync_mode": True}),
            ("send_disabled", {"host": "https://one.example.com", "send": False}),
        ]
    )
    def test_duplicate_client_warning_allows_intentional_multi_client_cases(
        self, _, duplicate_kwargs
    ):
        self._reset_duplicate_client_registry()
        self.addCleanup(self._reset_duplicate_client_registry)

        with (
            mock.patch("posthog.client.atexit.register"),
            mock.patch("posthog.client.Consumer.start"),
            mock.patch.object(Client.log, "warning") as mock_warning,
        ):
            first = Client(FAKE_TEST_API_KEY, host="https://one.example.com")
            duplicate = Client(FAKE_TEST_API_KEY, **duplicate_kwargs)

            self.assertIsNot(first, duplicate)
            mock_warning.assert_not_called()

            first.shutdown()
            duplicate.shutdown()

    def test_message_only_info_logs_include_posthog_prefix(self):
        self.client.flag_cache = mock.Mock()
        self.client.flag_cache.get_stale_cached_flag.return_value = FeatureFlagResult(
            key="flag-key", enabled=True, variant=None, payload=None, reason=None
        )

        with capture_message_only_logs(level=logging.INFO) as logs:
            self.client._get_stale_flag_fallback("distinct_id", "flag-key")

        self.assertEqual(
            logs.getvalue().strip(),
            "[PostHog] [FEATURE FLAGS] Using stale cached value for flag flag-key",
        )

    def test_message_only_logs_do_not_duplicate_existing_posthog_prefix(self):
        with capture_message_only_logs(level=logging.ERROR) as logs:
            self.client.log.error("[PostHog] already prefixed")

        self.assertEqual(logs.getvalue().strip(), "[PostHog] already prefixed")

    @mock.patch("posthog.client.get")
    def test_disabled_client_does_not_load_feature_flags(self, patch_get):
        client = Client("", secret_key="test", send=False)

        client.load_feature_flags()

        patch_get.assert_not_called()
        self.assertEqual(client.feature_flags, [])
        self.assertIsNone(client.poller)

    @mock.patch("posthog.client.flags")
    def test_disabled_client_does_not_get_flags_decision(self, patch_flags):
        client = Client("", send=False)

        self.assertEqual(client.get_flags_decision("distinct_id")["flags"], {})
        self.assertEqual(client.get_feature_variants("distinct_id"), {})
        self.assertEqual(client.get_feature_payloads("distinct_id"), {})
        self.assertEqual(
            client.get_feature_flags_and_payloads("distinct_id"),
            {"featureFlags": {}, "featureFlagPayloads": {}},
        )
        self.assertIsNone(
            client.capture("event", distinct_id="distinct_id", send_feature_flags=True)
        )
        patch_flags.assert_not_called()

    @mock.patch("posthog.client.flags")
    def test_client_flag_helpers_return_defaults_on_api_error(self, patch_flags):
        patch_flags.side_effect = APIError(401, "Unauthorized")
        client = Client(FAKE_TEST_API_KEY, send=False)

        test_cases = [
            (
                "get_flags_decision",
                lambda: client.get_flags_decision("distinct_id")["flags"],
                {},
            ),
            (
                "get_feature_variants",
                lambda: client.get_feature_variants("distinct_id"),
                {},
            ),
            (
                "get_feature_payloads",
                lambda: client.get_feature_payloads("distinct_id"),
                {},
            ),
            (
                "get_feature_flags_and_payloads",
                lambda: client.get_feature_flags_and_payloads("distinct_id"),
                {"featureFlags": {}, "featureFlagPayloads": {}},
            ),
        ]

        for method_name, call_helper, expected in test_cases:
            with self.subTest(method=method_name):
                self.assertEqual(call_helper(), expected)

    def test_empty_flush(self):
        self.client.flush()

    def test_empty_flush_does_not_drain_a_later_event(self):
        with mock.patch("posthog.consumer.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, flush_at=100, flush_interval=0.5)

            client.flush()
            client.capture("after empty flush", distinct_id="distinct_id")
            time.sleep(0.05)

            mock_post.assert_not_called()
            client.flush()
            mock_post.assert_called_once()

    def test_flush_timeout_returns_when_queue_does_not_drain(self):
        client = Client(FAKE_TEST_API_KEY, send=False, thread=0)
        client.queue.put({"event": "stuck"})

        start = time.monotonic()
        with self.assertLogs("posthog", level="WARNING") as logs:
            client.flush(timeout_seconds=0.01)

        self.assertLess(time.monotonic() - start, 1)
        self.assertFalse(client.queue.empty())
        self.assertIn("flush ran out of budget", logs.output[0])

        client.queue.get_nowait()
        client.queue.task_done()

    def test_flush_does_not_wait_for_flush_interval(self):
        # flush() must attempt delivery now rather than letting the consumer sit
        # on a below-flush_at batch until flush_interval elapses.
        with mock.patch("posthog.consumer.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, flush_interval=30)
            client.capture("event", distinct_id="distinct_id")

            start = time.monotonic()
            client.flush()

            self.assertLess(time.monotonic() - start, 5)
            self.assertTrue(client.queue.empty())
            mock_post.assert_called_once()

    def test_flush_delivers_when_flush_interval_exceeds_the_flush_timeout(self):
        # Waiting out flush_interval meant a flush_interval longer than the
        # flush timeout delivered nothing at all.
        with mock.patch("posthog.consumer.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, flush_interval=30)
            client.capture("event", distinct_id="distinct_id")

            client.flush(timeout_seconds=5)

            mock_post.assert_called_once()
            self.assertEqual(client.queue.unfinished_tasks, 0)

    def test_flush_keeps_batches_whole(self):
        # Draining early must not turn a full queue into one request per event.
        with mock.patch("posthog.consumer.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, flush_at=10, flush_interval=30)
            for _ in range(30):
                client.capture("event", distinct_id="distinct_id")

            client.flush()

            self.assertTrue(client.queue.empty())
            batch_sizes = [
                len(call.kwargs["batch"]) for call in mock_post.call_args_list
            ]
            self.assertEqual(sum(batch_sizes), 30)
            self.assertLessEqual(len(batch_sizes), 5)

    def test_flush_logs_and_returns_on_unexpected_error(self):
        client = Client(FAKE_TEST_API_KEY, send=False, thread=0)
        client.queue.put({"event": "stuck"})

        with mock.patch.object(
            client.queue.all_tasks_done,
            "wait",
            side_effect=RuntimeError("boom"),
        ):
            with self.assertLogs("posthog", level="ERROR") as logs:
                client.flush(timeout_seconds=1)

        self.assertIn("error flushing queue", logs.output[0])

        client.queue.get_nowait()
        client.queue.task_done()

    def test_basic_capture(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.capture("python test event", distinct_id="distinct_id")
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(msg["properties"]["$is_server"], True)
            # these will change between platforms so just asssert on presence here
            assert msg["properties"]["$python_runtime"] == mock.ANY
            assert msg["properties"]["$python_version"] == mock.ANY
            assert msg["properties"]["$os"] == mock.ANY
            assert msg["properties"]["$os_version"] == mock.ANY

    def test_capture_omits_is_server_when_disabled(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                sync_mode=True,
                is_server=False,
            )
            client.capture("python test event", distinct_id="distinct_id")
            self.assertFalse(self.failed)

            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertNotIn("$is_server", msg["properties"])

    def test_is_server_not_overridden_by_super_properties(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                sync_mode=True,
                super_properties={"$is_server": False},
            )
            client.capture("python test event", distinct_id="distinct_id")
            self.assertFalse(self.failed)

            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["properties"]["$is_server"], True)

    def test_basic_capture_with_uuid(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            uuid = str(uuid4())
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", uuid=uuid
            )
            self.assertEqual(msg_uuid, uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertEqual(msg["uuid"], uuid)
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)

    def test_basic_capture_with_uuid_object(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            uuid = UUID("00000000-0000-4000-8000-000000000002")
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", uuid=uuid
            )
            self.assertEqual(msg_uuid, str(uuid))
            self.assertFalse(self.failed)

            mock_post.assert_called_once()
            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["uuid"], str(uuid))

    @parameterized.expand(
        [
            ("empty string", ""),
            ("invalid string", "not-a-uuid"),
            ("short string", "1234"),
            ("integer", 123),
        ]
    )
    def test_capture_with_invalid_uuid_logs_and_falls_back_to_generated_uuid(
        self, _name, invalid_uuid
    ):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with self.assertLogs("posthog", level="ERROR") as logs:
                msg_uuid = client.capture(
                    "python test event", distinct_id="distinct_id", uuid=invalid_uuid
                )

            self.assertIsNotNone(msg_uuid)
            UUID(msg_uuid)
            mock_post.assert_called_once()
            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["uuid"], msg_uuid)
            self.assertNotEqual(msg["uuid"], str(invalid_uuid))
            self.assertTrue(
                any(
                    f"Invalid event uuid {invalid_uuid!r}" in message
                    and "Expected a valid UUID string or uuid.UUID instance" in message
                    and "Falling back to a generated UUID" in message
                    for message in logs.output
                )
            )

    @parameterized.expand(
        [
            ("empty string", ""),
            ("invalid string", "not-a-uuid"),
            ("short string", "1234"),
            ("integer", 123),
        ]
    )
    def test_capture_with_invalid_uuid_falls_back_in_debug(self, _name, invalid_uuid):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, debug=True, sync_mode=True)
            with self.assertLogs("posthog", level="ERROR"):
                msg_uuid = client.capture(
                    "python test event", distinct_id="distinct_id", uuid=invalid_uuid
                )

            self.assertIsNotNone(msg_uuid)
            UUID(msg_uuid)
            mock_post.assert_called_once()

    def test_basic_capture_with_project_api_key(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                project_api_key=FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                sync_mode=True,
            )

            msg_uuid = client.capture("python test event", distinct_id="distinct_id")
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)

    def test_basic_super_properties(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                super_properties={"source": "repo-name"},
                sync_mode=True,
            )

            msg_uuid = client.capture("python test event", distinct_id="distinct_id")
            self.assertIsNotNone(msg_uuid)

            # Check the enqueued message
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertEqual(msg["properties"]["source"], "repo-name")

    def test_basic_capture_exception(self):
        with mock.patch.object(Client, "capture", return_value=None) as patch_capture:
            client = self.client
            exception = Exception("test exception")
            client.capture_exception(exception, distinct_id="distinct_id")

            self.assertTrue(patch_capture.called)
            capture_call = patch_capture.call_args
            self.assertEqual(capture_call[0][0], "$exception")
            self.assertEqual(capture_call[1]["distinct_id"], "distinct_id")

    @parameterized.expand(
        [
            (
                "active_context",
                0x123,
                0x456,
                {},
                "00000000000000000000000000000123",
                "0000000000000456",
            ),
            (
                "explicit_properties",
                0x123,
                0x456,
                {"$trace_id": "custom-trace", "$span_id": "custom-span"},
                "custom-trace",
                "custom-span",
            ),
            ("invalid_context", 0, 0, {}, None, None),
        ]
    )
    def test_capture_exception_uses_current_otel_span_context(
        self,
        _,
        context_trace_id,
        context_span_id,
        properties,
        expected_trace_id,
        expected_span_id,
    ):
        span_context = SpanContext(
            trace_id=context_trace_id,
            span_id=context_span_id,
            is_remote=False,
            trace_flags=TraceFlags.SAMPLED,
        )

        with (
            mock.patch("posthog.client.batch_post") as mock_post,
            use_span(NonRecordingSpan(span_context)),
        ):
            client = Client(FAKE_TEST_API_KEY, sync_mode=True)
            client.capture_exception(Exception("test exception"), properties=properties)

        event = mock_post.call_args.kwargs["batch"][0]
        if expected_trace_id is None:
            self.assertNotIn("$trace_id", event["properties"])
            self.assertNotIn("$span_id", event["properties"])
        else:
            self.assertEqual(event["properties"]["$trace_id"], expected_trace_id)
            self.assertEqual(event["properties"]["$span_id"], expected_span_id)

    @parameterized.expand(
        [
            (
                "capture_active_context",
                "capture",
                0x123,
                0x456,
                {},
                "00000000000000000000000000000123",
                "0000000000000456",
            ),
            (
                "capture_explicit_properties_win",
                "capture",
                0x123,
                0x456,
                {"$trace_id": "custom-trace", "$span_id": "custom-span"},
                "custom-trace",
                "custom-span",
            ),
            ("capture_invalid_context", "capture", 0, 0, {}, None, None),
            (
                "capture_ai_active_context",
                "capture_ai",
                0x123,
                0x456,
                {},
                "00000000000000000000000000000123",
                "0000000000000456",
            ),
            (
                "capture_ai_explicit_properties_win",
                "capture_ai",
                0x123,
                0x456,
                {"$trace_id": "custom-trace", "$span_id": "custom-span"},
                "custom-trace",
                "custom-span",
            ),
            ("capture_ai_invalid_context", "capture_ai", 0, 0, {}, None, None),
        ]
    )
    def test_capture_uses_current_otel_span_context_when_enabled(
        self,
        _,
        entrypoint,
        context_trace_id,
        context_span_id,
        properties,
        expected_trace_id,
        expected_span_id,
    ):
        span_context = SpanContext(
            trace_id=context_trace_id,
            span_id=context_span_id,
            is_remote=False,
            trace_flags=TraceFlags.SAMPLED,
        )

        with (
            mock.patch("posthog.client.batch_post") as mock_post,
            use_span(NonRecordingSpan(span_context)),
        ):
            client = Client(
                FAKE_TEST_API_KEY, sync_mode=True, capture_trace_context=True
            )
            capture = getattr(client, entrypoint)
            capture("$ai_event", distinct_id="distinct_id", properties=properties)

        event = mock_post.call_args.kwargs["batch"][0]
        if expected_trace_id is None:
            self.assertNotIn("$trace_id", event["properties"])
            self.assertNotIn("$span_id", event["properties"])
        else:
            self.assertEqual(event["properties"]["$trace_id"], expected_trace_id)
            self.assertEqual(event["properties"]["$span_id"], expected_span_id)

    @parameterized.expand([("capture",), ("capture_ai",)])
    def test_capture_does_not_attach_otel_span_context_by_default(self, entrypoint):
        span_context = SpanContext(
            trace_id=0x123,
            span_id=0x456,
            is_remote=False,
            trace_flags=TraceFlags.SAMPLED,
        )

        with (
            mock.patch("posthog.client.batch_post") as mock_post,
            use_span(NonRecordingSpan(span_context)),
        ):
            client = Client(FAKE_TEST_API_KEY, sync_mode=True)
            capture = getattr(client, entrypoint)
            capture("$ai_event", distinct_id="distinct_id")

        event = mock_post.call_args.kwargs["batch"][0]
        self.assertNotIn("$trace_id", event["properties"])
        self.assertNotIn("$span_id", event["properties"])

    def test_basic_capture_exception_with_distinct_id(self):
        with mock.patch.object(Client, "capture", return_value=None) as patch_capture:
            client = self.client
            exception = Exception("test exception")
            client.capture_exception(exception, distinct_id="distinct_id")

            self.assertTrue(patch_capture.called)
            capture_call = patch_capture.call_args
            self.assertEqual(capture_call[0][0], "$exception")
            self.assertEqual(capture_call[1]["distinct_id"], "distinct_id")

    def test_basic_capture_exception_with_correct_host_generation(self):
        with mock.patch.object(Client, "capture", return_value=None) as patch_capture:
            client = Client(
                FAKE_TEST_API_KEY, on_error=self.set_fail, host="https://aloha.com"
            )
            exception = Exception("test exception")
            client.capture_exception(exception, distinct_id="distinct_id")

            self.assertTrue(patch_capture.called)
            call = patch_capture.call_args
            self.assertEqual(call[0][0], "$exception")
            self.assertEqual(call[1]["distinct_id"], "distinct_id")

    def test_basic_capture_exception_with_correct_host_generation_for_server_hosts(
        self,
    ):
        with mock.patch.object(Client, "capture", return_value=None) as patch_capture:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                host="https://app.posthog.com",
            )
            exception = Exception("test exception")
            client.capture_exception(exception, distinct_id="distinct_id")

            self.assertTrue(patch_capture.called)
            capture_call = patch_capture.call_args
            self.assertEqual(capture_call[0][0], "$exception")
            self.assertEqual(capture_call[1]["distinct_id"], "distinct_id")

    def test_basic_capture_exception_with_no_exception_given(self):
        with mock.patch.object(Client, "capture", return_value=None) as patch_capture:
            client = self.client
            try:
                raise Exception("test exception")
            except Exception:
                client.capture_exception(None, distinct_id="distinct_id")

            self.assertTrue(patch_capture.called)
            capture_call = patch_capture.call_args
            print(capture_call)
            self.assertEqual(capture_call[1]["distinct_id"], "distinct_id")
            self.assertEqual(capture_call[0][0], "$exception")
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["mechanism"][
                    "type"
                ],
                "generic",
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["mechanism"][
                    "handled"
                ],
                True,
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["module"], None
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["type"], "Exception"
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["value"],
                "test exception",
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["stacktrace"][
                    "type"
                ],
                "raw",
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["stacktrace"][
                    "frames"
                ][0]["filename"],
                "posthog/test/test_client.py",
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["stacktrace"][
                    "frames"
                ][0]["function"],
                "test_basic_capture_exception_with_no_exception_given",
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["stacktrace"][
                    "frames"
                ][0]["module"],
                "posthog.test.test_client",
            )
            self.assertEqual(
                capture_call[1]["properties"]["$exception_list"][0]["stacktrace"][
                    "frames"
                ][0]["in_app"],
                True,
            )

    def test_basic_capture_exception_with_no_exception_happening(self):
        with mock.patch.object(Client, "capture", return_value=None) as patch_capture:
            with self.assertLogs("posthog", level="WARNING") as logs:
                client = self.client
                client.capture_exception(None)

                self.assertFalse(patch_capture.called)
                self.assertEqual(
                    logs.output[0],
                    "WARNING:posthog:[PostHog] No exception information available",
                )

    def test_capture_exception_logs_when_enabled(self):
        client = Client(FAKE_TEST_API_KEY, log_captured_exceptions=True)
        with self.assertLogs("posthog", level="ERROR") as logs:
            client.capture_exception(
                Exception("test exception"), distinct_id="distinct_id"
            )
            self.assertEqual(
                logs.output[0], "ERROR:posthog:[PostHog] test exception\nNoneType: None"
            )

    @mock.patch("posthog.client.flags")
    def test_basic_capture_with_feature_flags(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "random-variant"}}

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", send_feature_flags=True
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(
                msg["properties"]["$feature/beta-feature"], "random-variant"
            )
            self.assertEqual(
                msg["properties"]["$active_feature_flags"], ["beta-feature"]
            )

            self.assertEqual(patch_flags.call_count, 1)

    @mock.patch("posthog.client.flags")
    def test_basic_capture_with_locally_evaluated_feature_flags(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "random-variant"}}

        multivariate_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature-local",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "properties": [
                            {
                                "key": "email",
                                "type": "person",
                                "value": "test@posthog.com",
                                "operator": "exact",
                            }
                        ],
                        "rollout_percentage": 100,
                    },
                    {
                        "rollout_percentage": 50,
                    },
                ],
                "multivariate": {
                    "variants": [
                        {
                            "key": "first-variant",
                            "name": "First Variant",
                            "rollout_percentage": 50,
                        },
                        {
                            "key": "second-variant",
                            "name": "Second Variant",
                            "rollout_percentage": 25,
                        },
                        {
                            "key": "third-variant",
                            "name": "Third Variant",
                            "rollout_percentage": 25,
                        },
                    ]
                },
                "payloads": {
                    "first-variant": "some-payload",
                    "third-variant": {"a": "json"},
                },
            },
        }
        basic_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "person-flag",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [
                            {
                                "key": "region",
                                "operator": "exact",
                                "value": ["USA"],
                                "type": "person",
                            }
                        ],
                        "rollout_percentage": 100,
                    }
                ],
                "payloads": {"true": 300},
            },
        }
        false_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "false-flag",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [],
                        "rollout_percentage": 0,
                    }
                ],
                "payloads": {"true": 300},
            },
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            client.feature_flags = [multivariate_flag, basic_flag, false_flag]

            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", send_feature_flags=True
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(
                msg["properties"]["$feature/beta-feature-local"], "third-variant"
            )
            self.assertEqual(msg["properties"]["$feature/false-flag"], False)
            self.assertEqual(
                msg["properties"]["$active_feature_flags"], ["beta-feature-local"]
            )
            assert "$feature/beta-feature" not in msg["properties"]

            self.assertEqual(patch_flags.call_count, 0)

        # test that flags are not evaluated without local evaluation
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            client.feature_flags = []
            msg_uuid = client.capture("python test event", distinct_id="distinct_id")
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            assert "$feature/beta-feature" not in msg["properties"]
            assert "$feature/beta-feature-local" not in msg["properties"]
            assert "$feature/false-flag" not in msg["properties"]
            assert "$active_feature_flags" not in msg["properties"]

    @mock.patch("posthog.client.get")
    def test_load_feature_flags_quota_limited(self, patch_get):
        mock_response = {
            "type": "quota_limited",
            "detail": "You have exceeded your feature flag request quota",
            "code": "payment_required",
        }
        patch_get.side_effect = APIError(402, mock_response["detail"])

        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        with self.assertLogs("posthog", level="WARNING") as logs:
            client._load_feature_flags()

            self.assertEqual(client.feature_flags, [])
            self.assertEqual(client.feature_flags_by_key, {})
            self.assertEqual(client.group_type_mapping, {})
            self.assertEqual(client.cohorts, {})
            self.assertIn("PostHog feature flags quota limited", logs.output[0])

    @mock.patch("posthog.client.get")
    def test_load_feature_flags_unauthorized(self, patch_get):
        patch_get.side_effect = APIError(401, "Unauthorized")

        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        with self.assertLogs("posthog", level="ERROR") as logs:
            client._load_feature_flags()

            self.assertEqual(client.feature_flags, [])
            self.assertEqual(client.feature_flags_by_key, {})
            self.assertEqual(client.group_type_mapping, {})
            self.assertEqual(client.cohorts, {})
            self.assertIn("Unauthorized", logs.output[0])
            self.assertIn("project_api_key", logs.output[0])
            self.assertIn("secret_key", logs.output[0])

    @mock.patch("posthog.client.flags")
    def test_dont_override_capture_with_local_flags(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "random-variant"}}

        multivariate_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature-local",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "properties": [
                            {
                                "key": "email",
                                "type": "person",
                                "value": "test@posthog.com",
                                "operator": "exact",
                            }
                        ],
                        "rollout_percentage": 100,
                    },
                    {
                        "rollout_percentage": 50,
                    },
                ],
                "multivariate": {
                    "variants": [
                        {
                            "key": "first-variant",
                            "name": "First Variant",
                            "rollout_percentage": 50,
                        },
                        {
                            "key": "second-variant",
                            "name": "Second Variant",
                            "rollout_percentage": 25,
                        },
                        {
                            "key": "third-variant",
                            "name": "Third Variant",
                            "rollout_percentage": 25,
                        },
                    ]
                },
                "payloads": {
                    "first-variant": "some-payload",
                    "third-variant": {"a": "json"},
                },
            },
        }
        basic_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "person-flag",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [
                            {
                                "key": "region",
                                "operator": "exact",
                                "value": ["USA"],
                                "type": "person",
                            }
                        ],
                        "rollout_percentage": 100,
                    }
                ],
                "payloads": {"true": 300},
            },
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            client.feature_flags = [multivariate_flag, basic_flag]

            msg_uuid = client.capture(
                "python test event",
                distinct_id="distinct_id",
                properties={"$feature/beta-feature-local": "my-custom-variant"},
                send_feature_flags=True,
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(
                msg["properties"]["$feature/beta-feature-local"], "my-custom-variant"
            )
            self.assertEqual(
                msg["properties"]["$active_feature_flags"], ["beta-feature-local"]
            )
            assert "$feature/beta-feature" not in msg["properties"]
            assert "$feature/person-flag" not in msg["properties"]

            self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_basic_capture_with_feature_flags_returns_active_only(self, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
                "alpha-feature": True,
                "off-feature": False,
            }
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", send_feature_flags=True
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertTrue(msg["properties"]["$geoip_disable"])
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(
                msg["properties"]["$feature/beta-feature"], "random-variant"
            )
            self.assertEqual(msg["properties"]["$feature/alpha-feature"], True)
            self.assertEqual(
                msg["properties"]["$active_feature_flags"],
                ["beta-feature", "alpha-feature"],
            )

            self.assertEqual(patch_flags.call_count, 1)
            patch_flags.assert_called_with(
                "random_key",
                "https://us.i.posthog.com",
                timeout=3,
                max_retries=1,
                distinct_id="distinct_id",
                groups={},
                person_properties={},
                group_properties={},
                geoip_disable=True,
                device_id=None,
            )

    @parameterized.expand(
        [
            ("default", 1),
            ("disabled", 0),
            ("two_retries", 2),
        ]
    )
    def test_feature_flags_request_max_retries_is_forwarded(
        self, _name, expected_max_retries
    ):
        with mock.patch("posthog.client.flags") as patch_flags:
            patch_flags.return_value = {"featureFlags": {}, "featureFlagPayloads": {}}
            client = Client(
                FAKE_TEST_API_KEY,
                feature_flags_request_max_retries=expected_max_retries,
                secret_key=FAKE_TEST_API_KEY,
            )

            client.get_all_flags("distinct_id")

        self.assertEqual(
            patch_flags.call_args.kwargs["max_retries"], expected_max_retries
        )

    @mock.patch("posthog.client.flags")
    def test_basic_capture_with_feature_flags_and_disable_geoip_returns_correctly(
        self, patch_flags
    ):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
                "alpha-feature": True,
                "off-feature": False,
            }
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                host="https://app.posthog.com",
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                disable_geoip=True,
                feature_flags_request_timeout_seconds=12,
                sync_mode=True,
            )
            msg_uuid = client.capture(
                "python test event",
                distinct_id="distinct_id",
                send_feature_flags=True,
                disable_geoip=False,
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertTrue("$geoip_disable" not in msg["properties"])
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(
                msg["properties"]["$feature/beta-feature"], "random-variant"
            )
            self.assertEqual(msg["properties"]["$feature/alpha-feature"], True)
            self.assertEqual(
                msg["properties"]["$active_feature_flags"],
                ["beta-feature", "alpha-feature"],
            )

            self.assertEqual(patch_flags.call_count, 1)
            patch_flags.assert_called_with(
                "random_key",
                "https://us.i.posthog.com",
                timeout=12,
                max_retries=1,
                distinct_id="distinct_id",
                groups={},
                person_properties={},
                group_properties={},
                geoip_disable=False,
                device_id=None,
            )

    @mock.patch("posthog.client.flags")
    def test_basic_capture_with_feature_flags_switched_off_doesnt_send_them(
        self, patch_flags
    ):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "random-variant"}}

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", send_feature_flags=False
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertTrue("$feature/beta-feature" not in msg["properties"])
            self.assertTrue("$active_feature_flags" not in msg["properties"])

            self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_capture_with_send_feature_flags_false_and_local_evaluation_doesnt_send_flags(
        self, patch_flags
    ):
        """Test that send_feature_flags=False with local evaluation enabled does NOT send flags"""
        patch_flags.return_value = {"featureFlags": {"beta-feature": "remote-variant"}}

        multivariate_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature-local",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "rollout_percentage": 100,
                    },
                ],
                "multivariate": {
                    "variants": [
                        {
                            "key": "first-variant",
                            "name": "First Variant",
                            "rollout_percentage": 50,
                        },
                        {
                            "key": "second-variant",
                            "name": "Second Variant",
                            "rollout_percentage": 50,
                        },
                    ]
                },
            },
        }
        simple_flag = {
            "id": 2,
            "name": "Simple Flag",
            "key": "simple-flag",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "rollout_percentage": 100,
                    }
                ],
            },
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            client.feature_flags = [multivariate_flag, simple_flag]

            msg_uuid = client.capture(
                "python test event",
                distinct_id="distinct_id",
                send_feature_flags=False,
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertEqual(msg["distinct_id"], "distinct_id")

            # CRITICAL: Verify local flags are NOT included in the event
            self.assertNotIn("$feature/beta-feature-local", msg["properties"])
            self.assertNotIn("$feature/simple-flag", msg["properties"])
            self.assertNotIn("$active_feature_flags", msg["properties"])

            # CRITICAL: Verify the /flags API was NOT called
            self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_capture_with_send_feature_flags_true_and_local_evaluation_uses_local_flags(
        self, patch_flags
    ):
        """Test that send_feature_flags=True with local evaluation enabled uses local flags without API call"""
        patch_flags.return_value = {"featureFlags": {"remote-flag": "remote-variant"}}

        multivariate_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature-local",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "rollout_percentage": 100,
                    },
                ],
                "multivariate": {
                    "variants": [
                        {
                            "key": "first-variant",
                            "name": "First Variant",
                            "rollout_percentage": 50,
                        },
                        {
                            "key": "second-variant",
                            "name": "Second Variant",
                            "rollout_percentage": 50,
                        },
                    ]
                },
            },
        }
        simple_flag = {
            "id": 2,
            "name": "Simple Flag",
            "key": "simple-flag",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "rollout_percentage": 100,
                    }
                ],
            },
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )
            client.feature_flags = [multivariate_flag, simple_flag]

            msg_uuid = client.capture(
                "python test event",
                distinct_id="distinct_id",
                send_feature_flags=True,
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertEqual(msg["distinct_id"], "distinct_id")

            # Verify local flags are included in the event
            self.assertIn("$feature/beta-feature-local", msg["properties"])
            self.assertIn("$feature/simple-flag", msg["properties"])
            self.assertEqual(msg["properties"]["$feature/simple-flag"], True)

            # Verify active feature flags are set correctly
            active_flags = msg["properties"]["$active_feature_flags"]
            self.assertIn("beta-feature-local", active_flags)
            self.assertIn("simple-flag", active_flags)

            # The remote flag should NOT be included since we used local evaluation
            self.assertNotIn("$feature/remote-flag", msg["properties"])

            # CRITICAL: Verify the /flags API was NOT called
            self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_capture_with_send_feature_flags_options_only_evaluate_locally_true(
        self, patch_flags
    ):
        """Test that SendFeatureFlagsOptions with only_evaluate_locally=True uses local evaluation"""
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )

            # Set up local flags
            client.feature_flags = [
                {
                    "id": 1,
                    "key": "local-flag",
                    "active": True,
                    "filters": {
                        "groups": [
                            {
                                "properties": [{"key": "region", "value": "US"}],
                                "rollout_percentage": 100,
                            }
                        ],
                    },
                }
            ]

            send_options = {
                "only_evaluate_locally": True,
                "person_properties": {"region": "US"},
            }

            msg_uuid = client.capture(
                "test event", distinct_id="distinct_id", send_feature_flags=send_options
            )

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Verify flags() was not called (no remote evaluation)
            patch_flags.assert_not_called()

            # Check the message includes the local flag
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["properties"]["$feature/local-flag"], True)
            self.assertEqual(msg["properties"]["$active_feature_flags"], ["local-flag"])

    @mock.patch("posthog.client.flags")
    def test_capture_with_send_feature_flags_options_only_evaluate_locally_false(
        self, patch_flags
    ):
        """Test that SendFeatureFlagsOptions with only_evaluate_locally=False forces remote evaluation"""
        patch_flags.return_value = {"featureFlags": {"remote-flag": "remote-value"}}

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )

            send_options = {
                "only_evaluate_locally": False,
                "person_properties": {"plan": "premium"},
                "group_properties": {"company": {"type": "enterprise"}},
            }

            msg_uuid = client.capture(
                "test event",
                distinct_id="distinct_id",
                groups={"company": "acme"},
                send_feature_flags=send_options,
            )

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Verify flags() was called with the correct properties
            patch_flags.assert_called_once()
            call_args = patch_flags.call_args[1]
            self.assertEqual(call_args["person_properties"], {"plan": "premium"})
            self.assertEqual(
                call_args["group_properties"], {"company": {"type": "enterprise"}}
            )

            # Check the message includes the remote flag
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["properties"]["$feature/remote-flag"], "remote-value")

    @mock.patch("posthog.client.flags")
    def test_capture_with_send_feature_flags_options_default_behavior(
        self, patch_flags
    ):
        """Test that SendFeatureFlagsOptions without only_evaluate_locally defaults to remote evaluation"""
        patch_flags.return_value = {"featureFlags": {"default-flag": "default-value"}}

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )

            send_options = {
                "person_properties": {"subscription": "pro"},
            }

            msg_uuid = client.capture(
                "test event", distinct_id="distinct_id", send_feature_flags=send_options
            )

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Verify flags() was called (default to remote evaluation)
            patch_flags.assert_called_once()
            call_args = patch_flags.call_args[1]
            self.assertEqual(call_args["person_properties"], {"subscription": "pro"})

            # Check the message includes the flag
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(
                msg["properties"]["$feature/default-flag"], "default-value"
            )

    @mock.patch("posthog.client.flags")
    def test_capture_exception_with_send_feature_flags_options(self, patch_flags):
        """Test that capture_exception also supports SendFeatureFlagsOptions"""
        patch_flags.return_value = {"featureFlags": {"exception-flag": True}}

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )

            send_options = {
                "only_evaluate_locally": False,
                "person_properties": {"user_type": "admin"},
            }

            try:
                raise ValueError("Test exception")
            except ValueError as e:
                msg_uuid = client.capture_exception(
                    e, distinct_id="distinct_id", send_feature_flags=send_options
                )

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Verify flags() was called with the correct properties
            patch_flags.assert_called_once()
            call_args = patch_flags.call_args[1]
            self.assertEqual(call_args["person_properties"], {"user_type": "admin"})

            # Check the message includes the flag
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "$exception")
            self.assertEqual(msg["properties"]["$feature/exception-flag"], True)

    def test_stringifies_distinct_id(self):
        # A large number that loses precision in node:
        # node -e "console.log(157963456373623802 + 1)" > 157963456373623800
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.capture(
                "python test event", distinct_id=157963456373623802
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["distinct_id"], "157963456373623802")

    def test_advanced_capture(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.capture(
                "python test event",
                distinct_id="distinct_id",
                properties={"property": "value"},
                timestamp=datetime(2014, 9, 3),
                uuid="00000000-0000-4000-8000-000000000001",
            )

            self.assertEqual(msg_uuid, "00000000-0000-4000-8000-000000000001")

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")
            self.assertEqual(msg["properties"]["property"], "value")
            self.assertEqual(msg["event"], "python test event")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertEqual(msg["uuid"], "00000000-0000-4000-8000-000000000001")
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertTrue("$groups" not in msg["properties"])

    def test_capture_converts_aware_timestamp_to_utc_without_changing_instant(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            client.capture(
                "python test event",
                distinct_id="distinct_id",
                timestamp=datetime(
                    2014, 9, 3, 5, 30, tzinfo=timezone(timedelta(hours=5, minutes=30))
                ),
            )

            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")

    def test_capture_converts_parseable_timestamp_string_to_utc(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            client.capture(
                "python test event",
                distinct_id="distinct_id",
                timestamp="2014-09-03T05:30:00+05:30",
            )

            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")

    @parameterized.expand(["2026-06-27", "not-an-iso-timestamp"])
    def test_capture_replaces_invalid_timestamp_with_current_utc_time(self, timestamp):
        now = datetime(2026, 6, 27, 12, 30, tzinfo=timezone.utc)
        with (
            mock.patch("posthog.client.batch_post") as mock_post,
            mock.patch("posthog.client.datetime", wraps=datetime) as mock_datetime,
            mock.patch.object(Client.log, "warning") as mock_warning,
        ):
            mock_datetime.now.return_value = now
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            result = client.capture(
                "python test event",
                distinct_id="distinct_id",
                timestamp=timestamp,
            )

        self.assertIsNotNone(result)
        msg = mock_post.call_args[1]["batch"][0]
        self.assertEqual(msg["timestamp"], "2026-06-27T12:30:00+00:00")
        mock_warning.assert_called_once_with(
            "Invalid timestamp %r. Falling back to the current UTC time.", timestamp
        )

    def test_capture_does_not_normalize_datetime_properties(self):
        property_value = datetime(
            2014, 9, 3, 5, 30, tzinfo=timezone(timedelta(hours=5, minutes=30))
        )
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            client.capture(
                "python test event",
                distinct_id="distinct_id",
                properties={"caller_datetime": property_value},
            )

            msg = mock_post.call_args[1]["batch"][0]
            self.assertIs(msg["properties"]["caller_datetime"], property_value)

    def test_groups_capture(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.capture(
                "test_event",
                distinct_id="distinct_id",
                groups={"company": "id:5", "instance": "app.posthog.com"},
            )

            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(
                msg["properties"]["$groups"],
                {"company": "id:5", "instance": "app.posthog.com"},
            )

    def test_basic_set(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.set(
                distinct_id="distinct_id", properties={"trait": "value"}
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["$set"]["trait"], "value")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")

    def test_advanced_set(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.set(
                distinct_id="distinct_id",
                properties={"trait": "value"},
                timestamp=datetime(2014, 9, 3),
                uuid="00000000-0000-4000-8000-000000000001",
            )

            self.assertEqual(msg_uuid, "00000000-0000-4000-8000-000000000001")

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")
            self.assertEqual(msg["$set"]["trait"], "value")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertEqual(msg["uuid"], "00000000-0000-4000-8000-000000000001")
            self.assertEqual(msg["distinct_id"], "distinct_id")

    def test_basic_set_once(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.set_once(
                distinct_id="distinct_id", properties={"trait": "value"}
            )
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["$set_once"]["trait"], "value")
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))
            self.assertEqual(msg["distinct_id"], "distinct_id")

    def test_advanced_set_once(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.set_once(
                distinct_id="distinct_id",
                properties={"trait": "value"},
                timestamp=datetime(2014, 9, 3),
                uuid="00000000-0000-4000-8000-000000000001",
            )

            self.assertEqual(msg_uuid, "00000000-0000-4000-8000-000000000001")

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")
            self.assertEqual(msg["$set_once"]["trait"], "value")
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertEqual(msg["uuid"], "00000000-0000-4000-8000-000000000001")
            self.assertEqual(msg["distinct_id"], "distinct_id")

    def test_basic_group_identify(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.group_identify("organization", "id:5")

            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "$groupidentify")
            self.assertEqual(
                msg["properties"],
                {
                    "$group_type": "organization",
                    "$group_key": "id:5",
                    "$group_set": {},
                    "$lib": "posthog-python",
                    "$lib_version": VERSION,
                    "$geoip_disable": True,
                    "$is_server": True,
                },
            )
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))

    def test_basic_group_identify_with_distinct_id(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.group_identify(
                "organization", "id:5", distinct_id="distinct_id"
            )
            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "$groupidentify")
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(
                msg["properties"],
                {
                    "$group_type": "organization",
                    "$group_key": "id:5",
                    "$group_set": {},
                    "$lib": "posthog-python",
                    "$lib_version": VERSION,
                    "$geoip_disable": True,
                    "$is_server": True,
                },
            )
            self.assertTrue(isinstance(msg["timestamp"], str))
            self.assertIsNotNone(msg.get("uuid"))

    def test_advanced_group_identify(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.group_identify(
                "organization",
                "id:5",
                {"trait": "value"},
                timestamp=datetime(2014, 9, 3),
                uuid="00000000-0000-4000-8000-000000000001",
            )

            self.assertEqual(msg_uuid, "00000000-0000-4000-8000-000000000001")

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "$groupidentify")
            self.assertEqual(
                msg["properties"],
                {
                    "$group_type": "organization",
                    "$group_key": "id:5",
                    "$group_set": {"trait": "value"},
                    "$lib": "posthog-python",
                    "$lib_version": VERSION,
                    "$geoip_disable": True,
                    "$is_server": True,
                },
            )
            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")

    def test_advanced_group_identify_with_distinct_id(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.group_identify(
                "organization",
                "id:5",
                {"trait": "value"},
                timestamp=datetime(2014, 9, 3),
                uuid="00000000-0000-4000-8000-000000000001",
                distinct_id="distinct_id",
            )

            self.assertEqual(msg_uuid, "00000000-0000-4000-8000-000000000001")

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "$groupidentify")
            self.assertEqual(msg["distinct_id"], "distinct_id")

            self.assertEqual(
                msg["properties"],
                {
                    "$group_type": "organization",
                    "$group_key": "id:5",
                    "$group_set": {"trait": "value"},
                    "$lib": "posthog-python",
                    "$lib_version": VERSION,
                    "$geoip_disable": True,
                    "$is_server": True,
                },
            )
            self.assertEqual(msg["timestamp"], "2014-09-03T00:00:00+00:00")

    @parameterized.expand(
        [
            ("none", None),
            ("empty_string", ""),
        ]
    )
    def test_group_identify_without_group_type_is_dropped(self, _name, group_type):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with self.assertLogs("posthog", level="WARNING") as logs:
                msg_uuid = client.group_identify(group_type, "id:5")

            self.assertIsNone(msg_uuid)
            mock_post.assert_not_called()
            self.assertIn("group_type", logs.output[0])

    @parameterized.expand(
        [
            ("none", None),
            ("empty_string", ""),
        ]
    )
    def test_group_identify_without_group_key_is_dropped(self, _name, group_key):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with self.assertLogs("posthog", level="WARNING") as logs:
                msg_uuid = client.group_identify("organization", group_key)

            self.assertIsNone(msg_uuid)
            mock_post.assert_not_called()
            self.assertIn("group_key", logs.output[0])

    def test_group_identify_accepts_falsy_non_string_group_key(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.group_identify("organization", 0)
            self.assertIsNotNone(msg_uuid)

            mock_post.assert_called_once()
            msg = mock_post.call_args[1]["batch"][0]
            # The group key is validated, not normalized - it goes out as passed.
            self.assertEqual(msg["properties"]["$group_key"], 0)

    def test_basic_alias(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.alias("previousId", "distinct_id")
            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]
            self.assertEqual(msg["properties"]["distinct_id"], "previousId")
            self.assertEqual(msg["properties"]["alias"], "distinct_id")

    @parameterized.expand(
        [
            ("none", None),
            ("empty_string", ""),
        ]
    )
    def test_alias_without_previous_id_is_dropped(self, _name, previous_id):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with self.assertLogs("posthog", level="WARNING") as logs:
                msg_uuid = client.alias(previous_id, "distinct_id")

            self.assertIsNone(msg_uuid)
            mock_post.assert_not_called()
            self.assertIn("previous_id", logs.output[0])

    def test_alias_accepts_non_string_previous_id(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            msg_uuid = client.alias(0, "distinct_id")
            self.assertIsNotNone(msg_uuid)

            mock_post.assert_called_once()
            msg = mock_post.call_args[1]["batch"][0]
            self.assertEqual(msg["distinct_id"], "0")
            self.assertEqual(msg["properties"]["distinct_id"], "0")

    def test_alias_without_distinct_id_is_dropped(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with self.assertLogs("posthog", level="WARNING") as logs:
                msg_uuid = client.alias("previousId", None)

            self.assertIsNone(msg_uuid)
            mock_post.assert_not_called()
            self.assertIn("distinct_id", logs.output[0])

    @parameterized.expand(
        [
            # test_name, session_id, additional_properties, expected_properties
            ("basic_session_id", "test-session-123", {}, {}),
            (
                "session_id_with_other_properties",
                "test-session-456",
                {
                    "custom_prop": "custom_value",
                    "$process_person_profile": False,
                    "$current_url": "https://example.com",
                },
                {
                    "custom_prop": "custom_value",
                    "$process_person_profile": False,
                    "$current_url": "https://example.com",
                },
            ),
            ("session_id_uuid_format", str(uuid4()), {}, {}),
            ("session_id_numeric_string", "1234567890", {}, {}),
            ("session_id_empty_string", "", {}, {}),
            ("session_id_with_special_chars", "session-123_test.id", {}, {}),
        ]
    )
    def test_capture_with_session_id_variations(
        self, test_name, session_id, additional_properties, expected_properties
    ):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)

            properties = {"$session_id": session_id, **additional_properties}
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", properties=properties
            )

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], "python test event")
            self.assertEqual(msg["distinct_id"], "distinct_id")
            self.assertEqual(msg["properties"]["$session_id"], session_id)
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)

            # Check additional expected properties
            for key, value in expected_properties.items():
                self.assertEqual(msg["properties"][key], value)

    def test_session_id_preserved_with_groups(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            session_id = "group-session-101"

            msg_uuid = client.capture(
                "test_event",
                distinct_id="distinct_id",
                properties={"$session_id": session_id},
                groups={"company": "id:5", "instance": "app.posthog.com"},
            )

            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["properties"]["$session_id"], session_id)
            self.assertEqual(
                msg["properties"]["$groups"],
                {"company": "id:5", "instance": "app.posthog.com"},
            )

    def test_session_id_with_anonymous_event(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            session_id = "anonymous-session-202"

            msg_uuid = client.capture(
                "anonymous_event",
                distinct_id="distinct_id",
                properties={
                    "$session_id": session_id,
                    "$process_person_profile": False,
                },
            )

            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["properties"]["$session_id"], session_id)
            self.assertEqual(msg["properties"]["$process_person_profile"], False)

    @parameterized.expand(
        [
            # test_name, event_name, session_id, additional_properties, expected_additional_properties
            (
                "screen_event",
                "$screen",
                "special-session-505",
                {"$screen_name": "HomeScreen"},
                {"$screen_name": "HomeScreen"},
            ),
            (
                "survey_event",
                "survey sent",
                "survey-session-606",
                {
                    "$survey_id": "survey_123",
                    "$survey_questions": [
                        {"id": "q1", "question": "How likely are you to recommend us?"}
                    ],
                },
                {"$survey_id": "survey_123"},
            ),
            (
                "complex_properties_event",
                "complex_event",
                "mixed-session-707",
                {
                    "$current_url": "https://example.com/page",
                    "$process_person_profile": True,
                    "custom_property": "custom_value",
                    "numeric_property": 42,
                    "boolean_property": True,
                },
                {
                    "$current_url": "https://example.com/page",
                    "$process_person_profile": True,
                    "custom_property": "custom_value",
                    "numeric_property": 42,
                    "boolean_property": True,
                },
            ),
            (
                "csp_violation",
                "$csp_violation",
                "csp-session-789",
                {
                    "$csp_version": "1.0",
                    "$current_url": "https://example.com/page",
                    "$process_person_profile": False,
                    "$raw_user_agent": "Mozilla/5.0 Test Agent",
                    "$csp_document_url": "https://example.com/page",
                    "$csp_blocked_url": "https://malicious.com/script.js",
                    "$csp_violated_directive": "script-src",
                },
                {
                    "$csp_version": "1.0",
                    "$current_url": "https://example.com/page",
                    "$process_person_profile": False,
                    "$raw_user_agent": "Mozilla/5.0 Test Agent",
                    "$csp_document_url": "https://example.com/page",
                    "$csp_blocked_url": "https://malicious.com/script.js",
                    "$csp_violated_directive": "script-src",
                },
            ),
        ]
    )
    def test_session_id_with_different_event_types(
        self,
        test_name,
        event_name,
        session_id,
        additional_properties,
        expected_additional_properties,
    ):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)

            properties = {"$session_id": session_id, **additional_properties}
            msg_uuid = client.capture(
                event_name, distinct_id="distinct_id", properties=properties
            )

            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["event"], event_name)
            self.assertEqual(msg["properties"]["$session_id"], session_id)

            # Check additional expected properties
            for key, value in expected_additional_properties.items():
                self.assertEqual(msg["properties"][key], value)

            # Verify system properties are still added
            self.assertEqual(msg["properties"]["$lib"], "posthog-python")
            self.assertEqual(msg["properties"]["$lib_version"], VERSION)

    @parameterized.expand(
        [
            # test_name, super_properties, event_session_id, expected_session_id, expected_super_props
            (
                "super_properties_override_session_id",
                {"$session_id": "super-session", "source": "test"},
                "event-session-808",
                "super-session",
                {"source": "test"},
            ),
            (
                "no_super_properties_conflict",
                {"source": "test", "version": "1.0"},
                "event-session-909",
                "event-session-909",
                {"source": "test", "version": "1.0"},
            ),
            (
                "empty_super_properties",
                {},
                "event-session-111",
                "event-session-111",
                {},
            ),
            (
                "super_properties_with_other_dollar_props",
                {"$current_url": "https://super.com", "source": "test"},
                "event-session-222",
                "event-session-222",
                {"$current_url": "https://super.com", "source": "test"},
            ),
        ]
    )
    def test_session_id_with_super_properties_variations(
        self,
        test_name,
        super_properties,
        event_session_id,
        expected_session_id,
        expected_super_props,
    ):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY, super_properties=super_properties, sync_mode=True
            )

            msg_uuid = client.capture(
                "test_event",
                distinct_id="distinct_id",
                properties={"$session_id": event_session_id},
            )

            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["properties"]["$session_id"], expected_session_id)

            # Check expected super properties are present
            for key, value in expected_super_props.items():
                self.assertEqual(msg["properties"][key], value)

    def test_flush(self):
        client = self.client
        # set up the consumer with more requests than a single batch will allow
        for i in range(1000):
            client.capture(
                "event", distinct_id="distinct_id", properties={"trait": "value"}
            )
        # We can't reliably assert that the queue is non-empty here; that's
        # a race condition. We do our best to load it up though.
        client.flush()
        # Make sure that the client queue is empty after flushing
        self.assertTrue(client.queue.empty())

    def test_shutdown(self):
        client = self.client
        # set up the consumer with more requests than a single batch will allow
        for i in range(1000):
            client.capture(
                "test event", distinct_id="distinct_id", properties={"trait": "value"}
            )
        client.shutdown()
        # we expect two things after shutdown:
        # 1. client queue is empty
        # 2. consumer thread has stopped
        self.assertTrue(client.queue.empty())
        for consumer in client.consumers:
            self.assertFalse(consumer.is_alive())

    def test_atexit_registers_bounded_worker_cleanup(self):
        with mock.patch("posthog.client.atexit.register") as register:
            client = Client(FAKE_TEST_API_KEY)

        register.assert_called_once_with(client._atexit)
        self.addCleanup(client.shutdown)

    def test_atexit_bounds_flush_and_stops_consumers_without_joining(self):
        client = Client(FAKE_TEST_API_KEY, send=False)
        lanes = [mock.Mock(), mock.Mock()]
        for lane in lanes:
            lane.consumers = [mock.Mock(), mock.Mock()]
        client._lanes = lanes

        client._atexit()

        for lane in lanes:
            lane.close.assert_called_once_with()
            lane.flush.assert_called_once()
            timeout = lane.flush.call_args.args[0]
            self.assertGreaterEqual(timeout, 0)
            self.assertLessEqual(timeout, 1)
            lane.wait_for_sync_sends.assert_not_called()
            lane.join.assert_not_called()
            for consumer in lane.consumers:
                consumer.pause.assert_called_once_with()

    def test_atexit_subprocess_does_not_drain_queued_backlog(self):
        script = textwrap.dedent(
            """
            import threading
            import time
            from unittest import mock

            from posthog.client import Client
            from posthog.consumer import Consumer

            with mock.patch.object(Consumer, "start"):
                clients = [
                    Client(f"test-key-{index}", flush_at=100, flush_interval=60)
                    for index in range(3)
                ]

            for client in clients:
                consumer = client.consumers[0]
                consumer.request = lambda batch: time.sleep(10)
                consumer.start()
            time.sleep(0.1)

            queues = [client.queue for client in clients]
            for queue in queues:
                for index in range(10):
                    queue.put({"event": str(index), "distinct_id": "test"})

            deadline = time.monotonic() + 1
            while any(not queue.empty() for queue in queues):
                if time.monotonic() >= deadline:
                    raise RuntimeError("consumer did not buffer the queued backlog")
                time.sleep(0.001)
            """
        )

        subprocess.run(
            [sys.executable, "-c", script],
            check=True,
            capture_output=True,
            text=True,
            timeout=3,
        )

    def test_atexit_does_not_wait_for_active_lifecycle_owner(self):
        client = Client(FAKE_TEST_API_KEY, send=False)
        owner = mock.Mock()
        client._lifecycle_owner = owner

        lane = mock.Mock()
        client._lanes = [lane]

        client._atexit()

        lane.close.assert_not_called()
        lane.flush.assert_not_called()
        self.assertIs(client._lifecycle_owner, owner)

    def test_shutdown_clears_feature_flag_called_dedupe_cache(self):
        client = Client(FAKE_TEST_API_KEY, send=False, thread=0)
        client.distinct_ids_feature_flags_reported["user"] = {("flag", True, ())}

        client.shutdown()

        self.assertEqual(len(client.distinct_ids_feature_flags_reported), 0)

    def test_shutdown_flushes_without_timeout(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)

        with mock.patch.object(client._analytics_lane, "flush") as mock_flush:
            client.shutdown()

        mock_flush.assert_called_once_with(timeout_seconds=None)

    def test_callback_shutdown_escalates_pending_deferred_join(self):
        client = Client(FAKE_TEST_API_KEY)
        first_run_started = threading.Event()
        release_first_run = threading.Event()
        shutdown_run_complete = threading.Event()
        require_shutdown_calls = []

        def run_lifecycle(require_shutdown=False):
            require_shutdown_calls.append(require_shutdown)
            if len(require_shutdown_calls) == 1:
                first_run_started.set()
                self.assertTrue(release_first_run.wait(2))
            else:
                shutdown_run_complete.set()

        with (
            mock.patch.object(
                client, "_is_lifecycle_callback_thread", return_value=True
            ),
            mock.patch.object(client, "_run_lifecycle", side_effect=run_lifecycle),
            mock.patch.object(
                client,
                "_start_lifecycle_thread",
                wraps=client._start_lifecycle_thread,
            ) as start_thread,
        ):
            client.join()
            self.assertTrue(first_run_started.wait(1))
            client.shutdown()
            release_first_run.set()
            self.assertTrue(shutdown_run_complete.wait(1))

        start_thread.assert_called_once()
        self.assertEqual(start_thread.call_args.args[1], "lifecycle")
        self.assertEqual(require_shutdown_calls, [False, True])
        self.assertTrue(
            _wait_until(lambda: not client._deferred_lifecycle_thread_pending)
        )
        self.assertFalse(client._deferred_lifecycle_dirty)

    def test_callback_shutdown_escalates_failed_deferred_join(self):
        client = Client(FAKE_TEST_API_KEY)
        first_run_started = threading.Event()
        release_first_run = threading.Event()
        shutdown_run_complete = threading.Event()
        require_shutdown_calls = []

        def run_lifecycle(require_shutdown=False):
            require_shutdown_calls.append(require_shutdown)
            if len(require_shutdown_calls) == 1:
                first_run_started.set()
                self.assertTrue(release_first_run.wait(2))
                raise Exception("join cleanup failed")
            shutdown_run_complete.set()

        with (
            mock.patch.object(
                client, "_is_lifecycle_callback_thread", return_value=True
            ),
            mock.patch.object(client, "_run_lifecycle", side_effect=run_lifecycle),
            mock.patch.object(
                client,
                "_start_lifecycle_thread",
                wraps=client._start_lifecycle_thread,
            ) as start_thread,
        ):
            client.join()
            self.assertTrue(first_run_started.wait(1))
            client.shutdown()
            release_first_run.set()
            self.assertTrue(shutdown_run_complete.wait(1))

        start_thread.assert_called_once()
        self.assertEqual(require_shutdown_calls, [False, True])
        self.assertTrue(
            _wait_until(lambda: not client._deferred_lifecycle_thread_pending)
        )
        self.assertFalse(client._deferred_lifecycle_dirty)

    def test_deferred_lifecycle_worker_is_daemon(self):
        client = Client(FAKE_TEST_API_KEY)
        target = mock.Mock()

        with mock.patch("posthog.client.threading.Thread") as thread:
            client._start_lifecycle_thread(target, "lifecycle")

        thread.assert_called_once_with(
            target=target,
            args=(),
            name="posthog-lifecycle",
            daemon=True,
        )
        thread.return_value.start.assert_called_once_with()

    def test_deferred_lifecycle_logs_selected_operation(self):
        client = Client(FAKE_TEST_API_KEY)

        with (
            mock.patch.object(
                client, "_is_lifecycle_callback_thread", return_value=True
            ),
            mock.patch.object(
                client,
                "_run_lifecycle",
                side_effect=Exception("cleanup failed"),
            ) as run_lifecycle,
            mock.patch.object(client.log, "exception") as log_exception,
        ):
            client.shutdown()
            self.assertTrue(
                _wait_until(lambda: not client._deferred_lifecycle_thread_pending)
            )

        run_lifecycle.assert_called_once_with(require_shutdown=True)
        log_exception.assert_called_once_with("Deferred %s failed", "shutdown")

    def test_callback_flushes_are_coalesced_with_strongest_followup(self):
        client = Client(FAKE_TEST_API_KEY)
        first_flush_started = threading.Event()
        release_first_flush = threading.Event()
        followup_complete = threading.Event()
        timeouts = []

        def flush(timeout_seconds):
            timeouts.append(timeout_seconds)
            if len(timeouts) == 1:
                first_flush_started.set()
                self.assertTrue(release_first_flush.wait(2))
            else:
                followup_complete.set()

        with (
            mock.patch.object(
                client, "_is_lifecycle_callback_thread", return_value=True
            ),
            mock.patch.object(client, "flush", side_effect=flush),
        ):
            self.assertTrue(client._defer_flush_from_callback(0))
            self.assertTrue(first_flush_started.wait(1))
            self.assertTrue(client._defer_flush_from_callback(1))
            self.assertTrue(client._defer_flush_from_callback(None))
            release_first_flush.set()
            self.assertTrue(followup_complete.wait(1))

        self.assertEqual(timeouts, [0, None])

    def test_sync_send_failure_does_not_invoke_async_on_error(self):
        on_error = mock.Mock()
        client = Client(
            FAKE_TEST_API_KEY,
            sync_mode=True,
            on_error=on_error,
        )

        with mock.patch(
            "posthog.client.batch_post", side_effect=Exception("upload failed")
        ):
            result = client.capture("event", distinct_id="distinct_id")

        self.assertIsNone(result)
        on_error.assert_not_called()
        self.assertEqual(client._analytics_lane._active_sync_sends, 0)

    def test_on_error_can_request_shutdown_with_pending_work(self):
        first_send_started = threading.Event()
        release_first_send = threading.Event()
        callback_returned = threading.Event()
        sent_events = []
        client: Client

        def request(batch):
            event = batch[0]["event"]
            sent_events.append(event)
            if event == "first":
                first_send_started.set()
                self.assertTrue(release_first_send.wait(2))
                raise Exception("upload failed")

        def on_error(error, batch):
            client.shutdown()
            client.join()
            callback_returned.set()

        client = Client(
            FAKE_TEST_API_KEY,
            on_error=on_error,
            flush_at=1,
            flush_interval=0.01,
            max_retries=0,
        )
        exception_capture = mock.Mock()
        exception_capture.close.side_effect = Exception("cleanup failed")
        client.exception_capture = exception_capture
        with mock.patch.object(client.consumers[0], "request", side_effect=request):
            client.capture("first", distinct_id="distinct_id")
            self.assertTrue(first_send_started.wait(1))
            client.capture("second", distinct_id="distinct_id")
            release_first_send.set()

            self.assertTrue(callback_returned.wait(1))
            self.assertTrue(_wait_until(lambda: client._shutdown_complete))

        self.assertEqual(sent_events, ["first", "second"])
        self.assertEqual(client.queue.unfinished_tasks, 0)
        exception_capture.close.assert_called_once_with()
        self.assertTrue(all(not consumer.is_alive() for consumer in client.consumers))

    def test_concurrent_join_waits_for_lifecycle_owner(self):
        send_started = threading.Event()
        release_send = threading.Event()

        def request(batch):
            send_started.set()
            self.assertTrue(release_send.wait(2))

        client = Client(FAKE_TEST_API_KEY, flush_at=1)
        with mock.patch.object(client.consumers[0], "request", side_effect=request):
            client.capture("event", distinct_id="distinct_id")
            self.assertTrue(send_started.wait(1))

            first_join = threading.Thread(target=client.join)
            second_join = threading.Thread(target=client.join)
            first_join.start()
            time.sleep(0.05)
            second_join.start()
            time.sleep(0.05)
            self.assertTrue(second_join.is_alive())

            release_send.set()
            first_join.join(3)
            second_join.join(3)

        self.assertFalse(first_join.is_alive())
        self.assertFalse(second_join.is_alive())
        self.assertTrue(client._join_cleanup_complete)

    def test_join_winning_shutdown_race_drains_pending_work_without_deadlock(self):
        first_send_started = threading.Event()
        release_first_send = threading.Event()
        join_started = threading.Event()
        sent_events = []

        def request(batch):
            sent_events.extend(event["event"] for event in batch)
            first_send_started.set()
            self.assertTrue(release_first_send.wait(2))

        client = Client(FAKE_TEST_API_KEY, flush_at=1)
        with mock.patch.object(client.consumers[0], "request", side_effect=request):
            client.capture("first", distinct_id="distinct_id")
            self.assertTrue(first_send_started.wait(1))
            client.capture("second", distinct_id="distinct_id")

            original_close = client._analytics_lane.close

            def observed_close():
                original_close()
                join_started.set()

            with mock.patch.object(
                client._analytics_lane, "close", side_effect=observed_close
            ):
                join_thread = threading.Thread(target=client.join)
                shutdown_thread = threading.Thread(target=client.shutdown)
                join_thread.start()
                self.assertTrue(join_started.wait(1))
                shutdown_thread.start()
                release_first_send.set()
                join_thread.join(3)
                shutdown_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertFalse(shutdown_thread.is_alive())
        self.assertEqual(sent_events, ["first", "second"])
        self.assertEqual(client.queue.unfinished_tasks, 0)
        self.assertTrue(client._shutdown_complete)

    def test_shutdown_winning_join_race_drains_pending_work(self):
        first_send_started = threading.Event()
        release_first_send = threading.Event()
        shutdown_started = threading.Event()
        sent_events = []

        def request(batch):
            sent_events.extend(event["event"] for event in batch)
            if len(sent_events) == 1:
                first_send_started.set()
                self.assertTrue(release_first_send.wait(2))

        client = Client(FAKE_TEST_API_KEY, flush_at=1, flush_interval=0.01)
        with mock.patch.object(client.consumers[0], "request", side_effect=request):
            client.capture("first", distinct_id="distinct_id")
            self.assertTrue(first_send_started.wait(1))
            client.capture("second", distinct_id="distinct_id")

            original_close = client._analytics_lane.close

            def observed_close():
                original_close()
                shutdown_started.set()

            with mock.patch.object(
                client._analytics_lane, "close", side_effect=observed_close
            ):
                shutdown_thread = threading.Thread(target=client.shutdown)
                join_thread = threading.Thread(target=client.join)
                shutdown_thread.start()
                self.assertTrue(shutdown_started.wait(1))
                join_thread.start()
                release_first_send.set()
                shutdown_thread.join(3)
                join_thread.join(3)

        self.assertFalse(shutdown_thread.is_alive())
        self.assertFalse(join_thread.is_alive())
        self.assertEqual(sent_events, ["first", "second"])
        self.assertEqual(client.queue.unfinished_tasks, 0)

    def test_join_publishes_terminal_intent_before_closing_lanes(self):
        client = Client(FAKE_TEST_API_KEY, send=False)
        original_close = client._analytics_lane.close

        def close_analytics_lane():
            self.assertTrue(client._join_requested)
            original_close()

        with mock.patch.object(
            client._analytics_lane, "close", side_effect=close_analytics_lane
        ):
            client.join()

        self.assertTrue(client._join_cleanup_complete)

    def test_shutdown_after_join_runs_shutdown_only_cleanup(self):
        client = Client(FAKE_TEST_API_KEY)
        metrics = mock.Mock()
        exception_capture = mock.Mock()
        client._metrics = metrics
        client.exception_capture = exception_capture

        client.join()
        client.shutdown()

        metrics.flush.assert_called_once()
        metrics.reset.assert_called_once()
        exception_capture.close.assert_called_once()
        self.assertTrue(client._shutdown_complete)

    def test_async_cache_provider_default_executor_can_reenter_join(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        executor_called = threading.Event()

        class AsyncProvider:
            async def shutdown(self):
                def reenter_join():
                    client.join()
                    executor_called.set()

                await asyncio.get_running_loop().run_in_executor(None, reenter_join)

        client._flag_definition_cache_provider = AsyncProvider()  # type: ignore[assignment]
        join_thread = threading.Thread(target=client.join)
        join_thread.start()
        join_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertTrue(executor_called.is_set())
        self.assertTrue(client._join_cleanup_complete)

    def test_async_cache_provider_custom_executor_can_reenter_join(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        executor_called = threading.Event()

        class DelegatingExecutor(Executor):
            def __init__(self):
                self.executor = ThreadPoolExecutor(max_workers=1)

            def submit(self, fn, /, *args, **kwargs):
                return self.executor.submit(fn, *args, **kwargs)

            def shutdown(self, wait=True, *, cancel_futures=False):
                self.executor.shutdown(wait=wait, cancel_futures=cancel_futures)

        class AsyncProvider:
            async def shutdown(self):
                def reenter_join():
                    client.join()
                    executor_called.set()

                with DelegatingExecutor() as executor:
                    await asyncio.get_running_loop().run_in_executor(
                        executor, reenter_join
                    )

        client._flag_definition_cache_provider = AsyncProvider()  # type: ignore[assignment]
        join_thread = threading.Thread(target=client.join)
        join_thread.start()
        join_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertTrue(executor_called.is_set())
        self.assertTrue(client._join_cleanup_complete)

    def test_async_cache_provider_read_only_loop_falls_back_without_deadlocking(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        executor_called = threading.Event()

        class ReadOnlyLoop(asyncio.SelectorEventLoop):
            def __setattr__(self, name, value):
                if name == "run_in_executor":
                    raise AttributeError("run_in_executor is read-only")
                super().__setattr__(name, value)

        class AsyncProvider:
            async def shutdown(self):
                def reenter_join():
                    executor_called.set()
                    client.join()

                await asyncio.get_running_loop().run_in_executor(None, reenter_join)

        loop = ReadOnlyLoop()
        client._flag_definition_cache_provider = AsyncProvider()  # type: ignore[assignment]
        with mock.patch(
            "posthog._async_utils.asyncio.new_event_loop", return_value=loop
        ):
            join_thread = threading.Thread(target=client.join)
            join_thread.start()
            join_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertTrue(executor_called.is_set())
        self.assertTrue(loop.is_closed())
        self.assertTrue(client._join_cleanup_complete)

    def test_async_cache_provider_process_executor_remains_supported(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)

        class AsyncProvider:
            result = None

            async def shutdown(self):
                with ProcessPoolExecutor(max_workers=1) as executor:
                    self.result = await asyncio.get_running_loop().run_in_executor(
                        executor, abs, -6
                    )

        provider = AsyncProvider()
        client._flag_definition_cache_provider = provider  # type: ignore[assignment]
        client.join()

        self.assertEqual(provider.result, 6)
        self.assertTrue(client._join_cleanup_complete)

    def test_async_cache_provider_executor_can_reenter_join_during_runner_close(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        finalizer_called = threading.Event()

        class AsyncProvider:
            async def shutdown(self):
                async def pending_task():
                    try:
                        await asyncio.Event().wait()
                    finally:
                        await asyncio.to_thread(client.join)
                        finalizer_called.set()

                asyncio.create_task(pending_task())
                await asyncio.sleep(0)

        client._flag_definition_cache_provider = AsyncProvider()  # type: ignore[assignment]
        join_thread = threading.Thread(target=client.join)
        join_thread.start()
        join_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertTrue(finalizer_called.is_set())
        self.assertTrue(client._join_cleanup_complete)

    def test_cache_provider_shutdown_can_reenter_join(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)

        with mock.patch.object(
            client,
            "_shutdown_flag_definition_cache_provider",
            side_effect=client.join,
        ):
            join_thread = threading.Thread(target=client.join)
            join_thread.start()
            join_thread.join(2)

        self.assertFalse(join_thread.is_alive())
        self.assertTrue(client._workers_joined)

    def test_cache_provider_shutdown_can_reenter_join_from_another_thread(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)

        class Runner:
            _thread = None

            def owns_thread(self, thread):
                return thread is self._thread

        runner = Runner()
        client._flag_definition_cache_provider_async_runner = runner  # type: ignore[assignment]

        def reenter_join():
            reentrant_thread = threading.Thread(target=client.join)
            runner._thread = reentrant_thread
            reentrant_thread.start()
            reentrant_thread.join(1)
            self.assertFalse(reentrant_thread.is_alive())

        with mock.patch.object(
            client,
            "_shutdown_flag_definition_cache_provider",
            side_effect=reenter_join,
        ):
            client.join()

        self.assertTrue(client._workers_joined)
        self.assertTrue(client._join_cleanup_complete)

    def test_poller_shutdown_request_is_completed_by_join_owner(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)

        class ReentrantPoller(threading.Thread):
            def __init__(self):
                super().__init__(daemon=True)
                self.stop_requested = threading.Event()

            def run(self):
                self.stop_requested.wait(2)
                client.shutdown()

            def stop(self):
                self.stop_requested.set()
                self.join(1)
                self.assert_stopped()

            def assert_stopped(self):
                if self.is_alive():
                    raise AssertionError("poller did not stop")

        poller = ReentrantPoller()
        client.poller = poller  # type: ignore[assignment]
        poller.start()

        client.join()

        self.assertTrue(client._shutdown_complete)

    def test_join_failure_does_not_retry_or_skip_later_cleanup(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)

        with (
            mock.patch.object(
                client,
                "_shutdown_flag_definition_cache_provider",
                side_effect=Exception("cleanup failed"),
            ) as cleanup,
            mock.patch.object(client, "_unregister_duplicate_client") as unregister,
        ):
            client.join()
            client.join()

        self.assertTrue(client._workers_joined)
        self.assertTrue(client._join_cleanup_complete)
        cleanup.assert_called_once_with()
        unregister.assert_called_once_with()

    def test_concurrent_debug_join_callers_observe_cleanup_failure(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01, debug=True)
        cleanup_started = threading.Event()
        release_cleanup = threading.Event()
        owner_errors = []
        waiter_errors = []

        def cleanup():
            cleanup_started.set()
            self.assertTrue(release_cleanup.wait(2))
            raise ValueError("cleanup failed")

        def run_join(errors):
            try:
                client.join()
            except Exception as error:
                errors.append(error)

        with mock.patch.object(
            client,
            "_shutdown_flag_definition_cache_provider",
            side_effect=cleanup,
        ):
            owner = threading.Thread(target=run_join, args=(owner_errors,))
            waiter = threading.Thread(target=run_join, args=(waiter_errors,))
            owner.start()
            self.assertTrue(cleanup_started.wait(1))
            waiter.start()
            time.sleep(0.05)
            self.assertTrue(waiter.is_alive())

            release_cleanup.set()
            owner.join(2)
            waiter.join(2)

        self.assertFalse(owner.is_alive())
        self.assertFalse(waiter.is_alive())
        self.assertEqual(len(owner_errors), 1)
        self.assertRegex(str(owner_errors[0]), "cleanup failed")
        self.assertEqual(len(waiter_errors), 1)
        self.assertRegex(str(waiter_errors[0]), "client lifecycle cleanup failed")
        self.assertTrue(client._join_cleanup_complete)

    def test_pending_shutdown_continues_when_join_cleanup_fails(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        cleanup_started = threading.Event()
        release_cleanup = threading.Event()
        cleanup_calls = 0
        join_errors = []

        def cleanup():
            nonlocal cleanup_calls
            cleanup_calls += 1
            if cleanup_calls == 1:
                cleanup_started.set()
                self.assertTrue(release_cleanup.wait(2))
                raise Exception("cleanup failed")

        def run_join():
            try:
                client.join()
            except Exception as error:
                join_errors.append(error)

        with mock.patch.object(
            client,
            "_shutdown_flag_definition_cache_provider",
            side_effect=cleanup,
        ):
            join_thread = threading.Thread(target=run_join)
            join_thread.start()
            self.assertTrue(cleanup_started.wait(1))

            shutdown_thread = threading.Thread(target=client.shutdown)
            shutdown_thread.start()
            time.sleep(0.05)
            self.assertTrue(shutdown_thread.is_alive())

            release_cleanup.set()
            join_thread.join(2)
            shutdown_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertFalse(shutdown_thread.is_alive())
        self.assertEqual(join_errors, [])
        self.assertEqual(cleanup_calls, 1)
        self.assertTrue(client._shutdown_complete)

    def test_join_interruption_does_not_publish_completion(self):
        client = Client(FAKE_TEST_API_KEY, send=False)

        with (
            mock.patch.object(
                client, "_flush_or_discard_queues", side_effect=KeyboardInterrupt
            ),
            self.assertRaises(KeyboardInterrupt),
        ):
            client.join()

        self.assertFalse(client._workers_joined)
        self.assertFalse(client._join_cleanup_complete)
        self.assertIsNone(client._lifecycle_owner)

    def test_shutdown_interruption_does_not_publish_completion(self):
        client = Client(FAKE_TEST_API_KEY, send=False)
        metrics = mock.Mock()
        metrics.flush.side_effect = KeyboardInterrupt
        client._metrics = metrics

        with self.assertRaises(KeyboardInterrupt):
            client.shutdown()

        self.assertFalse(client._workers_joined)
        self.assertFalse(client._join_cleanup_complete)
        self.assertFalse(client._shutdown_complete)
        self.assertIsNone(client._lifecycle_owner)

    def test_shutdown_failure_is_terminal_and_not_retried(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        exception_capture = mock.Mock()
        exception_capture.close.side_effect = Exception("cleanup failed")
        client.exception_capture = exception_capture

        client.shutdown()
        client.shutdown()

        self.assertTrue(client._shutdown_complete)
        exception_capture.close.assert_called_once_with()

    def test_shutdown_failure_is_raised_after_later_cleanup_in_debug_mode(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01, debug=True)
        metrics = mock.Mock()
        metrics.reset.side_effect = Exception("reset failed")
        dedupe_cache = mock.Mock()
        dedupe_cache.clear.side_effect = Exception("clear failed")
        exception_capture = mock.Mock()
        client._metrics = metrics
        client.distinct_ids_feature_flags_reported = dedupe_cache
        client.exception_capture = exception_capture

        with self.assertRaisesRegex(Exception, "reset failed"):
            client.shutdown()
        with self.assertRaisesRegex(RuntimeError, "client lifecycle cleanup failed"):
            client.shutdown()

        metrics.flush.assert_called_once_with()
        metrics.reset.assert_called_once_with()
        dedupe_cache.clear.assert_called_once_with()
        exception_capture.close.assert_called_once_with()
        self.assertTrue(client._workers_joined)
        self.assertTrue(client._join_cleanup_complete)
        self.assertTrue(client._shutdown_complete)

    def test_lane_join_raises_first_failure_after_attempting_later_cleanup(self):
        client = Client(FAKE_TEST_API_KEY, send=False)
        lane = client._analytics_lane
        consumer = mock.Mock()
        first_error = ValueError("pause failed")
        consumer._pause.side_effect = first_error
        lane.consumers = [consumer]

        with (
            mock.patch.object(lane, "discard_undrainable_queued_work") as discard,
            mock.patch.object(
                lane._drain_signal,
                "complete",
                side_effect=RuntimeError("complete failed"),
            ) as complete,
            self.assertRaises(ValueError) as raised,
        ):
            lane.join()

        self.assertIs(raised.exception, first_error)
        consumer.join.assert_called_once_with()
        discard.assert_called_once_with()
        complete.assert_called_once_with()

    def test_shutdown_prepares_each_lane_once(self):
        client = Client(FAKE_TEST_API_KEY, send=False)
        close_methods = []
        wait_methods = []

        with contextlib.ExitStack() as stack:
            for lane in client._lanes:
                close_methods.append(
                    stack.enter_context(
                        mock.patch.object(lane, "close", wraps=lane.close)
                    )
                )
                wait_methods.append(
                    stack.enter_context(
                        mock.patch.object(
                            lane,
                            "wait_for_sync_sends",
                            wraps=lane.wait_for_sync_sends,
                        )
                    )
                )
            client.shutdown()

        for close, wait in zip(close_methods, wait_methods):
            close.assert_called_once_with()
            wait.assert_called_once_with()

    def test_shutdown_does_not_wait_for_idle_consumers_flush_interval(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=5)

        start = time.monotonic()
        client.shutdown()

        self.assertLess(time.monotonic() - start, 1)

    def test_shutdown_waits_for_racing_enqueue_before_draining(self):
        client = Client(FAKE_TEST_API_KEY, flush_interval=0.01)
        put_started = threading.Event()
        release_put = threading.Event()
        shutdown_done = threading.Event()
        original_put = client.queue.put
        capture_result = []

        def blocking_put(*args, **kwargs):
            put_started.set()
            self.assertTrue(release_put.wait(2))
            return original_put(*args, **kwargs)

        capture_thread = threading.Thread(
            target=lambda: capture_result.append(
                client.capture("racing event", distinct_id="distinct_id")
            )
        )
        shutdown_thread = threading.Thread(
            target=lambda: (client.shutdown(), shutdown_done.set())
        )

        with mock.patch.object(client.queue, "put", side_effect=blocking_put):
            capture_thread.start()
            self.assertTrue(put_started.wait(2))
            shutdown_thread.start()
            try:
                self.assertFalse(shutdown_done.wait(0.1))
            finally:
                release_put.set()

            capture_thread.join(2)
            shutdown_thread.join(2)

        self.assertFalse(capture_thread.is_alive())
        self.assertFalse(shutdown_thread.is_alive())
        self.assertTrue(shutdown_done.is_set())
        self.assertIsNotNone(capture_result[0])
        self.assertTrue(client.queue.empty())

    def test_shutdown_waits_for_sync_send_and_rejects_later_sends(self):
        client = Client(FAKE_TEST_API_KEY, sync_mode=True)
        send_started = threading.Event()
        release_send = threading.Event()
        shutdown_done = threading.Event()
        capture_result = []

        def blocking_post(*args, **kwargs):
            send_started.set()
            self.assertTrue(release_send.wait(2))

        capture_thread = threading.Thread(
            target=lambda: capture_result.append(
                client.capture("in-flight event", distinct_id="distinct_id")
            )
        )
        shutdown_thread = threading.Thread(
            target=lambda: (client.shutdown(), shutdown_done.set())
        )

        with mock.patch("posthog.client.batch_post", side_effect=blocking_post) as post:
            capture_thread.start()
            self.assertTrue(send_started.wait(2))
            shutdown_thread.start()
            try:
                self.assertFalse(shutdown_done.wait(0.1))
            finally:
                release_send.set()

            capture_thread.join(2)
            shutdown_thread.join(2)
            later_result = client.capture(
                "post-shutdown event", distinct_id="distinct_id"
            )

        self.assertFalse(capture_thread.is_alive())
        self.assertFalse(shutdown_thread.is_alive())
        self.assertTrue(shutdown_done.is_set())
        self.assertIsNotNone(capture_result[0])
        self.assertIsNone(later_result)
        post.assert_called_once()

    def test_synchronous(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, sync_mode=True)

            msg_uuid = client.capture("test event", distinct_id="distinct_id")
            self.assertFalse(client.consumers)
            self.assertTrue(client.queue.empty())
            self.assertIsNotNone(msg_uuid)

            # Verify the message was sent immediately
            mock_post.assert_called_once()

    def test_overflow(self):
        client = Client(FAKE_TEST_API_KEY, max_queue_size=1, thread=0)
        client.capture("test event", distinct_id="distinct_id")

        with self.assertLogs("posthog", level="WARNING") as logs:
            msg_uuid = client.capture("test event", distinct_id="distinct_id")
        # Make sure we are informed that the queue is at capacity
        self.assertIsNone(msg_uuid)
        self.assertIn("dropping event", logs.output[0])

    def test_join_discards_queued_work_when_no_consumer_can_drain_it(self):
        client = Client(FAKE_TEST_API_KEY, thread=0)
        client.capture("test event", distinct_id="distinct_id")

        start = time.monotonic()
        client.join()

        self.assertLess(time.monotonic() - start, 1)
        self.assertEqual(client.queue.unfinished_tasks, 0)

    def test_join_discards_remaining_work_if_consumer_stops_during_drain(self):
        send_started = threading.Event()
        release_send = threading.Event()

        def request(batch):
            send_started.set()
            self.assertTrue(release_send.wait(2))

        client = Client(FAKE_TEST_API_KEY, flush_at=1)
        consumer = client.consumers[0]
        with mock.patch.object(consumer, "request", side_effect=request):
            client.capture("first", distinct_id="distinct_id")
            self.assertTrue(send_started.wait(1))
            client.capture("second", distinct_id="distinct_id")

            join_thread = threading.Thread(target=client.join)
            join_thread.start()
            time.sleep(0.05)
            consumer.pause()
            release_send.set()
            join_thread.join(3)

        self.assertFalse(join_thread.is_alive())
        self.assertEqual(client.queue.unfinished_tasks, 0)

    def test_shutdown_discards_queued_work_when_no_consumer_can_drain_it(self):
        client = Client(FAKE_TEST_API_KEY, thread=0)
        client.capture("test event", distinct_id="distinct_id")

        start = time.monotonic()
        client.shutdown()

        self.assertLess(time.monotonic() - start, 1)
        self.assertEqual(client.queue.unfinished_tasks, 0)
        self.assertTrue(client._shutdown_complete)

    def test_unicode(self):
        Client("unicode_key")

    def test_numeric_distinct_id(self):
        self.client.capture("python event", distinct_id=1234)
        self.client.flush()
        self.assertFalse(self.failed)

    def test_debug(self):
        Client("bad_key", debug=True)

    def test_gzip(self):
        client = Client(FAKE_TEST_API_KEY, on_error=self.fail, gzip=True)
        for _ in range(10):
            client.capture(
                "event", distinct_id="distinct_id", properties={"trait": "value"}
            )
        client.flush()
        self.assertFalse(self.failed)

    def test_user_defined_flush_at(self):
        client = Client(
            FAKE_TEST_API_KEY, on_error=self.fail, flush_at=10, flush_interval=3
        )

        def mock_post_fn(*args, **kwargs):
            self.assertEqual(len(kwargs["batch"]), 10)

        # the post function should be called 2 times, with a batch size of 10
        # each time.
        with mock.patch(
            "posthog.consumer.batch_post", side_effect=mock_post_fn
        ) as mock_post:
            for _ in range(20):
                client.capture(
                    "event", distinct_id="distinct_id", properties={"trait": "value"}
                )
            time.sleep(1)
            self.assertEqual(mock_post.call_count, 2)

    def test_user_defined_timeout(self):
        client = Client(FAKE_TEST_API_KEY, timeout=10)
        for consumer in client.consumers:
            self.assertEqual(consumer.timeout, 10)

    def test_default_timeout_15(self):
        client = Client(FAKE_TEST_API_KEY)
        for consumer in client.consumers:
            self.assertEqual(consumer.timeout, 15)

    def test_disabled(self):
        client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, disabled=True)
        msg_uuid = client.capture("python test event", distinct_id="distinct_id")
        client.flush()
        self.assertIsNone(msg_uuid)
        self.assertFalse(self.failed)

    @mock.patch("posthog.client.flags")
    def test_disabled_with_feature_flags(self, patch_flags):
        client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, disabled=True)

        response = client.get_feature_flag("beta-feature", "12345")
        self.assertIsNone(response)
        patch_flags.assert_not_called()

        response = client.feature_enabled("beta-feature", "12345")
        self.assertIsNone(response)
        patch_flags.assert_not_called()

        response = client.get_all_flags("12345")
        self.assertIsNone(response)
        patch_flags.assert_not_called()

        response = client.get_feature_flag_payload("key", "12345")
        self.assertIsNone(response)
        patch_flags.assert_not_called()

        response = client.get_all_flags_and_payloads("12345")
        self.assertEqual(response, {"featureFlags": None, "featureFlagPayloads": None})
        patch_flags.assert_not_called()

        # no capture calls
        self.assertTrue(client.queue.empty())

    def test_enabled_to_disabled(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                disabled=False,
                sync_mode=True,
            )
            msg_uuid = client.capture("python test event", distinct_id="distinct_id")

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]
            self.assertEqual(msg["event"], "python test event")

            client.disabled = True
            msg_uuid = client.capture("python test event", distinct_id="distinct_id")
            self.assertIsNone(msg_uuid)
            self.assertFalse(self.failed)

    def test_disable_geoip_default_on_events(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                disable_geoip=True,
                sync_mode=True,
            )
            msg_uuid = client.capture("python test event", distinct_id="distinct_id")
            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            capture_msg = batch_data[0]
            self.assertEqual(capture_msg["properties"]["$geoip_disable"], True)

    def test_disable_geoip_override_on_events(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                disable_geoip=False,
                sync_mode=True,
            )
            msg_uuid = client.set(
                distinct_id="distinct_id",
                properties={"a": "b", "c": "d"},
                disable_geoip=True,
            )
            self.assertIsNotNone(msg_uuid)

            msg_uuid = client.capture(
                "event",
                distinct_id="distinct_id",
                properties={"trait": "value"},
                disable_geoip=False,
            )
            self.assertIsNotNone(msg_uuid)

            # Check both calls were made
            self.assertEqual(mock_post.call_count, 2)

            # Check set event
            set_batch = mock_post.call_args_list[0][1]["batch"]
            capture_msg = set_batch[0]
            self.assertEqual(capture_msg["properties"]["$geoip_disable"], True)

            # Check page event
            page_batch = mock_post.call_args_list[1][1]["batch"]
            identify_msg = page_batch[0]
            self.assertEqual("$geoip_disable" not in identify_msg["properties"], True)

    def test_disable_geoip_method_overrides_init_on_events(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                disable_geoip=True,
                sync_mode=True,
            )
            msg_uuid = client.capture(
                "python test event", distinct_id="distinct_id", disable_geoip=False
            )
            self.assertIsNotNone(msg_uuid)

            # Get the enqueued message from the mock
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]
            self.assertTrue("$geoip_disable" not in msg["properties"])

    @mock.patch("posthog.client.flags")
    def test_disable_geoip_default_on_decide(self, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
                "alpha-feature": True,
                "off-feature": False,
            }
        }
        client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, disable_geoip=False)
        client.get_feature_flag("random_key", "some_id", disable_geoip=True)
        patch_flags.assert_called_with(
            "random_key",
            "https://us.i.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="some_id",
            groups={},
            person_properties={},
            group_properties={},
            geoip_disable=True,
            device_id=None,
            flag_keys_to_evaluate=["random_key"],
        )
        patch_flags.reset_mock()
        client.feature_enabled(
            "random_key", "feature_enabled_distinct_id", disable_geoip=True
        )
        patch_flags.assert_called_with(
            "random_key",
            "https://us.i.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="feature_enabled_distinct_id",
            groups={},
            person_properties={},
            group_properties={},
            geoip_disable=True,
            device_id=None,
            flag_keys_to_evaluate=["random_key"],
        )
        patch_flags.reset_mock()
        client.get_all_flags_and_payloads("all_flags_payloads_id")
        patch_flags.assert_called_with(
            "random_key",
            "https://us.i.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="all_flags_payloads_id",
            groups={},
            person_properties={},
            group_properties={},
            geoip_disable=False,
            device_id=None,
        )

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_call_identify_fails(self, patch_get, patch_poller):
        def raise_effect():
            raise Exception("http exception")

        patch_get.return_value.raiseError.side_effect = raise_effect
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [{"key": "example"}]

        self.assertFalse(client.feature_enabled("example", "distinct_id"))

    @mock.patch("posthog.client.flags")
    def test_default_properties_get_added_properly(self, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
                "alpha-feature": True,
                "off-feature": False,
            }
        }
        client = Client(
            FAKE_TEST_API_KEY,
            host="http://app2.posthog.com",
            on_error=self.set_fail,
            disable_geoip=False,
        )
        client.get_feature_flag(
            "random_key",
            "some_id",
            groups={"company": "id:5", "instance": "app.posthog.com"},
            person_properties={"x1": "y1"},
            group_properties={"company": {"x": "y"}},
        )
        patch_flags.assert_called_with(
            "random_key",
            "http://app2.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="some_id",
            groups={"company": "id:5", "instance": "app.posthog.com"},
            person_properties={"x1": "y1"},
            group_properties={
                "company": {"$group_key": "id:5", "x": "y"},
                "instance": {"$group_key": "app.posthog.com"},
            },
            geoip_disable=False,
            device_id=None,
            flag_keys_to_evaluate=["random_key"],
        )

        patch_flags.reset_mock()
        client.get_feature_flag(
            "random_key",
            "some_id",
            groups={"company": "id:5", "instance": "app.posthog.com"},
            person_properties={"distinct_id": "override"},
            group_properties={
                "company": {
                    "$group_key": "group_override",
                }
            },
        )
        patch_flags.assert_called_with(
            "random_key",
            "http://app2.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="some_id",
            groups={"company": "id:5", "instance": "app.posthog.com"},
            person_properties={"distinct_id": "override"},
            group_properties={
                "company": {"$group_key": "group_override"},
                "instance": {"$group_key": "app.posthog.com"},
            },
            geoip_disable=False,
            device_id=None,
            flag_keys_to_evaluate=["random_key"],
        )

        patch_flags.reset_mock()
        # test nones
        client.get_all_flags_and_payloads(
            "some_id", groups={}, person_properties=None, group_properties=None
        )
        patch_flags.assert_called_with(
            "random_key",
            "http://app2.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="some_id",
            groups={},
            person_properties={},
            group_properties={},
            geoip_disable=False,
            device_id=None,
        )

    @parameterized.expand(
        [
            # method, method_args, expected_person_props, expected_flag_keys
            (
                "get_feature_flag",
                ["random_key", "some_id"],
                {},
                ["random_key"],
            ),
            (
                "feature_enabled",
                ["random_key", "some_id"],
                {},
                ["random_key"],
            ),
            (
                "get_all_flags_and_payloads",
                ["some_id"],
                {},
                None,
            ),
            ("get_all_flags", ["some_id"], {}, None),
            ("get_flags_decision", ["some_id"], {}, None),
        ]
    )
    @mock.patch("posthog.client.flags")
    def test_device_id_is_passed_to_flags_request(
        self,
        method,
        method_args,
        expected_person_props,
        expected_flag_keys,
        patch_flags,
    ):
        """Test that device_id is properly passed to the flags request when provided."""
        patch_flags.return_value = {"featureFlags": {"beta-feature": "random-variant"}}
        client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail)

        getattr(client, method)(*method_args, device_id="test-device-123")

        expected_call = {
            "distinct_id": "some_id",
            "groups": {},
            "person_properties": expected_person_props,
            "group_properties": {},
            "geoip_disable": True,
            "device_id": "test-device-123",
        }
        if expected_flag_keys:
            expected_call["flag_keys_to_evaluate"] = expected_flag_keys

        patch_flags.assert_called_with(
            "random_key",
            "https://us.i.posthog.com",
            timeout=3,
            max_retries=1,
            **expected_call,
        )

    @mock.patch("posthog.client.flags")
    def test_device_id_from_context_is_used_in_flags_request(self, patch_flags):
        """Test that device_id from context is used in flags request when not explicitly provided."""
        from posthog.contexts import new_context, set_context_device_id

        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
            }
        }
        client = Client(
            FAKE_TEST_API_KEY,
            on_error=self.set_fail,
        )

        # Test that device_id from context is used
        with new_context():
            set_context_device_id("context-device-id")
            client.get_feature_flag("random_key", "some_id")
            patch_flags.assert_called_with(
                "random_key",
                "https://us.i.posthog.com",
                timeout=3,
                max_retries=1,
                distinct_id="some_id",
                groups={},
                person_properties={},
                group_properties={},
                geoip_disable=True,
                device_id="context-device-id",
                flag_keys_to_evaluate=["random_key"],
            )

        # Test that explicit device_id overrides context
        patch_flags.reset_mock()
        with new_context():
            set_context_device_id("context-device-id")
            client.get_feature_flag(
                "random_key", "some_id", device_id="explicit-device-id"
            )
            patch_flags.assert_called_with(
                "random_key",
                "https://us.i.posthog.com",
                timeout=3,
                max_retries=1,
                distinct_id="some_id",
                groups={},
                person_properties={},
                group_properties={},
                geoip_disable=True,
                device_id="explicit-device-id",
                flag_keys_to_evaluate=["random_key"],
            )

    @mock.patch("posthog.client.flags")
    def test_client_set_context_device_id_is_used_in_flags_request(self, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
            }
        }
        client = Client(
            FAKE_TEST_API_KEY,
            on_error=self.set_fail,
        )

        with client.new_context():
            client.set_context_device_id("client-context-device-id")
            client.get_feature_flag("random_key", "some_id")

        patch_flags.assert_called_with(
            "random_key",
            "https://us.i.posthog.com",
            timeout=3,
            max_retries=1,
            distinct_id="some_id",
            groups={},
            person_properties={},
            group_properties={},
            geoip_disable=True,
            device_id="client-context-device-id",
            flag_keys_to_evaluate=["random_key"],
        )

    @parameterized.expand(
        [
            # name, sys_platform, version_info, expected_runtime, expected_version, expected_os, expected_os_version, expected_os_distro, platform_method, platform_return
            (
                "macOS",
                "darwin",
                (3, 8, 10),
                "MockPython",
                "3.8.10",
                "Mac OS X",
                "10.15.7",
                None,
                "mac_ver",
                ("10.15.7", "", ""),
            ),
            (
                "Windows",
                "win32",
                (3, 8, 10),
                "MockPython",
                "3.8.10",
                "Windows",
                "10",
                None,
                "win32_ver",
                ("10", "", "", ""),
            ),
            (
                "Linux",
                "linux",
                (3, 8, 10),
                "MockPython",
                "3.8.10",
                "Linux",
                "20.04",
                "Ubuntu",
                None,
                None,
            ),
        ]
    )
    def test_mock_system_context(
        self,
        _name,
        sys_platform,
        version_info,
        expected_runtime,
        expected_version,
        expected_os,
        expected_os_version,
        expected_os_distro,
        platform_method,
        platform_return,
    ):
        """Test that we can mock platform and sys for testing system_context"""
        with mock.patch("posthog.utils.platform") as mock_platform:
            with mock.patch("posthog.utils.sys") as mock_sys:
                # Set up common mocks
                mock_platform.python_implementation.return_value = expected_runtime
                mock_sys.version_info = version_info
                mock_sys.platform = sys_platform

                # Set up platform-specific mocks
                if platform_method:
                    getattr(
                        mock_platform, platform_method
                    ).return_value = platform_return

                # Special handling for Linux which uses distro module
                if sys_platform == "linux":
                    with mock.patch("posthog.utils.distro") as mock_distro:
                        mock_distro.info.return_value = {"version": expected_os_version}
                        mock_distro.name.return_value = expected_os_distro or ""

                        from posthog.utils import system_context

                        context = system_context()
                else:
                    # Get system context for non-Linux platforms
                    from posthog.utils import system_context

                    context = system_context()

                # Verify results
                expected_context = {
                    "$python_runtime": expected_runtime,
                    "$python_version": expected_version,
                    "$os": expected_os,
                    "$os_version": expected_os_version,
                }

                if sys_platform == "linux":
                    expected_context["$os_distro"] = expected_os_distro

                assert context == expected_context

    @mock.patch("posthog.client.flags")
    def test_get_decide_returns_normalized_decide_response(self, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "random-variant",
                "alpha-feature": True,
                "off-feature": False,
            },
            "featureFlagPayloads": {"beta-feature": '{"some": "data"}'},
            "errorsWhileComputingFlags": False,
            "requestId": "test-id",
        }

        client = Client(FAKE_TEST_API_KEY)
        distinct_id = "test_distinct_id"
        groups = {"test_group_type": "test_group_id"}
        person_properties = {"test_property": "test_value"}

        response = client.get_flags_decision(distinct_id, groups, person_properties)

        assert response == {
            "flags": {
                "beta-feature": FeatureFlag(
                    key="beta-feature",
                    enabled=True,
                    variant="random-variant",
                    reason=None,
                    metadata=LegacyFlagMetadata(
                        payload='{"some": "data"}',
                    ),
                ),
                "alpha-feature": FeatureFlag(
                    key="alpha-feature",
                    enabled=True,
                    variant=None,
                    reason=None,
                    metadata=LegacyFlagMetadata(
                        payload=None,
                    ),
                ),
                "off-feature": FeatureFlag(
                    key="off-feature",
                    enabled=False,
                    variant=None,
                    reason=None,
                    metadata=LegacyFlagMetadata(
                        payload=None,
                    ),
                ),
            },
            "errorsWhileComputingFlags": False,
            "requestId": "test-id",
        }

    def test_set_context_session_with_capture(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with new_context():
                set_context_session("context-session-123")

                msg_uuid = client.capture(
                    "test_event",
                    distinct_id="distinct_id",
                    properties={"custom_prop": "value"},
                )

                self.assertIsNotNone(msg_uuid)

                # Get the enqueued message from the mock
                mock_post.assert_called_once()
                batch_data = mock_post.call_args[1]["batch"]
                msg = batch_data[0]

                self.assertEqual(
                    msg["properties"]["$session_id"], "context-session-123"
                )

    @parameterized.expand([("new_context",), ("scoped",)])
    def test_client_context_helpers_apply_to_capture(self, context_helper):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)

            def capture_in_context():
                client.tag("client_tag", "tag-value")
                client.identify_context("context-user")
                client.set_context_session("context-session-123")

                self.assertEqual(client.get_tags(), {"client_tag": "tag-value"})

                return client.capture(
                    "test_event",
                    properties={"custom_prop": "value"},
                )

            if context_helper == "new_context":
                with client.new_context(fresh=True):
                    msg_uuid = capture_in_context()
            else:

                @client.scoped(fresh=True)
                def scoped_capture():
                    return capture_in_context()

                msg_uuid = scoped_capture()

            self.assertIsNotNone(msg_uuid)
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["distinct_id"], "context-user")
            self.assertEqual(msg["properties"]["client_tag"], "tag-value")
            self.assertEqual(msg["properties"]["custom_prop"], "value")
            self.assertEqual(msg["properties"]["$session_id"], "context-session-123")
            self.assertCountEqual(msg["properties"]["$context_tags"], ["client_tag"])
            self.assertEqual(client.get_tags(), {})

    def test_client_scoped_context_helpers_apply_to_capture_async(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)

            @client.scoped(fresh=True)
            async def scoped_capture():
                client.tag("async_scoped_tag", "async-scoped-value")
                client.identify_context("async-scoped-user")
                client.set_context_session("async-scoped-session-123")
                await asyncio.sleep(0)
                return client.capture("async_scoped_event")

            msg_uuid = asyncio.run(scoped_capture())

            self.assertIsNotNone(msg_uuid)
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["distinct_id"], "async-scoped-user")
            self.assertEqual(
                msg["properties"]["async_scoped_tag"], "async-scoped-value"
            )
            self.assertEqual(
                msg["properties"]["$session_id"], "async-scoped-session-123"
            )
            self.assertCountEqual(
                msg["properties"]["$context_tags"], ["async_scoped_tag"]
            )
            self.assertEqual(client.get_tags(), {})

    def test_set_context_session_with_page_explicit_properties(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with new_context():
                set_context_session("page-explicit-session-789")

                properties = {
                    "$session_id": get_context_session_id(),
                    "page_type": "landing",
                }
                msg_uuid = client.capture(
                    "$page", distinct_id="distinct_id", properties=properties
                )

                self.assertIsNotNone(msg_uuid)

                # Get the enqueued message from the mock
                mock_post.assert_called_once()
                batch_data = mock_post.call_args[1]["batch"]
                msg = batch_data[0]

                self.assertEqual(
                    msg["properties"]["$session_id"], "page-explicit-session-789"
                )

    def test_set_context_session_override_in_capture(self):
        """Test that explicit session ID overrides context session ID in capture"""
        from posthog.contexts import new_context, set_context_session

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)
            with new_context():
                set_context_session("context-session-override")

                msg_uuid = client.capture(
                    "test_event",
                    distinct_id="distinct_id",
                    properties={
                        "$session_id": "explicit-session-override",
                        "custom_prop": "value",
                    },
                )

                self.assertIsNotNone(msg_uuid)

                # Get the enqueued message from the mock
                mock_post.assert_called_once()
                batch_data = mock_post.call_args[1]["batch"]
                msg = batch_data[0]

                self.assertEqual(
                    msg["properties"]["$session_id"], "explicit-session-override"
                )

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_enable_local_evaluation_false_disables_poller(
        self, patch_get, patch_poller
    ):
        """Test that when enable_local_evaluation=False, the poller is not started"""
        patch_get.return_value = GetResponse(
            data={
                "flags": [
                    {
                        "id": 1,
                        "name": "Beta Feature",
                        "key": "beta-feature",
                        "active": True,
                    }
                ],
                "group_type_mapping": {},
                "cohorts": {},
            },
            etag='"test-etag"',
        )

        client = Client(
            FAKE_TEST_API_KEY,
            secret_key="test-personal-key",
            enable_local_evaluation=False,
        )

        # Load feature flags should not start the poller
        client.load_feature_flags()

        # Assert that the poller was not created/started
        patch_poller.assert_not_called()
        # But the feature flags should still be loaded
        patch_get.assert_called_once()
        self.assertEqual(len(client.feature_flags), 1)
        self.assertEqual(client.feature_flags[0]["key"], "beta-feature")

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_enable_local_evaluation_true_starts_poller(self, patch_get, patch_poller):
        """Test that when enable_local_evaluation=True (default), the poller is started"""
        patch_get.return_value = GetResponse(
            data={
                "flags": [
                    {
                        "id": 1,
                        "name": "Beta Feature",
                        "key": "beta-feature",
                        "active": True,
                    }
                ],
                "group_type_mapping": {},
                "cohorts": {},
            },
            etag='"test-etag"',
        )

        client = Client(
            FAKE_TEST_API_KEY,
            secret_key="test-personal-key",
            enable_local_evaluation=True,
        )

        # Load feature flags should start the poller
        client.load_feature_flags()

        # Assert that the poller was created and started
        patch_poller.assert_called_once()
        patch_get.assert_called_once()
        self.assertEqual(len(client.feature_flags), 1)
        self.assertEqual(client.feature_flags[0]["key"], "beta-feature")

    @mock.patch("posthog.client.remote_config")
    def test_get_remote_config_payload_works_without_poller(self, patch_remote_config):
        """Test that get_remote_config_payload works without local evaluation enabled"""
        patch_remote_config.return_value = {"test": "payload"}

        client = Client(
            FAKE_TEST_API_KEY,
            secret_key="test-personal-key",
            enable_local_evaluation=False,
        )

        # Should work without poller
        result = client.get_remote_config_payload("test-flag")

        self.assertEqual(result, {"test": "payload"})
        patch_remote_config.assert_called_once_with(
            "test-personal-key",
            FAKE_TEST_API_KEY,
            client.host,
            "test-flag",
            timeout=client.feature_flags_request_timeout_seconds,
        )

    def test_get_remote_config_payload_requires_personal_api_key(self):
        """Test that get_remote_config_payload requires personal API key"""
        client = Client(
            FAKE_TEST_API_KEY,
            enable_local_evaluation=False,
        )

        result = client.get_remote_config_payload("test-flag")

        self.assertIsNone(result)

    def test_parse_send_feature_flags_method(self):
        """Test the _parse_send_feature_flags helper method"""
        client = Client(FAKE_TEST_API_KEY, sync_mode=True)

        # Test boolean True
        result = client._parse_send_feature_flags(True)
        expected = {
            "should_send": True,
            "only_evaluate_locally": None,
            "person_properties": None,
            "group_properties": None,
            "flag_keys_filter": None,
        }
        self.assertEqual(result, expected)

        # Test boolean False
        result = client._parse_send_feature_flags(False)
        expected = {
            "should_send": False,
            "only_evaluate_locally": None,
            "person_properties": None,
            "group_properties": None,
            "flag_keys_filter": None,
        }
        self.assertEqual(result, expected)

        # Test options dict with all fields
        options = {
            "only_evaluate_locally": True,
            "person_properties": {"plan": "premium"},
            "group_properties": {"company": {"type": "enterprise"}},
        }
        result = client._parse_send_feature_flags(options)
        expected = {
            "should_send": True,
            "only_evaluate_locally": True,
            "person_properties": {"plan": "premium"},
            "group_properties": {"company": {"type": "enterprise"}},
            "flag_keys_filter": None,
        }
        self.assertEqual(result, expected)

        # Test options dict with partial fields
        options = {"person_properties": {"user_id": "123"}}
        result = client._parse_send_feature_flags(options)
        expected = {
            "should_send": True,
            "only_evaluate_locally": None,
            "person_properties": {"user_id": "123"},
            "group_properties": None,
            "flag_keys_filter": None,
        }
        self.assertEqual(result, expected)

        # Test empty dict
        result = client._parse_send_feature_flags({})
        expected = {
            "should_send": True,
            "only_evaluate_locally": None,
            "person_properties": None,
            "group_properties": None,
            "flag_keys_filter": None,
        }
        self.assertEqual(result, expected)

        # Test invalid types
        with self.assertRaises(TypeError) as cm:
            client._parse_send_feature_flags("invalid")
        self.assertIn("Invalid type for send_feature_flags", str(cm.exception))

        with self.assertRaises(TypeError) as cm:
            client._parse_send_feature_flags(123)
        self.assertIn("Invalid type for send_feature_flags", str(cm.exception))

        with self.assertRaises(TypeError) as cm:
            client._parse_send_feature_flags(None)
        self.assertIn("Invalid type for send_feature_flags", str(cm.exception))

    @mock.patch("posthog.client.flags")
    def test_capture_with_send_feature_flags_flag_keys_filter(self, patch_flags):
        """Test that SendFeatureFlagsOptions with flag_keys_filter only evaluates specified flags"""
        # When flag_keys_to_evaluate is provided, the API should only return the requested flags
        patch_flags.return_value = {
            "featureFlags": {
                "flag1": "value1",
                "flag3": "value3",
            }
        }

        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(
                FAKE_TEST_API_KEY,
                on_error=self.set_fail,
                secret_key=FAKE_TEST_API_KEY,
                sync_mode=True,
            )

            send_options = {
                "flag_keys_filter": ["flag1", "flag3"],
                "person_properties": {"subscription": "pro"},
            }

            msg_uuid = client.capture(
                "test event", distinct_id="distinct_id", send_feature_flags=send_options
            )

            self.assertIsNotNone(msg_uuid)
            self.assertFalse(self.failed)

            # Verify flags() was called with flag_keys_to_evaluate
            patch_flags.assert_called_once()
            call_args = patch_flags.call_args[1]
            self.assertEqual(call_args["flag_keys_to_evaluate"], ["flag1", "flag3"])
            self.assertEqual(call_args["person_properties"], {"subscription": "pro"})

            # Check the message includes only the filtered flags
            mock_post.assert_called_once()
            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]

            self.assertEqual(msg["properties"]["$feature/flag1"], "value1")
            self.assertEqual(msg["properties"]["$feature/flag3"], "value3")
            # flag2 should not be included since it wasn't requested
            self.assertNotIn("$feature/flag2", msg["properties"])

    @mock.patch("posthog.client.batch_post")
    def test_get_feature_flag_result_with_empty_string_payload(self, patch_batch_post):
        """Test that get_feature_flag_result returns a FeatureFlagResult when payload is empty string"""
        client = Client(
            FAKE_TEST_API_KEY,
            secret_key="test_personal_api_key",
            sync_mode=True,
        )

        # Set up local evaluation with a flag that has empty string payload
        client.feature_flags = [
            {
                "id": 1,
                "name": "Test flag",
                "key": "test-flag",
                "is_simple_flag": False,
                "active": True,
                "rollout_percentage": None,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": None,
                            "variant": "empty-variant",
                        }
                    ],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "empty-variant",
                                "name": "Empty Variant",
                                "rollout_percentage": 100,
                            }
                        ]
                    },
                    "payloads": {"empty-variant": ""},  # Empty string payload
                },
            }
        ]

        # Test get_feature_flag_result
        result = client.get_feature_flag_result(
            "test-flag", "test-user", only_evaluate_locally=True
        )

        # Should return a FeatureFlagResult, not None
        self.assertIsNotNone(result)
        self.assertEqual(result.key, "test-flag")
        self.assertEqual(result.get_value(), "empty-variant")
        self.assertIsNone(result.payload)

    @mock.patch("posthog.client.batch_post")
    def test_get_all_flags_and_payloads_with_empty_string(self, patch_batch_post):
        """Test that get_all_flags_and_payloads includes flags with empty string payloads"""
        client = Client(
            FAKE_TEST_API_KEY,
            secret_key="test_personal_api_key",
            sync_mode=True,
        )

        # Set up multiple flags with different payload types
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag with empty payload",
                "key": "empty-payload-flag",
                "is_simple_flag": False,
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "variant": "variant1"}],
                    "multivariate": {
                        "variants": [{"key": "variant1", "rollout_percentage": 100}]
                    },
                    "payloads": {"variant1": ""},  # Empty string
                },
            },
            {
                "id": 2,
                "name": "Flag with normal payload",
                "key": "normal-payload-flag",
                "is_simple_flag": False,
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "variant": "variant2"}],
                    "multivariate": {
                        "variants": [{"key": "variant2", "rollout_percentage": 100}]
                    },
                    "payloads": {"variant2": '"normal payload"'},
                },
            },
        ]

        result = client.get_all_flags_and_payloads(
            "test-user", only_evaluate_locally=True
        )

        # Check that both flags are included
        self.assertEqual(result["featureFlags"]["empty-payload-flag"], "variant1")
        self.assertEqual(result["featureFlags"]["normal-payload-flag"], "variant2")

        self.assertIn("empty-payload-flag", result["featureFlagPayloads"])
        self.assertIsNone(result["featureFlagPayloads"]["empty-payload-flag"])
        self.assertEqual(
            result["featureFlagPayloads"]["normal-payload-flag"], '"normal payload"'
        )

    def test_context_tags_added(self):
        with mock.patch("posthog.client.batch_post") as mock_post:
            client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail, sync_mode=True)

            with new_context():
                tag("random_tag", 12345)
                client.capture("python test event", distinct_id="distinct_id")

            batch_data = mock_post.call_args[1]["batch"]
            msg = batch_data[0]
            self.assertEqual(msg["properties"]["$context_tags"], ["random_tag"])

    @mock.patch(
        "posthog.client.Client._enqueue", side_effect=Exception("Unexpected error")
    )
    def test_methods_handle_exceptions(self, mock_enqueue):
        """Test that all decorated methods handle exceptions gracefully."""
        client = Client("test-key")

        test_cases = [
            ("capture", ["test_event"], {}),
            ("set", [], {"distinct_id": "some-id", "properties": {"a": "b"}}),
            ("set_once", [], {"distinct_id": "some-id", "properties": {"a": "b"}}),
            ("group_identify", ["group-type", "group-key"], {}),
            ("alias", ["some-id", "new-id"], {}),
        ]

        for method_name, args, kwargs in test_cases:
            with self.subTest(method=method_name):
                method = getattr(client, method_name)
                result = method(*args, **kwargs)
                self.assertEqual(result, None)

    @mock.patch(
        "posthog.client.Client._enqueue", side_effect=Exception("Expected error")
    )
    def test_debug_flag_re_raises_exceptions(self, mock_enqueue):
        """Test that methods re-raise exceptions when debug=True."""
        client = Client("test-key", debug=True)

        test_cases = [
            ("capture", ["test_event"], {}),
            ("set", [], {"distinct_id": "some-id", "properties": {"a": "b"}}),
            ("set_once", [], {"distinct_id": "some-id", "properties": {"a": "b"}}),
            ("group_identify", ["group-type", "group-key"], {}),
            ("alias", ["some-id", "new-id"], {}),
        ]

        for method_name, args, kwargs in test_cases:
            with self.subTest(method=method_name):
                method = getattr(client, method_name)
                with self.assertRaises(Exception) as cm:
                    method(*args, **kwargs)
                self.assertEqual(str(cm.exception), "Expected error")


class TestClientCaptureRetrySemantics(unittest.TestCase):
    @parameterized.expand(
        [
            ("v0_sync", "v0", True),
            ("v1_sync", "v1", True),
            ("v0_async", "v0", False),
            ("v1_async", "v1", False),
        ]
    )
    def test_negative_max_retries_still_attempts_delivery_once(
        self, _name, capture_mode, sync_mode
    ):
        response = mock.Mock(status_code=200, headers={}, text="")
        response.json.return_value = {"results": {}}
        client = None

        with (
            mock.patch("posthog.client.batch_post") as sync_v0_post,
            mock.patch("posthog.consumer.batch_post") as async_v0_post,
            mock.patch("posthog.capture_v1._post_v1", return_value=response) as v1_post,
        ):
            try:
                client = Client(
                    FAKE_TEST_API_KEY,
                    capture_mode=capture_mode,
                    sync_mode=sync_mode,
                    max_retries=-1,
                    flush_at=1,
                    flush_interval=0.01,
                )
                client.capture("evt", distinct_id="d")
                if not sync_mode:
                    client.flush()

                self.assertEqual(client.max_retries, 0)
                if capture_mode == "v1":
                    v1_post.assert_called_once()
                    sync_v0_post.assert_not_called()
                    async_v0_post.assert_not_called()
                elif sync_mode:
                    sync_v0_post.assert_called_once()
                    async_v0_post.assert_not_called()
                    v1_post.assert_not_called()
                else:
                    async_v0_post.assert_called_once()
                    sync_v0_post.assert_not_called()
                    v1_post.assert_not_called()
            finally:
                if client is not None and not sync_mode:
                    client.shutdown()


class TestClientSyncCaptureMode(unittest.TestCase):
    """Sync-mode `_enqueue` selects the analytics submitter by `capture_mode`."""

    def _client(self, **kwargs):
        return Client(FAKE_TEST_API_KEY, sync_mode=True, **kwargs)

    @parameterized.expand(
        [
            ("v0", None, False),
            ("v1", "v1", True),
        ]
    )
    def test_capture_mode_selects_sync_submitter(self, _name, capture_mode, expects_v1):
        kwargs = {"capture_mode": capture_mode} if capture_mode else {}
        with (
            mock.patch("posthog.client.batch_post") as mock_post,
            mock.patch("posthog.client._send_v1_batch") as mock_v1,
        ):
            self._client(**kwargs).capture("evt", distinct_id="d")
        if expects_v1:
            mock_post.assert_not_called()
            mock_v1.assert_called_once()
            sent_batch = mock_v1.call_args.args[2]
            self.assertEqual(len(sent_batch), 1)
            self.assertEqual(sent_batch[0]["event"], "evt")
        else:
            mock_v1.assert_not_called()
            mock_post.assert_called_once()

    def test_v1_sync_forwards_config_to_submitter(self):
        with (
            mock.patch("posthog.client.batch_post"),
            mock.patch("posthog.client._send_v1_batch") as mock_v1,
        ):
            self._client(
                capture_mode="v1",
                capture_compression=CaptureCompression.GZIP,
                max_retries=4,
                historical_migration=True,
            ).capture("evt", distinct_id="d")
            kwargs = mock_v1.call_args.kwargs
            self.assertEqual(kwargs["compression"], CaptureCompression.GZIP)
            self.assertEqual(kwargs["max_retries"], 4)
            self.assertEqual(kwargs["historical_migration"], True)

    def test_v1_sync_gzip_flag_falls_back_to_gzip_compression(self):
        # Legacy `gzip=True` with no explicit capture_compression -> GZIP on v1.
        with (
            mock.patch("posthog.client.batch_post"),
            mock.patch("posthog.client._send_v1_batch") as mock_v1,
        ):
            self._client(capture_mode="v1", gzip=True).capture("evt", distinct_id="d")
            self.assertEqual(
                mock_v1.call_args.kwargs["compression"], CaptureCompression.GZIP
            )

    def test_v1_sync_ai_named_event_through_capture_uses_v1(self):
        # `capture()` never special-cases AI events: an `$ai_*`-named event
        # follows `capture_mode` and rides the v1 submitter like any analytics
        # event. Only `capture_ai()` reaches the AI lane.
        with (
            mock.patch("posthog.client.batch_post") as mock_post,
            mock.patch("posthog.client._send_v1_batch") as mock_v1,
        ):
            client = self._client(capture_mode="v1")
            client.capture("$ai_generation", distinct_id="d")
            mock_post.assert_not_called()
            mock_v1.assert_called_once()
            sent_batch = mock_v1.call_args.args[2]
            self.assertEqual(len(sent_batch), 1)
            self.assertEqual(sent_batch[0]["event"], "$ai_generation")
