"""
Routes for interacting with work queue objects.
"""

from typing import List, Optional
from uuid import UUID

from fastapi import (
    Body,
    Depends,
    Header,
    HTTPException,
    Path,
    status,
)
from sqlalchemy.exc import IntegrityError

import prefect.server.api.dependencies as dependencies
import prefect.server.models as models
import prefect.server.schemas as schemas
from prefect.server.database import (
    PrefectDBInterface,
    provide_database_interface,
)
from prefect.server.models.deployments import mark_deployments_ready
from prefect.server.models.work_queues import (
    emit_work_queue_status_event,
    mark_work_queues_ready,
)
from prefect.server.schemas.statuses import WorkQueueStatus
from prefect.server.utilities.server import PrefectRouter
from prefect.types import DateTime

router: PrefectRouter = PrefectRouter(prefix="/work_queues", tags=["Work Queues"])


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_work_queue(
    work_queue: schemas.actions.WorkQueueCreate,
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> schemas.responses.WorkQueueResponse:
    """
    Creates a new work queue.

    If a work queue with the same name already exists, an error
    will be raised.

    For more information, see https://docs.prefect.io/v3/concepts/work-pools#work-queues.
    """

    try:
        async with db.session_context(begin_transaction=True) as session:
            model = await models.work_queues.create_work_queue(
                session=session, work_queue=work_queue
            )

            response = schemas.responses.WorkQueueResponse.model_validate(
                model, from_attributes=True
            )
            if response.concurrency_limit is not None:
                response.active_slots = 0
    except IntegrityError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A work queue with this name already exists.",
        )

    return response


@router.patch("/{id:uuid}", status_code=status.HTTP_204_NO_CONTENT)
async def update_work_queue(
    work_queue: schemas.actions.WorkQueueUpdate,
    work_queue_id: UUID = Path(..., description="The work queue id", alias="id"),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> None:
    """
    Updates an existing work queue.
    """
    async with db.session_context(begin_transaction=True) as session:
        result = await models.work_queues.update_work_queue(
            session=session,
            work_queue_id=work_queue_id,
            work_queue=work_queue,
            emit_status_change=emit_work_queue_status_event,
        )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail=f"Work Queue {id} not found"
        )


@router.get("/name/{name}")
async def read_work_queue_by_name(
    name: str = Path(..., description="The work queue name"),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> schemas.responses.WorkQueueResponse:
    """
    Get a work queue by id.
    """
    async with db.session_context() as session:
        work_queue = await models.work_queues.read_work_queue_by_name(
            session=session, name=name
        )
        if not work_queue:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="work queue not found"
            )
        response = schemas.responses.WorkQueueResponse.model_validate(
            work_queue, from_attributes=True
        )
        if response.concurrency_limit is not None:
            response.active_slots = (
                await models.work_queues.count_work_queue_active_slots(
                    session=session, work_queue_id=work_queue.id
                )
            )
    return response


@router.get("/{id:uuid}")
async def read_work_queue(
    work_queue_id: UUID = Path(..., description="The work queue id", alias="id"),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> schemas.responses.WorkQueueResponse:
    """
    Get a work queue by id.
    """
    async with db.session_context() as session:
        work_queue = await models.work_queues.read_work_queue(
            session=session, work_queue_id=work_queue_id
        )
        if not work_queue:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="work queue not found"
            )
        response = schemas.responses.WorkQueueResponse.model_validate(
            work_queue, from_attributes=True
        )
        if response.concurrency_limit is not None:
            response.active_slots = (
                await models.work_queues.count_work_queue_active_slots(
                    session=session, work_queue_id=work_queue_id
                )
            )
    return response


@router.post("/{id:uuid}/get_runs")
async def read_work_queue_runs(
    docket: dependencies.Docket,
    work_queue_id: UUID = Path(..., description="The work queue id", alias="id"),
    limit: int = dependencies.LimitBody(),
    scheduled_before: DateTime = Body(
        None,
        description=(
            "Only flow runs scheduled to start before this time will be returned."
        ),
    ),
    x_prefect_ui: Optional[bool] = Header(
        default=False,
        description="A header to indicate this request came from the Prefect UI.",
    ),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> List[schemas.responses.FlowRunResponse]:
    """
    Get flow runs from the work queue.
    """
    async with db.session_context(begin_transaction=True) as session:
        work_queue, flow_runs = await models.work_queues.get_runs_in_work_queue(
            session=session,
            work_queue_id=work_queue_id,
            scheduled_before=scheduled_before,
            limit=limit,
        )

    # The Prefect UI often calls this route to see which runs are enqueued.
    # We do not want to record this as an actual poll event.
    if x_prefect_ui:
        return flow_runs

    await docket.add(
        mark_work_queues_ready,
        key=f"mark_work_queues_ready:{work_queue_id}",
    )(
        polled_work_queue_ids=[work_queue_id],
        ready_work_queue_ids=(
            [work_queue_id] if work_queue.status == WorkQueueStatus.NOT_READY else []
        ),
    )

    await docket.add(
        mark_deployments_ready,
        key=f"mark_deployments_ready:work_queue:{work_queue_id}",
    )(
        work_queue_ids=[work_queue_id],
    )

    return flow_runs


@router.post("/filter")
async def read_work_queues(
    limit: int = dependencies.LimitBody(),
    offset: int = Body(0, ge=0),
    work_queues: Optional[schemas.filters.WorkQueueFilter] = None,
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> List[schemas.responses.WorkQueueResponse]:
    """
    Query for work queues.
    """
    async with db.session_context() as session:
        wqs = await models.work_queues.read_work_queues(
            session=session, offset=offset, limit=limit, work_queue_filter=work_queues
        )

        ret = [
            schemas.responses.WorkQueueResponse.model_validate(wq, from_attributes=True)
            for wq in wqs
        ]
        queues_with_limit = [wq for wq in ret if wq.concurrency_limit is not None]
        if queues_with_limit:
            slot_counts = await models.work_queues.count_work_queue_active_slots_bulk(
                session=session,
                work_queue_ids=[wq.id for wq in queues_with_limit],
            )
            for wq_response in queues_with_limit:
                wq_response.active_slots = slot_counts.get(wq_response.id, 0)

    return ret


@router.delete("/{id:uuid}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_work_queue(
    work_queue_id: UUID = Path(..., description="The work queue id", alias="id"),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> None:
    """
    Delete a work queue by id.
    """
    async with db.session_context(begin_transaction=True) as session:
        result = await models.work_queues.delete_work_queue(
            session=session, work_queue_id=work_queue_id
        )
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="work queue not found"
        )


@router.post("/{id:uuid}/concurrency_status")
async def read_work_queue_concurrency_status(
    work_queue_id: UUID = Path(..., description="The work queue id", alias="id"),
    page: int = Body(1, ge=1),
    limit: int = dependencies.LimitBody(),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> schemas.responses.WorkQueueConcurrencyStatus:
    """
    Read concurrency status for a work queue, including paginated flow run
    summaries. active_slots always reflects the total count.
    """
    import asyncio

    from prefect.types._datetime import now as prefect_now

    run_offset = (page - 1) * limit

    async with db.session_context() as session:
        work_queue = await models.work_queues.read_work_queue(
            session=session, work_queue_id=work_queue_id
        )
        if not work_queue:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Work queue not found.",
            )

        # Count and paginated fetch in parallel
        total_count, slot_holders_page = await asyncio.gather(
            models.workers.count_work_queue_slot_holders(
                session=session, work_queue_id=work_queue_id
            ),
            models.workers.get_work_queue_slot_holders(
                session=session,
                work_queue_id=work_queue_id,
                offset=run_offset,
                limit=limit,
            ),
        )

    current_time = prefect_now("UTC")

    flow_runs = [
        schemas.responses.FlowRunSlotSummary(
            id=run.id,
            name=run.name,
            state_type=run.state_type if run.state_type else None,
            state_name=run.state_name if run.state_name else None,
            start_time=run.start_time,
            state_timestamp=run.state_timestamp,
            time_in_current_state=(
                (current_time - run.state_timestamp) if run.state_timestamp else None
            ),
        )
        for run, slot_acquired_at in slot_holders_page
    ]

    return schemas.responses.WorkQueueConcurrencyStatus(
        active_slots=total_count,
        concurrency_limit=work_queue.concurrency_limit,
        flow_runs=flow_runs,
        count=total_count,
        limit=limit,
        pages=(total_count + limit - 1) // limit if limit > 0 else 0,
        page=page,
    )


@router.get("/{id:uuid}/status")
async def read_work_queue_status(
    work_queue_id: UUID = Path(..., description="The work queue id", alias="id"),
    db: PrefectDBInterface = Depends(provide_database_interface),
) -> schemas.core.WorkQueueStatusDetail:
    """
    Get the status of a work queue.
    """
    async with db.session_context() as session:
        work_queue_status = await models.work_queues.read_work_queue_status(
            session=session, work_queue_id=work_queue_id
        )
    return work_queue_status
