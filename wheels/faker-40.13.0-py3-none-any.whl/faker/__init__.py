from faker.factory import Factory
from faker.generator import Generator
from faker.proxy import Faker

VERSION = "40.13.0"

__all__ = ("Factory", "Generator", "Faker")
