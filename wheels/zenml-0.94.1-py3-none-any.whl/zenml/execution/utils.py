#  Copyright (c) ZenML GmbH 2026. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at:
#
#       https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
#  or implied. See the License for the specific language governing
#  permissions and limitations under the License.
"""Execution utilities."""

import contextvars

from zenml.utils import context_utils


class DebugModeContext(context_utils.BaseContext):
    """Context manager for enabling debug mode.

    When debug mode is enabled, a local orchestrator is used instead of the
    actual orchestrator.
    """

    __context_var__ = contextvars.ContextVar("debug_mode_context")
