class LifespanNotSupported(Exception):
    pass
