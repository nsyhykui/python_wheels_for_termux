from __future__ import annotations

import functools
from collections.abc import Sequence
from typing import Any, Callable, cast

from fakeredis import _msgs as msgs
from fakeredis._command_args_parsing import Int, Timeout, extract_args, parse_mpop_args
from fakeredis._commands import Key, command
from fakeredis._core import CommandItem
from fakeredis._helpers import OK, SimpleError, SimpleString, casematch, fix_range
from fakeredis.commands_mixins._mixin_base import CommandsMixinBase


def _list_pop_count(get_slice: Callable[[int], slice], key: CommandItem, count: int) -> list[bytes] | None:
    if not key:
        return None
    elif type(key.value) is not list:
        raise SimpleError(msgs.WRONGTYPE_MSG)
    slc = get_slice(count)
    ret = key.value[slc]
    del key.value[slc]
    key.updated()
    return ret


def _list_pop(get_slice: Callable[[int], slice], key: CommandItem, *args: bytes) -> bytes | list[bytes] | None:
    """Implements lpop and rpop.

    `get_slice` must take a count and return a slice expression for the range to pop.
    """
    # This implementation is somewhat contorted to match the odd behaviours described in
    # https://github.com/redis/redis/issues/9680.
    count = 1
    if len(args) > 1:
        raise SimpleError(msgs.SYNTAX_ERROR_MSG)
    elif len(args) == 1:
        count = Int.decode(args[0], msgs.INDEX_NEGATIVE_ERROR_MSG)
        if count < 0:
            raise SimpleError(msgs.INDEX_NEGATIVE_ERROR_MSG)
    ret = _list_pop_count(get_slice, key, count)
    if ret and not args:
        return ret[0]
    return ret


def _parse_list_end(where: bytes) -> bool:
    """Parse a LEFT/RIGHT argument, returning True for LEFT."""
    if casematch(where, b"left"):
        return True
    if casematch(where, b"right"):
        return False
    raise SimpleError(msgs.SYNTAX_ERROR_MSG)


def _parse_lmovem_options(args: tuple[bytes, ...]) -> tuple[bool, int, bool]:
    """Parse the optional `<COUNT | EXACTLY> count <OBO | BULK>` trailer of [B]LMOVEM.

    Returns (exactly, count, one_by_one). Without the trailer a single element is moved.
    """
    if not args:
        return False, 1, False
    if len(args) != 3:
        raise SimpleError(msgs.SYNTAX_ERROR_MSG)
    if casematch(args[0], b"count"):
        exactly = False
    elif casematch(args[0], b"exactly"):
        exactly = True
    else:
        raise SimpleError(msgs.SYNTAX_ERROR_MSG)
    count = Int.decode(args[1], msgs.COUNT_GREATER_THAN_ZERO_MSG)
    if count < 1:
        raise SimpleError(msgs.COUNT_GREATER_THAN_ZERO_MSG)
    if casematch(args[2], b"obo"):
        one_by_one = True
    elif casematch(args[2], b"bulk"):
        one_by_one = False
    else:
        raise SimpleError(msgs.SYNTAX_ERROR_MSG)
    return exactly, count, one_by_one


def _lmovem(
    src: CommandItem,
    dst: CommandItem,
    from_left: bool,
    to_left: bool,
    exactly: bool,
    count: int,
    one_by_one: bool,
    first_pass: bool,
) -> list[bytes] | None:
    """Move elements for [B]LMOVEM, returning them in destination order, or None if nothing could be moved.

    A missing, empty or (EXACTLY) too short source moves nothing, and is checked before the destination's type.
    """
    if src.value is not None and not isinstance(src.value, list):
        if first_pass:
            raise SimpleError(msgs.WRONGTYPE_MSG)
        return None
    src_len = len(src.value) if src.value else 0
    if src_len < (count if exactly else 1):
        return None
    if dst.value is not None and not isinstance(dst.value, list):
        raise SimpleError(msgs.WRONGTYPE_MSG)
    n = min(count, src_len)
    source: list[bytes] = cast(list[bytes], src.value)
    if from_left:
        popped = source[:n]
        del source[:n]
    else:
        popped = source[: -n - 1 : -1]
        del source[-n:]
    # One by one, each element lands beyond the previous one, so a head push reverses the popped order. In bulk, the
    # block keeps the elements' relative order in the source, which is the reverse of the order they were popped
    # from the tail.
    moved = popped[::-1] if (to_left if one_by_one else not from_left) else popped
    target = dst.value if dst.value is not None else []  # the source itself when both name the same key
    if to_left:
        target[0:0] = moved
    else:
        target.extend(moved)
    src.updated()
    dst.update(target)
    return moved


class ListCommandsMixin(CommandsMixinBase):
    def _bpop_pass(self, keys: list[bytes], op: Callable[[list[bytes]], bytes], first_pass: bool) -> list[bytes] | None:
        for key in keys:
            item = CommandItem(key, self._db, item=self._db.get(key), default=[])
            if not isinstance(item.value, list):
                if first_pass:
                    raise SimpleError(msgs.WRONGTYPE_MSG)
                else:
                    continue
            if item.value:
                ret = op(item.value)
                item.updated()
                item.writeback()
                return [key, ret]
        return None

    def _bpop(self, args: Any, op: Callable[[list[bytes]], bytes]) -> Any:
        keys = args[:-1]
        timeout = Timeout.decode(args[-1])
        return self._blocking(timeout, functools.partial(self._bpop_pass, keys, op), self._empty_blocking_reply)

    @command((bytes, bytes), (bytes,), flags=msgs.FLAG_NO_SCRIPT)
    def blpop(self, *args: bytes) -> Any:
        return self._bpop(args, lambda lst: lst.pop(0))

    @command((bytes, bytes), (bytes,), flags=msgs.FLAG_NO_SCRIPT)
    def brpop(self, *args: bytes) -> Any:
        return self._bpop(args, lambda lst: lst.pop())

    def _brpoplpush_pass(self, source: bytes, destination: bytes, first_pass: bool) -> Any:
        src = CommandItem(source, self._db, item=self._db.get(source), default=[])
        if not isinstance(src.value, list):
            if first_pass:
                raise SimpleError(msgs.WRONGTYPE_MSG)
            else:
                return None
        if not src.value:
            return None  # Empty list
        dst = CommandItem(destination, self._db, item=self._db.get(destination), default=[])
        if not isinstance(dst.value, list):
            raise SimpleError(msgs.WRONGTYPE_MSG)
        el = src.value.pop()
        dst.value.insert(0, el)
        src.updated()
        src.writeback()
        if destination != source:
            # Ensure writeback only happens once
            dst.updated()
            dst.writeback()
        return el

    @command(name="BRPOPLPUSH", fixed=(bytes, bytes, Timeout), flags=msgs.FLAG_NO_SCRIPT)
    def brpoplpush(self, source: bytes, destination: bytes, timeout: float) -> Any:
        return self._blocking(timeout, functools.partial(self._brpoplpush_pass, source, destination))

    @command((Key(list, None), Int))
    def lindex(self, key: CommandItem, index: int) -> Any:
        try:
            return key.value[index]
        except IndexError:
            return None

    @command((Key(list), bytes, bytes, bytes))
    def linsert(self, key: CommandItem, where: bytes, pivot: bytes, value: bytes) -> int:
        if not casematch(where, b"before") and not casematch(where, b"after"):
            raise SimpleError(msgs.SYNTAX_ERROR_MSG)
        if not key:
            return 0
        else:
            try:
                index = key.value.index(pivot)
            except ValueError:
                return -1
            if casematch(where, b"after"):
                index += 1
            key.value.insert(index, value)
            key.updated()
            return len(key.value)

    @command((Key(list),))
    def llen(self, key: CommandItem) -> int:
        return len(key.value)

    def _lmove(
        self,
        first_list: CommandItem,
        second_list: CommandItem,
        src: bytes,
        dst: bytes,
        first_pass: bool,
    ) -> Any:
        if (not casematch(src, b"left") and not casematch(src, b"right")) or (
            not casematch(dst, b"left") and not casematch(dst, b"right")
        ):
            raise SimpleError(msgs.SYNTAX_ERROR_MSG)

        el = self.rpop(first_list) if casematch(src, b"RIGHT") else self.lpop(first_list)
        self.lpush(second_list, el) if casematch(dst, b"LEFT") else self.rpush(second_list, el)
        return el

    @command((Key(list, None), Key(list), SimpleString, SimpleString))
    def lmove(self, first_list: CommandItem, second_list: CommandItem, src: bytes, dst: bytes) -> Any:
        return self._lmove(first_list, second_list, src, dst, False)

    @command((Key(list, None), Key(list), SimpleString, SimpleString, Timeout))
    def blmove(
        self,
        first_list: CommandItem,
        second_list: CommandItem,
        src: bytes,
        dst: bytes,
        timeout: float,
    ) -> Any:
        return self._blocking(timeout, functools.partial(self._lmove, first_list, second_list, src, dst))

    @command(name="LMOVEM", fixed=(Key(), Key(), bytes, bytes), repeat=(bytes,), server_types=("redis",))
    def lmovem(self, src: CommandItem, dst: CommandItem, wherefrom: bytes, whereto: bytes, *args: bytes) -> Any:
        """LMOVEM source destination <LEFT | RIGHT> <LEFT | RIGHT> [<COUNT count | EXACTLY count> <OBO | BULK>]"""
        from_left, to_left = _parse_list_end(wherefrom), _parse_list_end(whereto)
        exactly, count, one_by_one = _parse_lmovem_options(args)
        return _lmovem(src, dst, from_left, to_left, exactly, count, one_by_one, True)

    def _blmovem_pass(
        self,
        source: bytes,
        destination: bytes,
        from_left: bool,
        to_left: bool,
        exactly: bool,
        count: int,
        one_by_one: bool,
        first_pass: bool,
    ) -> list[bytes] | None:
        src = CommandItem(source, self._db, item=self._db.get(source))
        dst = src if destination == source else CommandItem(destination, self._db, item=self._db.get(destination))
        moved = _lmovem(src, dst, from_left, to_left, exactly, count, one_by_one, first_pass)
        if moved is not None:
            src.writeback()
            if dst is not src:
                dst.writeback()
        return moved

    @command(name="BLMOVEM", fixed=(bytes, bytes, bytes, bytes, bytes), repeat=(bytes,), server_types=("redis",))
    def blmovem(
        self, source: bytes, destination: bytes, wherefrom: bytes, whereto: bytes, timeout: bytes, *args: bytes
    ) -> Any:
        """BLMOVEM source destination <LEFT | RIGHT> <LEFT | RIGHT> timeout [<COUNT count | EXACTLY count> <OBO | BULK>]

        Blocks until the source holds an element, or with EXACTLY until it holds `count` of them.
        """
        from_left, to_left = _parse_list_end(wherefrom), _parse_list_end(whereto)
        timeout_secs = Timeout.decode(timeout)
        exactly, count, one_by_one = _parse_lmovem_options(args)
        return self._blocking(
            timeout_secs,
            functools.partial(self._blmovem_pass, source, destination, from_left, to_left, exactly, count, one_by_one),
        )

    @command(fixed=(Key(),), repeat=(bytes,))
    def lpop(self, key: CommandItem, *args: bytes) -> bytes | list[bytes] | None:
        return _list_pop(lambda count: slice(None, count), key, *args)

    def _lmpop(self, keys: Sequence[bytes], count: int, direction_left: bool, first_pass: bool) -> list[Any] | None:
        if direction_left:
            op = lambda count: slice(None, count)
        else:
            op = lambda count: slice(None, -count - 1, -1)

        for key in keys:
            item = CommandItem(key, self._db, item=self._db.get(key), default=[])
            res = _list_pop_count(op, item, count)
            if res:
                return [key, res]
            # Dragonfly allows COUNT 0, which names the first existing key but pops nothing.
            if count == 0 and item.value and self.server_type == "dragonfly":
                return [key, []]
        return None

    @command(fixed=(Int,), repeat=(bytes,))
    def lmpop(self, numkeys: int, *args: bytes) -> list[Any] | None:
        keys, count, left = parse_mpop_args("lmpop", numkeys, args, ("left", "right"), self.server_type)
        return self._lmpop(keys, count, left, False)

    @command(fixed=(Timeout, Int), repeat=(bytes,))
    def blmpop(self, timeout: float, numkeys: int, *args: bytes) -> Any:
        keys, count, left = parse_mpop_args("blmpop", numkeys, args, ("left", "right"), self.server_type)
        return self._blocking(
            timeout,
            functools.partial(self._lmpop, keys, count, left),
        )

    @command((Key(list), bytes), (bytes,))
    def lpush(self, key: CommandItem, *values: bytes) -> int:
        for value in values:
            key.value.insert(0, value)
        key.updated()
        return len(key.value)

    @command((Key(list), bytes), (bytes,))
    def lpushx(self, key: CommandItem, *values: bytes) -> Any:
        if not key:
            return 0
        return self.lpush(key, *values)

    @command((Key(list), Int, Int))
    def lrange(self, key: CommandItem, start: int, stop: int) -> Any:
        start, stop = fix_range(start, stop, len(key.value))
        return key.value[start:stop]

    @command((Key(list), Int, bytes))
    def lrem(self, key: CommandItem, count: int, value: bytes) -> int:
        a_list = key.value
        found = []
        for i, el in enumerate(a_list):
            if el == value:
                found.append(i)
        if count > 0:
            indices_to_remove = found[:count]
        elif count < 0:
            indices_to_remove = found[count:]
        else:
            indices_to_remove = found
        # Iterating in reverse order to ensure the indices remain valid during deletion.
        for index in reversed(indices_to_remove):
            del a_list[index]
        if indices_to_remove:
            key.updated()
        return len(indices_to_remove)

    @command((Key(list), bytes, bytes))
    def lset(self, key: CommandItem, index: bytes, value: bytes) -> SimpleString:
        if not key:
            raise SimpleError(msgs.NO_KEY_MSG)
        idx = Int.decode(index)
        try:
            key.value[idx] = value
            key.updated()
        except IndexError:
            raise SimpleError(msgs.INDEX_ERROR_MSG)
        return OK

    @command((Key(list), Int, Int))
    def ltrim(self, key: CommandItem, start: int, stop: int) -> SimpleString:
        if key:
            end: int | None = None if stop == -1 else stop + 1
            new_value = key.value[start:end]
            # Redis signals the key as modified even for a no-op trim (see test_watch_when_ltrim_does_not_change_value),
            # so always update.
            key.update(new_value)
        return OK

    @command(fixed=(Key(),), repeat=(bytes,))
    def rpop(self, key: CommandItem, *args: bytes) -> bytes | list[bytes] | None:
        return _list_pop(lambda count: slice(None, -count - 1, -1), key, *args)

    @command((Key(list, None), Key(list)))
    def rpoplpush(self, src: CommandItem, dst: CommandItem) -> Any:
        el = self.rpop(src)
        self.lpush(dst, el)
        return el

    @command((Key(list), bytes), (bytes,))
    def rpush(self, key: CommandItem, *values: bytes) -> int:
        for value in values:
            key.value.append(value)
        key.updated()
        return len(key.value)

    @command((Key(list), bytes), (bytes,))
    def rpushx(self, key: CommandItem, *values: bytes) -> Any:
        if not key:
            return 0
        return self.rpush(key, *values)

    @command(fixed=(Key(list), bytes), repeat=(bytes,))
    def lpos(self, key: CommandItem, elem: bytes, *args: bytes) -> None | int | list[int]:
        (rank, count, maxlen), _ = extract_args(
            args,
            (
                "+rank",
                "+count",
                "+maxlen",
            ),
        )
        # Dragonfly validates these while decoding them, so all three report the generic integer error rather than
        # naming the offending option.
        is_dragonfly = self.server_type == "dragonfly"
        if rank == 0:
            raise SimpleError(msgs.INVALID_INT_MSG if is_dragonfly else msgs.LPOS_RANK_CAN_NOT_BE_ZERO)
        if count is not None and count < 0:
            raise SimpleError(msgs.INVALID_INT_MSG if is_dragonfly else msgs.LPOS_COUNT_NEGATIVE_MSG)
        if maxlen is not None and maxlen < 0:
            raise SimpleError(msgs.INVALID_INT_MSG if is_dragonfly else msgs.LPOS_MAXLEN_NEGATIVE_MSG)
        rank = rank or 1
        ind, direction = (0, 1) if rank > 0 else (len(key.value) - 1, -1)
        rank = abs(rank)
        parse_count = len(key.value) if count == 0 else (count or 1)
        maxlen = maxlen or len(key.value)
        res: list[int] = []
        comparisons = 0
        while 0 <= ind <= len(key.value) - 1 and len(res) < parse_count and comparisons < maxlen:
            comparisons += 1
            if key.value[ind] == elem:
                if rank > 1:
                    rank -= 1
                else:
                    res.append(ind)
            ind += direction
        if len(res) == 0 and count is None:
            return None
        if len(res) == 1 and count is None:
            return res[0]
        return res
