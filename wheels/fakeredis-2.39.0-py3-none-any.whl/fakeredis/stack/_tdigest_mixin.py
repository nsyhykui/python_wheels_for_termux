from __future__ import annotations

from typing import Any

from fakeredis import _msgs as msgs
from fakeredis._command_args_parsing import Float, Int, extract_args
from fakeredis._commands import Key, command
from fakeredis._core import CommandItem
from fakeredis._helpers import OK, SimpleError, SimpleString
from fakeredis.commands_mixins._mixin_base import CommandsMixinBase
from fakeredis.model import TDigest


class TDigestCommandsMixin(CommandsMixinBase):
    @command(
        name="TDIGEST.CREATE",
        fixed=(Key(TDigest),),
        repeat=(bytes,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_create(self, key: CommandItem, *args: bytes) -> SimpleString:
        if key.value is not None:
            raise SimpleError(msgs.TDIGEST_KEY_EXISTS)
        (compression,), _left_args = extract_args(args, ("+compression",))
        if compression is None:
            compression = 100
        key.update(TDigest(compression))
        return OK

    @command(
        name="TDIGEST.RESET",
        fixed=(Key(TDigest),),
        repeat=(),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_reset(self, key: CommandItem) -> SimpleString:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        key.value.clear()
        return OK

    @command(
        name="TDIGEST.ADD",
        fixed=(Key(TDigest), Float),
        repeat=(Float,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_add(self, key: CommandItem, *values: float) -> SimpleString:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        # parsing
        try:
            values_to_add = [float(val) for val in values]
        except ValueError:
            raise SimpleError(msgs.TDIGEST_ERROR_PARSING_VALUE)
        # adding
        key.value.update(values_to_add)
        return OK

    @command(
        name="TDIGEST.MERGE",
        fixed=(Key(TDigest), Int, bytes),
        repeat=(bytes,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_merge(self, dest: CommandItem, numkeys: int, *args: bytes) -> SimpleString:
        if len(args) < numkeys:
            raise SimpleError(msgs.WRONG_ARGS_MSG6.format("tdigest.merge"))
        sources_names = args[:numkeys]
        (compression, override), _ = extract_args(args[numkeys:], ("+compression", "override"))
        sources: list[TDigest] = [self._db.get(name).value for name in sources_names if name in self._db]  # type:ignore
        if len(sources) != len(sources_names):
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)

        if dest.value is None:
            compression = compression or max([source.compression for source in sources])
            dest.value = TDigest(compression)
        elif override:
            dest.value.clear()
        for source in sources:
            dest.value.update(source)
        dest.updated()
        return OK

    @command(
        name="TDIGEST.MAX", fixed=(Key(TDigest),), repeat=(), flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL
    )
    def tdigest_max(self, key: CommandItem) -> float:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if len(key.value) == 0:
            return float("nan")
        val: float = key.value[-1]
        return val

    @command(
        name="TDIGEST.MIN", fixed=(Key(TDigest),), repeat=(), flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL
    )
    def tdigest_min(self, key: CommandItem) -> float:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if len(key.value) == 0:
            return float("nan")
        val: float = key.value[0]
        return val

    @command(
        name="TDIGEST.RANK",
        fixed=(Key(TDigest), Float),
        repeat=(Float,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_rank(self, key: CommandItem, *values: float) -> list[int]:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if len(key.value) == 0:
            return [
                -2,
            ]
        res = []
        for v in values:
            if v > key.value[-1]:
                res.append(len(key.value))
            else:
                res.append(key.value.bisect_right(v) - 1)
        return res

    @command(
        name="TDIGEST.REVRANK",
        fixed=(Key(TDigest), Float),
        repeat=(Float,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_revrank(self, key: CommandItem, *values: float) -> list[int]:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if len(key.value) == 0:
            return [-2]
        res = []
        length = len(key.value)
        for v in values:
            loc = key.value.bisect_right(v)
            if loc == length:
                loc += 1
            res.append(length - loc)
        return res

    @command(
        name="TDIGEST.QUANTILE",
        fixed=(Key(TDigest), Float),
        repeat=(Float,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_quantile(self, key: CommandItem, *quantiles: float) -> list[float]:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if any(q < 0 or q > 1 for q in quantiles):
            raise SimpleError(msgs.TDIGEST_BAD_QUANTILE)
        # Before redis 8.10, a digest holding a single observation had no quantiles either.
        single_is_nan = self.server_type != "redis" or self.version < (8, 10)
        if len(key.value) == 0 or (len(key.value) == 1 and single_is_nan):
            return [float("nan")] * len(quantiles)
        res: list[float] = []
        for q in quantiles:
            ind = int(q * len(key.value))
            if ind == len(key.value):
                ind -= 1
            res.append(key.value[ind])
        return res

    @command(
        name="TDIGEST.CDF",
        fixed=(Key(TDigest), Float),
        repeat=(Float,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_cdf(self, key: CommandItem, *values: float) -> list[float]:  # Cumulative Distribution Function
        """Returns, for each input value, an estimation of the fraction (floating-point) of
        (observations smaller than the given value + half the observations equal to the given value).
        """
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        res: list[float] = []
        for v in values:
            left = key.value.bisect_left(v)
            right = key.value.bisect_right(v)
            if right == 0:
                res.append(0.0)
            elif left == len(key.value):
                res.append(1.0)
            else:
                res.append(float((left + right) / 2) / len(key.value))
        return res

    @command(
        name="TDIGEST.INFO", fixed=(Key(TDigest),), repeat=(), flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL
    )
    def tdigest_info(self, key: CommandItem) -> dict[bytes, Any]:
        return {
            b"Compression": key.value.compression,
            b"Capacity": len(key.value),
            b"Merged nodes": len(key.value),
            b"Unmerged nodes": 0,
            b"Merged weight": len(key.value),
            b"Unmerged weight": 0,
            b"Observations": len(key.value),
            b"Total compressions": len(key.value),
            b"Memory usage": len(key.value),
        }

    @command(
        name="TDIGEST.TRIMMED_MEAN",
        fixed=(Key(TDigest), Float, Float),
        repeat=(),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_trimmed_mean(self, key: CommandItem, lower: float, upper: float) -> float:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if lower < 0 or upper > 1 or lower > upper:
            raise SimpleError(msgs.TDIGEST_BAD_QUANTILE)
        if len(key.value) == 0:
            return float("nan")
        left = int(lower * len(key.value))
        right = int(upper * len(key.value))
        res: float = key.value[(left + right) // 2]
        if right == left + 1:
            res = (res + key.value[right]) / 2
        return res

    @command(
        name="TDIGEST.BYRANK",
        fixed=(Key(TDigest), Int),
        repeat=(Int,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_byrank(self, key: CommandItem, *ranks: int) -> list[float]:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if len(key.value) == 0:
            return [float("nan")]
        res: list[float] = []
        for rank in ranks:
            if rank < 0:
                raise SimpleError(msgs.TDIGEST_BAD_RANK)
            if rank >= len(key.value):
                res.append(float("inf"))
            else:
                res.append(key.value[rank])
        return res

    @command(
        name="TDIGEST.BYREVRANK",
        fixed=(Key(TDigest), Int),
        repeat=(Int,),
        flags=msgs.FLAG_DO_NOT_CREATE + msgs.FLAG_LEAVE_EMPTY_VAL,
    )
    def tdigest_byrevrank(self, key: CommandItem, *ranks: int) -> list[float]:
        if key.value is None:
            raise SimpleError(msgs.TDIGEST_KEY_NOT_EXISTS)
        if len(key.value) == 0:
            return [float("nan")]
        res: list[float] = []
        for rank in ranks:
            if rank < 0:
                raise SimpleError(msgs.TDIGEST_BAD_RANK)
            if rank >= len(key.value):
                res.append(float("-inf"))
            else:
                res.append(key.value[-rank - 1])
        return res
