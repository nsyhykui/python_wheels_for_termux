#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""### LatestOnlyOperator

Example DAG demonstrating the LatestOnlyOperator.

The LatestOnlyOperator skips downstream tasks for all DAG runs except the
most recent scheduled run. This is useful when downstream work should only run
for the latest interval, such as refreshing a dashboard or publishing a current
snapshot.

See also:
https://airflow.apache.org/docs/apache-airflow-providers-standard/stable/operators/latest_only.html
"""

from __future__ import annotations

import datetime

from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.latest_only import LatestOnlyOperator
from airflow.sdk import DAG

with DAG(
    dag_id="latest_only",
    schedule=datetime.timedelta(hours=4),
    start_date=datetime.datetime(2021, 1, 1),
    catchup=False,
    tags=["example", "example2", "example3"],
    doc_md=__doc__,
) as dag:
    # [START howto_operator_latest_only]
    latest_only = LatestOnlyOperator(task_id="latest_only")
    # [END howto_operator_latest_only]
    task1 = EmptyOperator(task_id="task1")

    latest_only >> task1
