# Copyright 2014, 2015 SAP SE
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Function codes

# These values are embedded in REPLY segment headers

DDL = 1
INSERT = 2
UPDATE = 3
DELETE = 4
SELECT = 5
DBPROCEDURECALL = 8             # CALL statement
DBPROCEDURECALLWITHRESULT = 9   # CALL statement returning one or more results
WRITELOB = 15
READLOB = 16
DISCONNECT = 18

DML = frozenset([INSERT, UPDATE, DELETE])
