PLUGGY_HOOKGROUP = "squirrel"
