import inspect
import sys
from collections.abc import Iterable, Sequence
from enum import Enum
from functools import lru_cache, partial
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    ForwardRef,
    Literal,
    Self,
    Union,
    get_args,
    get_origin,
)

from attrs import define, evolve, field

from cyclopts.annotations import (
    VARIADIC_COLLECTION_TYPES,
    get_hint_name,
    is_enum,
    is_iterable_type,
    is_union,
    resolve_annotated,
    resolve_optional,
)
from cyclopts.argument.utils import is_short_flag
from cyclopts.core import _get_root_module_name, _iter_resolution_argument_collections
from cyclopts.field_info import get_field_infos
from cyclopts.group import Group
from cyclopts.help.inline_text import InlineText
from cyclopts.help.silent import SILENT, SilentRich
from cyclopts.parameter import ITERATIVE_BOOL_IMPLICIT_VALUE, get_parameters
from cyclopts.utils import SortHelper, frozen, resolve_callables, slice_to_str

if TYPE_CHECKING:
    from rich.console import RenderableType
    from rich.theme import Theme

    from cyclopts.argument import Argument, ArgumentCollection
    from cyclopts.core import App


@lru_cache(maxsize=16)
def docstring_parse(doc: str | None, format: str):
    """Addon to :func:`docstring_parser.parse` that supports multi-line `short_description`."""
    import docstring_parser

    if not doc:
        return docstring_parser.parse("")

    cleaned_doc = inspect.cleandoc(doc)
    short_description_and_maybe_remainder = cleaned_doc.split("\n\n", 1)

    # Place multi-line summary into a single line.
    # This kind of goes against PEP-0257, but any reasonable CLI command will
    # have either no description, or it will have both a short and long description.
    short = short_description_and_maybe_remainder[0].replace("\n", " ")
    if len(short_description_and_maybe_remainder) == 1:
        cleaned_doc = short
    else:
        cleaned_doc = short + "\n\n" + short_description_and_maybe_remainder[1]

    res = docstring_parser.parse(cleaned_doc)

    # Ensure a short description exists if there's a long description
    assert not res.long_description or res.short_description

    return res


def _text_factory():
    from rich.text import Text

    return Text()


def _description_converter(value: Any | None) -> Any:
    if value is None:
        return _text_factory()
    return value


@frozen(kw_only=True)
class HelpEntry:
    """Container for help table entry data."""

    positive_names: tuple[str, ...] = ()
    """Positive long option names (e.g., ``--verbose``, ``--dry-run``)."""

    positive_shorts: tuple[str, ...] = ()
    """Positive short option names (e.g., ``-v``, ``-n``)."""

    negative_names: tuple[str, ...] = ()
    """Negative long option names (e.g., ``--no-verbose``, ``--no-dry-run``)."""

    negative_shorts: tuple[str, ...] = ()
    """Negative short option names (e.g., ``-N``). Rarely used."""

    metavar: str | None = None
    """Placeholder text for this parameter's **value** (e.g., the ``PATH`` in ``--config PATH``).

    Describes the *shape* of the value a token becomes; it defaults to the parameter's
    **type** in uppercase (``--config`` typed :class:`~pathlib.Path` → ``PATH``; ``str`` → ``STR``;
    ``Literal``/``Enum`` → ``CHOICE``) and can be overridden with
    :attr:`Parameter.metavar <cyclopts.Parameter.metavar>`. :obj:`None` for entries that do not
    consume a value (boolean flags, counting parameters, dict/structured parameters populated via
    dotted keys, commands), even with an explicit ``Parameter.metavar``. Entries whose ``[choices]``
    list is displayed still carry a ``CHOICE`` metavar (both are shown).

    This is *not* how a positional parameter is displayed — that is its :attr:`positional_label`,
    derived from the parameter's name. ``metavar`` never affects the identifier.
    """

    positional_label: str | None = None
    """Display identifier for a **positional** parameter (e.g., the ``SRC`` in ``SRC --src``).

    Derived from the parameter's **name** in uppercase; change it via
    :attr:`Parameter.name <cyclopts.Parameter.name>`. :obj:`None` for keyword-only
    parameters (which are identified by their option names) and commands. Unaffected
    by :attr:`Parameter.metavar <cyclopts.Parameter.metavar>`. Prefixed onto
    :attr:`display_labels` for positional parameters.
    """

    @property
    def names(self) -> tuple[str, ...]:
        """All long **option** names (positive + negative).

        Only contains ``--`` option names. A positional-only parameter has no option
        names, so this is empty for it — its display identifier lives in
        :attr:`positional_label`. Use :attr:`display_labels` to render an entry the way
        the builtin formatters do.
        """
        return self.positive_names + self.negative_names

    @property
    def shorts(self) -> tuple[str, ...]:
        """All short option names (positive + negative)."""
        return self.positive_shorts + self.negative_shorts

    @property
    def all_options(self) -> tuple[str, ...]:
        """All options in display order: positive longs, positive shorts, negative longs, negative shorts.

        Never includes the :attr:`positional_label`; see :attr:`display_labels`.
        """
        return self.positive_names + self.positive_shorts + self.negative_names + self.negative_shorts

    @property
    def display_labels(self) -> tuple[str, ...]:
        """:attr:`all_options`, preceded by :attr:`positional_label` for positional parameters.

        This is what the builtin formatters render.
        """
        if self.positional_label:
            return (self.positional_label,) + self.all_options
        return self.all_options

    description: Any = None
    """Help text description for this entry.

    Typically a :class:`str` or a :obj:`~rich.console.RenderableType`
    """

    required: bool = False
    """Whether this parameter/command is required."""

    sort_key: Any = None
    """Custom sorting key for ordering entries."""

    type: Any | None = None
    """Type annotation of the parameter."""

    choices: tuple[str, ...] | None = None
    """Available choices for this parameter."""

    env_var: tuple[str, ...] | None = None
    """Environment variable names that can set this parameter."""

    default: str | None = None
    """Default value for this parameter to display. None means no default to show."""

    @property
    def display_labels_with_metavar(self) -> tuple[str, ...]:
        """:attr:`display_labels` with the :attr:`metavar` appended to the last value-taking name.

        This is what the builtin formatters render, e.g. ``("--config", "-c PATH", "--no-flag")``.
        Positional rows are unchanged (their :attr:`positional_label` already stands in for the value).
        """
        if self.positional_label or not self.metavar:
            return self.display_labels
        positives = [*self.positive_names, *self.positive_shorts]
        if positives:
            positives[-1] = f"{positives[-1]} {self.metavar}"
        else:
            positives = [self.metavar]
        return (*positives, *self.negative_names, *self.negative_shorts)

    def copy(self, **kwargs: Any) -> Self:
        return evolve(self, **kwargs)


@define
class HelpPanel:
    """Data container for help panel information."""

    format: Literal["command", "parameter"]
    """Panel format type."""

    title: "RenderableType"
    """The title text displayed at the top of the help panel."""

    description: Any = field(
        default=None,
        converter=_description_converter,
    )
    """Optional description text displayed below the title.

    Typically a :class:`str` or a :obj:`~rich.console.RenderableType`
    """

    entries: list[HelpEntry] = field(factory=list)
    """List of help entries to display (in order) in the panel."""

    theme: Union[dict[str, str], "Theme", None] = None
    """Per-group theme (from :attr:`Group.theme`) layered over the ``cyclopts.*`` style defaults for this panel."""

    def copy(self, **kwargs: Any) -> Self:
        return evolve(self, **kwargs)

    def _remove_duplicates(self):
        seen, out = set(), []
        for item in self.entries:
            hashable = (item.names, item.shorts, item.positional_label)
            if hashable not in seen:
                seen.add(hashable)
                out.append(item)
        self.entries = out

    def _sort(self):
        """Sort entries in-place."""
        if not self.entries:
            return

        if self.format == "command":
            sorted_sort_helper = SortHelper.sort(
                [
                    SortHelper(
                        entry.sort_key,
                        (
                            entry.names[0].startswith("-") if entry.names else False,
                            entry.names[0] if entry.names else "",
                        ),
                        entry,
                    )
                    for entry in self.entries
                ]
            )
            self.entries = [x.value for x in sorted_sort_helper]
        else:
            raise NotImplementedError


def _categorize_keyword_arguments(argument_collection: "ArgumentCollection") -> tuple[list, list]:
    """Categorize keyword arguments by requirement status for usage string formatting.

    Parameters
    ----------
    argument_collection : ArgumentCollection
        Collection of arguments to categorize.

    Returns
    -------
    tuple[list, list]
        (required_keyword, optional_keyword) where:
        - required_keyword: Required keyword-only parameters
        - optional_keyword: Optional keyword-only parameters and VAR_KEYWORD
    """
    required, optional = [], []

    for argument in argument_collection:
        if not argument.show:
            continue

        if argument.field_info.kind in (argument.field_info.VAR_KEYWORD,):
            optional.append(argument)
        elif argument.field_info.is_keyword and argument.index is None:
            if argument.required:
                required.append(argument)
            else:
                optional.append(argument)

    return required, optional


def _categorize_positional_arguments(argument_collection: "ArgumentCollection") -> tuple[list, list]:
    """Categorize positional arguments by requirement status for usage string formatting.

    Parameters
    ----------
    argument_collection : ArgumentCollection
        Collection of arguments to categorize.

    Returns
    -------
    tuple[list, list]
        (required_positional, optional_positional) where:
        - required_positional: Required positional and VAR_POSITIONAL parameters
        - optional_positional: Optional positional and VAR_POSITIONAL parameters
    """
    required, optional = [], []

    for argument in argument_collection:
        if not argument.show:
            continue

        if argument.field_info.kind == argument.field_info.VAR_POSITIONAL:
            if argument.required:
                required.append(argument)
            else:
                optional.append(argument)
        elif argument.index is not None:
            if argument.required:
                required.append(argument)
            else:
                optional.append(argument)

    return required, optional


def format_usage(
    app: "App",
    command_chain: Iterable[str],
    execution_path: Sequence["App"] | None = None,
    *,
    show_metavar: bool | None = None,
):
    """Build the ``Usage:`` line.

    Parameters
    ----------
    show_metavar : bool | None
        Force value placeholders on or off. :obj:`None` follows each parameter's
        rendering formatter (its group's ``help_formatter``, else the app's), so the
        usage line agrees with the panel rows.
    """
    from rich.text import Text

    usage = []

    # If we're at the root level (no command chain), the app has a default_command,
    # and no explicit name was set, derive a better name from sys.argv[0]
    if not command_chain and app.default_command and not app._name:
        # Use the same logic as in App.name property for apps without default_command
        name = Path(sys.argv[0]).name
        if name == "__main__.py":
            name = _get_root_module_name()
        app_name = name
    else:
        app_name = app.name[0]

    usage.append(app_name)
    usage.extend(command_chain)

    for command in command_chain:
        app = app[command]
    default_formatter = app.app_stack.resolve("help_formatter")

    def shows_metavar(argument) -> bool:
        if show_metavar is not None:
            return show_metavar
        formatter = next((g.help_formatter for g in argument.parameter.group if g.help_formatter), default_formatter)
        return getattr(formatter, "show_metavar", True)

    # Check for visible non-help/version commands without resolving lazy CommandSpecs.
    help_version_flags = {*app.help_flags, *app.version_flags}
    if any(x not in help_version_flags and app._get_item(x, recurse_meta=True).show for x in app):
        usage.append("COMMAND")

    # Aggregate arguments across all apps that contribute parameters to this help page.
    # Shares the resolution logic with ``App._assemble_help_panels`` so the usage line and
    # the parameter panels always agree on which apps contribute.
    required_keyword_params: list = []
    optional_keyword_params: list = []
    required_positional_args: list = []
    optional_positional_args: list = []
    for _, argument_collection in _iter_resolution_argument_collections(
        execution_path, fallback_app=app, parse_docstring=False
    ):
        rkw, okw = _categorize_keyword_arguments(argument_collection)
        rpos, opos = _categorize_positional_arguments(argument_collection)
        required_keyword_params.extend(rkw)
        optional_keyword_params.extend(okw)
        required_positional_args.extend(rpos)
        optional_positional_args.extend(opos)

    for argument in required_keyword_params:
        # Keyword parameters show the value placeholder (``--foo STR``); positionals
        # below show their name-derived label instead.
        metavar = _resolve_metavar(argument) if shows_metavar(argument) else None
        usage.append(f"{argument.name} {metavar}" if metavar else argument.name)

    if optional_keyword_params:
        usage.append("[OPTIONS]")

    for argument in required_positional_args:
        arg_name = _resolve_positional_label(argument) or argument.name.lstrip("-").upper()
        if argument.field_info.kind == argument.field_info.VAR_POSITIONAL:
            usage.append(f"{arg_name}...")
        else:
            usage.append(arg_name)

    if optional_positional_args:
        has_var_positional = any(
            arg.field_info.kind == arg.field_info.VAR_POSITIONAL for arg in optional_positional_args
        )
        if has_var_positional:
            usage.append("[ARGS...]")
        else:
            usage.append("[ARGS]")

    return Text(" ".join(usage) + "\n", style="cyclopts.usage")


def _smart_join(strings: Sequence[str]) -> str:
    """Joins strings with a space, unless the previous string ended in a newline."""
    if not strings:
        return ""

    result = [strings[0]]
    for s in strings[1:]:
        if result[-1].endswith("\n"):
            result.append(s)
        else:
            result.append(" " + s)

    return "".join(result)


def format_deprecated_tag(version: str | None, content: str | None) -> str:
    """Format a "Deprecated" tag, shared by the ``.. deprecated::`` directive and ``DocstringDeprecated`` metadata.

    Parameters
    ----------
    version : str | None
        Version the deprecation applies to, if any.
    content : str | None
        Optional explanatory content (e.g. "Use something else instead").

    Returns
    -------
    str
        Formatted tag, e.g. ``"[⚠ Deprecated in v1.0] Use something else instead"``.
    """
    tag = f"[⚠ Deprecated in v{version}]" if version else "[⚠ Deprecated]"
    content = (content or "").strip()
    return f"{tag} {content}" if content else tag


def format_doc(app: "App", format: str) -> InlineText | SilentRich:
    raw_doc_string = app.help

    if not raw_doc_string:
        return SILENT

    parsed = docstring_parse(raw_doc_string, format)

    components: list[str] = []
    if parsed.short_description:
        components.append(parsed.short_description + "\n")

    # docstring_parser extracts a top-level ``.. deprecated::`` directive into
    # ``parsed.deprecation`` metadata, so it never reaches the renderer as text;
    # reconstruct it here for every help format.
    if parsed.deprecation:
        if components:
            components.append("\n")
        components.append(format_deprecated_tag(parsed.deprecation.version, parsed.deprecation.description) + "\n")

    if parsed.long_description:
        if components:
            components.append("\n")
        components.append(parsed.long_description + "\n")

    return InlineText.from_format(_smart_join(components), format=format, force_empty_end=True)


def _is_dynamic_structured_dict(argument: "Argument") -> bool:
    """True if ``argument`` is ``dict[str, StructuredType]`` eligible for help expansion.

    Covers pydantic, dataclass, attrs, TypedDict, NamedTuple via the shared
    ``get_field_infos`` dispatcher.  Uses the same indicators as the parser's
    dict branch in ``Argument.__attrs_post_init__``: ``_accepts_keywords`` is
    set, ``_lookup`` is empty (no pre-built children — keys are dynamic), and
    ``_default`` is the value type with structured fields.

    Also matches when ``_default`` is a string/``ForwardRef`` — an unresolved
    self-reference from something like ``dict[str, "Node"]``.  We can't walk
    into it, but we treat it as assumed-structured so the expansion still
    renders a ``.{NAME}`` layer before terminating.
    """
    default = argument._default
    if not (argument._accepts_keywords and not argument._lookup and default is not None):
        return False
    if isinstance(default, (str, ForwardRef)):
        return True
    try:
        return bool(get_field_infos(default))
    except Exception:
        return False


def _expand_structured_dict_for_help(
    argument: "Argument",
    format: str,
    *,
    seen: frozenset[int] = frozenset(),
) -> Iterable[HelpEntry]:
    """Yield help entries for every leaf field of a ``dict[str, StructuredType]``.

    Reuses :meth:`ArgumentCollection._from_type_preview` so synthesized entries
    carry the full metadata (choices, defaults, env_var, required propagation,
    ``Parameter.help`` precedence, ``name_transform``) that the normal
    per-argument path produces.
    """
    # NOTE: help output uses cyclopts' name_transform (e.g. ``my_field`` →
    # ``--models.{NAME}.my-field``).  The parser currently only accepts the raw
    # snake_case form for dict-nested paths; harmonizing the two is a separate
    # follow-up (touches ``_argument.py`` token routing).
    from cyclopts.argument import ArgumentCollection
    from cyclopts.field_info import FieldInfo
    from cyclopts.parameter import Parameter

    value_type = argument._default

    negatives = set(argument.negatives)
    outer_long_names = tuple(o for o in argument.names if o not in negatives and not is_short_flag(o))

    is_unresolvable = isinstance(value_type, (str, ForwardRef))
    is_cycle = id(value_type) in seen

    if is_cycle or is_unresolvable or not outer_long_names:
        # Cycle or unresolved forward-ref — stop expanding, but still indicate
        # the next level is another ``{NAME}`` layer by appending ``.{{NAME}}``
        # to the names.
        base = _make_help_entry(argument, format)
        if outer_long_names:
            yield evolve(base, positive_names=tuple(f"{n}.{{NAME}}" for n in base.positive_names))
        else:
            yield base
        return

    new_seen = seen | {id(value_type)}
    synthetic = FieldInfo(
        names=("_preview",),
        kind=FieldInfo.KEYWORD_ONLY,
        annotation=value_type,
        default=FieldInfo.empty,
        required=argument.required,
    )
    for outer in outer_long_names:
        preview = ArgumentCollection._from_type(
            synthetic,
            (),
            Parameter(name=(f"{outer}.{{NAME}}",)),
            group_lookup={},
            group_arguments=Group.create_default_arguments(),
            group_parameters=Group.create_default_parameters(),
            _resolve_groups=False,
        )
        for leaf in preview.filter_by(show=True):
            if _is_dynamic_structured_dict(leaf):
                yield from _expand_structured_dict_for_help(leaf, format, seen=new_seen)
            else:
                yield _make_help_entry(leaf, format)


def _resolve_metavar(argument: "Argument") -> str | None:
    """Resolve the value placeholder representing ``argument``'s **value** (the ``PATH`` in ``--config PATH``).

    Returns :obj:`None` for arguments that never consume a value on the command line
    (boolean flags, counting parameters), regardless of any explicit metavar: a placeholder
    would misrepresent the CLI. For value-consuming arguments an explicit
    :attr:`Parameter.metavar <cyclopts.Parameter.metavar>` wins (an empty string suppresses
    it); structured/dict parameters populated only through dotted sub-keys otherwise get
    :obj:`None`. The default derives from the type hint (``STR``, ``PATH``, ``CHOICE``).
    Independent of the positional display identifier; see :func:`_resolve_positional_label`.
    """
    if argument.parameter.count:
        return None
    hint = argument.hint
    is_var_keyword = argument.field_info.kind is argument.field_info.VAR_KEYWORD
    if is_var_keyword:
        hint = get_args(hint)[1]
    # Mirror ``Argument.match``'s flag rule rather than ``token_count`` so that
    # ``Optional[bool]`` agrees with what the parser accepts.
    resolved = resolve_optional(hint)
    if resolved is bool or resolved in ITERATIVE_BOOL_IMPLICIT_VALUE:
        return None
    override = argument.parameter.metavar
    if override is not None:
        return override or None
    if (
        not is_var_keyword
        and argument._accepts_keywords
        and (argument._accepts_arbitrary_keywords or argument.children)
    ):
        return None
    # An explicit ``Parameter.choices`` describes the leaf value exactly like a
    # ``Literal``/``Enum`` hint does, so the leaf renders as ``CHOICE`` (``CHOICE...`` for a
    # single-token collection, ``LIST[CHOICE]`` for a multi-token one), never the type name.
    leaf = "CHOICE" if argument._explicit_choices() else None
    metavar = _type_metavar(hint, leaf=leaf)
    n_tokens = argument.parameter.n_tokens
    if metavar and n_tokens and get_origin(resolved) is not tuple:
        if is_iterable_type(resolved) and (args := get_args(resolved)):
            # Each consumed token is one element, not one whole container.
            metavar = _type_metavar(args[0], leaf=leaf)
        metavar = f"{metavar}..." if n_tokens == -1 else " ".join([metavar] * n_tokens)
    return metavar or None


def _explicit_metavar(hint) -> tuple[Any, str | None]:
    """Unwrap ``hint`` and return the highest-priority ``Parameter.metavar`` attached to it, if any.

    Covers ``Annotated[T, Parameter(metavar=...)]`` aliases such as :data:`cyclopts.types.Port`
    and ``@Parameter(metavar=...)``-decorated classes such as :class:`~cyclopts.StdioPath`.
    """
    hint, params = get_parameters(hint, skip_converter_params=True)
    return hint, next((p.metavar for p in reversed(params) if p.metavar is not None), None)


def _type_metavar(hint, *, leaf: str | None = None) -> str:
    """Derive the default metavar from a type hint.

    Tuples render argparse-style, one placeholder per token the user types
    (``tuple[int, int]`` -> ``INT INT``, ``tuple[int, ...]`` -> ``INT...``), with nested
    tuples flattened. Other variadic collections (``list``, ``set``, ``Sequence``, ...) consume
    one element per token, so a single-token element renders like ``tuple[X, ...]``
    (``list[str]`` -> ``STR...``); a multi-token element keeps the container form so its grouping
    stays unambiguous (``list[tuple[int, str]]`` -> ``LIST[INT STR]``).
    Remaining generics (e.g. ``dict``) are the uppercased type name over their arguments
    (``DICT[STR, INT]``); a multi-token member is parenthesized when it has siblings
    (``(INT INT)|STR``, ``DICT[STR, (INT INT)]``) so the grouping stays unambiguous.
    ``Literal``/``Enum`` render as ``CHOICE``; ``leaf`` replaces every non-generic leaf name
    (explicit ``Parameter.choices``).
    """
    if hint is Ellipsis:
        return "..."
    hint, explicit = _explicit_metavar(hint)
    if explicit is not None:
        return explicit
    # ``Optional[Path]`` is always supplied as a ``PATH``; absence is conveyed by the
    # parameter being optional, not by a ``NONE`` the user would type.
    hint = resolve_optional(hint)
    if get_origin(hint) is Literal or is_enum(hint):
        return "CHOICE"
    recurse = partial(_type_metavar, leaf=leaf)
    if is_union(hint):
        return "|".join(_group_tokens(m) for arg in get_args(hint) if (m := recurse(arg)))
    origin, args = get_origin(hint), get_args(hint)
    if origin is tuple and args:
        if args[-1] is Ellipsis:
            element = recurse(args[0])
            return f"{element}..." if element else ""
        return " ".join(m for arg in args if (m := recurse(arg)))
    if origin in VARIADIC_COLLECTION_TYPES and args:
        # Consumes one element per token, like ``tuple[X, ...]``. Only a single-token element
        # collapses to ``X...``; a multi-token element keeps the ``LIST[...]`` form below so its
        # grouping stays unambiguous (``LIST[INT STR]``, not ``INT STR...``).
        element = recurse(args[0])
        if element and " " not in element and "..." not in element:
            return f"{element}..."
    if origin and args:
        names = [recurse(arg) for arg in args]
        if not all(names):
            # An element suppressed via an explicit empty ``Parameter.metavar`` collapses
            # the whole container's placeholder.
            return ""
        if len(names) > 1:
            names = [_group_tokens(n) for n in names]
        return f"{get_hint_name(origin).upper()}[{', '.join(names)}]"
    return leaf if leaf is not None else get_hint_name(hint).upper()


def _group_tokens(metavar: str) -> str:
    """Parenthesize a multi-token metavar so it reads as one member next to siblings."""
    return f"({metavar})" if " " in metavar else metavar


def _resolve_positional_label(argument: "Argument") -> str | None:
    """Resolve the display identifier for a **positional** parameter (the ``SRC`` in ``SRC --src``).

    Derived from the parameter's name; :obj:`None` for keyword-only parameters, which
    are identified by their option names. Never affected by
    :attr:`Parameter.metavar <cyclopts.Parameter.metavar>` — use
    :attr:`Parameter.name <cyclopts.Parameter.name>` to change it.
    """
    if argument.index is None or not argument.names:
        return None
    negatives = set(argument.negatives)
    label_source = next((o for o in argument.names if o.startswith("--") and o not in negatives), argument.name)
    return label_source.lstrip("-").upper() or None


def _make_help_entry(argument: "Argument", format: str) -> HelpEntry:
    """Build a single ``HelpEntry`` for one ``Argument``.

    Extracted from ``create_parameter_help_panel`` so it can also be applied
    to synthetic preview arguments (see ``_expand_structured_dict_for_help``).
    """
    assert argument.parameter.name_transform

    options = list(argument.names)

    seen: set[str] = set()
    options = [x for x in options if x not in seen and not seen.add(x)]

    positional = argument.index is not None
    metavar = _resolve_metavar(argument)
    positional_label = _resolve_positional_label(argument)

    if positional:
        # A positional-only argument's bare name is a display label carried by
        # ``positional_label``, not an option the user can type.
        options = [o for o in options if o.startswith("-")]

    negatives = set(argument.negatives)
    positive_names = [o for o in options if o not in negatives and not is_short_flag(o)]
    positive_shorts = [o for o in options if o not in negatives and is_short_flag(o)]
    negative_names = [o for o in options if o in negatives and not is_short_flag(o)]
    negative_shorts = [o for o in options if o in negatives and is_short_flag(o)]

    help_description = InlineText.from_format(argument.parameter.help, format=format)

    choices = argument.get_choices()

    env_var = None
    if argument.parameter.show_env_var and argument.parameter.env_var:
        env_var = tuple(argument.parameter.env_var)

    default = None
    if isinstance(argument.show_default, str):
        default = argument.show_default
    elif argument.show_default:
        default_val = argument.field_info.default
        if isinstance(default_val, Enum):
            default = argument.parameter.name_transform(default_val.name)
        elif isinstance(default_val, (list, tuple, set, frozenset)):
            formatted_items = []
            for item in default_val:
                if isinstance(item, Enum):
                    formatted_items.append(argument.parameter.name_transform(item.name))
                elif isinstance(item, str):
                    formatted_items.append(f"'{item}'")
                else:
                    formatted_items.append(str(item))
            if isinstance(default_val, tuple):
                if len(formatted_items) == 1:
                    default = "(" + formatted_items[0] + ",)"
                else:
                    default = "(" + ", ".join(formatted_items) + ")"
            elif isinstance(default_val, list):
                default = "[" + ", ".join(formatted_items) + "]"
            else:
                default = "{" + ", ".join(formatted_items) + "}"
        elif isinstance(default_val, slice):
            default = slice_to_str(default_val)
        elif default_val == "":
            default = '""'
        else:
            default = str(default_val)
        if callable(argument.show_default):
            default = argument.show_default(default_val)

    return HelpEntry(
        positive_names=tuple(positive_names),
        positive_shorts=tuple(positive_shorts),
        negative_names=tuple(negative_names),
        negative_shorts=tuple(negative_shorts),
        metavar=metavar,
        positional_label=positional_label,
        description=help_description,
        required=argument.required,
        type=resolve_annotated(argument.field_info.annotation),
        choices=choices,
        env_var=env_var,
        default=default,
    )


def create_parameter_help_panel(
    group: "Group",
    argument_collection: "ArgumentCollection",
    format: str,
) -> HelpPanel:
    from rich.text import Text

    kwargs = {
        "format": "parameter",
        "title": group.name,
        "theme": group.theme,
        "description": InlineText.from_format(group.help, format=format, force_empty_end=True)
        if group.help
        else Text(),
    }

    help_panel = HelpPanel(**kwargs)

    entries_positional, entries_kw = [], []
    for argument in argument_collection.filter_by(show=True):
        if _is_dynamic_structured_dict(argument):
            entries_kw.extend(_expand_structured_dict_for_help(argument, format))
            continue
        entry = _make_help_entry(argument, format)
        if argument.field_info.is_positional:
            entries_positional.append(entry)
        else:
            entries_kw.append(entry)

    help_panel.entries.extend(entries_positional)
    help_panel.entries.extend(entries_kw)

    return help_panel


def format_command_entries(apps_with_names: Iterable, format: str) -> list[HelpEntry]:
    """Format command entries for help display.

    Parameters
    ----------
    apps_with_names : Iterable[RegisteredCommand]
        Iterable of RegisteredCommand tuples.
    format : str
        Help text format.

    Returns
    -------
    list[HelpEntry]
        List of formatted help entries.
    """
    entries = []
    for registered_command in apps_with_names:
        app = registered_command.app
        if not app.show:
            continue
        names = registered_command.names
        # Commands don't have negative variants, so all names are "positive"
        short_names, long_names = [], []
        for name in names:
            short_names.append(name) if is_short_flag(name) else long_names.append(name)

        sort_key = resolve_callables(app.sort_key, app)

        parsed = docstring_parse(app.help, format)
        description = parsed.short_description
        if parsed.deprecation:
            # Tag-only in the command list; the full deprecation message shows on the command's own help page.
            tag = format_deprecated_tag(parsed.deprecation.version, None)
            description = f"{tag} {description}" if description else tag

        entry = HelpEntry(
            positive_names=tuple(long_names),
            positive_shorts=tuple(short_names),
            description=InlineText.from_format(description, format=format),
            sort_key=sort_key,
        )
        if entry not in entries:
            entries.append(entry)
    return entries
