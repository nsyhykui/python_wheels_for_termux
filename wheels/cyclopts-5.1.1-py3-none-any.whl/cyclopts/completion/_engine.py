"""Runtime engine for dynamic (Python-invoked) shell completion.

The static ``bash``/``zsh``/``fish`` generators bake command, option, and static
choice names into a script at install time. When an argument has a
:attr:`.Parameter.completer`, that script also calls back at TAB time through the
reserved ``__complete`` command, which routes here to run the completer and emit
its candidate values.
"""

import os
import sys
from collections.abc import Iterable, Mapping, Sequence
from contextlib import contextmanager, redirect_stdout
from functools import partial
from typing import TYPE_CHECKING, Any, NamedTuple

from cyclopts.argument import ArgumentCollection
from cyclopts.bind import _parse_configs, _parse_env, _parse_kw_and_flags, _parse_pos
from cyclopts.exceptions import CycloptsError, MissingArgumentError, RepeatArgumentError
from cyclopts.utils import UNSET, frozen, is_option_like

if TYPE_CHECKING:
    from cyclopts import App
    from cyclopts.argument import Argument


def completion_debug_enabled() -> bool:
    """Whether the ``CYCLOPTS_COMPLETION_DEBUG`` diagnostic is switched on."""
    return bool(os.environ.get("CYCLOPTS_COMPLETION_DEBUG"))


def _exc(e: BaseException) -> str:
    """Concise one-line exception summary (Cyclopts error reprs are enormous).

    A :class:`.CycloptsError` renders as a panel whose first line is its own
    class name, so that line is skipped in favor of the actual message.
    """
    lines = [line.strip() for line in str(e).strip().splitlines() if line.strip()]
    if lines and lines[0] == type(e).__name__:
        lines = lines[1:]
    summary = lines[0] if lines else ""
    return f"{type(e).__name__}: {summary}"[:200] if summary else type(e).__name__


def debug(message: str) -> None:
    """Print a ``[cyclopts:completion]`` diagnostic to stderr when ``CYCLOPTS_COMPLETION_DEBUG`` is set.

    Completion otherwise swallows all output, so this is the escape hatch for
    running ``<prog> __complete <words...>`` by hand.
    """
    if completion_debug_enabled():
        print(f"[cyclopts:completion] {message}", file=sys.stderr)


#: What a :attr:`.Parameter.completer` may return: a single value, an iterable
#: of values and/or ``(value, description)`` tuples, or a ``{value: description}``
#: mapping.
CompletionResult = str | Iterable[str | tuple[str, str]] | Mapping[str, str]


class Completion(NamedTuple):
    """A single dynamic completion candidate emitted to the shell."""

    value: str
    help: str = ""


@frozen
class ArgumentValue:
    """A best-effort view of another argument's typed-so-far value.

    Handed out by ``context[name]`` so a completer can branch on sibling
    arguments already on the command line.
    """

    argument: "Argument"

    @property
    def provided(self) -> bool:
        """Whether the user has supplied a value for this argument yet."""
        return self.argument.has_tokens

    @property
    def raw(self) -> str | None:
        """The raw string the user typed, or :obj:`None` if not provided (first token only; see :attr:`raw_tokens`)."""
        tokens = self.argument.tokens
        return tokens[0].value if tokens else None

    @property
    def raw_tokens(self) -> tuple[str, ...]:
        """Every raw string token supplied for this argument, in order."""
        return tuple(token.value for token in self.argument.tokens)

    @property
    def value(self) -> Any:
        """Best-effort coerced value, or :obj:`~.UNSET` if unavailable.

        Runs the argument's normal conversion over the tokens typed so far (may
        invoke a user :attr:`.Parameter.converter` on partial input); returns
        :obj:`~.UNSET` instead of raising on failure, and does not validate.
        Falls back to the parameter's default when no tokens were given.
        """
        if not self.argument.has_tokens:
            default = self.argument.field_info.default
            return UNSET if default is self.argument.field_info.empty else default
        try:
            return self.argument.convert()
        except Exception:
            return UNSET


@frozen
class CompletionContext:
    """Completion-time context passed to a :attr:`.Parameter.completer`.

    A completer is always invoked as ``completer(context)``. The word being
    completed is :attr:`incomplete`; the values the user has already typed for
    other arguments are reachable via ``context[name]``.
    """

    incomplete: str
    argument: "Argument"
    arguments: "ArgumentCollection"

    @property
    def parameter(self):
        """The :class:`.Parameter` of the argument currently being completed."""
        return self.argument.parameter

    @property
    def index(self) -> int:
        """Zero-based position of the word being completed among this argument's values.

        ``0`` for a scalar. For a multi-value parameter (``tuple[str, str]``,
        ``list[str]``, ``*args``) it counts the values already typed for it, so
        a completer can offer element-specific candidates.
        """
        return len(self.argument.tokens)

    def _match(self, name: str) -> "Argument":
        # ``_match_explicit`` matches ``name`` against declared options while
        # skipping the ``**kwargs`` catch-all, so a bare name like ``"region"``
        # keeps falling through to the explicit field/option-name scan below.
        argument = self.arguments._match_explicit(name)
        if argument is not None:
            return argument
        for argument in self.arguments:
            if argument.field_info.name == name or name in argument.names or f"--{name}" in argument.names:
                return argument
        raise KeyError(name)

    def __getitem__(self, name: str) -> ArgumentValue:
        """Look up an argument by option name (``"--region"``/``"region"``) or field name."""
        return ArgumentValue(self._match(name))

    def get(self, name: str, default: Any = None) -> "ArgumentValue | Any":
        """Like ``context[name]`` but returns ``default`` for an unknown ``name``."""
        try:
            return self[name]
        except KeyError:
            return default


def normalize_completions(result: "CompletionResult | None") -> list[tuple[str, str]]:
    """Normalize a completer's return value to ``(value, description)`` pairs.

    A bare :class:`str` is one candidate. A mapping is ``{value: description}``.
    Any other iterable (including a tuple) is a collection of :class:`str` values
    and/or ``(value, description)`` tuples, so a single described candidate must
    be wrapped: ``[("us-west", "Oregon")]``. An empty-tuple item is dropped.
    """
    if result is None:
        return []
    items: Iterable[str | tuple]
    if isinstance(result, str):
        items = [result]
    elif isinstance(result, Mapping):
        items = result.items()
    else:
        items = result
    normalized = [_normalize_item(item) for item in items]
    return [pair for pair in normalized if pair is not None]


def _normalize_item(item: "str | tuple") -> "tuple[str, str] | None":
    if isinstance(item, str):
        return (item, "")
    if isinstance(item, tuple):
        if not item:
            return None
        value, *rest = item
        return (str(value), str(rest[0]) if rest else "")
    # Not a str or (value, description) tuple (e.g. a completer yielding ints):
    # coerce to its string form rather than raising mid-completion.
    return (str(item), "")


#: Stands in for the word being completed while the real parser distributes
#: tokens. Contains NUL so it can never collide with a real shell word, and is
#: never option-like, so the parser routes it exactly like the value the user
#: is about to type.
_ACTIVE_SENTINEL = "\x00cyclopts-active\x00"


def _merge_wordbreaks(words: list[str]) -> list[str]:
    """Rejoin bash's ``=`` ``COMP_WORDBREAKS`` split (``--user=al`` arrives as ``['--user', '=', 'al']``) into one token.

    Matches what zsh and fish send. Only the option form (``--opt=value``) is
    rejoined: a bare ``=`` elsewhere is a real word. ``:`` is deliberately not
    rejoined -- the bash script does not rejoin it either (its ``cur`` and
    positional count would disagree with the engine), and zsh/fish never split
    on it, so a lone ``:`` word is a genuine positional value.
    """
    merged: list[str] = []
    i = 0
    n = len(words)
    while i < n:
        word = words[i]
        if word == "=" and merged and merged[-1].startswith("-") and "=" not in merged[-1]:
            # Glue ``=`` onto the option and absorb the following word too (it
            # sat between the two halves of one token).
            merged[-1] += word
            if i + 1 < n:
                merged[-1] += words[i + 1]
                i += 2
            else:
                i += 1
            continue
        merged.append(word)
        i += 1
    return merged


def _resolve_active_argument(
    arguments: "ArgumentCollection",
    tokens: list[str],
    end_of_options_delimiter: str,
) -> "Argument | None":
    """Run the real parser over ``tokens`` and return the argument owning the cursor.

    ``tokens`` end with a sentinel standing in for the word being completed.
    Reusing the real :mod:`.bind` parser (minus ``_convert``/validation) makes
    option-value consumption, ``=`` forms, ``--``, and variadics behave exactly
    like a real invocation, and leaves prior tokens on the sibling arguments.
    Whichever argument the sentinel lands on is active; it is stripped afterward.
    """
    active: Argument | None = None
    try:
        unused, _, contiguous, _ = _parse_kw_and_flags(
            arguments, tokens, end_of_options_delimiter=end_of_options_delimiter
        )
        _parse_pos(
            arguments,
            unused,
            end_of_options_delimiter=end_of_options_delimiter,
            contiguous_positional_count=contiguous,
        )
    except MissingArgumentError as e:
        # A multi-token argument (e.g. ``tuple[int, int]``) raised before the
        # sentinel could complete its token set: the cursor is filling its next
        # element. Best effort — the error can also stem from malformed *prior*
        # input, in which case the real parse would reject the line anyway.
        active = e.argument
        debug(f"active argument resolved from incomplete multi-token argument: {_exc(e)}")
    except RepeatArgumentError as e:
        # ``--user bob --user <TAB>``: the real parse rejects the repeat, but the
        # user is mid-edit and the cursor clearly belongs to that option.
        if e.token.value != _ACTIVE_SENTINEL or e.token.keyword is None:
            debug(f"parsing prior tokens {tokens[:-1]!r} failed: {_exc(e)}")
            return None
        active, _, _ = arguments.match(e.token.keyword)
        debug(f"active argument resolved from repeated option {e.token.keyword!r}")
    except Exception as e:
        debug(f"parsing prior tokens {tokens[:-1]!r} failed: {_exc(e)}")
        return None

    for argument in arguments:
        if any(token.value == _ACTIVE_SENTINEL for token in argument.tokens):
            active = argument
            argument.tokens = [token for token in argument.tokens if token.value != _ACTIVE_SENTINEL]
    return active


def _assemble_arguments(execution_path: "Sequence[App]") -> ArgumentCollection:
    """Collect every argument that may occupy a slot on the resolved command's line.

    The resolved command's own parameters, plus the keyword parameters
    contributed by meta launchers on the path (mirroring the static
    extractor): a meta option like ``--env`` shares the command line
    with the resolved command (``myapp deploy --env prod``), so its
    value slot must resolve here too -- even when the resolved command
    is a bare command group with no default_command of its own.
    Launcher positionals are consumed before the command name, so they
    are dropped (positional-only) or made keyword-only (``index=None``)
    so they never shift the command's own positional slots.

    Must be called inside the ``app_stack(execution_path)`` context.
    """
    from cyclopts.core import _iter_resolution_argument_collections

    command_app = execution_path[-1]
    arguments = ArgumentCollection()
    launcher_arguments = ArgumentCollection()
    for subapp, collection in _iter_resolution_argument_collections(execution_path, parse_docstring=False):
        if subapp is command_app:
            arguments.extend(collection)
            continue
        for argument in collection:
            if argument.field_info.is_positional_only:
                continue
            argument.index = None
            launcher_arguments.append(argument)
    arguments.extend(launcher_arguments)
    return arguments


@frozen
class Slot:
    """The command-line slot under the cursor, resolved with the real parser.

    ``arguments`` carry the tokens typed so far (from the same parse that found
    ``active``), so a completer can read sibling values. ``active`` is ``None``
    when no argument owns the cursor, including while an option *name* is being
    typed (``option_name``).
    """

    app: "App"
    command_app: "App"
    command_chain: tuple[str, ...]
    execution_path: tuple["App", ...]
    prior: list[str]
    unused: list[str]
    prefix: str
    incomplete: str
    option_name: bool
    arguments: ArgumentCollection
    active: "Argument | None"


def resolve_slot(app: "App", words: list[str]) -> Slot | None:
    """Resolve which command and argument own the word being completed.

    Parameters
    ----------
    app : App
        Any app in the program; resolution always starts from the root.
    words : list[str]
        Command-line words following the program name; the last is the (possibly
        empty) word under the cursor.

    Returns
    -------
    Slot | None
        ``None`` when the typed prefix cannot be resolved (malformed prior input).
        For ``--opt=va`` the slot's ``prefix`` is ``"--opt="`` and ``incomplete`` is ``"va"``.
    """
    if not words:
        words = [""]
    words = _merge_wordbreaks(words)
    prior, incomplete = words[:-1], words[-1]
    debug(f"words={words!r} prior={prior!r} incomplete={incomplete!r}")

    # The sentinel stands in for the word being completed. For an eq-form token
    # (``--user=al``) the sentinel replaces only the value part so the real
    # parser routes it to ``--user``; an option name in progress has no value
    # slot to complete.
    prefix = ""
    parse_token = _ACTIVE_SENTINEL
    option_name = is_option_like(incomplete)
    if option_name and "=" in incomplete:
        option, _, incomplete = incomplete.partition("=")
        prefix, parse_token, option_name = f"{option}=", f"{option}={_ACTIVE_SENTINEL}", False

    # ``__complete`` may arrive at whichever App the program's entry point is
    # (``app.meta()`` is common). The launcher forwards its tokens to the root
    # app, so completion always resolves from the root, exactly like the real run.
    while app._meta_parent is not None:
        app = app._meta_parent

    # Resolve the active command from the tokens typed so far. ``unused`` strips
    # the resolved command chain, leaving only option/positional tokens so slot
    # accounting below never miscounts a subcommand name as a positional value.
    try:
        command_chain, execution_path, unused, command_indices, _ = app._parse_commands(prior)
    except (CycloptsError, ValueError, TypeError) as e:
        debug(f"command resolution failed for {prior!r}: {_exc(e)}")
        return None
    # Command resolution also swallows leading meta-launcher options (``--env
    # prod deploy ...``). Re-feed them so the merged launcher arguments below
    # carry the values a dependent completer reads via ``context["env"]``.
    consumed = len(prior) - len(unused)
    meta_tokens = [token for i, token in enumerate(prior[:consumed]) if i not in command_indices]
    unused = [*meta_tokens, *unused]
    debug(f"resolved command={command_chain!r} unused={unused!r}")

    # The app_stack context applies stack-resolved configuration — e.g. an
    # ``App(default_parameter=Parameter(completer=...))`` — exactly like the
    # real parse (core.py) and the static extractor (_base.py) do.
    with app.app_stack(execution_path):
        try:
            arguments = _assemble_arguments(execution_path)
        except Exception as e:
            debug(f"assembling arguments failed: {_exc(e)}")
            return None
        active = None
        if option_name:
            debug("completing an option name; no value slot to resolve")
        else:
            end_of_options_delimiter = app.app_stack.resolve("end_of_options_delimiter", fallback="--")
            active = _resolve_active_argument(arguments, [*unused, parse_token], end_of_options_delimiter)
            if active is None:
                debug("no argument occupies this slot")

    return Slot(
        app=app,
        command_app=execution_path[-1],
        command_chain=tuple(command_chain),
        execution_path=tuple(execution_path),
        prior=prior,
        unused=unused,
        prefix=prefix,
        incomplete=incomplete,
        option_name=option_name,
        arguments=arguments,
        active=active,
    )


@contextmanager
def stdout_to_stderr():
    """Divert ``sys.stdout`` *and* OS-level fd 1 to stderr while user code runs.

    :func:`contextlib.redirect_stdout` alone only swaps the Python object; a
    completer's subprocess inheriting fd 1 would still write straight into the
    completion protocol.
    """
    sys.stdout.flush()
    saved = os.dup(1)
    os.dup2(2, 1)
    try:
        with redirect_stdout(sys.stderr):
            yield
    finally:
        os.dup2(saved, 1)
        os.close(saved)


def dynamic_candidates(slot: Slot) -> list[tuple[str, str]]:
    """Run the active argument's :attr:`.Parameter.completer`; ``[]`` when it has none."""
    active = slot.active
    if active is None or active.parameter.completer is None:
        if active is not None:
            debug(f"active argument {active.name!r} has no completer")
        return []
    debug(
        f"active argument={active.name!r} completer={getattr(active.parameter.completer, '__name__', active.parameter.completer)!r}"
    )

    with slot.app.app_stack(slot.execution_path):
        # The sibling arguments already carry the CLI tokens from the same parse
        # that resolved the active argument. Layer in env-var and config-sourced
        # values (like the real binding pass) so a dependent completer sees the
        # same sibling values the command itself would receive. Best effort — a
        # broken config source must not kill completion.
        # The active argument itself must keep only its typed tokens: an env/config
        # value for it would otherwise inflate ``ctx.index`` and mark it provided.
        typed = list(active.tokens)
        try:
            _parse_env(slot.arguments)
            configs = slot.command_app.app_stack.resolve("_config") or ()
            _parse_configs(slot.arguments, tuple(partial(x, slot.command_app, slot.command_chain) for x in configs))
        except Exception as e:
            debug(f"applying env/config sources failed (sibling values may be partial): {_exc(e)}")
        finally:
            active.tokens[:] = typed

        context = CompletionContext(incomplete=slot.incomplete, argument=active, arguments=slot.arguments)
        completions = active.get_completions(context)
    debug(f"completer returned {len(completions or [])} candidate(s): {completions!r}")
    return completions or []


def compute_completions(app: "App", words: list[str]) -> list[Completion]:
    """Compute dynamic completion candidates for a partial command line.

    Parameters
    ----------
    app : App
        Root application.
    words : list[str]
        Command-line words following the program name. The final element is the
        (possibly empty) word currently being completed; everything before it is
        already-committed input.

    Returns
    -------
    list[Completion]
        Candidates from the active slot's :attr:`.Parameter.completer`. Empty
        when it has no completer (the generated script handles static choices,
        command names, and option names).
    """
    slot = resolve_slot(app, words)
    if slot is None:
        return []
    # Emitted as-is: the engine never filters. The generated shell script
    # prefix-matches these candidates against the word being completed (bash's
    # ``[[ $x == $cur* ]]``, zsh ``compadd``, fish ``complete -a``), so a
    # completer need not prefix-filter itself -- and cannot override that prefix
    # match, which is why substring/fuzzy completion isn't possible. ``incomplete``
    # is for narrowing expensive lookups, not for filtering the result.
    return [Completion(value, help) for value, help in dynamic_candidates(slot)]
