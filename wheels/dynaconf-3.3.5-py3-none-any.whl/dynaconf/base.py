from __future__ import annotations

import copy
import importlib
import inspect
import os
import re
import warnings
from collections import defaultdict
from collections.abc import Callable
from contextlib import contextmanager
from contextlib import suppress
from dataclasses import dataclass
from dataclasses import field
from functools import lru_cache
from functools import wraps
from pathlib import Path
from typing import Any
from typing import Optional
from typing import Union

from dynaconf import default_settings
from dynaconf.loaders import default_loader
from dynaconf.loaders import enable_external_loaders
from dynaconf.loaders import env_loader
from dynaconf.loaders import execute_instance_hooks
from dynaconf.loaders import execute_module_hooks
from dynaconf.loaders import py_loader
from dynaconf.loaders import settings_loader
from dynaconf.loaders import yaml_loader
from dynaconf.loaders.base import SourceMetadata
from dynaconf.nodes import DataDict
from dynaconf.nodes import DataList
from dynaconf.nodes import recursively_evaluate_lazy_format
from dynaconf.strategies.filtering import PrefixFilter
from dynaconf.utils import BANNER
from dynaconf.utils import ensure_a_list
from dynaconf.utils import ensure_upperfied_list
from dynaconf.utils import ListMergeOptions
from dynaconf.utils import missing
from dynaconf.utils import normalize_kwargs
from dynaconf.utils import object_merge
from dynaconf.utils import RENAMED_VARS
from dynaconf.utils import to_dict
from dynaconf.utils import upperfy
from dynaconf.utils.files import find_file
from dynaconf.utils.files import glob
from dynaconf.utils.files import has_magic
from dynaconf.utils.functional import empty
from dynaconf.utils.functional import LazyObject
from dynaconf.utils.parse_conf import apply_converter
from dynaconf.utils.parse_conf import boolean_fix
from dynaconf.utils.parse_conf import converters
from dynaconf.utils.parse_conf import Lazy
from dynaconf.utils.parse_conf import parse_conf_data
from dynaconf.utils.parse_conf import true_values
from dynaconf.validator import ValidationError
from dynaconf.validator import ValidatorList


class LazySettings(LazyObject):
    """Loads settings lazily from multiple sources:

        settings = Dynaconf(
            settings_files=["settings.toml"],  # path/glob
            environments=True,                 # activate layered environments
            envvar_prefix="MYAPP",             # `export MYAPP_FOO=bar`
            env_switcher="MYAPP_MODE",         # `export MYAPP_MODE=production`
            load_dotenv=True,                  # read a .env file
        )

    More options available on https://www.dynaconf.com/configuration/
    """

    def __init__(self, wrapped=None, **kwargs):
        """
        handle initialization for the customization cases

        :param wrapped: a deepcopy of this object will be wrapped (issue #596)
        :param kwargs: values that overrides default_settings
        """
        self._wrapper_class = kwargs.pop("_wrapper_class", Settings)
        self._kwargs = normalize_kwargs(kwargs)
        super().__init__()

        if wrapped:
            if self._django_override:
                # This fixes django issue #596
                self._wrapped = copy.deepcopy(wrapped)
            else:
                self._wrapped = wrapped

    def __getattr__(self, name):
        """Setup wrapped Setting instance on first access."""
        if self._wrapped is empty:
            self._setup()

        return getattr(self._wrapped, name)

    def _setup(self):
        """Initial setup, run once."""
        using_global_settings = self._kwargs.pop(
            "warn_dynaconf_global_settings", None
        )  # in 3.0.0 global settings is deprecated

        if using_global_settings:
            _warn_global_settings_deprecation()
            self._wrapper_class = Settings  # Force unhooked for this

        self.configure()

    def configure(self, settings_module=None, **kwargs):
        """
        Allows user to reconfigure settings object passing a new settings
        module or separated kwargs

        :param settings_module: defines the settings file
        :param kwargs:  override default settings
        """
        load_dotenv = _should_load_dotenv(self._kwargs)
        default_settings.reload(load_dotenv=load_dotenv)
        environment_var = self._kwargs.get(
            "ENVVAR_FOR_DYNACONF", default_settings.ENVVAR_FOR_DYNACONF
        )
        settings_module = settings_module or os.environ.get(environment_var)
        kwargs = normalize_kwargs(kwargs)
        kwargs.update(self._kwargs)
        self._wrapped = self._wrapper_class(
            settings_module=settings_module, **kwargs
        )

    @property
    def configured(self):
        """If wrapped is configured"""
        return self._wrapped is not empty

    def __call__(self, *args, **kwargs):
        """Allow direct call of settings('val')
        in place of settings.get('val')
        """
        return self.get(*args, **kwargs)


@dataclass
class DynaconfConfig:
    """Dynaconf specific configuration.

    For internal use only.
    """

    # for_dynaconf
    fresh_vars: list[str] = field(default_factory=list)  # always upper

    # validation
    validate_only: Optional[list[str]] = None
    validate_exclude: Optional[list[str]] = None
    validate_only_current_env: bool = False

    # hooks
    post_hooks: list[Callable] = field(default_factory=list)

    # general
    fresh: bool = False
    dynaboxify: bool = True
    filter_strategy: Optional[PrefixFilter] = None

    # not overridable in instantiation
    # NOTE: putting it here for simplifying the internal change. Consider
    # getting them out of this config, later
    defaults: Optional[dict] = None
    loaded_envs: list[str] = field(default_factory=list)
    loaded_hooks: dict[str, dict] = field(
        default_factory=lambda: defaultdict(dict)
    )
    loaded_by_loaders: dict[SourceMetadata, Any] = field(default_factory=dict)
    loaded_py_modules: list[str] = field(default_factory=list)
    loaded_files: list[str] = field(default_factory=list)
    loaders: list[str] = field(default_factory=list)
    deleted: set[str] = field(default_factory=set)
    env_cache: dict = field(default_factory=dict)

    not_installed_warnings: list[str] = field(default_factory=list)

    def __post_init__(self):
        """Process values."""
        if not isinstance(self.post_hooks, list):
            self.post_hooks = ensure_a_list(self.post_hooks)

    def override_with(self, data: dict):
        """Override keys and ignore unknows items."""
        exclude = [
            "defaults",
            "loaded_envs",
            "loaded_hooks",
            "loaded_py_modules",
            "loaded_files",
            "deleted",
            "env_cache",
        ]
        keys = self.__dataclass_fields__
        for key, value in data.items():
            lower_key = key.lower()
            if (lower_key in keys) and (lower_key not in exclude):
                setattr(self, lower_key, value)
        self.__post_init__()


class DynaconfCore:
    """Developer-facing settings manager."""

    def __init__(self, id: str, **kwargs):
        if "dynaconf_options" in kwargs:
            _warn_incompatible_typed_dynaconf_arg()

        # obj is the user facing object (e.g, a Settings instance)
        obj = kwargs.get("box_settings") or Settings()

        config = DynaconfConfig()
        config.override_with(kwargs)
        default_store = DataDict(box_settings=obj) if config.dynaboxify else {}
        store = kwargs.pop("_store", default_store)
        validators = kwargs.pop("validators", None)

        self._cache: dict = {}
        self.cache_enabled = True
        self.obj = obj
        self.config = config
        self.store = store
        self.validators = ValidatorList(obj, validators=validators)

    # CACHING

    def get_cached(self, key):
        """Return value or raises KeyError for key not found."""
        if not self.cache_enabled:
            raise KeyError
        return self._cache[key]

    def set_cached(self, key, value):
        # NOTE: remove support for this marker in a breaking change
        _is_lazy = hasattr(value, "_dynaconf_lazy_format")
        if not self.cache_enabled:
            return
        fresh_vars = self.config.fresh_vars
        if key not in fresh_vars and not _is_lazy:
            self._cache[key] = value

    def clear_cache(self):
        if not self.cache_enabled:
            return
        self._cache.clear()

    # COPYING

    def __deepcopy__(self, memo):
        import copy

        new_instance = self.__class__.__new__(self.__class__)
        memo[id(self)] = new_instance

        for key, value in self.__dict__.items():
            if key != "_cache":
                setattr(new_instance, key, copy.deepcopy(value, memo))

        new_instance._cache = {}
        return new_instance


def invalidates_cache(func):
    """Decorator that clears the cache before calling the decorated method."""

    @wraps(func)
    def wrapper(self, *args, **kwargs):
        # core should encapsulates all the caching logic
        # using getattr because before Settings init it's unset
        core = getattr(self, "__core__", None)
        if core:
            core.clear_cache()
        return func(self, *args, **kwargs)

    return wrapper


class Settings:
    """User-facing settings object."""

    dynaconf_banner = BANNER

    def __init__(self, settings_module=None, **kwargs):  # pragma: no cover
        """Execute loaders and custom initialization

        :param settings_module: defines the settings file
        :param kwargs:  override default settings
        """
        core = DynaconfCore("main", box_settings=self, **kwargs)
        config = core.config
        config.defaults = kwargs

        self.__core__ = core
        self.SETTINGS_MODULE = None

        if settings_module:
            self.set(
                "SETTINGS_FILE_FOR_DYNACONF",
                settings_module,
                loader_identifier="init_settings_module",
            )
        kwargs.pop("validators", None)
        for key, value in kwargs.items():
            self.set(
                key,
                value,
                loader_identifier="init_kwargs",
                validate=False,
                dotted_lookup=True,
            )

        # These skipping flags are used for when copying of settings is done
        skip_loaders = kwargs.get("dynaconf_skip_loaders", False)
        skip_validators = kwargs.get("dynaconf_skip_validators", False)

        if not skip_loaders:
            self.execute_loaders()

        if not skip_validators:
            core.validators.validate(
                only=config.validate_only,
                exclude=config.validate_exclude,
                only_current_env=config.validate_only_current_env,
            )

    @property
    def environ(self):
        return os.environ

    @property
    def filter_strategy(self):
        return self.__core__.config.filter_strategy

    @property
    def validators(self):
        return self.__core__.validators

    @property
    def store(self):
        """Gets internal storage"""
        return self.__core__.store

    def __getattr__(self, key):
        # do we have cached value?
        try:
            if key != "__core__":
                core = self.__core__
                return core.get_cached(key)
        except KeyError:
            pass

        # Uses the super 'object' class getter, which looks in instance __dict__
        # Only use that for internal values, otherwise use self._store
        if _is_key_internal(key):
            value = super().__getattribute__(key)
            return value

        # This is to keep the only upper case mode working
        # __getattribute__ will only match exact casing, first levels always upper
        if _should_use_strict_uppercase(key, self):
            value = core.store.__getattribute__(key)
        # Use regular .get which triggers hooks among other things
        else:
            value = self.get(key, default=empty)
            if value is empty:
                raise AttributeError(key)
            core.set_cached(key, value)
        return value

    def __getitem__(self, key):
        """Allow getting variables as dict keys `settings['KEY']`"""
        # WARNING: keep logic in sync with __getattr__
        # do we have cached value?
        try:
            if key != "__core__":
                core = self.__core__
                return core.get_cached(key)
        except KeyError:
            pass

        # Use regular .get which triggers hooks among other things
        value = self.get(key, default=empty)
        if value is empty:
            raise KeyError(f"{key} does not exist")
        core.set_cached(key, value)
        return value

    @invalidates_cache
    def __setattr__(self, name, value):
        """Allow `settings.FOO = 'value'` while keeping internal attrs."""
        if name in RESERVED_ATTRS:
            super().__setattr__(name, value)
        else:
            self.set(name, value)

    def __setitem__(self, key, value):
        """Allow `settings['KEY'] = 'value'`"""
        self.__setattr__(key, value)

    @invalidates_cache
    def __delattr__(self, name):
        """stores reference in `_deleted` for proper error management"""
        self.__core__.config.deleted.add(name)
        if hasattr(self, name):
            super().__delattr__(name)

    @invalidates_cache
    def __delitem__(self, name):
        self.__core__.config.deleted.add(name)
        self.set(name, "@del")

    def __contains__(self, item):
        """Respond to `item in settings`"""
        nested_sep = getattr(self, "NESTED_SEPARATOR_FOR_DYNACONF", None)

        if isinstance(item, str) and nested_sep and nested_sep in item:
            item = item.replace(nested_sep, ".")
        if isinstance(item, str) and "." in item:
            return self.get(item, default=missing) is not missing

        return item.upper() in self.store or item.lower() in self.store

    def __dir__(self):
        """Enable auto-complete for code editors"""
        return (
            RESERVED_ATTRS
            + [k.lower() for k in self.keys()]
            + list(self.keys())
        )

    def __iter__(self):
        """Redirects to store object"""
        yield from self.store

    def __call__(self, *args, **kwargs):
        """Allow direct call of `settings('val')`
        in place of `settings.get('val')`
        """
        return self.get(*args, **kwargs)

    def items(self):
        """Redirects to store object"""
        return self.store.items()

    def keys(self):
        """Redirects to store object"""
        return self.store.keys()

    def values(self):
        """Redirects to store object"""
        return self.store.values()

    @invalidates_cache
    def setdefault(
        self, item, default, apply_default_on_none=False, env: str = "unknown"
    ):
        """Returns value if exists or set it as the given default

        apply_default_on_none: if True, default is set when value is None
        env: used to create the source identifier
        """
        value = self.get(item, empty)

        # Yaml loader reads empty values as None, would we apply defaults?
        global_apply_default = (
            self.get("APPLY_DEFAULT_ON_NONE_FOR_DYNACONF") is not None
        )
        apply_default = default is not empty and (
            value is empty
            or (
                value is None
                and (
                    apply_default_on_none is True
                    or global_apply_default is True
                )
            )
        )
        loader_identifier = SourceMetadata("setdefault", "unique", env.lower())

        if apply_default:
            # Passing tomlfy_filter prevents side-effects of tomlfy on sibling items.
            # See: https://github.com/dynaconf/dynaconf/issues/905
            self.set(
                item,
                default,
                loader_identifier=loader_identifier,
                tomlfy=True,
                tomlfy_filter=(item,),
            )
            return default

        return value

    def as_dict(self, env=None, internal=False):
        """Returns a dictionary with set key and values.

        :param env: Str env name, default self.current_env `DEVELOPMENT`
        :param internal: bool - should include dynaconf internal vars?
        """
        ctx_mgr = suppress() if env is None else self.using_env(env)
        with ctx_mgr:
            data = to_dict(self.store)
            # if not internal remove internal settings
            if not internal:
                for name in UPPER_DEFAULT_SETTINGS:
                    data.pop(name, None)
            return data

    to_dict = as_dict  # backwards compatibility

    def _dotted_get(
        self,
        dotted_key,
        default=None,
        parent=None,
        cast=None,
        tomlfy_filter=None,
        **kwargs,
    ):
        """
        Perform dotted key lookups and keep track of where we are.
        :param key: The name of the setting value, will always be upper case
        :param default: In case of not found it will be returned
        :param parent: Is there a pre-loaded parent in a nested data?
        """
        split_key = dotted_key.split(".")
        name, keys = split_key[0], split_key[1:]
        result = self.get(name, default=default, parent=parent, **kwargs)

        # If we've reached the end, or parent key not found, then return result
        if not keys or result == default:
            if cast and cast in converters:
                return apply_converter(cast, result, box_settings=self)
            elif cast is True:
                return parse_conf_data(
                    result,
                    tomlfy=True,
                    box_settings=self,
                    tomlfy_filter=tomlfy_filter,
                )
            return result

        # Still keys left, but current result/parent is not a data container
        if keys and not isinstance(result, (dict, list)):
            result_type = type(result).__name__
            raise AttributeError(
                f"Invalid dotted lookup in {dotted_key}. {name} is a {result_type}"
            )

        # If we've still got key elements to traverse, let's do that.
        return self._dotted_get(
            ".".join(keys),
            default=default,
            parent=result,
            cast=cast,
            tomlfy_filter=tomlfy_filter,
            **kwargs,
        )

    def get(
        self,
        key,
        default=None,
        cast=None,
        fresh=False,
        dotted_lookup=empty,
        parent=None,
        sysenv_fallback=None,
    ) -> Any:
        """
        Get a value from settings store, this is the preferred way to access::

            >>> from dynaconf import settings
            >>> settings.get('KEY')

        :param key: The name of the setting value, will always be upper case
        :param default: In case of not found it will be returned
        :param cast: Should cast in to @int, @float, @bool or @json ?
        :param fresh: Should reload from loaders store before access?
        :param dotted_lookup: Should perform dotted-path lookup?
        :param parent: Is there a pre-loaded parent in a nested data?
        :param sysenv_fallback: Should fallback to system environ if not found?
        :return: The value if found, default or None
        """
        core = self.__core__
        config = core.config
        if sysenv_fallback is None:
            sysenv_fallback = getattr(
                self, "SYSENV_FALLBACK_FOR_DYNACONF", None
            )

        nested_sep = getattr(self, "NESTED_SEPARATOR_FOR_DYNACONF", None)
        if isinstance(key, str):
            if nested_sep and nested_sep in key:
                # turn FOO__bar__ZAZ in `FOO.bar.ZAZ`
                key = key.replace(nested_sep, ".")

            if dotted_lookup is empty:
                dotted_lookup = getattr(
                    self, "DOTTED_LOOKUP_FOR_DYNACONF", None
                )

            if "." in key and dotted_lookup:
                return self._dotted_get(
                    dotted_key=key,
                    default=default,
                    cast=cast,
                    fresh=fresh,
                    parent=parent,
                )

            key = upperfy(key)

        # handles system environment fallback
        if default is None:
            key_in_sysenv_fallback_list = isinstance(
                sysenv_fallback, list
            ) and key in [upperfy(k) for k in sysenv_fallback]
            if sysenv_fallback is True or key_in_sysenv_fallback_list:
                default = self.get_environ(key, cast=True)

        # default values should behave exactly Dynaconf parsed values
        # NOTE: is this really required?
        if default is not None and config.dynaboxify:
            if isinstance(default, list):
                default = DataList(default)
            elif isinstance(default, dict):
                default = DataDict(default)

        if key in config.deleted:
            return default

        if (
            (fresh or config.fresh or key in config.fresh_vars)
            and key not in UPPER_DEFAULT_SETTINGS
            and parent is None
        ):
            # `parent` is only set when resolving a child segment of a
            # dotted key against an already-fetched nested container
            # (see `_dotted_get`). Such a `key` is not a real top-level
            # setting, so it must not be unset/reloaded here: doing so
            # would mark it as deleted permanently and break every
            # future lookup of the dotted key.
            self.unset(key)
            self.execute_loaders(key=key)

        data = _get_with_default(parent or core.store, key, default)
        if config.dynaboxify is False:
            data = recursively_evaluate_lazy_format(data, self)
        if cast:
            data = apply_converter(cast, data, box_settings=self)
        return data

    def exists(self, key, fresh=False):
        """Check if key exists

        :param key: the name of setting variable
        :param fresh: if key should be taken from source directly
        :return: Boolean
        """
        key = upperfy(key)
        if key in self.__core__.config.deleted:
            return False
        return self.get(key, fresh=fresh, default=missing) is not missing

    @invalidates_cache
    def get_fresh(self, key, default=None, cast=None):
        """This is a shortcut to `get(key, fresh=True)`. always reload from
        loaders store before getting the var.

        :param key: The name of the setting value, will always be upper case
        :param default: In case of not found it will be returned
        :param cast: Should cast in to @int, @float, @bool or @json ?
        :return: The value if found, default or None
        """
        return self.get(key, default=default, cast=cast, fresh=True)

    @invalidates_cache
    def get_environ(self, key, default=None, cast=None):
        """Get value from environment variable using os.environ.get

        :param key: The name of the setting value, will always be upper case
        :param default: In case of not found it will be returned
        :param cast: Should cast in to @int, @float, @bool or @json ?
         or cast must be true to use cast inference
        :return: The value if found, default or None
        """
        key = upperfy(key)
        data = self.environ.get(key, default)
        if data:
            if cast in converters:
                data = apply_converter(cast, data, box_settings=self)
            elif cast is True:
                data = parse_conf_data(
                    boolean_fix(data),
                    tomlfy=True,
                    box_settings=self,
                    tomlfy_filter=(key,),
                )
        return data

    def exists_in_environ(self, key):
        """Return True if env variable is exported"""
        return upperfy(key) in self.environ

    def as_bool(self, key):
        """Partial method for get with bool cast"""
        return self.get(key, cast="@bool")

    def as_int(self, key):
        """Partial method for get with int cast"""
        return self.get(key, cast="@int")

    def as_float(self, key):
        """Partial method for get with float cast"""
        return self.get(key, cast="@float")

    def as_json(self, key):
        """Partial method for get with json cast"""
        return self.get(key, cast="@json")

    @property
    def loaded_envs(self):
        """Get or create internal loaded envs list"""
        return self.__core__.config.loaded_envs

    @loaded_envs.setter
    def loaded_envs(self, value):
        """Setter for env list"""
        self.__core__.config.loaded_envs = value

    # compat
    loaded_namespaces = loaded_envs

    @property
    def loaded_by_loaders(self):  # pragma: no cover
        """Gets the internal mapping of LOADER -> values"""
        config = self.__core__.config
        return config.loaded_by_loaders

    @invalidates_cache
    def from_env(self, env="", keep=False, **kwargs):
        """Return a new isolated settings object pointing to specified env.

        Example of settings.toml::

            [development]
            message = 'This is in dev'
            [other]
            message = 'this is in other env'

        Program::

            >>> from dynaconf import settings
            >>> print(settings.MESSAGE)
            'This is in dev'
            >>> print(settings.from_env('other').MESSAGE)
            'This is in other env'
            # The existing settings object remains the same.
            >>> print(settings.MESSAGE)
            'This is in dev'

        Arguments:
            env {str} -- Env to load (development, production, custom)

        Keyword Arguments:
            keep {bool} -- Keep pre-existing values (default: {False})
            kwargs {dict} -- Passed directly to new instance.
        """
        config = self.__core__.config

        cache_key = f"{env}_{keep}_{kwargs}"
        if cache_key in config.env_cache:
            return config.env_cache[cache_key]

        new_data = {
            key: self.get(key)
            for key in UPPER_DEFAULT_SETTINGS
            if key not in RENAMED_VARS
        }

        if self.filter_strategy:
            # Retain the filtering strategy when switching environments
            new_data["filter_strategy"] = self.filter_strategy

        # This is here for backwards compatibility
        # To be removed on 4.x.x
        default_settings_paths = self.get("default_settings_paths")
        if default_settings_paths:  # pragma: no cover
            new_data["default_settings_paths"] = default_settings_paths

        if keep:
            # keep existing values from current env
            new_data.update(
                {
                    key: value
                    for key, value in to_dict(self.store).items()
                    if key.isupper() and key not in RENAMED_VARS
                }
            )

        if getattr(self, "validators", None):
            new_data.setdefault("validators", self.validators)

        new_data.update(kwargs)
        new_data["FORCE_ENV_FOR_DYNACONF"] = env
        new_data.setdefault("dynaconf_skip_validators", True)
        new_settings = LazySettings(**new_data)
        new_settings.unset("DYNACONF_SKIP_VALIDATORS")
        config.env_cache[cache_key] = new_settings

        # update source metadata for inspecting
        self.loaded_by_loaders.update(new_settings.loaded_by_loaders)

        return new_settings

    @contextmanager
    @invalidates_cache
    def using_env(self, env, clean=True, silent=True, filename=None):
        """
        This context manager allows the contextual use of a different env
        Example of settings.toml::

            [development]
            message = 'This is in dev'
            [other]
            message = 'this is in other env'

        Program::

            >>> from dynaconf import settings
            >>> print settings.MESSAGE
            'This is in dev'
            >>> with settings.using_env('OTHER'):
            ...    print settings.MESSAGE
            'this is in other env'

        :param env: Upper case name of env without any _
        :param clean: If preloaded vars should be cleaned
        :param silent: Silence errors
        :param filename: Custom filename to load (optional)
        :return: context
        """
        try:
            self.setenv(env, clean=clean, silent=silent, filename=filename)
            yield
        finally:
            if env.lower() != self.ENV_FOR_DYNACONF.lower():
                del self.loaded_envs[-1]
            self.setenv(self.current_env, clean=clean, filename=filename)

    # compat
    using_namespace = using_env

    @contextmanager
    @invalidates_cache
    def fresh(self):
        """
        this context manager force the load of a key direct from the store::

            $ export DYNACONF_VALUE='Original'
            >>> from dynaconf import settings
            >>> print settings.VALUE
            'Original'
            $ export DYNACONF_VALUE='Changed Value'
            >>> print settings.VALUE  # will not be reloaded from env vars
            'Original
            >>> with settings.fresh(): # inside this context all is reloaded
            ...    print settings.VALUE
            'Changed Value'

        an alternative is using `settings.get_fresh(key)`

        :return: context
        """

        self.__core__.config.fresh = True
        yield
        self.__core__.config.fresh = False

    @property
    def current_env(self):
        """Return the current active env"""

        if self.ENVIRONMENTS_FOR_DYNACONF is False:
            return self.MAIN_ENV_FOR_DYNACONF.lower()

        if self.FORCE_ENV_FOR_DYNACONF is not None:
            forced = self.FORCE_ENV_FOR_DYNACONF
            self.set("ENV_FOR_DYNACONF", forced, validate=False)
            return forced

        try:
            return self.loaded_envs[-1]
        except IndexError:
            return self.ENV_FOR_DYNACONF

    # compat
    current_namespace = current_env

    @property
    def settings_module(self):
        """Gets SETTINGS_MODULE variable"""
        settings_module = parse_conf_data(
            os.environ.get(
                self.ENVVAR_FOR_DYNACONF, self.SETTINGS_FILE_FOR_DYNACONF
            ),
            tomlfy=True,
            box_settings=self,
        )
        if settings_module != getattr(self, "SETTINGS_MODULE", None):
            self.set(
                "SETTINGS_MODULE",
                settings_module,
                loader_identifier="settings_module_method",
            )

        # This is for backewards compatibility, to be removed on 4.x.x
        if not self.SETTINGS_MODULE and self.get("default_settings_paths"):
            self.SETTINGS_MODULE = self.get("default_settings_paths")

        return self.SETTINGS_MODULE

    # Backwards compatibility see #169
    settings_file = settings_module

    @invalidates_cache
    def setenv(self, env=None, clean=True, silent=True, filename=None):
        """Used to interactively change the env
        Example of settings.toml::

            [development]
            message = 'This is in dev'
            [other]
            message = 'this is in other env'

        Program::

            >>> from dynaconf import settings
            >>> print settings.MESSAGE
            'This is in dev'
            >>> with settings.using_env('OTHER'):
            ...    print settings.MESSAGE
            'this is in other env'

        :param env: Upper case name of env without any _
        :param clean: If preloaded vars should be cleaned
        :param silent: Silence errors
        :param filename: Custom filename to load (optional)
        :return: context
        """
        env = env or self.ENV_FOR_DYNACONF

        if not isinstance(env, str) or " " in env:
            raise ValueError("env should be a string without spaces")

        env = env.upper()

        if env != self.ENV_FOR_DYNACONF:
            self.loaded_envs.append(env)
        else:
            self.loaded_envs = []

        if clean:
            self.clean(env=env)
        self.execute_loaders(env=env, silent=silent, filename=filename)

    # compat
    namespace = setenv

    @invalidates_cache
    def clean(self, *args, **kwargs):
        """Clean all loaded values to reload when switching envs"""
        for key in list(self.store.keys()):
            self.unset(key)

    @invalidates_cache
    def unset(self, key, force=False):
        """Unset on all references

        :param key: The key to be unset
        :param force: Bypass default checks and force unset
        """
        config = self.__core__.config
        key = upperfy(key.strip())
        if (
            key not in UPPER_DEFAULT_SETTINGS
            and key not in config.defaults
            or force
        ):
            with suppress(KeyError, AttributeError):
                # AttributeError can happen when a LazyValue consumes
                # a previously deleted key
                delattr(self, key)
                del self.store[key]

    @invalidates_cache
    def unset_all(self, keys, force=False):  # pragma: no cover
        """Unset based on a list of keys

        :param keys: a list of keys
        :param force: Bypass default checks and force unset
        """
        for key in keys:
            self.unset(key, force=force)

    def _dotted_set(
        self,
        dotted_key: str,
        value,
        tomlfy=False,
        validate=empty,
        tomlfy_filter=None,
        list_merge: ListMergeOptions = "shallow",
        **kwargs,
    ):
        """Sets dotted keys as nested dictionaries.

        Dotted set will always reassign the value, to merge use `@merge` token

        Arguments:
            dotted_key: A traversal name. E.g: foo.bar.zaz
            value: The value to set to the nested value.

        Keyword Arguments:
            tomlfy: Perform toml parsing (default: {False})
            validate: Pass the flag to validate down
            list_merge: The strategy used for list merging
        """
        config = self.__core__.config
        if validate is empty:
            validate = self.get(
                "VALIDATE_ON_UPDATE_FOR_DYNACONF"
            )  # pragma: nocover

        if config.dynaboxify:
            new_data: dict | DataDict = DataDict(box_settings=self)
        else:
            new_data = {}
        tree = new_data
        value = parse_conf_data(
            value,
            tomlfy=tomlfy,
            box_settings=self,
            tomlfy_filter=tomlfy_filter,
        )

        # 'deep' strategy is the index merging behavior
        if list_merge != "deep":
            split_keys = dotted_key.split(".")
            existing_data = self.get(split_keys[0], {})
            for k in split_keys[:-1]:
                tree = tree.setdefault(k, {})
            value = parse_conf_data(value, tomlfy=tomlfy, box_settings=self)
            tree[split_keys[-1]] = value
        else:
            # TODO @pbrochad: refactor this implementation, it's really cumbersome
            # https://github.com/dynaconf/dynaconf/issues/todo
            # Example in the `tree.extend` call in the block below:
            # if 'id(tree) == id(next_default)' we may get an infinite recursive list. Try:
            # >>> li=[]
            # >>> li.extend([li])
            # >>> li[0][0]...[0]
            split_keys = dotted_key.replace("[", ".[").split(".")
            existing_data = self.get(split_keys[0], {})
            for n, k in enumerate(split_keys):
                is_not_end = n < (len(split_keys) - 1)
                if is_not_end:
                    next_default: Union[list, dict] = (
                        [] if "[" in split_keys[n + 1] else {}
                    )

                if "[" not in k:  # accessing field of a dict
                    if is_not_end:
                        tree = tree.setdefault(k, next_default)  # get next
                    else:
                        tree[k] = value  # assign value
                elif (
                    k.startswith("[")
                    and k.endswith("]")
                    and isinstance(tree, list)
                ):  # accessing index of a list
                    index = int(k.replace("[", "").replace("]", ""))
                    # Pad missing positions so we can assign any index.
                    # On the last segment the slot holds the value itself, so
                    # gaps should be empty (None) instead of a copy of
                    # `next_default`, which still refers to the previous level.
                    if is_not_end:
                        extended_list = [
                            next_default.copy()  # type: ignore[attr-defined]
                            for _ in range(index + 1)
                        ]
                    else:
                        extended_list = [None] * (index + 1)
                    # This makes sure we can assign any arbitrary index
                    tree.extend(extended_list)
                    if is_not_end:
                        tree = tree[index]  # get at index
                    else:
                        tree[index] = value  # assign value
                else:  # odd cases like [2]0
                    raise (ValueError("Invalid field:", k))

        if existing_data:
            if config.dynaboxify:
                old_data: dict | DataDict = DataDict(
                    {split_keys[0]: existing_data}, box_settings=self
                )
            else:
                old_data = {split_keys[0]: existing_data}

            new_data = object_merge(
                old=old_data,
                new=new_data,
                full_path=split_keys,
                list_merge=list_merge,  # when to use deep / shallow replace?
            )
        # `new_data` is keyed by the already-resolved top level key
        # (`split_keys[0]`). With index merge disabled a bracket is a literal
        # key, so that key can still contain `[` (e.g. `servers[0]`). Writing
        # it with dotted_lookup on would route it back into `_dotted_set` and
        # recurse forever, so set the resolved keys literally.
        self.update(
            data=new_data,
            tomlfy=tomlfy,
            validate=validate,
            tomlfy_filter=tomlfy_filter,
            dotted_lookup=False,
            **kwargs,
        )

    @invalidates_cache
    def set(
        self,
        key,
        value,
        loader_identifier: SourceMetadata | str | None = None,
        tomlfy=False,
        dotted_lookup=empty,
        is_secret="DeprecatedArgument",  # noqa
        validate=empty,
        merge=empty,
        tomlfy_filter: tuple[str, ...] | None = None,
    ):
        """Set a value storing references for the loader

        :param key: The key to store. Can be of any type.
        :param value: The raw value to parse and store
        :param loader_identifier: Optional loader name e.g: toml, yaml etc.
                                  Or instance of SourceMetadata
        :param tomlfy: Bool define if value is parsed by toml (defaults False)
        :param merge: Bool define if existing nested data will be merged.
        :param validate: Bool define if validation will be triggered
        :param tomlfy_filter: Optional tuple with the keys where tomlfy should apply
        """
        core = self.__core__
        config = core.config

        # Ensure source_metadata always is set even if set is called
        # without a loader_identifier
        if isinstance(loader_identifier, str) or loader_identifier is None:
            source_metadata = SourceMetadata(
                loader="set_method",
                identifier=loader_identifier or "undefined",
                merged=merge is True,
            )
        else:  # loader identifier must be a SourceMetadata instance
            source_metadata = loader_identifier

        if validate is empty:
            validate = self.get("VALIDATE_ON_UPDATE_FOR_DYNACONF")
        if dotted_lookup is empty:
            dotted_lookup = self.get("DOTTED_LOOKUP_FOR_DYNACONF")

        # Do index replacement first
        list_merge: ListMergeOptions = "shallow"  # default
        nested_ind = self.get("INDEX_SEPARATOR_FOR_DYNACONF")
        index_merge_enabled = bool(nested_ind)
        if index_merge_enabled and isinstance(key, str):
            list_merge = "deep"
            # DYNACONF_DATA__a___0__key___2__subkey ->
            # DYNACONF_DATA__a[0]__key[2]__subkey
            nested_ind = rf"{nested_ind}(\d+)"
            key = re.sub(nested_ind, r"[\1]", key)

        nested_sep = self.get("NESTED_SEPARATOR_FOR_DYNACONF")

        if isinstance(key, str):
            if nested_sep and nested_sep in key:
                key = key.replace(nested_sep, ".")  # FOO__bar -> FOO.bar

            if ("." in key or "[" in key) and dotted_lookup is True:
                return self._dotted_set(
                    key,
                    value,
                    loader_identifier=source_metadata,
                    tomlfy=tomlfy,
                    validate=validate,
                    tomlfy_filter=tomlfy_filter,
                    list_merge=list_merge,
                )
            key = upperfy(key.strip())

        parsed = parse_conf_data(
            value,
            tomlfy=tomlfy,
            box_settings=self,
            tomlfy_filter=tomlfy_filter,
        )

        # Fix for #869 - Evaluating an existing lazy value during set can
        # fail before a complete replacement value is stored.
        existing = None
        if not isinstance(parsed, Lazy):
            with suppress(AttributeError, KeyError):
                if isinstance(self.store, DataDict):
                    existing = self.store.get(key, bypass_eval=True)
                else:
                    existing = self.store.get(key)

        if getattr(parsed, "_dynaconf_insert", False):
            # `@insert` calls insert in a list by index
            if existing and isinstance(existing, list):
                source_metadata = source_metadata._replace(merged=True)
                existing.insert(parsed.index, parsed.unwrap())
                parsed = existing
            else:
                parsed = [parsed.unwrap()]

        if getattr(parsed, "_dynaconf_del", None):
            self.unset(key, force=True)  # `@del` in a first level var.
            return

        if getattr(parsed, "_dynaconf_reset", False):  # pragma: no cover
            parsed = parsed.unwrap()  # `@reset` in a first level var.

        if getattr(parsed, "_dynaconf_merge_unique", False):
            # `@merge_unique` in a first level var
            if existing:
                # update SourceMetadata (for inspecting purposes)
                source_metadata = source_metadata._replace(merged=True)
                parsed = object_merge(existing, parsed.unwrap(), unique=True)
            else:
                parsed = parsed.unwrap()

        if getattr(parsed, "_dynaconf_merge", False):
            # `@merge` in a first level var
            if existing:
                # update SourceMetadata (for inspecting purposes)
                source_metadata = source_metadata._replace(merged=True)
                parsed = object_merge(existing, parsed.unwrap())
            else:
                parsed = parsed.unwrap()

        should_merge = existing is not None and existing != parsed
        if should_merge:
            # `dynaconf_merge` used in file root `merge=True`
            if merge and merge is not empty:
                source_metadata = source_metadata._replace(merged=True)
                parsed = object_merge(existing, parsed)
            else:
                # `dynaconf_merge` may be used within the key structure
                # Or merge_enabled is set to True
                parsed, source_metadata = self._merge_before_set(
                    existing,
                    parsed,
                    source_metadata,
                    context_merge=merge,
                )

        if (
            self.get("DYNABOXIFY", True)
            and isinstance(parsed, dict)
            and not isinstance(parsed, DataDict)
        ):
            parsed = DataDict(parsed, box_settings=self)

        if isinstance(parsed, list) and not isinstance(parsed, DataList):
            parsed = DataList(parsed, box_settings=self)

        # Set the parsed value
        self.store[key] = parsed
        config.deleted.discard(key)

        # only use super().__setattr__ (uses the 'object' class setattr)
        # with internal values. Other values should go to internal store
        if _is_key_internal(key):
            super().__setattr__(key, parsed)

        # Track history for inspect, store the raw_value
        if source_metadata in self.loaded_by_loaders:
            self.loaded_by_loaders[source_metadata][key] = value
        else:
            self.loaded_by_loaders[source_metadata] = {key: value}

        if loader_identifier is None:
            # if .set is called without loader identifier it becomes
            # a default value and goes away only when explicitly unset
            config.defaults[key] = parsed

        if validate is True:
            core.validators.validate()

    @invalidates_cache
    def update(
        self,
        data=None,
        loader_identifier=None,
        tomlfy=False,
        merge=empty,
        is_secret="DeprecatedArgument",  # noqa
        dotted_lookup=empty,
        validate=empty,
        tomlfy_filter=None,
        **kwargs,
    ):
        """
        Update values in the current settings object without saving in stores::

            >>> from dynaconf import settings
            >>> print settings.NAME
            'Bruno'
            >>> settings.update({'NAME': 'John'}, other_value=1)
            >>> print settings.NAME
            'John'
            >>> print settings.OTHER_VALUE
            1

        :param data: Data to be updated
        :param loader_identifier: Only to be used by custom loaders
        :param tomlfy: Bool define if value is parsed by toml (defaults False)
        :param merge: Bool define if existing nested data will be merged.
        :param validate: Bool define if validators will trigger automatically
        :param kwargs: extra values to update
        :return: None
        """
        core = self.__core__

        if validate is empty:
            validate = self.get("VALIDATE_ON_UPDATE_FOR_DYNACONF")

        data = data or {}
        data.update(kwargs)

        for key, value in data.items():
            # update() will handle validation later
            with suppress(ValidationError):
                self.set(
                    key,
                    value,
                    loader_identifier=loader_identifier,
                    tomlfy=tomlfy,
                    merge=merge,
                    dotted_lookup=dotted_lookup,
                    validate=validate,
                    tomlfy_filter=tomlfy_filter,
                )

        # handle param `validate`
        if validate is True:
            core.validators.validate()
        elif validate == "all":
            core.validators.validate_all()

    def _merge_before_set(
        self,
        existing,
        value,
        identifier: SourceMetadata | None = None,
        context_merge=empty,
        list_merge="merge",
    ):
        """
        Merge the new value being set with the existing value before set
        Returns the merged value and the updated identifier (for inspecting).
        """
        # context_merge may come from file_scope or env_scope
        if context_merge is empty:
            context_merge = self.get("MERGE_ENABLED_FOR_DYNACONF")

        if isinstance(value, dict):
            local_merge = value.pop(
                "dynaconf_merge", value.pop("dynaconf_merge_unique", None)
            )
            if local_merge not in (True, False, None) and not value:
                # In case `dynaconf_merge:` holds value not boolean - ref #241
                value = local_merge

            if local_merge or (context_merge and local_merge is not False):
                identifier = (
                    identifier._replace(merged=True) if identifier else None
                )
                value = object_merge(existing, value, list_merge=list_merge)

        if isinstance(value, (list, tuple)):
            value = list(value)
            local_merge = None
            unique = False
            if "dynaconf_merge" in value:
                value.remove("dynaconf_merge")
                local_merge = True
            elif "dynaconf_merge_unique" in value:
                value.remove("dynaconf_merge_unique")
                local_merge = True
                unique = True

            if local_merge or (context_merge and local_merge is not False):
                identifier = (
                    identifier._replace(merged=True) if identifier else None
                )
                value = object_merge(existing, value, unique=unique)
        return value, identifier

    @property
    def loaders(self):  # pragma: no cover
        """Return available loaders"""
        config = self.__core__.config
        if self.LOADERS_FOR_DYNACONF in (None, 0, "0", "false", False):
            return []

        if not config.loaders:
            config.loaders = self.LOADERS_FOR_DYNACONF

        return [importlib.import_module(loader) for loader in config.loaders]

    @invalidates_cache
    def reload(self, env=None, silent=None):  # pragma: no cover
        """Clean end Execute all loaders"""
        config = self.__core__.config
        self.clean()
        config.loaded_hooks.clear()
        for hook in config.post_hooks:
            with suppress(AttributeError, TypeError):
                hook._called = False

        self.execute_loaders(env, silent)

    def execute_loaders(
        self, env=None, silent=None, key=None, filename=None, loaders=None
    ):
        """Execute all internal and registered loaders

        :param env: The environment to load
        :param silent: If loading errors is silenced
        :param key: if provided load a single key
        :param filename: optional custom filename to load
        :param loaders: optional list of loader modules
        """
        config = self.__core__.config
        if key is None:
            default_loader(self, config.defaults)

        env = (env or self.current_env).upper()
        silent = silent or self.SILENT_ERRORS_FOR_DYNACONF

        if loaders is None:
            self.pre_load(env, silent=silent, key=key)
            settings_loader(
                self, env=env, silent=silent, key=key, filename=filename
            )
            self.load_extra_yaml(env, silent, key)  # DEPRECATED
            enable_external_loaders(self)

            loaders = self.loaders
        # non setting_file or py_module loaders
        for core_loader in loaders:
            core_loader.load(self, env, silent=silent, key=key)

        self.load_includes(env, silent=silent, key=key)

        # execute hooks
        execute_module_hooks("post", self, env, silent=silent, key=key)
        execute_instance_hooks(self, "post", config.post_hooks)

        # always upper
        config.fresh_vars = ensure_upperfied_list(self.FRESH_VARS_FOR_DYNACONF)

    def pre_load(self, env, silent, key):
        """Do we have any file to pre-load before main settings file?"""
        preloads = self.get("PRELOAD_FOR_DYNACONF", [])
        if preloads:
            self.load_file(path=preloads, env=env, silent=silent, key=key)

    def load_includes(self, env, silent, key):
        """Do we have any nested includes we need to process?"""
        includes = ensure_a_list(self.get("DYNACONF_INCLUDE"))
        includes.extend(ensure_a_list(self.get("INCLUDES_FOR_DYNACONF")))
        if includes:
            self.load_file(path=includes, env=env, silent=silent, key=key)
            # ensure env vars are the last thing loaded after all includes
            last_loader = self.loaders and self.loaders[-1]
            if last_loader and last_loader == env_loader:
                last_loader.load(self, env, silent, key)

    @invalidates_cache
    def load_file(
        self,
        path=None,
        env=None,
        silent=True,
        key=None,
        validate=empty,
        run_hooks=True,
    ):
        """Programmatically load files from ``path``.

        When using relative paths, the basedir fallbacks in this order:
        - ROOT_PATH_FOR_DYNACONF
        - Directory of the last loaded file
        - CWD

        :param path: A single filename, a glob or a file list
        :param env: Which env to load from file (default current_env)
        :param silent: Should raise errors?
        :param key: Load a single key?
        :param validate: Should trigger validation?
        :param run_hooks: Should run collected hooks?
        """
        core = self.__core__
        config = core.config

        files = ensure_a_list(path)
        if not files:  # a glob pattern may return empty
            return

        if validate is empty:
            validate = self.get("VALIDATE_ON_UPDATE_FOR_DYNACONF")

        env = "_envless" if env is False else (env or self.current_env).upper()

        # Using inspect take the filename and line number of the caller
        # to be used in the source_metadata
        frame = inspect.currentframe()
        caller = inspect.getouterframes(frame)[1]

        already_loaded = set()
        for _filename in files:
            # load_file() will handle validation later
            with suppress(ValidationError):
                source_metadata = SourceMetadata(
                    loader=f"load_file@{caller.filename}:{caller.lineno}",
                    identifier=_filename,
                    env=env,
                )
                if py_loader.try_to_load_from_py_module_name(
                    obj=self,
                    name=_filename,
                    silent=True,
                    identifier=source_metadata,
                ):
                    # if it was possible to load from module name
                    # continue the loop.
                    continue

            root_dir = str(self._root_path or os.getcwd())

            # Issue #494
            if (
                isinstance(_filename, Path)
                and str(_filename.parent) in root_dir
            ):  # pragma: no cover
                filepath = str(_filename)
            else:
                filepath = os.path.join(root_dir, str(_filename))

            paths = [p for p in sorted(glob(filepath)) if ".local." not in p]
            local_paths = [p for p in sorted(glob(filepath)) if ".local." in p]

            if (
                not silent
                and not paths
                and not local_paths
                and not has_magic(filepath)
            ):
                raise FileNotFoundError(filepath)

            # Handle possible *.globs sorted alphanumeric
            for path in paths + local_paths:
                if path in already_loaded:  # pragma: no cover
                    continue

                # load_file() will handle validation later
                with suppress(ValidationError):
                    source_metadata = SourceMetadata(
                        loader=f"load_file@{caller.filename}:{caller.lineno}",
                        identifier=path,
                        env=env,
                    )
                    settings_loader(
                        obj=self,
                        env=env,
                        silent=silent,
                        key=key,
                        filename=path,
                        validate=validate,
                        identifier=source_metadata,
                    )
                    already_loaded.add(path)

        if run_hooks:
            # this will call any collected hook that was not called yet
            execute_instance_hooks(
                self,
                "post",
                [
                    _hook
                    for _hook in config.post_hooks
                    if getattr(_hook, "_dynaconf_hook", False) is True
                    and not getattr(_hook, "_called", False)
                ],
            )

        # handle param `validate`
        if validate is True:
            core.validators.validate()
        elif validate == "all":
            core.validators.validate_all()

    @property
    def _root_path(self):
        """ROOT_PATH_FOR_DYNACONF or the path of first loaded file or '.'"""
        config = self.__core__.config

        if self.ROOT_PATH_FOR_DYNACONF is not None:
            return self.ROOT_PATH_FOR_DYNACONF

        if config.loaded_files:  # called once
            root_path = os.path.dirname(config.loaded_files[0])
            self.set(
                "ROOT_PATH_FOR_DYNACONF",
                root_path,
                loader_identifier="_root_path",
            )
            return root_path

    def load_extra_yaml(self, env, silent, key):
        """This is deprecated, kept for compat

        .. deprecated:: 1.0.0
            Use multiple settings or INCLUDES_FOR_DYNACONF files instead.
        """
        if self.get("YAML") is not None:
            warnings.warn(
                "The use of YAML var is deprecated, please define multiple "
                "filepaths instead: "
                "e.g: SETTINGS_FILE_FOR_DYNACONF = "
                "'settings.py,settings.yaml,settings.toml' or "
                "INCLUDES_FOR_DYNACONF=['path.toml', 'folder/*']"
            )
            yaml_loader.load(
                self,
                env=env,
                filename=self.find_file(self.get("YAML")),
                silent=silent,
                key=key,
            )

    def path_for(self, *args):
        """Path containing _root_path"""
        if args and args[0].startswith(os.path.sep):
            return os.path.join(*args)
        return os.path.join(self._root_path or os.getcwd(), *args)

    def find_file(self, *args, **kwargs):
        kwargs.setdefault("project_root", self._root_path)
        kwargs.setdefault(
            "skip_files", self.get("SKIP_FILES_FOR_DYNACONF", [])
        )
        return find_file(*args, **kwargs)

    def flag(self, key, env=None):
        """Feature flagging system
        write flags to redis
        $ dynaconf write redis -s DASHBOARD=1 -e premiumuser
        meaning: Any premium user has DASHBOARD feature enabled

        In your program do::

            # premium user has access to dashboard?
            >>> if settings.flag('dashboard', 'premiumuser'):
            ...     activate_dashboard()

        The value is ensured to be loaded fresh from redis server

        It also works with file settings but the recommended is redis
        as the data can be loaded once it is updated.

        :param key: The flag name
        :param env: The env to look for
        """
        env = env or self.ENVVAR_PREFIX_FOR_DYNACONF or "DYNACONF"
        with self.using_env(env):
            value = self.get_fresh(key)
            return value is True or str(value).strip().lower() in true_values

    def populate_obj(
        self,
        obj,
        keys=None,
        ignore=None,
        merge=False,
        merge_unique=False,
        internal=False,
        convert_to_dict=False,
    ):
        """Given the `obj` populate it using self.store items.

        :param obj: An object to be populated, a class instance.
        :param keys: A list of keys to be included.
        :param ignore: A list of keys to be excluded.
        :param merge: Merge values with values existing in object.
        :param merge_unique: Merge without duplication.
        :param internal: Include internal keys.
        :param convert_to_dict: Convert the settings to a pure dict (no Box)
         before populating.
        """
        merge = merge or self.get("MERGE_ENABLED_FOR_DYNACONF")
        data = self.to_dict(internal=internal) if convert_to_dict else self
        keys = keys or self.keys()
        for key in keys:
            key = upperfy(key)
            if not internal:
                if key in UPPER_DEFAULT_SETTINGS:
                    continue
            if ignore and key in ignore:
                continue
            value = data.get(key, empty)
            if isinstance(value, (list, dict)):
                if isinstance(value, dict):
                    if "dynaconf_merge" in value:
                        # the key will be popped out inside object_merge
                        merge = True
                if isinstance(value, list):
                    if "dynaconf_merge" in value:
                        value.remove("dynaconf_merge")
                        merge = True
                    if "dynaconf_merge_unique" in value:
                        merge = merge_unique = True
                if merge and (existing := getattr(obj, key, None)):
                    value = object_merge(existing, value, merge_unique)
            if value is not empty:
                setattr(obj, key, value)

    def dynaconf_clone(self):
        """Clone the current settings object."""
        try:
            return copy.deepcopy(self)
        except (TypeError, copy.Error):
            # can't deepcopy settings object because of module object
            # being set as value in the settings dict
            new_data = self.to_dict(internal=True)
            new_data["dynaconf_skip_loaders"] = True
            new_data["dynaconf_skip_validators"] = True
            new_data["_registered_hooks"] = {}
            new_data["_REGISTERED_HOOKS"] = {}
            return self.__class__(**new_data)

    @property
    def dynaconf(self):
        """A proxy to access internal methods and attributes

        Starting in 3.0.0 Dynaconf now allows first level lower case
        keys that are not reserved keyword, so this is a proxy to
        internal methods and attrs.
        """

        class AttrProxy:
            def __init__(self, obj):
                self.obj = obj

            def __getattr__(self, name):
                return getattr(self.obj, f"dynaconf_{name}")

        return AttrProxy(self)

    @property
    def logger(self):  # pragma: no cover
        """backwards compatibility with pre 3.0 loaders
        In dynaconf 3.0.0 logger and debug messages has been removed.
        """
        warnings.warn(
            "logger and DEBUG messages has been removed on dynaconf 3.0.0"
        )
        import logging  # noqa

        return logging.getLogger("dynaconf")

    def is_overridden(self, setting):  # noqa
        """This is to provide Django DJDT support: issue 382"""
        return False


"""Upper case default settings"""
UPPER_DEFAULT_SETTINGS = [k for k in dir(default_settings) if k.isupper()]

"""Attributes created on Settings before 3.0.0. Remove in 4.0.0"""
RESERVED_ATTRS = [
    "__core__",
    "_kwargs",
    "SETTINGS_MODULE",
    "loaded_envs",
    "from_env",
    "_registered_hooks",
    "_REGISTERED_HOOKS",
]

_INTERNAL_KEYS = set(RESERVED_ATTRS + UPPER_DEFAULT_SETTINGS)

# These are special fields defined by Dynaconf, but users can access it
_PUBLIC_PROPERTIES = [
    name
    for name, _ in inspect.getmembers(
        Settings, lambda x: isinstance(x, property)
    )
]


@lru_cache
def _is_key_internal(key: str | int) -> bool:
    return (
        isinstance(key, str) and key.startswith("__")
    ) or key in _INTERNAL_KEYS


def _should_use_strict_uppercase(key, obj):
    return (isinstance(key, str) and key.islower()) and getattr(
        obj, "LOWERCASE_READ_FOR_DYNACONF", empty
    ) is False


def _should_load_dotenv(kwargs):
    """Chicken and egg problem, we must manually check envvar
    before deciding if we are loading envvars :)"""
    _environ_load_dotenv = parse_conf_data(
        boolean_fix(os.environ.get("LOAD_DOTENV_FOR_DYNACONF")),
        tomlfy=True,
    )
    return kwargs.get("load_dotenv", _environ_load_dotenv)


def _warn_global_settings_deprecation():
    warnings.warn(
        "Usage of `from dynaconf import settings` is now "
        "DEPRECATED in 3.0.0+. You are encouraged to change it to "
        "your own instance e.g: `settings = Dynaconf(*options)`",
        DeprecationWarning,
    )


def _warn_incompatible_typed_dynaconf_arg():
    warnings.warn(
        "dynaconf_options: Options works only with typed Dynaconf"
        "Change your import to: `from dynaconf.typed import Dynaconf`",
        RuntimeWarning,
    )


def _get_with_default(data: dict | list, key: str, default):
    if isinstance(data, dict):
        return data.get(key, default)
    elif isinstance(data, list):
        if not key.isdigit():
            raise ValueError(f"Expected integer, got: {key}")
        try:
            return data[int(key)]
        except KeyError:
            return default
    else:
        raise AttributeError(f"Unknown data container type: {type(data)}")
