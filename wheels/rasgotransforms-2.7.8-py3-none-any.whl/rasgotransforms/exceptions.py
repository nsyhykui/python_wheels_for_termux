class RenderException(Exception):
    pass
