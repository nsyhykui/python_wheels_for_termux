"""
A drop-in replacement for `argparse` that allows options to also be set via config files and/or environment variables.

:see: `configargparse.ArgumentParser`, `configargparse.add_argument`
"""

import argparse
import ast
import configparser
import csv
import functools
import json
import glob
import os
import re
import sys
import types
from collections import OrderedDict
import textwrap
import warnings
from io import StringIO

ACTION_TYPES_THAT_DONT_NEED_A_VALUE = [
    argparse._StoreTrueAction,
    argparse._StoreFalseAction,
    argparse._CountAction,
    argparse._StoreConstAction,
    argparse._AppendConstAction,
]

if sys.version_info >= (3, 9):
    ACTION_TYPES_THAT_DONT_NEED_A_VALUE.append(argparse.BooleanOptionalAction)
    is_boolean_optional_action = lambda action: isinstance(
        action, argparse.BooleanOptionalAction
    )
else:
    is_boolean_optional_action = lambda action: False

ACTION_TYPES_THAT_DONT_NEED_A_VALUE = tuple(ACTION_TYPES_THAT_DONT_NEED_A_VALUE)


# global ArgumentParser instances
_parsers = {}


def init_argument_parser(name=None, **kwargs):
    """Creates a global ArgumentParser instance with the given name,
    passing any args other than "name" to the ArgumentParser constructor.
    This instance can then be retrieved using get_argument_parser(..)
    """

    if name is None:
        name = "default"

    if name in _parsers:
        raise ValueError(
            (
                "kwargs besides 'name' can only be passed in the"
                " first time. '%s' ArgumentParser already exists: %s"
            )
            % (name, _parsers[name])
        )

    kwargs.setdefault("formatter_class", argparse.ArgumentDefaultsHelpFormatter)
    kwargs.setdefault("conflict_handler", "resolve")
    _parsers[name] = ArgumentParser(**kwargs)


def get_argument_parser(name=None, **kwargs):
    """Returns the global ArgumentParser instance with the given name. The 1st
    time this function is called, a new ArgumentParser instance will be created
    for the given name, and any args other than "name" will be passed on to the
    ArgumentParser constructor.
    """
    if name is None:
        name = "default"

    if len(kwargs) > 0 or name not in _parsers:
        init_argument_parser(name, **kwargs)

    return _parsers[name]


class ArgumentDefaultsRawHelpFormatter(
    argparse.ArgumentDefaultsHelpFormatter,
    argparse.RawTextHelpFormatter,
    argparse.RawDescriptionHelpFormatter,
):
    """HelpFormatter that adds default values AND doesn't do line-wrapping"""

    pass


class ConfigFileParser(object):
    """This abstract class can be extended to add support for new config file
    formats"""

    def get_syntax_description(self):
        """Returns a string describing the config file syntax."""
        raise NotImplementedError("get_syntax_description(..) not implemented")

    def parse(self, stream):
        """Parses the keys and values from a config file.

        NOTE: For keys that were specified to configargparse as
        action="store_true" or "store_false", the config file value must be
        one of: "yes", "no", "on", "off", "true", "false". Otherwise an error will be raised.

        Args:
            stream (io.IOBase): A config file input stream (such as an open file object).

        Returns:
            OrderedDict: Items where the keys are strings and the
            values are either strings or lists (eg. to support config file
            formats like YAML which allow lists).
        """
        raise NotImplementedError("parse(..) not implemented")

    def serialize(self, items):
        """Does the inverse of config parsing by taking parsed values and
        converting them back to a string representing config file contents.

        Args:
            items: an OrderedDict of items to be converted to the config file
                format. Keys should be strings, and values should be either strings
                or lists.

        Returns:
            Contents of config file as a string
        """
        raise NotImplementedError("serialize(..) not implemented")


class _WriteOutConfigFileActionMixin(object):
    """Remembers the path this arg was given, on the parser that parsed it.

    The path can't just be read back out of the parsed namespace once parsing
    finishes: another arg sharing this one's dest could have put a value there,
    from a config file or anywhere else, and writing a config file overwrites
    the path it is given. Recording it as the arg is parsed means only this
    arg decides where that write goes.

    add_argument() puts this over whichever store action the program asked for,
    so an arg that does something of its own with the path still records it.
    """

    def __call__(self, parser, namespace, values, option_string=None):
        super(_WriteOutConfigFileActionMixin, self).__call__(
            parser, namespace, values, option_string
        )
        # take the value back off the namespace: the action just put it there,
        # and a store action of the program's own may have changed it on the
        # way (expanding a '~', say). Keyed by the action so that repeating the
        # arg replaces the path rather than adding a second one.
        # a parser that isn't a ConfigArgParse one has nowhere to record it,
        # and doesn't write config files either, so there is nothing to record
        if hasattr(parser, "_write_out_config_file_paths"):
            parser._write_out_config_file_paths[id(self)] = getattr(
                namespace, self.dest, values
            )


class ConfigFileParserException(Exception):
    """Raised when config file parsing failed."""


class ConfigFileParserMissingDependency(ConfigFileParserException):
    """Raised when an optional dependency is missing."""


class DefaultConfigFileParser(ConfigFileParser):
    """
    Based on a simplified subset of INI and YAML formats. Here is the
    supported syntax

    .. code::

        # this is a comment
        ; this is also a comment (.ini style)
        ---            # lines that start with --- are ignored (yaml style)
        -------------------
        [section]      # .ini-style section names are treated as comments

        # how to specify a key-value pair (all of these are equivalent):
        name value     # key is case sensitive: "Name" isn't "name"
        name = value   # (.ini style)  (white space is ignored, so name = value same as name=value)
        name: value    # (yaml style)
        --name value   # (argparse style)

        # how to set a flag arg (eg. arg which has action="store_true")
        --name
        name
        name = True    # "True" and "true" are the same

        # how to specify a list arg (eg. arg which has action="append")
        fruit = [apple, orange, lemon]
        indexes = [1, 12, 35 , 40]

    """

    def get_syntax_description(self):
        msg = (
            "Config file syntax allows: key=value, flag=true, stuff=[a,b,c] "
            "(for details, see syntax at https://goo.gl/R74nmi)."
        )
        return msg

    def parse(self, stream):
        # see ConfigFileParser.parse docstring

        items = OrderedDict()
        for i, line in enumerate(stream):
            line = line.strip()
            if not line or line[0] in ["#", ";", "["] or line.startswith("---"):
                continue

            match = re.match(
                r"^(?P<key>[^:=;#\s]+)\s*"
                r'(?:(?P<equal>[:=\s])\s*([\'"]?)(?P<value>.+?)?\3)?'
                r"\s*(?:\s[;#]\s*(?P<comment>.*?)\s*)?$",
                line,
            )
            if match:
                key = match.group("key")
                equal = match.group("equal")
                value = match.group("value")
                comment = match.group("comment")
                if value is None and equal is not None and equal != " ":
                    value = ""
                elif value is None:
                    value = "true"
                if value.startswith("[") and value.endswith("]"):
                    # handle special case of k=[1,2,3] or other json-like syntax
                    try:
                        value = json.loads(value)
                    except Exception as e:
                        # for backward compatibility with legacy format (eg. where config value is [a, b, c] instead of proper json ["a", "b", "c"]
                        value = [elem.strip() for elem in value[1:-1].split(",")]
                items[key] = value
            else:
                raise ConfigFileParserException(
                    "Unexpected line {} in {}: {}".format(
                        i, getattr(stream, "name", "stream"), line
                    )
                )
        return items

    def serialize(self, items):
        # see ConfigFileParser.serialize docstring
        r = StringIO()
        for key, value in items.items():
            if isinstance(value, list):
                # handle special case of lists
                value = "[" + ", ".join(map(str, value)) + "]"
            else:
                # render it the way this has always rendered it: str() differs
                # for an Enum on Python before 3.11
                value = "{}".format(value)
            # this format puts one key on each line, so a newline in a key or a
            # value would silently turn into extra keys when the file is read
            # back in (see parse() above). There's no way to quote it, so say so
            # instead of writing a file that means something else.
            for field in (str(key), value):
                if "\n" in field or "\r" in field:
                    raise ValueError(
                        "Config file values can't contain newlines, so {} = {} "
                        "can't be written out in this config file format. Use a "
                        "config_file_parser_class that supports multi-line "
                        "values, such as YAMLConfigFileParser.".format(key, value)
                    )
            r.write("{} = {}\n".format(key, value))
        return r.getvalue()


class ConfigparserConfigFileParser(ConfigFileParser):
    """parses INI files using pythons configparser."""

    def get_syntax_description(self):
        msg = """Uses configparser module to parse an INI file which allows multi-line
        values.

        Allowed syntax is that for a ConfigParser with the following options:

            allow_no_value = False,
            inline_comment_prefixes = ("#",)
            strict = True
            empty_lines_in_values = False

        See https://docs.python.org/3/library/configparser.html for details.

        Note: INI file sections names are still treated as comments.
        """
        return msg

    def parse(self, stream):
        # see ConfigFileParser.parse docstring
        # parse with configparser to allow multi-line values
        config = configparser.ConfigParser(
            delimiters=("=", ":"),
            allow_no_value=False,
            comment_prefixes=("#", ";"),
            inline_comment_prefixes=("#", ";"),
            strict=True,
            empty_lines_in_values=False,
        )
        try:
            config.read_string(stream.read())
        except Exception as e:
            raise ConfigFileParserException("Couldn't parse config file: %s" % e)

        # convert to dict and remove INI section names
        result = OrderedDict()
        for section in config.sections():
            for k, v in config[section].items():
                multiLine2SingleLine = v.replace("\n", " ").replace("\r", " ")
                # handle special case for lists
                if "[" in multiLine2SingleLine and "]" in multiLine2SingleLine:
                    # ensure not a dict with a list value
                    prelist_string = multiLine2SingleLine.split("[")[0]
                    if "{" not in prelist_string:
                        try:
                            result[k] = ast.literal_eval(multiLine2SingleLine)
                        except (ValueError, SyntaxError) as e:
                            raise ConfigFileParserException(
                                "Error evaluating list: "
                                + str(e)
                                + ". Put quotes around your text if it's meant to be a string."
                            ) from e
                    else:
                        result[k] = multiLine2SingleLine
                else:
                    result[k] = multiLine2SingleLine
        return result

    def serialize(self, items):
        # see ConfigFileParser.serialize docstring
        config = configparser.ConfigParser(
            allow_no_value=False,
            inline_comment_prefixes=("#",),
            strict=True,
            empty_lines_in_values=False,
        )
        items = {"DEFAULT": items}
        config.read_dict(items)
        stream = StringIO()
        config.write(stream)
        stream.seek(0)
        return stream.read()


class YAMLConfigFileParser(ConfigFileParser):
    """Parses YAML config files. Depends on the PyYAML module.
    https://pypi.python.org/pypi/PyYAML
    """

    def get_syntax_description(self):
        msg = (
            "The config file uses YAML syntax and must represent a YAML "
            "'mapping' (for details, see http://learn.getgrav.org/advanced/yaml)."
        )
        return msg

    def _load_yaml(self):
        """lazy-import PyYAML so that configargparse doesn't have to depend
        on it unless this parser is used."""
        try:
            import yaml
        except ImportError:
            raise ConfigFileParserMissingDependency(
                "Could not import yaml. "
                "It can be installed by running 'pip install PyYAML'"
            )

        try:
            from yaml import CSafeLoader as SafeLoader
            from yaml import CDumper as Dumper
        except ImportError:
            from yaml import SafeLoader
            from yaml import Dumper

        return yaml, SafeLoader, Dumper

    def parse(self, stream):
        # see ConfigFileParser.parse docstring
        yaml, SafeLoader, _ = self._load_yaml()

        try:
            parsed_obj = yaml.load(stream, Loader=SafeLoader)
        except Exception as e:
            raise ConfigFileParserException("Couldn't parse config file: %s" % e)

        if not isinstance(parsed_obj, dict):
            raise ConfigFileParserException(
                "The config file doesn't appear to "
                "contain 'key: value' pairs (aka. a YAML mapping). "
                "yaml.load('%s') returned type '%s' instead of 'dict'."
                % (getattr(stream, "name", "stream"), type(parsed_obj).__name__)
            )

        result = OrderedDict()
        for key, value in parsed_obj.items():
            if isinstance(value, list):
                result[key] = value
            elif value is None:
                pass
            else:
                result[key] = str(value)

        return result

    def serialize(self, items, default_flow_style=False):
        # see ConfigFileParser.serialize docstring

        # lazy-import so there's no dependency on yaml unless this class is used
        yaml, _, Dumper = self._load_yaml()

        # it looks like ordering can't be preserved: http://pyyaml.org/ticket/29
        items = dict(items)
        return yaml.dump(items, default_flow_style=default_flow_style, Dumper=Dumper)


"""
Provides `configargparse.ConfigFileParser` classes to parse ``TOML`` and ``INI`` files with **mandatory** support for sections.
Useful to integrate configuration into project files like ``pyproject.toml`` or ``setup.cfg``.

`TomlConfigParser` usage:

>>> TomlParser = TomlConfigParser(['tool.my_super_tool']) # Simple TOML parser.
>>> parser = ArgumentParser(..., default_config_files=['./pyproject.toml'], config_file_parser_class=TomlParser)

`IniConfigParser` works the same way (also it optionaly convert multiline strings to list with argument ``split_ml_text_to_list``).

`CompositeConfigParser` usage:

>>> MY_CONFIG_SECTIONS = ['tool.my_super_tool', 'tool:my_super_tool', 'my_super_tool']
>>> TomlParser =  TomlConfigParser(MY_CONFIG_SECTIONS)
>>> IniParser = IniConfigParser(MY_CONFIG_SECTIONS, split_ml_text_to_list=True)
>>> MixedParser = CompositeConfigParser([TomlParser, IniParser]) # This parser supports both TOML and INI formats.
>>> parser = ArgumentParser(..., default_config_files=['./pyproject.toml', 'setup.cfg', 'my_super_tool.ini'], config_file_parser_class=MixedParser)

"""

# I did not invented these regex, just put together some stuff from:
# - https://stackoverflow.com/questions/11859442/how-to-match-string-in-quotes-using-regex
# - and https://stackoverflow.com/a/41005190

_QUOTED_STR_REGEX = re.compile(r"(^\"(?:\\.|[^\"\\])*\"$)|" r"(^\'(?:\\.|[^\'\\])*\'$)")

_TRIPLE_QUOTED_STR_REGEX = re.compile(
    r"(^\"\"\"(\s+)?(([^\"]|\"([^\"]|\"[^\"]))*(\"\"?)?)?(\s+)?(?:\\.|[^\"\\])?\"\"\"$)|"
    # Unescaped quotes at the end of a string generates
    # "SyntaxError: EOL while scanning string literal",
    # so we don't account for those kind of strings as quoted.
    r"(^\'\'\'(\s+)?(([^\']|\'([^\']|\'[^\']))*(\'\'?)?)?(\s+)?(?:\\.|[^\'\\])?\'\'\'$)",
    flags=re.DOTALL,
)


@functools.lru_cache(maxsize=256, typed=True)
def is_quoted(text, triple=True):
    """
    Detect whether a string is a quoted representation.

    :param triple: Also match tripple quoted strings.
    """
    return bool(_QUOTED_STR_REGEX.match(text)) or (
        triple and bool(_TRIPLE_QUOTED_STR_REGEX.match(text))
    )


def unquote_str(text, triple=True):
    """
    Unquote a maybe quoted string representation.
    If the string is not detected as being a quoted representation, it returns the same string as passed.
    It supports all kinds of python quotes: ``\"\"\"``, ``'''``, ``"`` and ``'``.

    :param triple: Also unquote tripple quoted strings.
    :raises ValueError: If the string is detected as beeing quoted but literal_eval() fails to evaluate it as string.
        This would be a bug in the regex.
    """
    if is_quoted(text, triple=triple):
        try:
            s = ast.literal_eval(text)
            assert isinstance(s, str)
        except Exception as e:
            raise ValueError(
                f"Error trying to unquote the quoted string: {text}: {e}"
            ) from e
        return s
    return text


def parse_toml_section_name(section_name):
    """
    Parse a TOML section name to a sequence of strings.

    The following names are all valid:

    .. python::

        "a.b.c"            # this is best practice -> returns ("a", "b", "c")
        " d.e.f "          # same as [d.e.f] -> returns ("d", "e", "f")
        " g .  h  . i "    # same as [g.h.i] -> returns ("g", "h", "i")
        ' j . "ʞ" . "l" '  # same as [j."ʞ"."l"], double or simple quotes here are supported. -> returns ("j", "ʞ", "l")
    """
    section = []
    for row in csv.reader([section_name], delimiter="."):
        for a in row:
            section.append(unquote_str(a.strip(), triple=False))
    return tuple(section)


def get_toml_section(data, section):
    """
    Given some TOML data (as loaded with toml.load()), returns the requested section of the data.
    Returns ``None`` if the section is not found.
    """
    sections = parse_toml_section_name(section) if isinstance(section, str) else section
    itemdata = data.get(sections[0])
    if not itemdata:
        return None
    sections = sections[1:]
    if sections:
        return get_toml_section(itemdata, sections)
    else:
        if not isinstance(itemdata, dict):
            return None
        return itemdata


class TomlConfigParser(ConfigFileParser):
    """
    Create a TOML parser bounded to the list of provided sections.

    Example::

        # this is a comment
        [tool.my-software] # TOML section table.
        # how to specify a key-value pair
        format-string = "restructuredtext" # strings must be quoted
        # how to set an arg which has action="store_true"
        warnings-as-errors = true
        # how to set an arg which has action="count" or type=int
        verbosity = 1
        # how to specify a list arg (eg. arg which has action="append")
        repeatable-option = ["https://docs.python.org/3/objects.inv",
                             "https://twistedmatrix.com/documents/current/api/objects.inv"]
        # how to specify a multiline text:
        multi-line-text = '''
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Vivamus tortor odio, dignissim non ornare non, laoreet quis nunc.
            Maecenas quis dapibus leo, a pellentesque leo.
            '''

    Note that the config file fragment above is also valid for the `IniConfigParser` class and would be parsed the same manner.
    Thought, any valid TOML config file will not be necessarly parsable with `IniConfigParser` (INI files must be rigorously indented whereas TOML files).

    See the `TOML specification <https://toml.io/en/>`_ for details.
    """

    def __init__(self, sections):
        """
        :param sections: The section names bounded to the new parser.
        """
        super().__init__()
        self.sections = sections

    def __call__(self):
        return self

    def parse(self, stream):
        """Parses the keys and values from a TOML config file."""
        # Use tomllib (Python 3.11+) if available, otherwise fall back to toml package
        try:
            import tomllib as toml
        except ImportError:
            try:
                import toml
            except ImportError as e:
                raise ConfigFileParserMissingDependency(
                    "Could not import toml or tomllib. "
                    "toml can be installed by running 'pip install toml'"
                ) from e

        # tomllib.load() requires binary mode, so use loads() for stream compatibility
        try:
            content = stream.read()
            # If content is bytes, decode it; if string, use as-is
            if isinstance(content, bytes):
                content = content.decode("utf-8")
            config = toml.loads(content)
        except Exception as e:
            raise ConfigFileParserException("Couldn't parse TOML file: %s" % e)

        # convert to dict and filter based on section names
        result = OrderedDict()

        for section in self.sections:
            data = get_toml_section(config, section)
            if data:
                # Seems a little weird, but anything that is not a list is converted to string,
                # It will be converted back to boolean, int or whatever after.
                # Because config values are still passed to argparser for computation.
                for key, value in data.items():
                    if isinstance(value, list):
                        result[key] = value
                    elif value is None:
                        pass
                    else:
                        result[key] = str(value)

        return result

    def get_syntax_description(self):
        return (
            "Config file syntax is Tom's Obvious, Minimal Language. "
            "See https://github.com/toml-lang/toml/blob/v0.5.0/README.md for details."
        )

    def serialize(self, items):
        """Serialize items to TOML format with section support.

        Note: Requires the 'toml' package for serialization (pip install toml).
        Python 3.11's tomllib only supports reading, not writing.
        """
        # lazy-import to avoid dependency unless class is used
        try:
            import toml
        except ImportError:
            raise ConfigFileParserMissingDependency(
                "The 'toml' package is required for TOML serialization. "
                "Install it with: pip install toml"
            )

        # Put items in the first configured section
        if not self.sections:
            # No sections configured, serialize as flat TOML
            return toml.dumps(dict(items))

        # Create nested dict structure for section
        section_name = self.sections[0]
        sections = parse_toml_section_name(section_name)

        # Build nested dict from section path
        result = {}
        current = result
        for i, section in enumerate(sections[:-1]):
            current[section] = {}
            current = current[section]
        current[sections[-1]] = dict(items)

        return toml.dumps(result)


class IniConfigParser(ConfigFileParser):
    """
    Create a INI parser bounded to the list of provided sections.
    Optionaly convert multiline strings to list.

    Example (if split_ml_text_to_list=False)::

        # this is a comment
        ; also a comment
        [my-software]
        # how to specify a key-value pair
        format-string: restructuredtext
        # white space are ignored, so name = value same as name=value
        # this is why you can quote strings
        quoted-string = '\thello\tmom...  '
        # how to set an arg which has action="store_true"
        warnings-as-errors = true
        # how to set an arg which has action="count" or type=int
        verbosity = 1
        # how to specify a list arg (eg. arg which has action="append")
        repeatable-option = ["https://docs.python.org/3/objects.inv",
                       "https://twistedmatrix.com/documents/current/api/objects.inv"]
        # how to specify a multiline text:
        multi-line-text =
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Vivamus tortor odio, dignissim non ornare non, laoreet quis nunc.
            Maecenas quis dapibus leo, a pellentesque leo.

    Example (if split_ml_text_to_list=True)::

        # the same rules are applicable with the following changes:
        [my-software]
        # how to specify a list arg (eg. arg which has action="append")
        repeatable-option = # Just enter one value per line (the list literal format can also be used)
            https://docs.python.org/3/objects.inv
            https://twistedmatrix.com/documents/current/api/objects.inv
        # how to specify a multiline text (you have to quote it):
        multi-line-text = '''
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
            Vivamus tortor odio, dignissim non ornare non, laoreet quis nunc.
            Maecenas quis dapibus leo, a pellentesque leo.
            '''
    """

    def __init__(self, sections, split_ml_text_to_list):
        """
        :param sections: The section names bounded to the new parser.
        :param split_ml_text_to_list: Whether to convert multiline strings to list
        """
        super().__init__()
        self.sections = sections
        self.split_ml_text_to_list = split_ml_text_to_list

    def __call__(self):
        return self

    def parse(self, stream):
        """Parses the keys and values from an INI config file."""
        # parse with configparser to allow multi-line values
        config = configparser.ConfigParser()
        try:
            config.read_string(stream.read())
        except Exception as e:
            raise ConfigFileParserException("Couldn't parse INI file: %s" % e)

        # convert to dict and filter based on INI section names
        result = OrderedDict()
        for section in config.sections() + [configparser.DEFAULTSECT]:
            if section not in self.sections:
                continue
            for k, v in config[section].items():
                strip_v = v.strip()
                if not strip_v:
                    # ignores empty values, anyway allow_no_value=False by default so this should not happend.
                    continue
                # evaluate lists
                if strip_v.startswith("[") and strip_v.endswith("]"):
                    try:
                        result[k] = ast.literal_eval(strip_v)
                    except (ValueError, SyntaxError) as e:
                        # error evaluating object
                        raise ConfigFileParserException(
                            "Error evaluating list: "
                            + str(e)
                            + ". Put quotes around your text if it's meant to be a string."
                        ) from e
                else:
                    if is_quoted(strip_v):
                        # evaluate quoted string
                        try:
                            result[k] = unquote_str(strip_v)
                        except ValueError as e:
                            # error unquoting string
                            raise ConfigFileParserException(str(e)) from e
                    # split multi-line text into list of strings if split_ml_text_to_list is enabled.
                    elif self.split_ml_text_to_list and "\n" in v.rstrip("\n"):
                        try:
                            result[k] = [
                                unquote_str(i) for i in strip_v.split("\n") if i
                            ]
                        except ValueError as e:
                            # error unquoting string
                            raise ConfigFileParserException(str(e)) from e
                    else:
                        result[k] = v
        return result

    def get_syntax_description(self):
        msg = (
            "Uses configparser module to parse an INI file which allows multi-line values. "
            "See https://docs.python.org/3/library/configparser.html for details. "
            "This parser includes support for quoting strings literal as well as python list syntax evaluation. "
        )
        if self.split_ml_text_to_list:
            msg += (
                "Alternatively lists can be constructed with a plain multiline string, "
                "each non-empty line will be converted to a list item."
            )
        return msg

    def serialize(self, items):
        """Serialize items to INI format with section support."""
        config = configparser.ConfigParser()

        # Use the first configured section
        section_name = self.sections[0] if self.sections else "DEFAULT"

        # Add section if not DEFAULT
        if section_name != "DEFAULT" and section_name != configparser.DEFAULTSECT:
            config.add_section(section_name)

        # Add items to the section
        for key, value in items.items():
            if isinstance(value, list):
                # Handle lists
                if self.split_ml_text_to_list:
                    # Multi-line format
                    config.set(
                        section_name, key, "\n" + "\n".join(str(v) for v in value)
                    )
                else:
                    # Python list syntax
                    config.set(section_name, key, str(value))
            else:
                config.set(section_name, key, str(value))

        stream = StringIO()
        config.write(stream)
        stream.seek(0)
        return stream.read()


class CompositeConfigParser(ConfigFileParser):
    """
    Create a config parser composed by other ConfigFileParser instances.

    The composite parser will successively try to parse the file with each parser,
    until it succeeds, else raise exception with all encountered errors.
    """

    def __init__(self, config_parser_types):
        super().__init__()
        self.parsers: list[ConfigFileParser] = [p() for p in config_parser_types]

        seen_ini = False
        for parser in self.parsers:
            if not seen_ini and isinstance(parser, IniConfigParser):
                seen_ini = True
                continue
            if seen_ini and isinstance(parser, TomlConfigParser):
                warnings.warn(
                    "IniConfigParser was found before TomlConfigParser in parsers for "
                    "CompositeConfigParser. This might lead to a TOML file being "
                    "parsed as an INI file. Reorder the parsers.",
                    category=SyntaxWarning,
                )

    def __call__(self):
        return self

    def parse(self, stream):
        errors = []
        for i, p in enumerate(self.parsers):
            try:
                return p.parse(stream)  # type: ignore[no-any-return]
            except Exception as e:
                if isinstance(e, ConfigFileParserMissingDependency):
                    # don't skip it silently, but don't take the rest of the
                    # chain down with it either
                    warnings.warn(
                        f"Cannot use parser {p.__class__.__name__} without "
                        f"optional dependency: {e}"
                    )
                errors.append(e)
                # Try to seek back to beginning for next parser
                # If this is not the last parser and seek fails, we can't continue
                if i < len(self.parsers) - 1:
                    try:
                        stream.seek(0)
                    except (AttributeError, OSError):
                        # Stream doesn't support seeking
                        raise ConfigFileParserException(
                            f"Error parsing config with {p.__class__.__name__}: {e}. "
                            f"Cannot try additional parsers because stream is not seekable."
                        ) from e
        raise ConfigFileParserException(
            f"Error parsing config: {', '.join(repr(str(e)) for e in errors)}"
        )

    def get_syntax_description(self):
        def guess_format_name(classname):
            strip = (
                classname.lower()
                .strip("_")
                .replace("parser", "")
                .replace("config", "")
                .replace("file", "")
            )
            return strip.upper() if strip else "??"

        msg = "Uses multiple config parser settings (in order): \n"
        for i, parser in enumerate(self.parsers):
            msg += f"[{i + 1}] {guess_format_name(parser.__class__.__name__)}: {parser.get_syntax_description()} \n"
        return msg

    def serialize(self, items):
        """Serialize items using the first parser in the composite."""
        if not self.parsers:
            raise ConfigFileParserException(
                "No parsers configured in CompositeConfigParser"
            )
        # Use the first parser to serialize
        return self.parsers[0].serialize(items)  # type: ignore[no-any-return]


# used while parsing args to keep track of where they came from
_COMMAND_LINE_SOURCE_KEY = "command_line"
_ENV_VAR_SOURCE_KEY = "environment_variables"
_CONFIG_FILE_SOURCE_KEY = "config_file"
_DEFAULTS_SOURCE_KEY = "defaults"


class ArgumentParser(argparse.ArgumentParser):
    """Drop-in replacement for `argparse.ArgumentParser` that adds support for
    environment variables and ``.ini`` or ``.yaml-style`` config files.
    """

    def __init__(self, *args, **kwargs):
        r"""Supports args of the `argparse.ArgumentParser` constructor
        as \*\*kwargs, as well as the following additional args.

        Keyword Arguments:
            add_config_file_help: Whether to add a description of config file
                syntax to the help message.
            add_env_var_help: Whether to add something to the help message for
                args that can be set through environment variables.
            auto_env_var_prefix: If set to a string instead of None, all config-
                file-settable options will become also settable via environment
                variables whose names are this prefix followed by the config
                file key, all in upper case. (eg. setting this to ``foo_`` will
                allow an arg like ``--my-arg`` to also be set via the FOO_MY_ARG
                environment variable)
            default_config_files: When specified, this list of config files will
                be parsed in order, with the values from each config file
                taking precedence over previous ones. This allows an application
                to look for config files in multiple standard locations such as
                the install directory, home directory, and/or current directory.
                Also, shell \* syntax can be used to specify all conf files in a
                directory. For example::

                    ["/etc/conf/app_config.ini",
                    "/etc/conf/conf-enabled/*.ini",
                    "~/.my_app_config.ini",
                    "./app_config.txt"]

                Path entries may be strings, ``os.PathLike`` objects (e.g.
                ``pathlib.Path``), or zero-argument callable functions that
                return an open file-like object containing config file
                contents. Any provided callable is invoked each time the parser opens
                config files, and the returned stream is closed by the parser
                after parsing. The callable must return a stream. This is useful
                for sourcing config from non-filesystem locations such as in-memory
                buffers, secrets managers, or HTTP responses.
            ignore_unknown_config_file_keys: If true, settings that are found
                in a config file but don't correspond to any defined
                configargparse args will be ignored. If false, they will be
                processed and appended to the commandline like other args, and
                can be retrieved using parse_known_args() instead of parse_args()
            config_file_open_func: function used to open a config file for reading
                or writing. Needs to return a file-like object.
            config_file_parser_class: configargparse.ConfigFileParser subclass
                which determines the config file format. configargparse comes
                with DefaultConfigFileParser and YAMLConfigFileParser.
            args_for_setting_config_path: A list of one or more command line
                args to be used for specifying the config file path
                (eg. ["-c", "--config-file"]). Default: []
            config_arg_is_required: When args_for_setting_config_path is set,
                set this to True to always require users to provide a config path.
            config_arg_help_message: the help message to use for the
                args listed in args_for_setting_config_path.
            args_for_writing_out_config_file: A list of one or more command line
                args to use for specifying a config file output path. If
                provided, these args cause configargparse to write out a config
                file with settings based on the other provided commandline args,
                environment variants and defaults, and then to exit.
                (eg. ["-w", "--write-out-config-file"]). Default: []
                These args can only be set on the command line. A config file
                key that names one is an error, and they can't have an env_var,
                since either would let whoever controls those overwrite an
                arbitrary file.
            write_out_config_file_arg_help_message: The help message to use for
                the args in args_for_writing_out_config_file.
        """
        # This is the only way to make positional args (tested in the argparse
        # main test suite) and keyword arguments work across both Python 2 and
        # 3. This could be refactored to not need extra local variables.
        add_config_file_help = kwargs.pop("add_config_file_help", True)
        add_env_var_help = kwargs.pop("add_env_var_help", True)
        auto_env_var_prefix = kwargs.pop("auto_env_var_prefix", None)
        default_config_files = kwargs.pop("default_config_files", [])
        ignore_unknown_config_file_keys = kwargs.pop(
            "ignore_unknown_config_file_keys", False
        )
        config_file_parser_class = kwargs.pop(
            "config_file_parser_class", DefaultConfigFileParser
        )
        args_for_setting_config_path = kwargs.pop("args_for_setting_config_path", [])
        config_arg_is_required = kwargs.pop("config_arg_is_required", False)
        config_arg_help_message = kwargs.pop(
            "config_arg_help_message", "config file path"
        )
        args_for_writing_out_config_file = kwargs.pop(
            "args_for_writing_out_config_file", []
        )
        write_out_config_file_arg_help_message = kwargs.pop(
            "write_out_config_file_arg_help_message",
            "takes the current "
            "command line args and writes them out to a config file at the "
            "given path, then exits",
        )

        config_file_open_func = kwargs.pop("config_file_open_func", open)

        # Validate args before proceeding
        for name, value in [
            ("default_config_files", default_config_files),
            ("args_for_setting_config_path", args_for_setting_config_path),
            ("args_for_writing_out_config_file", args_for_writing_out_config_file),
        ]:
            if not isinstance(value, (list, tuple)):
                hint = " (e.g. ['%s'])" % value if isinstance(value, str) else ""
                raise TypeError("%s must be a list%s. Got: %r" % (name, hint, value))

        for i, entry in enumerate(default_config_files):
            if not (isinstance(entry, (str, bytes, os.PathLike)) or callable(entry)):
                raise TypeError(
                    "default_config_files[%d] must be a string, bytes, or "
                    "os.PathLike path, or a callable that returns an open "
                    "file-like object. Got: %r" % (i, entry)
                )

        if not callable(config_file_open_func):
            raise TypeError(
                "config_file_open_func must be callable. Got: %r"
                % (config_file_open_func,)
            )

        self._config_file_open_func = config_file_open_func

        self._add_config_file_help = add_config_file_help
        self._add_env_var_help = add_env_var_help
        self._auto_env_var_prefix = auto_env_var_prefix

        if "formatter_class" in kwargs:
            fc = kwargs["formatter_class"]
            if isinstance(fc, type) and not issubclass(fc, argparse.HelpFormatter):
                msg = (
                    "formatter_class must be a subclass of "
                    "argparse.HelpFormatter. Got: %r." % (fc,)
                )
                if issubclass(fc, ConfigFileParser):
                    msg += " Perhaps you meant to use config_file_parser_class?"
                raise TypeError(msg)

        argparse.ArgumentParser.__init__(self, *args, **kwargs)

        # parse the additional args
        if config_file_parser_class is None:
            self._config_file_parser = DefaultConfigFileParser()
        elif isinstance(config_file_parser_class, ConfigFileParser):
            self._config_file_parser = config_file_parser_class
        elif isinstance(config_file_parser_class, type) and issubclass(
            config_file_parser_class, ConfigFileParser
        ):
            self._config_file_parser = config_file_parser_class()
        else:
            raise TypeError(
                "config_file_parser_class must be a subclass of "
                "ConfigFileParser (such as DefaultConfigFileParser, "
                "YAMLConfigFileParser, etc.). "
                "Got: %r. Perhaps you meant to use formatter_class?"
                % (config_file_parser_class,)
            )

        self._default_config_files = default_config_files
        self._ignore_unknown_config_file_keys = ignore_unknown_config_file_keys
        if args_for_setting_config_path:
            self.add_argument(
                *args_for_setting_config_path,
                dest="config_file",
                required=config_arg_is_required,
                help=config_arg_help_message,
                is_config_file_arg=True,
            )

        if args_for_writing_out_config_file:
            self.add_argument(
                *args_for_writing_out_config_file,
                dest="write_out_config_file_to_this_path",
                metavar="CONFIG_OUTPUT_PATH",
                help=write_out_config_file_arg_help_message,
                is_write_out_config_file_arg=True,
            )

        # Workaround for Python < 3.9: exit_on_error parameter was added in 3.9
        # This can be removed when minimum Python version is raised to 3.9+
        if sys.version_info < (3, 9):
            self.exit_on_error = True

    def _find_insertion_index(self, args):
        """Find the right index to insert config/env var args into the command line.

        Inserts before the ``--`` separator if present, before a subparser
        command so the parent parser sees injected args first, before the
        first optional arg, or at position 0 when a REMAINDER positional
        exists. Falls back to appending.
        """
        if "--" in args:
            return args.index("--")

        subcmd_index = self._find_subcommand_index(args)
        if subcmd_index is not None:
            return subcmd_index

        first_opt = None
        for i, arg in enumerate(args):
            if arg.startswith(tuple(self.prefix_chars)):
                first_opt = i
                break
        if first_opt is not None:
            return first_opt

        # No optional args on command line
        if any(
            a.is_positional_arg and a.nargs == argparse.REMAINDER for a in self._actions
        ):
            return 0

        return len(args)

    def _find_subcommand_index(self, args):
        """Find where the subcommand is on the command line, if there is one.

        Args:
            args: the command line args.

        Returns:
            int or None: the index of the first arg naming a subcommand
        """
        for action in self._actions:
            if isinstance(action, argparse._SubParsersAction) and action.choices:
                for i, arg_string in enumerate(args):
                    if arg_string in action.choices:
                        return i
                return None

        return None

    def _option_strings_that_override(self, action):
        """Find the option strings that, when already on the command line, mean
        an env var or config file value for the given action should be dropped.

        These are the action's own option strings plus those of every other
        action in the same mutually exclusive group, mirroring the conflicts
        argparse checks for. Without the latter, a config file value for one
        member of a group would clash with a different member given on the
        command line instead of being overridden by it (see issue #164).

        Args:
            action: the argparse.Action to find overriding option strings for.

        Returns:
            list[str]: the option strings
        """
        option_strings = list(action.option_strings)
        for group in self._mutually_exclusive_groups:
            if action in group._group_actions:
                for other_action in group._group_actions:
                    if other_action is not action:
                        option_strings += other_action.option_strings
        return option_strings

    def parse_args(
        self, args=None, namespace=None, config_file_contents=None, env_vars=os.environ
    ):
        """Supports all the same args as the `argparse.ArgumentParser.parse_args()`,
        as well as the following additional args.

        Arguments:
            args: a list of args as in argparse, or a string (eg. "-x -y bla")
            config_file_contents: String. Used for testing.
            env_vars: Dictionary. Used for testing.

        Returns:
            argparse.Namespace: namespace
        """
        args, argv = self.parse_known_args(
            args=args,
            namespace=namespace,
            config_file_contents=config_file_contents,
            env_vars=env_vars,
            ignore_help_args=False,
        )

        if argv:
            msg = "unrecognized arguments: %s" % " ".join(argv)
            if self.exit_on_error:
                self.error(msg)
            else:
                raise ArgumentError(None, msg)
        return args

    def parse_known_args(
        self,
        args=None,
        namespace=None,
        config_file_contents=None,
        env_vars=os.environ,
        ignore_help_args=False,
    ):
        """Supports all the same args as the `argparse.ArgumentParser.parse_args()`,
        as well as the following additional args.

        Arguments:
            args: a list of args as in argparse, or a string (eg. "-x -y bla")
            config_file_contents (str). Used for testing.
            env_vars (dict). Used for testing.
            ignore_help_args (bool): This flag determines behavior when user specifies ``--help`` or ``-h``. If False,
                it will have the default behavior - printing help and exiting. If True, it won't do either.

        Returns:
            tuple[argparse.Namespace, list[str]]: tuple namescpace, unknown_args
        """
        if args is None:
            args = sys.argv[1:]
        elif isinstance(args, str):
            args = args.split()
        else:
            args = list(args)

        for a in self._actions:
            a.is_positional_arg = not a.option_strings

        if ignore_help_args:
            args = [arg for arg in args if arg not in ("-h", "--help")]

        # maps a string describing the source (eg. env var) to a settings dict
        # to keep track of where values came from (used by print_values()).
        # The settings dicts for env vars and config files will then map
        # the config key to an (argparse Action obj, string value) 2-tuple.
        self._source_to_settings = OrderedDict()
        if args:
            a_v_pair = (None, list(args))  # copy args list to isolate changes
            self._source_to_settings[_COMMAND_LINE_SOURCE_KEY] = {"": a_v_pair}

        # handle auto_env_var_prefix __init__ arg by setting a.env_var as needed
        if self._auto_env_var_prefix is not None:
            for a in self._actions:
                config_file_keys = self.get_possible_config_keys(a)
                if config_file_keys and not (
                    a.env_var
                    or a.is_positional_arg
                    or a.is_config_file_arg
                    or a.is_write_out_config_file_arg
                    or isinstance(a, argparse._VersionAction)
                    or isinstance(a, argparse._HelpAction)
                ):
                    stripped_config_file_key = config_file_keys[0].strip(
                        self.prefix_chars
                    )
                    a.env_var = (
                        (self._auto_env_var_prefix + stripped_config_file_key)
                        .replace("-", "_")
                        .upper()
                    )

        # add env var settings to the commandline that aren't there already
        env_var_args = []
        actions_with_env_var_values = [
            a
            for a in self._actions
            if not a.is_positional_arg
            and a.env_var
            and a.env_var in env_vars
            and not already_on_command_line(
                args, self._option_strings_that_override(a), self.prefix_chars
            )
        ]
        for action in actions_with_env_var_values:
            key = action.env_var
            value = env_vars[key]
            # Skip empty string env vars for args with nargs to match YAML behavior
            # where empty values are treated as None/not present (see issue #296)
            if value == "" and action.nargs:
                continue
            # Make list-string into list.
            if action.nargs or isinstance(action, argparse._AppendAction):
                if value.startswith("[") and value.endswith("]"):
                    # handle special case of k=[1,2,3] or other json-like syntax
                    try:
                        value = json.loads(value)
                    except Exception:
                        # for backward compatibility with legacy format (eg. where config value is [a, b, c] instead of proper json ["a", "b", "c"]
                        value = [elem.strip() for elem in value[1:-1].split(",")]
            env_var_args += self.convert_item_to_command_line_arg(action, key, value)

        idx = self._find_insertion_index(args)
        if self._reject_write_out_config_file_args(
            env_var_args, "in an environment variable", self._reachable_parsers()
        ):
            args = args[:idx] + env_var_args + args[idx:]

        if env_var_args:
            self._source_to_settings[_ENV_VAR_SOURCE_KEY] = OrderedDict(
                [
                    (a.env_var, (a, env_vars[a.env_var]))
                    for a in actions_with_env_var_values
                ]
            )

        # before parsing any config files, check if -h was specified.
        supports_help_arg = any(
            a for a in self._actions if isinstance(a, argparse._HelpAction)
        )
        skip_config_file_parsing = supports_help_arg and (
            "-h" in args or "--help" in args
        )

        # prepare for reading config file(s)
        known_config_keys = {
            config_key: action
            for action in self._actions
            for config_key in self.get_possible_config_keys(action)
        }

        # open the config file(s). config_streams is a list of (stream, source_label) tuples.
        config_streams = []
        if config_file_contents is not None:
            stream = StringIO(config_file_contents)
            stream.name = "method arg"
            config_streams = [(stream, "method arg")]
        elif not skip_config_file_parsing:
            config_streams = self._open_config_files(args)

        # parse each config file
        try:
            for stream, source_label in reversed(config_streams):
                try:
                    config_items = self._config_file_parser.parse(stream)
                except ConfigFileParserException as e:
                    self.error(str(e))

                # add each config item to the commandline unless it's there already
                config_args = []
                for key, value in config_items.items():
                    if key in known_config_keys:
                        action = known_config_keys[key]
                        discard_this_key = already_on_command_line(
                            args,
                            self._option_strings_that_override(action),
                            self.prefix_chars,
                        )
                    else:
                        action = None
                        discard_this_key = (
                            self._ignore_unknown_config_file_keys
                            or already_on_command_line(
                                args,
                                [
                                    self.get_command_line_key_for_unknown_config_file_setting(
                                        key
                                    )
                                ],
                                self.prefix_chars,
                            )
                        )

                    # Skip empty string values for args with nargs to match YAML behavior
                    # where empty values are treated as None/not present (see issue #296)
                    if value == "" and action and action.nargs:
                        continue

                    if not discard_this_key:
                        config_args += self.convert_item_to_command_line_arg(
                            action, key, value
                        )
                        source_key = "%s|%s" % (
                            _CONFIG_FILE_SOURCE_KEY,
                            source_label,
                        )
                        if source_key not in self._source_to_settings:
                            self._source_to_settings[source_key] = OrderedDict()
                        self._source_to_settings[source_key][key] = (action, value)

                idx = self._find_insertion_index(args)
                if self._reject_write_out_config_file_args(
                    config_args,
                    "in a config file (%s)" % source_label,
                    self._reachable_parsers(),
                ):
                    args = args[:idx] + config_args + args[idx:]
        finally:
            # Close every stream exactly once, regardless of whether parsing
            # succeeded or aborted partway through (e.g. a custom parser
            # raised a non-ConfigFileParserException).
            for stream, _ in config_streams:
                try:
                    if hasattr(stream, "close"):
                        stream.close()
                except Exception:
                    pass

        # save default settings for use by print_values()
        default_settings = OrderedDict()
        for action in self._actions:
            cares_about_default_value = (
                not action.is_positional_arg or action.nargs in [OPTIONAL, ZERO_OR_MORE]
            )
            if (
                already_on_command_line(args, action.option_strings, self.prefix_chars)
                or not cares_about_default_value
                or action.default is None
                or action.default == SUPPRESS
                or isinstance(action, ACTION_TYPES_THAT_DONT_NEED_A_VALUE)
            ):
                continue
            else:
                if action.option_strings:
                    key = action.option_strings[-1]
                else:
                    key = action.dest
                default_settings[key] = (action, str(action.default))

        if default_settings:
            self._source_to_settings[_DEFAULTS_SOURCE_KEY] = default_settings

        # parse all args (including commandline, config file, and env var)
        self._write_out_config_file_paths = OrderedDict()
        namespace, unknown_args = argparse.ArgumentParser.parse_known_args(
            self, args=args, namespace=namespace
        )
        output_file_paths = [
            path
            for path in self._write_out_config_file_paths.values()
            if path is not None
        ]
        # handle any args that have is_write_out_config_file_arg set to true.
        # Each one recorded its own path as it was parsed, which is the only
        # place that path can have come from, and the args built from config
        # files and env vars were kept from setting one at all above.
        self.write_config_file(namespace, output_file_paths, exit_after=True)
        return namespace, unknown_args

    def get_source_to_settings_dict(self):
        """
        If called after `parse_args()` or `parse_known_args()`, returns a dict that contains up to 4 keys corresponding
        to where a given option's value is coming from:
        - "command_line"
        - "environment_variables"
        - "config_file"
        - "defaults"
        Each such key, will be mapped to another dictionary containing the options set via that method. Here the key
        will be the option name, and the value will be a 2-tuple of the form (`argparse.Action` obj, `str` value).

        Returns:
            dict[str, dict[str, tuple[argparse.Action, str]]]: source to settings dict
        """
        # _source_to_settings is set in parse_know_args().
        return self._source_to_settings  # type: ignore[attribute-error]

    def _reject_write_out_config_file_args(
        self, synthesized_args, source_description, parsers
    ):
        """Reject synthesized command line args that set a write-out-config-file arg.

        Config file entries and environment variables are turned into command
        line args and then parsed like any others, so either one's key or its
        value can end up naming an arg. A write-out-config-file arg overwrites
        the path it is given and then exits the program, so only the real
        command line may set one: otherwise whoever controls a config file the
        program reads could destroy an arbitrary file without the user passing
        any args at all. (This is also why get_possible_config_keys() keeps
        these args out of the keys a config file can set.)

        These args are checked against every parser reachable from this one,
        not just the one that looks like it will parse them. Which subcommand
        runs can't be told from the args: an option's value reads exactly like
        a subcommand name, and the synthesized args can name a subcommand
        themselves. So a config file may not name a write-out arg anywhere in
        the parser tree, which costs an error on a key named after one on a
        subcommand that wasn't going to run.

        Args:
            synthesized_args: command line args built from a config file or from
                environment variables, before they are added to the real ones.
            source_description: where they came from, for the error message.
            parsers: the parsers that could end up parsing them.

        Returns:
            bool: whether the args may be used. error() is meant to stop the
            program, but a program can override exit(), so this says so rather
            than counting on the call not returning.
        """
        if not self._write_out_config_file_args(parsers):
            return True

        # any of these parsers could be the one to expand an arg that names a
        # file of args, and each has its own idea of which chars start one
        fromfile_prefix_chars = "".join(
            parser.fromfile_prefix_chars or ""
            for parser in parsers
            if self._write_out_config_file_args(_subparsers_of(parser))
        )

        for arg_string in synthesized_args:
            if self._names_a_write_out_config_file_arg(arg_string, parsers):
                self.error(
                    "%s can only be set on the command line, not %s"
                    % (arg_string.split("=", 1)[0], source_description)
                )
                return False
            if arg_string and arg_string[0] in fromfile_prefix_chars:
                # argparse replaces this with the args read from that file, and
                # it does so after this check, so the file's contents would go
                # unchecked and could name any arg at all
                self.error(
                    "%s can't be used %s, since it would read command line args "
                    "from a file" % (arg_string, source_description)
                )
                return False

        return True

    def _names_a_write_out_config_file_arg(self, arg_string, parsers):
        """Check whether a command line arg would set a write-out-config-file arg.

        Args:
            arg_string: a single command line arg.
            parsers: the parsers that could end up parsing it.

        Returns:
            bool: whether it names a write-out-config-file arg
        """
        return any(
            # a parser that isn't one of ours has no matcher of its own, and
            # this one's is close enough to decide against
            getattr(parser, "_could_set_option", self._could_set_option)(
                arg_string, option_string
            )
            for parser, action in self._write_out_config_file_args(parsers)
            for option_string in action.option_strings
        )

    def _reachable_parsers(self):
        """Find this parser and every subparser these args could be handed to.

        A subparser is given the args this parser has put together and treats
        them as its own command line, and argparse parses it into this parser's
        namespace, so both what a subparser accepts and what it stores matter
        here. Subparsers that aren't ConfigArgParse parsers are walked through
        as well, since one of them can hold a subparser that is.

        Returns:
            list[argparse.ArgumentParser]: this parser and its subparsers
        """
        return _subparsers_of(self)

    def _write_out_config_file_args(self, parsers):
        """Find the write-out-config-file args the given parsers define.

        Args:
            parsers: the parsers to look in.

        Returns:
            list: each such arg as an ``(argparse.ArgumentParser,
            argparse.Action)`` pair, since it's the parser an arg belongs to
            that decides which command line args can set it.
        """
        return [
            (parser, action)
            for parser in parsers
            for action in parser._actions
            if getattr(action, "is_write_out_config_file_arg", False)
        ]

    def _could_set_option(self, arg_string, option_string):
        """Check whether a command line arg could set the given option.

        This covers every form argparse accepts: the option on its own, with its
        value attached after an ``=`` (or, for a short option, straight after
        it), bundled with other short options, and abbreviated. Where argparse
        would need to look at the rest of the command line to decide, this says
        yes, since it is used to reject args that must not reach an option at
        all, and being wrong in that direction only costs an error message.

        Args:
            arg_string: a single command line arg.
            option_string: an option string of the option to look for.

        Returns:
            bool: whether the arg could set the option
        """
        if arg_string == option_string:
            return True
        if arg_string == "--":
            # argparse's end-of-options separator, which it matches literally
            # rather than through prefix_chars, and never treats as an option
            return False
        if len(arg_string) < 2 or arg_string[0] not in self.prefix_chars:
            return False

        # argparse looks for an option matching the part before any '=' first,
        # whatever the option's prefix. Failing that, a long option is looked up
        # by that same part, while a short one keeps whatever follows it, since
        # a short option's value can be attached straight to it.
        is_long_option = arg_string[1] in self.prefix_chars
        bare_key = arg_string.split("=", 1)[0]
        key = bare_key if is_long_option else arg_string
        if bare_key == option_string or key == option_string:
            return True
        matched_action = self._option_string_actions.get(
            bare_key, self._option_string_actions.get(key)
        )
        if matched_action is not None and (
            is_long_option or getattr(matched_action, "nargs", None) != 0
        ):
            # argparse resolves an exact match straight to that option, so an
            # arg naming a different one can never reach this one. The exception
            # is a single prefix char naming an option that takes no value:
            # before Python 3.11 argparse goes on to read the rest of that arg
            # as more short options, so keep looking.
            return False

        if is_long_option:
            # only an unambiguous abbreviation can reach it from here
            return self.allow_abbrev and option_string.startswith(key)

        if option_string.startswith(bare_key):
            # argparse looks a single-prefix-char arg up by the part before any
            # '=' and takes any option starting with it, so even a lone prefix
            # char reaches an option when it is the only candidate. Before
            # Python 3.13 it does this whatever allow_abbrev says.
            return True

        if len(option_string) != 2:
            # an option with a single prefix char but a longer name is only
            # reachable whole or abbreviated, which the check above covers
            return False

        # a short option can also follow other short options that take no value
        # of their own, with its own value attached after it. When the part
        # before an '=' is itself a flag that takes no value, argparse before
        # 3.11.9 and 3.12.3 starts reading short options after the '=' instead.
        bundled = (
            arg_string.split("=", 1)[1]
            if matched_action is not None and "=" in arg_string
            else arg_string[1:]
        )
        index = bundled.find(option_string[1])
        if index == -1:
            return False

        return all(
            getattr(self._option_string_actions.get(arg_string[0] + c), "nargs", None)
            == 0
            for c in bundled[:index]
            if c != "="
        )

    def write_config_file(self, parsed_namespace, output_file_paths, exit_after=False):
        """Write the given settings to output files.

        Args:
            parsed_namespace: namespace object created within parse_known_args()
            output_file_paths: any number of file paths to write the config to
            exit_after: whether to exit the program after writing the config files
        """
        if output_file_paths:
            # generate the config file contents first. Opening an output file
            # truncates it, so nothing is opened until the contents that will
            # replace it exist. Each file is then opened exactly once, which
            # also avoids the gap between checking a path and writing to it.
            config_items = self.get_items_for_config_file_output(
                self._source_to_settings, parsed_namespace
            )
            file_contents = self._config_file_parser.serialize(config_items)
            for output_file_path in output_file_paths:
                try:
                    with self._config_file_open_func(
                        output_file_path, "w"
                    ) as output_file:
                        output_file.write(file_contents)
                except IOError as e:
                    raise ValueError(
                        "Couldn't open {} for writing: {}".format(output_file_path, e)
                    )

            print("Wrote config file to " + ", ".join(output_file_paths))
            if exit_after:
                self.exit(0)

    def get_command_line_key_for_unknown_config_file_setting(self, key):
        """Compute a commandline arg key to be used for a config file setting
        that doesn't correspond to any defined configargparse arg (and so
        doesn't have a user-specified commandline arg key).

        Args:
            key: The config file key that was being set.

        Returns:
            str: command line key
        """
        key_without_prefix_chars = key.strip(self.prefix_chars)
        command_line_key = self.prefix_chars[0] * 2 + key_without_prefix_chars

        return command_line_key

    def get_items_for_config_file_output(self, source_to_settings, parsed_namespace):
        """Converts the given settings back to a dictionary that can be passed
        to ConfigFormatParser.serialize(..).

        Args:
            source_to_settings: the dictionary described in parse_known_args()
            parsed_namespace: namespace object created within parse_known_args()
        Returns:
            OrderedDict: where keys are strings and values are either strings
            or lists
        """
        config_file_items = OrderedDict()
        for source, settings in source_to_settings.items():
            if source == _COMMAND_LINE_SOURCE_KEY:
                _, existing_command_line_args = settings[""]
                for action in self._actions:
                    config_file_keys = self.get_possible_config_keys(action)
                    if (
                        config_file_keys
                        and not action.is_positional_arg
                        and already_on_command_line(
                            existing_command_line_args,
                            action.option_strings,
                            self.prefix_chars,
                        )
                    ):
                        value = getattr(parsed_namespace, action.dest, None)
                        if value is not None:
                            if isinstance(value, bool):
                                value = str(value).lower()
                            config_file_items[config_file_keys[0]] = value

            elif source == _ENV_VAR_SOURCE_KEY:
                for key, (action, value) in settings.items():
                    config_file_keys = self.get_possible_config_keys(action)
                    if config_file_keys:
                        value = getattr(parsed_namespace, action.dest, None)
                        if value is not None:
                            config_file_items[config_file_keys[0]] = value
            elif source.startswith(_CONFIG_FILE_SOURCE_KEY):
                for key, (action, value) in settings.items():
                    config_file_items[key] = value
            elif source == _DEFAULTS_SOURCE_KEY:
                for key, (action, value) in settings.items():
                    config_file_keys = self.get_possible_config_keys(action)
                    if config_file_keys:
                        value = getattr(parsed_namespace, action.dest, None)
                        if value is not None:
                            config_file_items[config_file_keys[0]] = value
        return config_file_items

    def convert_item_to_command_line_arg(self, action, key, value):
        """Converts a config file or env var key + value to a list of
        commandline args to append to the commandline.

        Args:
            action: The argparse Action object for this setting, or None if this
                config file setting doesn't correspond to any defined
                configargparse arg.
            key: string (config file key or env var name)
            value: parsed value of type string or list

        Returns:
            list[str]: args
        """
        args = []

        if action is None:
            command_line_key = (
                self.get_command_line_key_for_unknown_config_file_setting(key)
            )
        else:
            if not is_boolean_optional_action(action):
                command_line_key = action.option_strings[-1]

        # handle boolean value
        if action is not None and isinstance(
            action, ACTION_TYPES_THAT_DONT_NEED_A_VALUE
        ):
            assert isinstance(
                value, str
            ), "config parser should convert anything that is not a list to string."
            if value.lower() in ("true", "yes", "on", "1"):
                if not is_boolean_optional_action(action):
                    args.append(command_line_key)
                else:
                    # --foo
                    args.append(action.option_strings[0])
            elif value.lower() in ("false", "no", "off", "0"):
                # don't append when set to "false" / "no"
                if not is_boolean_optional_action(action):
                    pass
                else:
                    # --no-foo
                    args.append(action.option_strings[1])
            elif isinstance(action, argparse._CountAction):
                # For count actions, repeat the flag the number of times specified
                args += [action.option_strings[0]] * int(value)
            else:
                self.error(
                    "Unexpected value for %s: '%s'. Expecting 'true', "
                    "'false', 'yes', 'no', 'on', 'off', '1' or '0'" % (key, value)
                )
        elif isinstance(value, list):
            # Only nargs is relevant here: any action, including a custom
            # argparse.Action subclass, consumes several values when nargs
            # allows it. Testing the action class as well would be redundant,
            # since actions that cannot consume a list have an nargs that
            # fails the test below anyway: 0 or None for store_const, count
            # and friends, 'A...' for subparsers, '...' for REMAINDER.
            accepts_list_and_has_nargs = action is not None and (
                action.nargs in ("+", "*")
                or (isinstance(action.nargs, int) and action.nargs > 1)
            )

            if action is None or isinstance(action, argparse._AppendAction):
                for list_elem in value:
                    if accepts_list_and_has_nargs and isinstance(list_elem, list):
                        args.append(command_line_key)
                        for sub_elem in list_elem:
                            args.append(str(sub_elem))
                    else:
                        args.append("%s=%s" % (command_line_key, str(list_elem)))
            elif accepts_list_and_has_nargs:
                args.append(command_line_key)
                for list_elem in value:
                    args.append(str(list_elem))
            else:
                self.error(
                    (
                        "%s can't be set to a list '%s' unless its action type is changed "
                        "to 'append' or nargs is set to '*', '+', or > 1"
                    )
                    % (key, value)
                )
        elif isinstance(value, str):
            args.append("%s=%s" % (command_line_key, value))
        else:
            raise ValueError(
                "Unexpected value type {} for value: {}".format(type(value), value)
            )

        return args

    def get_possible_config_keys(self, action):
        """This method decides which actions can be set in a config file and
        what their keys will be. It returns a list of 0 or more config keys that
        can be used to set the given action's value in a config file.

        Returns:
            list[str]: keys
        """
        keys = []

        # Do not write out the config options for writing out a config file
        if getattr(action, "is_write_out_config_file_arg", None):
            return keys

        for arg in action.option_strings:
            if any(arg.startswith(2 * c) for c in self.prefix_chars):
                keys += [arg[2:], arg]  # eg. for '--bla' return ['bla', '--bla']

        return keys

    def _open_config_files(self, command_line_args):
        """Tries to parse config file path(s) from within command_line_args.
        Returns a list of opened config files, including files specified on the
        commandline as well as any default_config_files specified in the
        constructor that are present on disk.

        Args:
            command_line_args: List of all args

        Returns:
            list[tuple[io.IOBase, str]]: list of ``(stream, source_label)``
            pairs. The ``source_label`` is unique per entry (file path for
            path entries; ``"<entry_label>[<index>]"`` for callable entries),
            so different entries cannot collapse into a single source key in
            ``format_values()``.
        """
        # open any default config files
        config_files = []
        try:
            for i, entry in enumerate(self._default_config_files):
                if isinstance(entry, (str, os.PathLike)):
                    # Path entries (str or PathLike). Checked before callable so
                    # objects implementing both __fspath__ and __call__ are
                    # treated as paths, matching the documented behavior.
                    for f in glob.glob(os.path.expanduser(os.fspath(entry))):
                        config_files.append((self._config_file_open_func(f), f))
                else:
                    # Callable entry (validation in __init__ guarantees this).
                    entry_label = getattr(entry, "__name__", repr(entry))
                    try:
                        stream = entry()
                    except Exception as e:
                        raise ConfigFileParserException(
                            "default_config_files entry %r raised while being "
                            "called: %s" % (entry_label, e)
                        ) from e
                    if stream is None:
                        raise TypeError(
                            "default_config_files entry %r returned None; "
                            "must return an open file-like object." % (entry_label,)
                        )
                    # Use a source label that always includes the entry index
                    # so two callables returning streams with the same .name
                    # (or even the same library-generated name from a previous
                    # iteration) cannot collide into one _source_to_settings
                    # entry. The label also doubles as stream.name when the
                    # stream lacks one, for readable parser error messages.
                    display_name = (
                        getattr(stream, "name", None)
                        if hasattr(stream, "name")
                        else None
                    )
                    source_label = "%s[%d]" % (display_name or entry_label, i)
                    # Append before attempting .name so the outer cleanup
                    # closes the stream if the assignment below raises.
                    config_files.append((stream, source_label))
                    if not hasattr(stream, "name"):
                        try:
                            stream.name = source_label
                        except Exception as e:
                            raise ConfigFileParserException(
                                "default_config_files entry %r returned a "
                                "stream whose .name attribute could not be "
                                "set: %s" % (entry_label, e)
                            ) from e

            # list actions with is_config_file_arg=True. Its possible there is
            # more than one such arg.
            user_config_file_arg_actions = [
                a for a in self._actions if getattr(a, "is_config_file_arg", False)
            ]

            if not user_config_file_arg_actions:
                return config_files

            for action in user_config_file_arg_actions:
                # try to parse out the config file path by using a clean new
                # ArgumentParser that only knows this one arg/action.
                arg_parser = argparse.ArgumentParser(
                    prefix_chars=self.prefix_chars, add_help=False
                )

                arg_parser._add_action(action)

                # make parser not exit on error by replacing its error method.
                # Otherwise it sys.exits(..) if, for example, config file
                # is_required=True and user doesn't provide it.
                def error_method(self, message):
                    pass

                arg_parser.error = types.MethodType(error_method, arg_parser)

                # check whether the user provided a value
                namespace, _ = arg_parser.parse_known_args(args=command_line_args)
                user_config_file = getattr(namespace, action.dest, None)

                if not user_config_file:
                    continue

                # open user-provided config file
                user_config_file = os.path.expanduser(user_config_file)
                try:
                    stream = self._config_file_open_func(user_config_file)
                except Exception as e:
                    self.error(
                        "Unable to open config file: %s. Error: %s"
                        % (user_config_file, str(e))
                    )

                config_files.append((stream, user_config_file))

            return config_files
        except BaseException:
            # If anything in the body above raises (callable failure, .name
            # assignment failure, glob/open failure, an inner argparse type=
            # callback raising during user-config-file parsing, self.error()
            # exiting, etc.), close every stream we opened so we don't leak
            # file handles. close() is idempotent for standard streams, so it
            # is safe to call on streams already closed by a nested handler.
            for cf, _ in config_files:
                try:
                    if hasattr(cf, "close"):
                        cf.close()
                except Exception:
                    pass
            raise

    def format_values(self):
        """Returns a string with all args and settings and where they came from
        (eg. commandline, config file, environment variable or default)

        Returns:
            str: source to settings string
        """
        source_key_to_display_value_map = {
            _COMMAND_LINE_SOURCE_KEY: "Command Line Args: ",
            _ENV_VAR_SOURCE_KEY: "Environment Variables:\n",
            _CONFIG_FILE_SOURCE_KEY: "Config File (%s):\n",
            _DEFAULTS_SOURCE_KEY: "Defaults:\n",
        }

        r = StringIO()
        for (
            source,
            settings,
        ) in self._source_to_settings.items():  # type: ignore[argument-error]
            source = source.split("|", 1)
            source = source_key_to_display_value_map[source[0]] % tuple(source[1:])
            r.write(source)
            for key, (action, value) in settings.items():
                if key:
                    r.write("  {:<19}{}\n".format(key + ":", value))
                else:
                    if isinstance(value, str):
                        r.write("  %s\n" % value)
                    elif isinstance(value, list):
                        r.write("  %s\n" % " ".join(value))

        return r.getvalue()

    def print_values(self, file=sys.stdout):
        """Prints the format_values() string (to sys.stdout or another file)."""
        file.write(self.format_values())

    def format_help(self):
        msg = ""
        added_config_file_help = False
        added_env_var_help = False
        if self._add_config_file_help:
            default_config_files = self._default_config_files
            cc = 2 * self.prefix_chars[0]  # eg. --
            config_settable_args = [
                (arg, a)
                for a in self._actions
                for arg in a.option_strings
                if self.get_possible_config_keys(a)
                and not (
                    a.dest == "help"
                    or a.is_config_file_arg
                    or a.is_write_out_config_file_arg
                )
            ]
            config_path_actions = [
                a for a in self._actions if getattr(a, "is_config_file_arg", False)
            ]

            if config_settable_args and (default_config_files or config_path_actions):
                self._add_config_file_help = False  # prevent duplication
                added_config_file_help = True

                msg += (
                    "Args that start with '%s' can also be set in a config file"
                ) % cc
                config_arg_string = " or ".join(
                    a.option_strings[0] for a in config_path_actions if a.option_strings
                )
                if config_arg_string:
                    config_arg_string = "specified via " + config_arg_string
                if default_config_files or config_arg_string:
                    # Mirror _open_config_files: path entries (str/PathLike)
                    # are checked before callable, so an object that is both
                    # PathLike and callable is rendered as a path here too.
                    # os.fsdecode() handles bytes-returning __fspath__ (PEP
                    # 519 allows it); the try/except handles malformed
                    # PathLike whose __fspath__ returns the wrong type.
                    def _describe_default_config_file_entry(e):
                        if isinstance(e, (str, os.PathLike)):
                            try:
                                return os.fsdecode(os.fspath(e))
                            except (TypeError, ValueError):
                                return repr(e)
                        return getattr(e, "__name__", "<callable>")

                    described_files = tuple(
                        _describe_default_config_file_entry(e)
                        for e in default_config_files
                    )
                    msg += " (%s)." % " or ".join(
                        described_files + tuple(filter(None, [config_arg_string]))
                    )
                msg += " " + self._config_file_parser.get_syntax_description()

        if self._add_env_var_help:
            env_var_actions = [
                (a.env_var, a) for a in self._actions if getattr(a, "env_var", None)
            ]
            for env_var, a in env_var_actions:
                if a.help == SUPPRESS:
                    continue
                env_var_help_string = "   [env var: %s]" % env_var
                if not a.help:
                    a.help = ""
                if env_var_help_string not in a.help:
                    a.help += env_var_help_string
                    added_env_var_help = True
                    self._add_env_var_help = False  # prevent duplication

        if added_env_var_help or added_config_file_help:
            value_sources = ["defaults"]
            if added_config_file_help:
                value_sources = ["config file values"] + value_sources
            if added_env_var_help:
                value_sources = ["environment variables"] + value_sources
            msg += " In general, command-line values override %s." % (
                " which override ".join(value_sources)
            )

        text_width = max(self._get_formatter()._width, 11)
        msg = textwrap.fill(msg, text_width)

        return argparse.ArgumentParser.format_help(self) + (
            "\n{}\n".format(msg) if msg != "" else ""
        )


def add_argument(self, *args, **kwargs):
    """
    This method supports the same args as ArgumentParser.add_argument(..)
    as well as the additional args below.

    Keyword Arguments:
        env_var: If set, the value of this environment variable will override
            any config file or default values for this arg (but can itself
            be overridden on the commandline). Also, if auto_env_var_prefix is
            set in the constructor, this env var name will be used instead of
            the automatic name.
        is_config_file_arg: If True, this arg is treated as a config file path
            This provides an alternative way to specify config files in place of
            the ArgumentParser(fromfile_prefix_chars=..) mechanism.
            Default: False
        is_write_out_config_file_arg: If True, this arg will be treated as a
            config file path, and, when it is specified on the command line,
            will cause configargparse to write all current commandline args to
            this file as config options and then exit. It can only be set on the
            command line: a config file key that names it is an error, and it
            can't be combined with env_var, nor be a positional arg, since a
            config file value would be indistinguishable from a path the user
            typed and could overwrite an arbitrary file.
            Default: False

    Returns:
        argparse.Action: the new argparse action
    """

    env_var = kwargs.pop("env_var", None)

    is_config_file_arg = kwargs.pop("is_config_file_arg", None) or kwargs.pop(
        "is_config_file", None
    )  # for backward compat.

    is_write_out_config_file_arg = kwargs.pop("is_write_out_config_file_arg", None)

    action = self.original_add_argument_method(*args, **kwargs)

    if is_write_out_config_file_arg and isinstance(action, argparse._StoreAction):
        # this arg has to record the path it is given as it is parsed, rather
        # than leave it to be read back out of the namespace later. Whatever
        # store action the program asked for keeps doing its own work.
        action.__class__ = type(
            type(action).__name__,
            (_WriteOutConfigFileActionMixin, type(action)),
            {},
        )

    action.is_positional_arg = not action.option_strings
    action.env_var = env_var
    action.is_config_file_arg = is_config_file_arg
    action.is_write_out_config_file_arg = is_write_out_config_file_arg

    if action.is_positional_arg and env_var:
        raise ValueError("env_var can't be set for a positional arg.")
    if action.is_config_file_arg and not isinstance(action, argparse._StoreAction):
        raise ValueError("arg with is_config_file_arg=True must have action='store'")
    if action.is_write_out_config_file_arg:
        error_prefix = "arg with is_write_out_config_file_arg=True "
        if not isinstance(action, _WriteOutConfigFileActionMixin):
            raise ValueError(error_prefix + "must have action='store'")
        if is_config_file_arg:
            raise ValueError(error_prefix + "can't also have is_config_file_arg=True")
        if env_var:
            # writing out a config file overwrites the given path and then
            # exits, so an env var that sets one could destroy an arbitrary file
            raise ValueError(error_prefix + "can't also have env_var set")
        if action.is_positional_arg:
            # a config file value becomes a plain command line arg, and a
            # positional would take one of those just as readily as one the user
            # typed, leaving no way to keep a config file from choosing the path
            # that gets overwritten
            raise ValueError(error_prefix + "can't be a positional arg")

    return action


def _subparsers_of(parser, seen=None):
    """Find a parser and every subparser reachable from it.

    Args:
        parser: the parser to start from.
        seen: ids of the parsers already visited, so that a subparser leading
            back to one of its own ancestors doesn't loop forever.

    Returns:
        list[argparse.ArgumentParser]: the parser and its subparsers
    """
    if seen is None:
        seen = set()
    if id(parser) in seen:
        return []
    seen.add(id(parser))

    parsers = [parser]
    for action in getattr(parser, "_actions", []):
        if _dispatches_to_subparsers(action):
            for subparser in action.choices.values():
                if isinstance(subparser, argparse.ArgumentParser):
                    parsers += _subparsers_of(subparser, seen)

    return parsers


def _dispatches_to_subparsers(action):
    """Check whether an action hands the rest of the command line to a subparser.

    Nearly always this is an ``argparse._SubParsersAction``, but a program can
    register a class of its own for the job, so recognize the shape too: a
    mapping of subcommand names to parsers, taking the rest of the args.

    Args:
        action: the action to check.

    Returns:
        bool: whether it dispatches to subparsers
    """
    if isinstance(action, argparse._SubParsersAction):
        return True

    return getattr(action, "nargs", None) in (
        argparse.PARSER,
        argparse.REMAINDER,
    ) and isinstance(getattr(action, "choices", None), dict)


def already_on_command_line(
    existing_args_list, potential_command_line_args, prefix_chars
):
    """Utility method for checking if any of the potential_command_line_args is
    already present in existing_args.

    Returns:
        bool: already on command line?
    """
    arg_names = []
    for arg_string in existing_args_list:
        if arg_string and arg_string[0] in prefix_chars and "=" in arg_string:
            option_string, explicit_arg = arg_string.split("=", 1)
            arg_names.append(option_string)
        else:
            arg_names.append(arg_string)

    return any(
        potential_arg in arg_names for potential_arg in potential_command_line_args
    )


# NOTE: Aliases below are not auto-documented. This could be improved by updating
# to latest version of pydoctor when https://github.com/twisted/pydoctor/pull/414
# has been merged, which would allow aliases to be documented automatically.

# wrap ArgumentParser's add_argument(..) method with the one above
argparse._ActionsContainer.original_add_argument_method = (
    argparse._ActionsContainer.add_argument
)
argparse._ActionsContainer.add_argument = add_argument


# add all public classes and constants from argparse module's namespace to this
# module's namespace so that the 2 modules are truly interchangeable
Action = argparse.Action
ArgumentDefaultsHelpFormatter = argparse.ArgumentDefaultsHelpFormatter
ArgumentError = argparse.ArgumentError
ArgumentTypeError = argparse.ArgumentTypeError
FileType = argparse.FileType
HelpFormatter = argparse.HelpFormatter
MetavarTypeHelpFormatter = argparse.MetavarTypeHelpFormatter
Namespace = argparse.Namespace
RawDescriptionHelpFormatter = argparse.RawDescriptionHelpFormatter
RawTextHelpFormatter = argparse.RawTextHelpFormatter
ONE_OR_MORE = argparse.ONE_OR_MORE
OPTIONAL = argparse.OPTIONAL
PARSER = argparse.PARSER
REMAINDER = argparse.REMAINDER
SUPPRESS = argparse.SUPPRESS
ZERO_OR_MORE = argparse.ZERO_OR_MORE


# deprecated PEP-8 incompatible API names.
initArgumentParser = init_argument_parser
getArgumentParser = get_argument_parser
getArgParser = get_argument_parser
getParser = get_argument_parser

# create shorter aliases for the key methods and class names
get_arg_parser = get_argument_parser
get_parser = get_argument_parser

ArgParser = ArgumentParser
Parser = ArgumentParser

argparse._ActionsContainer.add_arg = argparse._ActionsContainer.add_argument
argparse._ActionsContainer.add = argparse._ActionsContainer.add_argument

ArgumentParser.parse = ArgumentParser.parse_args
ArgumentParser.parse_known = ArgumentParser.parse_known_args

RawFormatter = RawDescriptionHelpFormatter
DefaultsFormatter = ArgumentDefaultsHelpFormatter
DefaultsRawFormatter = ArgumentDefaultsRawHelpFormatter
