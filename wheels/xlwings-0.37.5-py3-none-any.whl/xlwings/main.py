"""
xlwings - Make Excel fly with Python!

Homepage and documentation: https://www.xlwings.org

Copyright (C) 2014-present, Zoomer Analytics GmbH.
All rights reserved.

License: BSD 3-clause (see LICENSE.txt for details)
"""

from __future__ import annotations

import datetime as dt
import inspect
import math
import numbers
import os
import re
import sys
import time
import warnings
from contextlib import contextmanager
from os import PathLike
from pathlib import Path
from types import EllipsisType
from typing import (
    Any,
    Awaitable,
    ClassVar,
    Generator,
    Generic,
    Iterator,
    Literal,
    Mapping,
    Sequence,
    TypeVar,
    cast,
    get_args,
    overload,
)

import xlwings

from . import LicenseError, ShapeAlreadyExists, XlwingsError, utils
from .base_classes import (
    _UNSET,
    AUTOFILTER_COMPARISON_OPERATORS,
    AUTOFILTER_CRITERIA_TYPES,
    BORDER_GRID_SIDES,
    BORDER_SIDES,
    CHART_LEGEND_POSITIONS,
    CHART_MARKER_STYLES,
    CHART_PLOT_BY,
    CHART_TYPES,
    CONDITIONAL_FORMAT_ICON_SETS,
    CONDITIONAL_FORMAT_OPERATORS,
    CONDITIONAL_FORMAT_THRESHOLD_TYPES,
    CONDITIONAL_FORMAT_TYPES,
    DATA_VALIDATION_OPERATORS,
    DATA_VALIDATION_TYPES,
    HORIZONTAL_ALIGNMENTS,
    PIVOT_FUNCTIONS,
    PIVOT_LAYOUTS,
    VERTICAL_ALIGNMENTS,
    AutoFilterComparisonOperator,
    AutoFilterCriteriaType,
    BorderGroup,
    BorderLineStyle,
    BorderSide,
    BorderWeight,
    ChartLegendPosition,
    ChartMarkerStyle,
    ChartPlotBy,
    ConditionalFormatCriterionType,
    ConditionalFormatIconSet,
    ConditionalFormatOperator,
    ConditionalFormatThresholdType,
    ConditionalFormatType,
    DataValidationAlertStyle,
    DataValidationOperator,
    DataValidationType,
    HorizontalAlignment,
    PivotFunction,
    PivotLayout,
    VerticalAlignment,
)

# Optional imports
try:
    import matplotlib as mpl
    from matplotlib.backends.backend_agg import FigureCanvas
except ImportError:
    mpl = None
    FigureCanvas = None

try:
    import pandas as pd
except ImportError:
    pd = None

try:
    import PIL
except ImportError:
    PIL = None


_T = TypeVar("_T")


class Collection(Generic[_T]):
    _wrap: ClassVar[type]

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    def __call__(self, name_or_index: int | str) -> _T:
        return self._wrap(impl=self.impl(name_or_index))

    def __len__(self) -> int:
        return len(self.impl)

    @property
    def count(self) -> int:
        """Returns the number of objects in the collection."""
        return len(self)

    def __iter__(self) -> Iterator[_T]:
        for impl in self.impl:
            yield self._wrap(impl=impl)

    def __getitem__(self, key: int | str) -> _T:
        if isinstance(key, numbers.Number):
            length = len(self)
            if key >= length:
                raise IndexError("Index %s out of range (%s elements)" % (key, length))
            if key < 0:
                if key < -length:
                    raise IndexError(
                        "Index %s out of range (%s elements)" % (key, length)
                    )
                key += length
            return self(key + 1)
        elif isinstance(key, slice):
            raise ValueError(
                self.impl.__class__.__name__ + " object does not support slicing"
            )
        else:
            return self(key)

    def __contains__(self, key: str) -> bool:
        return key in self.impl

    # used by repr - by default the name of the collection class, but can be overridden
    @property
    def _name(self) -> str:
        return self.__class__.__name__

    def __repr__(self) -> str:
        r = []
        for i, x in enumerate(self):
            if i == 3:
                r.append("...")
                break
            else:
                r.append(repr(x))

        return "{}({})".format(self._name, "[" + ", ".join(r) + "]")


class Engines:
    def __init__(self) -> None:
        self.active = None
        self.engines = []
        self.engines_by_name = {}

    def add(self, engine: Engine) -> None:
        self.engines.append(engine)
        self.engines_by_name[engine.name] = engine

    @property
    def count(self) -> int:
        return len(self)

    def __call__(self, name_or_index: int | str) -> Engine:
        if isinstance(name_or_index, numbers.Number):
            return self.engines[name_or_index - 1]
        else:
            return self.engines_by_name[name_or_index]

    def __getitem__(self, name_or_index: int | str) -> Engine:
        if isinstance(name_or_index, numbers.Number):
            return self.engines[name_or_index]
        else:
            try:
                return self.engines_by_name[name_or_index]
            except KeyError:
                engine_to_product_name = {
                    "remote": "xlwings Server",
                    "calamine": "xlwings Reader",
                }
                if not xlwings.__pro__ and name_or_index != "excel":
                    raise LicenseError(
                        f"{engine_to_product_name.get(name_or_index, name_or_index)} "
                        "requires a license key. Install one by running 'xlwings "
                        "license update -k your-key-here' or by setting the "
                        "XLWINGS_LICENSE_KEY environment variable."
                    )
                else:
                    raise

    def __len__(self) -> int:
        return len(self.engines)

    def __iter__(self) -> Iterator[Engine]:
        for engine in self.engines:
            yield engine

    def __repr__(self) -> str:
        return "{}({})".format(self.__class__.__name__, repr(list(self)))


class Engine:
    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def apps(self) -> Apps:
        return Apps(impl=self.impl.apps)

    @property
    def name(self) -> str:
        return self.impl.name

    @property
    def type(self) -> str:
        return self.impl.type

    def activate(self) -> None:
        engines.active = self

    def __repr__(self) -> str:
        return f"<Engine {self.name}>"


class Apps:
    """A collection of all `app` objects:

    ```pycon
    >>> import xlwings as xw
    >>> xw.apps
    Apps([<Excel App 1668>, <Excel App 1644>])
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    def keys(self) -> list[int]:
        """Provides the PIDs of the Excel instances
        that act as keys in the Apps collection.

        ```{versionadded} 0.13.0
        ```
        """
        return self.impl.keys()

    def add(self, **kwargs: Any) -> App:
        """Creates a new App. The new App becomes the active one. Returns an App object."""
        return App(impl=self.impl.add(**kwargs))

    @property
    def active(self) -> App | None:
        """Returns the active app.

        ```{versionadded} 0.9.0
        ```
        """
        for app in self.impl:
            return App(impl=app)
        return None

    def __call__(self, i: int) -> App:
        return self[i]

    def __repr__(self) -> str:
        return "{}({})".format(
            getattr(self.__class__, "_name", self.__class__.__name__), repr(list(self))
        )

    def __getitem__(self, item: int) -> App:
        return App(impl=self.impl[item])

    def __len__(self) -> int:
        return len(self.impl)

    @property
    def count(self) -> int:
        """Returns the number of apps.

        ```{versionadded} 0.9.0
        ```
        """
        return len(self)

    def cleanup(self) -> None:
        """Removes Excel zombie processes (Windows-only). Note that this is
        automatically called with `App.quit()` and `App.kill()` and when the Python
        interpreter exits.

        ```{versionadded} 0.30.2
        ```
        """
        self.impl.cleanup()

    def __iter__(self) -> Iterator[App]:
        for app in self.impl:
            yield App(impl=app)


engines = Engines()


class App:
    """An app corresponds to an Excel instance and should normally be used as context
    manager to make sure that everything is properly cleaned up again and to prevent
    zombie processes. New Excel instances can be fired up like so:

    ```python
    import xlwings as xw

    with xw.App() as app:
        print(app.books)
    ```
    An app object is a member of the `apps` collection:

    ```pycon
    >>> xw.apps
    Apps([<Excel App 1668>, <Excel App 1644>])
    >>> xw.apps[1668]  # get the available PIDs via xw.apps.keys()
    <Excel App 1668>
    >>> xw.apps.active
    <Excel App 1668>
    ```

    Args:
        visible: Returns or sets a boolean value that determines whether the app is visible. The
            default leaves the state unchanged or sets visible=True if the object doesn't
            exist yet.
        spec: Mac-only, use the full path to the Excel application,
            e.g., `/Applications/Microsoft Office 2011/Microsoft Excel` or
            `/Applications/Microsoft Excel`.
            On Windows, if you want to change the version of Excel that xlwings talks to, go
            to `Control Panel > Programs and Features` and `Repair` the Office version
            that you want as default.


    ```{note}
    On Mac, while xlwings allows you to run multiple instances of Excel, it's a
    feature that is not officially supported by Excel for Mac: Unlike on Windows,
    Excel will not ask you to open a read-only version of a file if it is already
    open in another instance. This means that you need to watch out yourself so
    that the same file is not being overwritten from different instances.
    ```
    """

    def __init__(
        self,
        visible: bool | None = None,
        spec: str | None = None,
        add_book: bool = True,
        impl: Any = None,
    ) -> None:
        if impl is None:
            self.impl = engines.active.apps.add(
                spec=spec, add_book=add_book, visible=visible
            ).impl
            if visible or visible is None:
                self.visible = True
            if add_book and not self.books:
                # Simple hack for macOS where e.g., xw.view() wouldn't otherwise
                # work if Excel isn't running yet
                time.sleep(0.1)
        else:
            self.impl = impl
            if visible:
                self.visible = True
        self._pid = self.pid

    @property
    def engine(self) -> Engine:
        return Engine(impl=self.impl.engine)

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    @property
    def version(self) -> utils.VersionNumber:
        """Returns the Excel version number object.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> xw.App().version
            VersionNumber('15.24')
            >>> xw.apps[10559].version.major
            15
            ```

        ```{versionchanged} 0.9.0
        ```
        """
        return utils.VersionNumber(self.impl.version)

    @property
    def selection(self) -> Range | None:
        """Returns the selected cells as Range.

        ```{versionadded} 0.9.0
        ```
        """
        return Range(impl=self.impl.selection) if self.impl.selection else None

    async def get_selection(self) -> "Range | None":
        """Returns the selected cells as Range, fetched live from Excel.

        Requires xlwings Lite.

        ```{versionadded} 0.35.0
        ```
        """
        impl = await self.impl.get_selection()
        return Range(impl=impl) if impl else None

    def activate(self, steal_focus: bool = False) -> None:
        """Activates the Excel app.

        Args:
            steal_focus: If True, make frontmost application
                and hand over focus from Python to Excel.

        ```{versionadded} 0.9.0
        ```
        """
        # Win Excel >= 2013 fails if visible=False...
        # we may somehow not be using the correct HWND
        self.impl.activate(steal_focus)
        if self.engine.name != "remote":
            if self != apps.active:
                raise Exception(
                    "Could not activate App! "
                    "Try to instantiate the App with visible=True."
                )

    @property
    def visible(self) -> bool:
        """Gets or sets the visibility of Excel to `True` or  `False`.

        ```{versionadded} 0.3.3
        ```
        """
        return self.impl.visible

    @visible.setter
    def visible(self, value: bool) -> None:
        self.impl.visible = value

    def quit(self) -> None:
        """Quits the application without saving any workbooks.

        ```{versionadded} 0.3.3
        ```

        """
        return self.impl.quit()

    def kill(self) -> None:
        """Forces the Excel app to quit by killing its process.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.kill()

    @property
    def screen_updating(self) -> bool:
        """Turn screen updating off to speed up your script. You won't be able to see
        what the script is doing, but it will run faster. Remember to set the
        screen_updating property back to True when your script ends.

        ```{note}
        On xlwings Server and xlwings Lite, screen updating can only be
        suspended until the next sync rather than turned off indefinitely, so
        the effect ends on its own before your script does. Setting it back to
        `True` is a no-op there, and reading the property isn't supported.
        ```

        ```{versionadded} 0.3.3
        ```
        """
        return self.impl.screen_updating

    @screen_updating.setter
    def screen_updating(self, value: bool) -> None:
        self.impl.screen_updating = value

    @property
    def display_alerts(self) -> bool:
        """The default value is True. Set this property to False to suppress prompts and
        alert messages while code is running; when a message requires a response, Excel
        chooses the default response.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.display_alerts

    @display_alerts.setter
    def display_alerts(self, value: bool) -> None:
        self.impl.display_alerts = value

    @property
    def enable_events(self) -> bool:
        """`True` if events are enabled. Read/write boolean.

        ```{versionadded} 0.24.4
        ```
        """
        return self.impl.enable_events

    @enable_events.setter
    def enable_events(self, value: bool) -> None:
        self.impl.enable_events = value

    @property
    def interactive(self) -> bool:
        """`True` if Excel is in interactive mode. If you set this property to `False`,
        Excel blocks all input from the keyboard and mouse (except input to dialog boxes
        that are displayed by your code). Read/write Boolean.
        NOTE: Not supported on macOS.

        ```{versionadded} 0.24.4
        ```
        """
        return self.impl.interactive

    @interactive.setter
    def interactive(self, value: bool) -> None:
        self.impl.interactive = value

    @property
    def startup_path(self) -> str:
        """Returns the path to `XLSTART` which is where the xlwings add-in gets
        copied to by doing `xlwings addin install`.

        ```{versionadded} 0.19.4
        ```
        """
        return self.impl.startup_path

    @property
    def calculation(self) -> str:
        """Returns or sets a calculation value that represents the calculation mode.
        Modes: `'manual'`, `'automatic'`, `'semiautomatic'`

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> wb.app.calculation = 'manual'
            ```

        ```{versionchanged} 0.9.0
        ```
        """
        return self.impl.calculation

    @calculation.setter
    def calculation(self, value: str) -> None:
        self.impl.calculation = value

    def calculate(self) -> None:
        """Calculates all open books.

        ```{versionadded} 0.3.6
        ```

        """
        self.impl.calculate()

    @property
    def books(self) -> Books:
        """A collection of all Book objects that are currently open.

        ```{versionadded} 0.9.0
        ```
        """
        return Books(impl=self.impl.books)

    @property
    def hwnd(self) -> int | None:
        """Returns the Window handle (Windows-only).

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.hwnd

    @property
    def path(self) -> str:
        """Returns the path to where the App is installed.

        ```{versionadded} 0.28.4
        ```
        """
        return self.impl.path

    @property
    def pid(self) -> int:
        """Returns the PID of the app.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.pid

    def range(
        self,
        cell1: str | tuple[int, int] | Range,
        cell2: str | tuple[int, int] | Range | None = None,
    ) -> Range:
        """Range object from the active sheet of the active book, see `Range`.

        ```{versionadded} 0.9.0
        ```
        """
        return self.books.active.sheets.active.range(cell1, cell2)

    def macro(self, name: str) -> Macro:
        """Runs a Sub or Function in Excel VBA that are not part of a specific workbook
        but e.g. are part of an add-in.

        Args:
            name: e.g., `'Module1.MyMacro'` or `'MyMacro'`

        Examples:
            ```vb.net
            Function MySum(x, y)
                MySum = x + y
            End Function
            ```
            can be accessed like this:

            ```pycon
            >>> import xlwings as xw
            >>> app = xw.App()
            >>> my_sum = app.macro('MySum')
            >>> my_sum(1, 2)
            3
            ```

            Types are supported too:

            ```vb.net
            Function MySum(x as integer, y as integer)
                MySum = x + y
            End Function
            ```
            ```pycon
            >>> import xlwings as xw
            >>> app = xw.App()
            >>> my_sum = app.macro('MySum')
            >>> my_sum(1, 2)
            3
            ```

        However typed arrays are not supported. So the following won't work

        ```vb.net
        Function MySum(arr() as integer)
            ' code here
        End Function
        ```
        See also: `Book.macro`

        ```{versionadded} 0.9.0
        ```
        """
        return Macro(self, name)

    @property
    def status_bar(self) -> str | bool:
        """Gets or sets the value of the status bar.
        Returns `False` if Excel has control of it.

        ```{versionadded} 0.20.0
        ```
        """
        return self.impl.status_bar

    @status_bar.setter
    def status_bar(self, value: str | bool) -> None:
        self.impl.status_bar = value

    @property
    def cut_copy_mode(self) -> str | None:
        """Gets or sets the status of the cut or copy mode.
        Accepts `False` for setting and returns `None`,
        `copy` or `cut` when getting the status.

        ```{versionadded} 0.24.0
        ```
        """
        return self.impl.cut_copy_mode

    @cut_copy_mode.setter
    def cut_copy_mode(self, value: bool) -> None:
        self.impl.cut_copy_mode = value

    @contextmanager
    def properties(self, **kwargs: Any) -> Generator[App, None, None]:
        """Context manager that allows you to easily change the app's properties
        temporarily. Once the code leaves the with block, the properties are changed
        back to their previous state.
        Note: Must be used as context manager or else will have no effect. Also, you can
        only use app properties that you can both read and write.

        Examples:
            ```python
            import xlwings as xw
            app = App()

            # Sets app.display_alerts = False
            with app.properties(display_alerts=False):
            # do stuff

            # Sets app.calculation = 'manual' and app.enable_events = True
            with app.properties(calculation='manual', enable_events=True):
            # do stuff

            # Makes sure the status bar is reset even if an error happens in the with block
            with app.properties(status_bar='Calculating...'):
            # do stuff
            ```

        ```{versionadded} 0.24.4
        ```
        """
        initial_state = {}
        for attribute, value in kwargs.items():
            initial_state[attribute] = getattr(self, attribute, value)
            setattr(self, attribute, value)
        try:
            yield self
        finally:
            for attribute, value in initial_state.items():
                setattr(self, attribute, value)

    def create_report(
        self,
        template: str | PathLike[str] | None = None,
        output: str | PathLike[str] | None = None,
        book_settings: dict[str, Any] | None = None,
        **data: Any,
    ) -> Book:
        warnings.warn("Deprecated. Use render_template instead.")
        return self.render_template(
            template=template, output=output, book_settings=book_settings, **data
        )

    def render_template(
        self,
        template: str | PathLike[str] | None = None,
        output: str | PathLike[str] | None = None,
        book_settings: dict[str, Any] | None = None,
        **data: Any,
    ) -> Book:
        """This function requires xlwings `PRO`.

        This is a convenience wrapper around `mysheet.render_template`

        Writes the values of all key word arguments to the `output` file according to
        the `template` and the variables contained in there (Jinja variable syntax).
        Following variable types are supported:

        strings, numbers, lists, simple dicts, NumPy arrays, Pandas DataFrames, pictures
        and Matplotlib/Plotly figures.

        Args:
            template: Path to your Excel template, e.g. `r'C:\\Path\\to\\my_template.xlsx'`

            output: Path to your Report, e.g. `r'C:\\Path\\to\\my_report.xlsx'`

            book_settings: A dictionary of `xlwings.Book` parameters, for details see:
                `xlwings.Book`.
                For example: `book_settings={'update_links': False}`.

            data: All key/value pairs that are used in the template.

        ```{versionadded} 0.24.4
        ```
        """
        from .pro.reports import render_template

        return render_template(
            template=template,
            output=output,
            book_settings=book_settings,
            app=self,
            **data,
        )

    def alert(
        self,
        prompt: str,
        title: str | None = None,
        buttons: str = "ok",
        mode: str | None = None,
        callback: str | None = None,
    ) -> str | None:
        """This corresponds to `MsgBox` in VBA, shows an alert/message box and
        returns the value of the pressed button. For xlwings Server, instead of
        returning a value, the function accepts the name of a callback to which
        it will supply the value of the pressed button.

        Args:
            prompt: The message to be displayed.
            title: The title of the alert.
            buttons: Can be either `"ok"`, `"ok_cancel"`, `"yes_no"`, or
                `"yes_no_cancel"`.
            mode: Can be `"info"` or `"critical"`. Not supported by Google
                Sheets.
            callback: Only used by xlwings Server: you can provide the name of
                a function that will be called with the value of the pressed
                button as argument. The function has to exist on the client
                side, i.e., in VBA or JavaScript.

        Returns:
            `None` when used with xlwings Server, otherwise the value
            of the pressed button in lowercase: `"ok"`, `"cancel"`, `"yes"`,
            `"no"`.

        ```{versionadded} 0.27.13
        ```
        """
        return self.impl.alert(prompt, title, buttons, mode, callback)

    def __repr__(self) -> str:
        return f"<App [{self.engine.name}] {self.pid}>"

    def __eq__(self, other: object) -> bool:
        return type(other) is App and other.pid == self.pid

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash(self.pid)

    def __enter__(self) -> App:
        return self

    def __exit__(self, exc_type: Any, exc_value: Any, exc_tb: Any) -> None:
        self.quit()
        if sys.platform.startswith("win"):
            try:
                self.kill()
            except:  # noqa: E722
                pass


class Book:
    """A book object is a member of the `books` collection:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books[0]
    <Book [Book1]>
    ```


    The easiest way to connect to a book is offered by `xw.Book`: it looks for the
    book in all app instances and returns an error, should the same book be open in
    multiple instances. To connect to a book in the active app instance, use
    `xw.books` and to refer to a specific app, use:

    ```pycon
    >>> app = xw.App()  # or xw.apps[10559] (get the PIDs via xw.apps.keys())
    >>> app.books['Book1']
    ```

    |  | xw.Book | xw.books |
    | --- | --- | --- |
    | New book | `xw.Book()` | `xw.books.add()` |
    | Unsaved book | `xw.Book('Book1')` | `xw.books['Book1']` |
    | Book by (full)name | `xw.Book(r'C:/path/to/file.xlsx')` | `xw.books.open(r'C:/path/to/file.xlsx')` |

    Args:
        fullname: Full path or name (incl. xlsx, xlsm etc.) of existing workbook or name of an
            unsaved workbook. Without a full path, it looks for the file in the current
            working directory.
        update_links: If this argument is omitted, the user is prompted to specify how links will be
            updated
        read_only: True to open workbook in read-only mode
        format: If opening a text file, this specifies the delimiter character
        password: Password to open a protected workbook
        write_res_password: Password to write to a write-reserved workbook
        ignore_read_only_recommended: Set to `True` to mute the read-only recommended message
        origin: For text files only. Specifies where it originated. Use Platform constants.
        delimiter: If format argument is 6, this specifies the delimiter.
        editable: This option is only for legacy Microsoft Excel 4.0 addins.
        notify: Notify the user when a file becomes available If the file cannot be opened in
            read/write mode.
        converter: The index of the first file converter to try when opening the file.
        add_to_mru: Add this workbook to the list of recently added workbooks.
        local: If `True`, saves files against the language of Excel, otherwise against the
            language of VBA. Not supported on macOS.
        corrupt_load: Can be one of xlNormalLoad, xlRepairFile or xlExtractData.
            Not supported on macOS.
        json: A JSON object as delivered by the MS Office Scripts or Google Apps Script
            xlwings module but in a deserialized form, i.e., as dictionary.
            *New in version 0.26.0.*
        mode: Either `"i"` (interactive (default)) or `"r"` (read). In interactive mode,
            xlwings opens the workbook in Excel, i.e., Excel needs to be installed. In read
            mode, xlwings reads from the file directly, without requiring Excel to be
            installed. Read mode requires xlwings `PRO`.
            *New in version 0.28.0.*
    """

    def __init__(
        self,
        fullname: str | PathLike[str] | None = None,
        update_links: bool | None = None,
        read_only: bool | None = None,
        format: str | None = None,
        password: str | None = None,
        write_res_password: str | None = None,
        ignore_read_only_recommended: bool | None = None,
        origin: int | None = None,
        delimiter: str | None = None,
        editable: bool | None = None,
        notify: bool | None = None,
        converter: int | None = None,
        add_to_mru: bool | None = None,
        local: bool | None = None,
        corrupt_load: int | None = None,
        impl: Any = None,
        json: dict[str, Any] | None = None,
        mode: str | None = None,
        engine: str | None = None,
        **kwargs: Any,
    ) -> None:
        if not impl:
            if json:
                engine = engine if engine else "remote"
                impl = engines[engine].apps.active.books.open(json=json).impl
            elif fullname and mode == "r":
                engine = engine if engine else "calamine"
                impl = engines[engine].apps.active.books.open(fullname=fullname).impl
            elif fullname:
                fullname = utils.fspath(fullname)

                candidates = []
                for app in apps:
                    for wb in app.books:
                        if kwargs.get("from_xl") and sys.platform.startswith("darwin"):
                            if wb.name.lower() == os.path.split(fullname)[1].lower():
                                candidates.append((app, wb))
                        # Comparing by name first saves us from having to compare the
                        # fullname for non-candidates, which can get around issues in
                        # case the fullname is a problematic URL (GH 1946)
                        elif wb.name.lower() == os.path.split(fullname)[1].lower() and (
                            wb.fullname.lower() == fullname.lower()
                            or wb.name.lower() == fullname.lower()
                        ):
                            candidates.append((app, wb))

                app = apps.active
                if len(candidates) == 0:
                    if not app:
                        app = App(add_book=False)
                    impl = app.books.open(
                        fullname,
                        update_links,
                        read_only,
                        format,
                        password,
                        write_res_password,
                        ignore_read_only_recommended,
                        origin,
                        delimiter,
                        editable,
                        notify,
                        converter,
                        add_to_mru,
                        local,
                        corrupt_load,
                    ).impl
                elif len(candidates) > 1:
                    raise Exception(
                        "Workbook '%s' is open in more than one Excel instance."
                        % fullname
                    )
                else:
                    impl = candidates[0][1].impl
            else:
                # Open Excel if necessary and create a new workbook
                if apps.active:
                    impl = apps.active.books.add().impl
                else:
                    app = App()
                    impl = app.books[0].impl

        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj) of the engine being
        used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    def json(self) -> dict[str, Any]:
        """Returns a JSON serializable object as expected by the MS Office Scripts or
        Google Apps Script xlwings module. Only available with book objects that have
        been instantiated via `xw.Book(json=...)`.

        ```{versionadded} 0.26.0
        ```
        """
        return self.impl.json()

    async def flush(self) -> None:
        """Flushes all pending actions to Excel and the Output pane.

        Requires xlwings Lite.

        ```{versionadded} 0.35.0
        ```
        """
        await self.impl.flush()

    async def sync(self) -> None:
        """
        ```{deprecated} 0.35.0
        Use `flush` instead.
        ```
        """
        warnings.warn(
            "Book.sync() is deprecated, use Book.flush() instead.",
            FutureWarning,
            stacklevel=2,
        )
        await self.flush()

    async def load(self, values: bool | None = None) -> Book:
        """(Re)loads the book's data from Excel on demand.

        On an async book (see `xw.BookAsync`), this loads only *metadata*
        (tables, pictures, names) by default — not cell values — since
        bulk-loading values would defeat the point of the async API. Pass
        `values=True` to also snapshot all cell values, after which sync
        `.value` reads work again. On a regular book, everything including
        values is loaded regardless.

        Requires xlwings Lite.

        """
        await self.impl.load(values=values)
        return self

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, Book)
            and self.app == other.app
            and self.name == other.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash((self.app, self.name))

    @classmethod
    def caller(cls) -> Book:
        """References the calling book when the Python function is called from Excel via
        `RunPython`. Pack it into the function being called from Excel, e.g.:

        ```python
        import xlwings as xw

         def my_macro():
            wb = xw.Book.caller()
            wb.sheets[0].range('A1').value = 1
        ```
        To be able to easily invoke such code from Python for debugging, use
        `xw.Book.set_mock_caller()`.

        ```{versionadded} 0.3.0
        ```
        """
        wb, from_xl, hwnd = None, None, None
        for arg in sys.argv:
            if arg.startswith("--wb="):
                wb = arg.split("=")[1].strip()
            elif arg.startswith("--from_xl"):
                from_xl = arg.split("=")[1].strip()
            elif arg.startswith("--hwnd"):
                hwnd = arg.split("=")[1].strip()
        if hasattr(Book, "_mock_caller"):
            # Use mocking Book, see Book.set_mock_caller()
            return cls(impl=Book._mock_caller.impl)
        elif from_xl == "1":
            name = wb.lower()
            if sys.platform.startswith("win"):
                app = App(impl=xlwings._xlwindows.App(xl=int(hwnd)))
                return cls(impl=app.books[name].impl)
            else:
                # On Mac, the same file open in two instances is not supported
                if apps.active.version < 15:
                    name = name.encode("utf-8", "surrogateescape").decode("mac_latin2")
                return cls(impl=Book(name, from_xl=True).impl)
        elif xlwings._xlwindows.BOOK_CALLER:
            # Called via OPTIMIZED_CONNECTION = True
            return cls(impl=xlwings._xlwindows.Book(xlwings._xlwindows.BOOK_CALLER))
        else:
            raise Exception(
                "Book.caller() must not be called directly. Call through Excel "
                "or set a mock caller first with Book.set_mock_caller()."
            )

    def set_mock_caller(self) -> None:
        """Sets the Excel file which is used to mock `xw.Book.caller()` when the code is
        called from Python and not from Excel via `RunPython`.

        Examples:
            ```python
            # This code runs unchanged from Excel via RunPython and from Python directly
            import os
            import xlwings as xw

            def my_macro():
            sheet = xw.Book.caller().sheets[0]
            sheet.range('A1').value = 'Hello xlwings!'

            if __name__ == '__main__':
            xw.Book('file.xlsm').set_mock_caller()
            my_macro()
            ```

        ```{versionadded} 0.3.1
        ```
        """
        Book._mock_caller = self

    def macro(self, name: str) -> Macro:
        """Runs a Sub or Function in Excel VBA.

        Args:
            name:
                `'Module1.MyMacro'` or `'MyMacro'`

        Examples:

            ```vb.net
            Function MySum(x, y)
                MySum = x + y
            End Function
            ```
            can be accessed like this:

            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.books.active
            >>> my_sum = wb.macro('MySum')
            >>> my_sum(1, 2)
            3
            ```

        See also: `App.macro`

        ```{versionadded} 0.7.1
        ```
        """
        return self.app.macro("'{0}'!{1}".format(self.name, name))

    @property
    def name(self) -> str:
        """Returns the name of the book as str."""
        return self.impl.name

    @property
    def sheets(self) -> Sheets:
        """Returns a sheets collection that represents all the sheets in the book.

        ```{versionadded} 0.9.0
        ```
        """
        return Sheets(impl=self.impl.sheets)

    @property
    def notes(self) -> Notes:
        """Notes in this workbook. xlwings Lite includes the worksheets loaded for this script."""
        return Notes(self)

    @property
    def comments(self) -> Comments:
        """Threaded comments in this workbook. In xlwings Lite, use `await get_comments()`."""
        return Comments(self)

    async def get_comments(self) -> Comments:
        """Fetch the workbook's threaded comments.

        Requires xlwings Lite.
        """
        return Comments(
            self, [Comment(impl=item) for item in await self.impl.get_comments()]
        )

    @property
    def app(self) -> App:
        """Returns an app object that represents the creator of the book.

        ```{versionadded} 0.9.0
        ```
        """
        return App(impl=self.impl.app)

    def close(self) -> None:
        """Closes the book without saving it.

        ```{versionadded} 0.1.1
        ```
        """
        self.impl.close()

    def save(
        self, path: str | PathLike[str] | None = None, password: str | None = None
    ) -> None:
        """Saves the Workbook. If a path is provided, this works like SaveAs() in
        Excel. If no path is specified and if the file hasn't been saved previously,
        it's saved in the current working directory with the current filename.
        Existing files are overwritten without prompting. To change the file type,
        provide the appropriate extension, e.g. to save `myfile.xlsx` in the `xlsb`
        format, provide `myfile.xlsb` as path.

        Args:
            path: Path where you want to save the Book.
            password: Protection password with max. 15 characters
                *New in version 0.25.1.*

        Example:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> wb.save()
            >>> wb.save(r'C:\\path\\to\\new_file_name.xlsx')
            ```

        ```{note}
        On xlwings Server and xlwings Lite, the workbook is saved in place
        after your script returns rather than while it runs. `path` and
        `password` aren't supported there: the book can only be saved in
        place, and there's no way to set a password.
        ```

        ```{versionadded} 0.3.1
        ```
        """
        if path:
            path = utils.fspath(path)
        with self.app.properties(display_alerts=False):
            self.impl.save(path, password=password)

    @property
    def fullname(self) -> str:
        """Returns the name of the object, including its path on disk, as a string.
        Read-only String.

        """
        return self.impl.fullname

    @property
    def names(self) -> Names:
        """Returns a names collection that represents all the names in the specified book
        (including all sheet-specific names).

        ```{versionchanged} 0.9.0
        ```

        """
        return Names(impl=self.impl.names)

    def activate(self, steal_focus: bool = False) -> None:
        """Activates the book.

        Args:
            steal_focus: If True, make frontmost window and hand over focus from Python to Excel.

        """
        self.app.activate(steal_focus=steal_focus)
        self.impl.activate()

    @property
    def selection(self) -> Range | None:
        """Returns the selected cells as Range.

        ```{versionadded} 0.9.0
        ```
        """
        return Range(impl=self.app.selection.impl) if self.app.selection else None

    async def get_selection(self) -> "Range | None":
        """Returns the selected cells as Range, fetched live from Excel.

        Requires xlwings Lite.

        ```{versionadded} 0.35.0
        ```
        """
        return await self.app.get_selection()

    def to_pdf(
        self,
        path: str | PathLike[str] | None = None,
        include: int | str | list[int | str] | None = None,
        exclude: int | str | list[int | str] | None = None,
        layout: str | PathLike[str] | None = None,
        exclude_start_string: str = "#",
        show: bool = False,
        quality: str = "standard",
    ) -> str:
        """Exports the whole Excel workbook or a subset of the sheets to a PDF file.
        If you want to print hidden sheets, you will need to list them explicitely
        under `include`.

        Args:
            path: Path to the PDF file, defaults to the same name as the workbook, in the same
                directory. For unsaved workbooks, it defaults to the current working
                directory instead.

            include: Which sheets to include: provide a selection of sheets in the form of sheet
                indices (1-based like in Excel) or sheet names. Can be an int/str for a
                single sheet or a list of int/str for multiple sheets.

            exclude: Which sheets to exclude: provide a selection of sheets in the form of sheet
                indices (1-based like in Excel) or sheet names. Can be an int/str for a
                single sheet or a list of int/str for multiple sheets.

            layout: This argument requires xlwings `PRO`.
                Path to a PDF file on which the report will be printed. This is ideal for
                headers and footers as well as borderless printing of graphics/artwork. The
                PDF file either needs to have only 1 page (every report page uses the same
                layout) or otherwise needs the same amount of pages as the report (each
                report page is printed on the respective page in the layout PDF).
                *New in version 0.24.3.*
            exclude_start_string: Sheet names that start with this character/string will
                not be printed. *New in version 0.24.4.*
            show: Once created, open the PDF file with the default application.
                *New in version 0.24.6.*
            quality: Quality of the PDF file. Can either be `'standard'` or `'minimum'`.
                *New in version 0.26.2.*

        Examples:
            ```pycon
            >>> wb = xw.Book()
            >>> wb.sheets[0]['A1'].value = 'PDF'
            >>> wb.to_pdf()
            ```

            See also `xlwings.Sheet.to_pdf`

        ```{versionadded} 0.21.1
        ```
        """
        return utils.to_pdf(
            self,
            path=path,
            include=include,
            exclude=exclude,
            layout=layout,
            exclude_start_string=exclude_start_string,
            show=show,
            quality=quality,
        )

    def __repr__(self) -> str:
        return "<Book [{0}]>".format(self.name)

    def render_template(self, **data: Any) -> None:
        """This method requires xlwings `PRO`.

        Replaces all Jinja variables (e.g `{{ myvar }}`) in the book
        with the keyword argument of the same name.

        ```{versionadded} 0.25.0
        ```

        Args:
            data: All key/value pairs that are used in the template.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> book = xw.Book()
            >>> book.sheets[0]['A1:A2'].value = '{{ myvar }}'
            >>> book.render_template(myvar='test')
            ```
        """
        for sheet in reversed(self.sheets):
            sheet.render_template(**data)

    @property
    def sheet_names(self) -> list[str]:
        """Returns:
            List of sheet names in order of appearance.


        ```{versionadded} 0.28.1
        ```
        """
        return [sheet.name for sheet in self.sheets]

    def __enter__(self) -> Book:
        return self

    def __exit__(self, exc_type: Any, exc_value: Any, exc_tb: Any) -> None:
        self.close()


class BookAsync(Book):
    """Type hint for the async API in xlwings Lite scripts.

    Annotate a script's `book` parameter with `xw.BookAsync` to opt into the
    async, on-demand API --- no cell values are pre-loaded, and you read them via
    `await myrange.get_value()`:

    ```python
    import xlwings as xw
    from xlwings import script

    @script
    async def myfunc(book: xw.BookAsync):
        data = await book.sheets[0]["A1:B2"].get_value()
    ```

    At runtime it's a plain `Book`; the annotation only signals
    xlwings Lite to skip loading the values of the entire book up front.

    ```{versionadded} 0.36.9
    ```
    """


class Sheet:
    """A sheet object is a member of the `sheets` collection:

    ```pycon
    >>> import xlwings as xw
    >>> wb = xw.Book()
    >>> wb.sheets[0]
    <Sheet [Book1]Sheet1>
    >>> wb.sheets['Sheet1']
    <Sheet [Book1]Sheet1>
    >>> wb.sheets.add()
    <Sheet [Book1]Sheet2>
    ```

    ```{versionchanged} 0.9.0
    ```
    """

    def __init__(self, sheet: str | int | None = None, impl: Any = None) -> None:
        if impl is None:
            self.impl = books.active.sheets(sheet).impl
        else:
            self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, Sheet)
            and self.book == other.book
            and self.name == other.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash((self.book, self.name))

    @property
    def name(self) -> str:
        """Gets or sets the name of the Sheet."""
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        if value in [None, ""]:
            raise ValueError("A sheet name can't be empty.")
        elif any(char in value for char in ["\\", "/", "?", "*", "[", "]"]):
            raise ValueError(
                "A sheet name must not contain any "
                "of the following characters: \\, /, ?, *, [, ]"
            )
        elif len(value) > 31:
            raise ValueError(
                f"The max. length of a sheet name is 31 characters. "
                f"Yours is {len(value)}."
            )
        else:
            self.impl.name = value

    @property
    def names(self) -> Names:
        """Returns a names collection that represents all the sheet-specific names
        (names defined with the "SheetName!" prefix).

        ```{versionadded} 0.9.0
        ```

        """
        return Names(impl=self.impl.names)

    @property
    def freeze_panes(self) -> FreezePanes:
        """Interface to freeze/unfreeze panes.

        Examples:
            ```pycon
            >>> mysheet.freeze_panes.freeze_at("A1")
            >>> mysheet.freeze_panes.freeze_at(mysheet["A1"])
            >>> mysheet.freeze_panes.freeze_at("A:A")
            >>> mysheet.freeze_panes.freeze_at("1:1")
            >>> mysheet.freeze_panes.unfreeze()
            ```
        """
        return FreezePanes(impl=self.impl.freeze_panes, sheet=self)

    @property
    def book(self) -> Book:
        """Returns the Book of the specified Sheet. Read-only."""
        return Book(impl=self.impl.book)

    @property
    def notes(self) -> Notes:
        """Notes on this worksheet, indexed by cell address or position."""
        return Notes(self)

    @property
    def comments(self) -> Comments:
        """Threaded comments on this worksheet. In xlwings Lite, use `await get_comments()`."""
        return Comments(self)

    async def get_comments(self) -> Comments:
        """Fetch this worksheet's threaded comments.

        Requires xlwings Lite.
        """
        return Comments(
            self, [Comment(impl=item) for item in await self.impl.get_comments()]
        )

    @property
    def index(self) -> int:
        """Returns the index of the Sheet (1-based as in Excel)."""
        return self.impl.index

    def range(
        self,
        cell1: str | tuple[int, int] | Range,
        cell2: str | tuple[int, int] | Range | None = None,
    ) -> Range:
        """Returns a Range object from the active sheet of the active book,
        see `Range`.

        ```{versionadded} 0.9.0
        ```
        """
        if isinstance(cell1, Range):
            if cell1.sheet != self:
                raise ValueError("First range is not on this sheet")
            cell1 = cell1.impl
        if isinstance(cell2, Range):
            if cell2.sheet != self:
                raise ValueError("Second range is not on this sheet")
            cell2 = cell2.impl
        return Range(impl=self.impl.range(cell1, cell2))

    @property
    def cells(self) -> Range:
        """Returns a Range object that represents all the cells on the Sheet
        (not just the cells that are currently in use).

        ```{versionadded} 0.9.0
        ```
        """
        return Range(impl=self.impl.cells)

    def activate(self) -> None:
        """Activates the Sheet and returns it."""
        self.book.activate()
        return self.impl.activate()

    async def load(self, values: bool | None = None) -> Sheet:
        """(Re)loads the sheet's data from Excel on demand.

        Like `Book.load`, this loads only *metadata* by default on an async book
        and everything (including values) on a regular book. Pass `values=True`
        to also load this sheet's cell values.

        Requires xlwings Lite.

        """
        await self.impl.load(values=values)
        return self

    def select(self) -> None:
        """Selects the Sheet. Activates the book if it isn't the active one.

        ```{versionadded} 0.9.0
        ```
        """
        self.book.activate()
        return self.impl.select()

    def clear_contents(self) -> None:
        """Clears the content of the whole sheet but leaves the formatting."""
        return self.impl.clear_contents()

    def clear_formats(self) -> None:
        """Clears the format of the whole sheet but leaves the content.

        ```{versionadded} 0.26.2
        ```
        """
        return self.impl.clear_formats()

    def clear(self) -> None:
        """Clears the content and formatting of the whole sheet."""
        return self.impl.clear()

    def autofit(self, axis: str | None = None) -> None:
        """Autofits the width of either columns, rows or both on a whole Sheet.

        Args:
            axis: To autofit rows, use `"rows"` or `"r"`. To autofit columns,
                use `"columns"` or `"c"`. To autofit rows and columns, provide
                no arguments.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> wb.sheets['Sheet1'].autofit('c')
            >>> wb.sheets['Sheet1'].autofit('r')
            >>> wb.sheets['Sheet1'].autofit()
            ```

        ```{versionadded} 0.2.3
        ```
        """
        return self.impl.autofit(axis)

    def delete(self) -> None:
        """Deletes the Sheet.

        ```{versionadded} 0.6.0
        ```
        """
        return self.impl.delete()

    def to_html(self, path: str | PathLike[str] | None = None) -> None:
        """Export a Sheet as HTML page.

        Args:
            path: Path where you want to save the HTML file. Defaults to Sheet name in the
                current working directory.


        ```{versionadded} 0.28.1
        ```
        """
        path = utils.fspath(path)
        self.impl.to_html(self.name + ".html" if path is None else path)

    def to_pdf(
        self,
        path: str | PathLike[str] | None = None,
        layout: str | PathLike[str] | None = None,
        show: bool = False,
        quality: str = "standard",
    ) -> str:
        """Exports the sheet to a PDF file.

        Args:
            path: Path to the PDF file, defaults to the name of the sheet in the same
                directory of the workbook. For unsaved workbooks, it defaults to the current
                working directory instead.

            layout: This argument requires xlwings `PRO`.
                Path to a PDF file on which the report will be printed. This is ideal for
                headers and footers as well as borderless printing of graphics/artwork. The
                PDF file either needs to have only 1 page (every report page uses the same
                layout) or otherwise needs the same amount of pages as the report (each
                report page is printed on the respective page in the layout PDF).
                *New in version 0.24.3.*
            show: Once created, open the PDF file with the default application.
                *New in version 0.24.6.*
            quality: Quality of the PDF file. Can either be `'standard'` or `'minimum'`.
                *New in version 0.26.2.*

        Examples:
            ```pycon
            >>> wb = xw.Book()
            >>> sheet = wb.sheets[0]
            >>> sheet['A1'].value = 'PDF'
            >>> sheet.to_pdf()
            ```

            See also `xlwings.Book.to_pdf`

        ```{versionadded} 0.22.3
        ```
        """
        return self.book.to_pdf(
            self.name + ".pdf" if path is None else path,
            include=self.index,
            layout=layout,
            show=show,
            quality=quality,
        )

    def copy(
        self,
        before: Sheet | None = None,
        after: Sheet | None = None,
        name: str | None = None,
    ) -> Sheet:
        """Copy a sheet to the current or a new Book. By default, it places the copied
        sheet after all existing sheets in the current Book. Returns the copied sheet.

        ```{versionadded} 0.22.0
        ```

        Args:
            before: The sheet object before which you want to place the sheet

            after: The sheet object after which you want to place the sheet,
                by default it is placed after all existing sheets

            name: The sheet name of the copy

        Examples:
            ```python
            # Create two books and add a value to the first sheet of the first book
            first_book = xw.Book()
            second_book = xw.Book()
            first_book.sheets[0]['A1'].value = 'some value'

            # Copy to same Book with the default location and name
            first_book.sheets[0].copy()

            # Copy to same Book with custom sheet name
            first_book.sheets[0].copy(name='copied')

            # Copy to second Book requires to use before or after
            first_book.sheets[0].copy(after=second_book.sheets[0])
            ```
        """
        # copy() doesn't return the copied sheet object and has an awkward default
        # (copy it to a new workbook if neither before or after are provided),
        # so we're not taking that behavior over
        assert (before is None) or (
            after is None
        ), "you must provide either before or after but not both"
        if (before is None) and (after is None):
            after = self.book.sheets[-1]
        if before:
            target_book = before.book
            before = before.impl
        if after:
            target_book = after.book
            after = after.impl
        if name:
            if name.lower() in (s.name.lower() for s in target_book.sheets):
                raise ValueError(f"Sheet named '{name}' already present in workbook")
        sheet_names_before = {sheet.name for sheet in target_book.sheets}
        self.impl.copy(before=before, after=after)
        sheet_names_after = {sheet.name for sheet in target_book.sheets}
        new_sheet_name = sheet_names_after.difference(sheet_names_before).pop()
        copied_sheet = target_book.sheets[new_sheet_name]
        if name:
            copied_sheet.name = name
        return copied_sheet

    def move(
        self,
        before: Sheet | None = None,
        after: Sheet | None = None,
    ) -> None:
        """Move a sheet within its current Book.

        Provide exactly one of ``before`` or ``after``. Both the sheet being moved
        and the target sheet must belong to the same Book.

        Args:
            before: The sheet before which you want to place this sheet.
            after: The sheet after which you want to place this sheet.

        Examples:
            ```python
            book.sheets["Sheet3"].move(after=book.sheets["Sheet1"])
            ```

        ```{versionadded} 0.37.5
        ```
        """
        if (before is None) == (after is None):
            raise ValueError("Provide exactly one of 'before' or 'after'.")
        target = before if before is not None else after
        if target.book != self.book:
            raise ValueError("Sheets must belong to the same book.")
        if target == self:
            raise ValueError("A sheet can't be moved relative to itself.")
        self.impl.move(
            before=before.impl if before is not None else None,
            after=after.impl if after is not None else None,
        )

    def render_template(self, **data: Any) -> None:
        """This method requires xlwings `PRO`.

        Replaces all Jinja variables (e.g `{{ myvar }}`) in the sheet with the keyword
        argument that has the same name. Following variable types are supported:

        strings, numbers, lists, simple dicts, NumPy arrays, Pandas DataFrames,
        PIL Image objects that have a filename and Matplotlib figures.

        ```{versionadded} 0.22.0
        ```

        Args:
            data: All key/value pairs that are used in the template.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> book = xw.Book()
            >>> book.sheets[0]['A1:A2'].value = '{{ myvar }}'
            >>> book.sheets[0].render_template(myvar='test')
            ```
        """
        from .pro.reports.main import render_sheet

        render_sheet(self, **data)

    @property
    def charts(self) -> Charts:
        """See {class}`Charts <xlwings.main.Charts>`

        ```{versionadded} 0.9.0
        ```
        """
        return Charts(impl=self.impl.charts)

    @property
    def shapes(self) -> Shapes:
        """See {class}`Shapes <xlwings.main.Shapes>`

        ```{versionadded} 0.9.0
        ```
        """
        return Shapes(impl=self.impl.shapes)

    @property
    def tables(self) -> Tables:
        """See {class}`Tables <xlwings.main.Tables>`

        ```{versionadded} 0.21.0
        ```
        """
        return Tables(impl=self.impl.tables)

    @property
    def pivot_tables(self) -> PivotTables:
        """See {class}`PivotTables <xlwings.PivotTables>`

        ```{versionadded} 0.37.3
        ```
        """
        return PivotTables(impl=self.impl.pivot_tables)

    @property
    def pictures(self) -> Pictures:
        """See {class}`Pictures <xlwings.main.Pictures>`

        ```{versionadded} 0.9.0
        ```
        """
        return Pictures(impl=self.impl.pictures)

    @property
    def used_range(self) -> Range:
        """Used Range of Sheet.

        In xlwings Lite, this is a values-only snapshot and returns `A1` for an empty worksheet. Use {meth}`get_used_range` for a current formatting-aware result that returns `None` when the worksheet is empty.

        ```{versionadded} 0.13.0
        ```
        """
        return Range(impl=self.impl.used_range)

    async def get_used_range(self, values_only: bool = False) -> Range | None:
        """Returns the used range fetched from the current worksheet state, or `None` if the worksheet is empty according to `values_only`.

        Args:
            values_only: If `True`, only cells with values count as used. If `False`, cells with values or formatting count as used.

        Unlike this method, {attr}`used_range` is a values-only snapshot in xlwings Lite and returns `A1` for an empty worksheet for backward compatibility.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        if not isinstance(values_only, bool):
            raise TypeError("values_only must be a bool")
        impl = await self.impl.get_used_range(values_only)
        return Range(impl=impl) if impl else None

    @property
    def visible(self) -> bool:
        """Gets or sets the visibility of the Sheet (bool).

        ```{versionadded} 0.21.1
        ```
        """
        return self.impl.visible

    @visible.setter
    def visible(self, value: bool) -> None:
        self.impl.visible = value

    @property
    def show_gridlines(self) -> bool:
        """Gets or sets whether the sheet displays gridlines. This only
        affects what is shown on screen, not what is printed.

        With classic xlwings (Python running locally), the sheet must
        be (temporarily) activated by xlwings, which means that you can't use this
        with hidden sheets. xlwings Server and xlwings Lite don't have this restriction.

        Examples:
            ```pycon
            >>> mysheet.show_gridlines = False
            ```

        ```{versionadded} 0.37.3
        ```
        """
        return self.impl.show_gridlines

    @show_gridlines.setter
    def show_gridlines(self, value: bool) -> None:
        self.impl.show_gridlines = value

    @property
    def page_setup(self) -> PageSetup:
        """Returns a PageSetup object.

        ```{versionadded} 0.24.2
        ```
        """
        return PageSetup(self.impl.page_setup)

    def __getitem__(self, item: str | tuple[int, int]) -> Range:
        if isinstance(item, str):
            return self.range(item)
        else:
            return self.cells[item]

    def __repr__(self) -> str:
        return "<Sheet [{1}]{0}>".format(self.name, self.book.name)


class Range:
    """Returns a Range object that represents a cell or a range of cells.

    Args:
        cell1: Name of the range in the upper-left corner in A1 notation or as index-tuple or
            as name or as xw.Range object. It can also specify a range using the range
            operator (a colon), .e.g. 'A1:B2'

        cell2: Name of the range in the lower-right corner in A1 notation or as index-tuple or
            as name or as xw.Range object.

    Examples:
        ```python
        import xlwings as xw
        sheet1 = xw.Book("MyBook.xlsx").sheets[0]

        sheet1.range("A1")
        sheet1.range("A1:C3")
        sheet1.range((1,1))
        sheet1.range((1,1), (3,3))
        sheet1.range("NamedRange")

        # Or using index/slice notation
        sheet1["A1"]
        sheet1["A1:C3"]
        sheet1[0, 0]
        sheet1[0:4, 0:4]
        sheet1["NamedRange"]
        ```
    """

    def __init__(
        self,
        cell1: str | tuple[int, int] | Range | None = None,
        cell2: str | tuple[int, int] | Range | None = None,
        **options: Any,
    ) -> None:
        # Arguments
        impl = options.pop("impl", None)
        if impl is None:
            if (
                cell2 is not None
                and isinstance(cell1, Range)
                and isinstance(cell2, Range)
            ):
                if cell1.sheet != cell2.sheet:
                    raise ValueError("Ranges are not on the same sheet")
                impl = cell1.sheet.range(cell1, cell2).impl
            elif cell2 is None and isinstance(cell1, str):
                impl = apps.active.range(cell1).impl
            elif cell2 is None and isinstance(cell1, tuple):
                impl = sheets.active.range(cell1, cell2).impl
            elif (
                cell2 is not None
                and isinstance(cell1, tuple)
                and isinstance(cell2, tuple)
            ):
                impl = sheets.active.range(cell1, cell2).impl
            else:
                raise ValueError("Invalid arguments")

        self._impl = impl

        # Keyword Arguments
        self._impl.options = options
        self._options = options

    @property
    def impl(self) -> Any:
        return self._impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, Range)
            and self.sheet == other.sheet
            and self.row == other.row
            and self.column == other.column
            and self.shape == other.shape
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash((self.sheet, self.row, self.column, self.shape))

    def __iter__(self) -> Iterator[Range]:
        # Iterator object that returns cell Ranges: (1, 1), (1, 2) etc.
        for i in range(len(self)):
            yield self(i + 1)

    def adjust_indent(self, amount: int) -> None:
        """Adjusts the indentation in a Range.

        Args:
            amount: Number of spaces by which the indent is adjusted.
                Can be positive or negative.
        """
        self.impl.adjust_indent(amount)

    def group(self, by: str | None = None) -> None:
        """Group rows or columns.

        Args:
            by: "columns" or "rows". Figured out automatically if the range is defined as
                '1:3' or 'A:C', respectively.
        """
        if ":" in self.impl.arg1_input and by is None:
            by = utils.determine_columns_or_rows(self.impl.arg1_input)
        elif by is None:
            raise ValueError(
                "Either provide a range in the form '1:3' or 'A:C', respectively, or provide by='column' or by='rows' as argument"
            )
        self.impl.group(by)

    def ungroup(self, by: str | None = None) -> None:
        """Ungroup rows or columns

        Args:
            by: "columns" or "rows". Figured out automatically if the range is defined as
                '1:3' or 'A:C', respectively.
        """
        if ":" in self.impl.arg1_input and by is None:
            by = utils.determine_columns_or_rows(self.impl.arg1_input)
        elif by is None:
            raise ValueError(
                "Either provide a range in the form '1:3' or 'A:C', respectively, or provide by='column' or by='rows' as argument"
            )
        self.impl.ungroup(by)

    def options(self, convert: Any = None, **options: Any) -> Range:
        """Allows you to set a converter and their options. Converters define how Excel
        Ranges and their values are being converted both during reading and writing
        operations. If no explicit converter is specified, the base converter is being
        applied, see `converters`.

        Args:
            convert: A converter, e.g. `dict`, `np.array`, `pd.DataFrame`,
                `pd.Series`, defaults to default converter.

        Keyword Args:
            ndim: Number of dimensions.
            numbers: Type of numbers, e.g. `int`.
            dates: E.g. `datetime.date`, defaults to `datetime.datetime`.
            empty: Transformation of empty cells.
            transpose: Transpose values.
            expand: One of `'table'`, `'down'`, `'right'`.
            chunksize: Number of rows per chunk when reading or writing large
                amounts of data, e.g. `10000`. Large ranges are chunked
                automatically (reads above 4,000,000 cells, writes above
                100,000 cells on desktop Excel and the remote engines); set
                `chunksize` explicitly to tune the row count, e.g. to prevent
                timeout, memory or payload-size issues, or `chunksize=None` to
                disable chunking. Works with all formats, including DataFrames,
                NumPy arrays, and list of lists.
            err_to_str: If `True`, will include cell errors such as `#N/A` as
                strings. By default, they will be converted to `None`.
                *New in version 0.28.0.*

        For converter-specific options, see `converters`.


        """
        options["convert"] = convert
        return Range(impl=self.impl, **options)

    @property
    def sheet(self) -> Sheet:
        """Returns the Sheet object to which the Range belongs.

        ```{versionadded} 0.9.0
        ```
        """
        return Sheet(impl=self.impl.sheet)

    def __len__(self) -> int:
        return len(self.impl)

    @property
    def count(self) -> int:
        """Returns the number of cells."""
        return len(self)

    @property
    def row(self) -> int:
        """Returns the number of the first row in the specified range. Read-only.

        ```{versionadded} 0.3.5
        ```
        """
        return self.impl.row

    @property
    def column(self) -> int:
        """Returns the number of the first column in the in the specified range. Read-only.

        ```{versionadded} 0.3.5
        ```
        """
        return self.impl.column

    @property
    def raw_value(self) -> Any:
        """Gets and sets the values directly as delivered from/accepted by the engine that
        s being used (`pywin32` or `appscript`) without going through any of
        xlwings' data cleaning/converting. This can be helpful if speed is an issue but
        naturally will be engine specific, i.e. might remove the cross-platform
        compatibility.
        """
        return self.impl.raw_value

    @raw_value.setter
    def raw_value(self, data: Any) -> None:
        self.impl.raw_value = data

    def clear_contents(self) -> None:
        """Clears the content of a Range but leaves the formatting."""
        return self.impl.clear_contents()

    def clear_formats(self) -> None:
        """Clears the format of a Range but leaves the content.

        ```{versionadded} 0.26.2
        ```
        """
        return self.impl.clear_formats()

    def clear(self) -> None:
        """Clears the content and the formatting of a Range."""
        return self.impl.clear()

    def sort(
        self,
        keys: int | Sequence[int],
        ascending: bool | Sequence[bool] = True,
        has_headers: bool = False,
    ) -> None:
        """Sort the rows of this rectangular range by one or more columns.

        Args:
            keys: One-based column positions within this range, in priority order.
            ascending: One direction for every key, or one boolean per key.
            has_headers: Whether to keep the first row in place as a header.

        The range is not expanded to adjacent data. Ranges intersecting an Excel table are not supported.

        Examples:
            ```python
            sheet["A1:D20"].sort([2, 1], [False, True], has_headers=True)
            ```
        """
        if isinstance(keys, bool):
            raise TypeError("keys must be one-based column positions")
        if isinstance(keys, int):
            normalized_keys = [keys]
        elif isinstance(keys, Sequence) and not isinstance(keys, (str, bytes)):
            normalized_keys = list(keys)
        else:
            raise TypeError("keys must be an integer or a sequence of integers")
        if not normalized_keys:
            raise ValueError("keys must contain at least one column")
        if any(
            not isinstance(key, int) or isinstance(key, bool) for key in normalized_keys
        ):
            raise TypeError("keys must contain only integers")
        if any(key < 1 or key > self.shape[1] for key in normalized_keys):
            raise ValueError("sort keys must be within the range's columns")
        if len(set(normalized_keys)) != len(normalized_keys):
            raise ValueError("sort keys must be unique")

        if isinstance(ascending, bool):
            normalized_ascending = [ascending] * len(normalized_keys)
        elif isinstance(ascending, Sequence) and not isinstance(
            ascending, (str, bytes)
        ):
            normalized_ascending = list(ascending)
            if len(normalized_ascending) != len(normalized_keys):
                raise ValueError("ascending must have one boolean per key")
            if any(
                not isinstance(direction, bool) for direction in normalized_ascending
            ):
                raise TypeError("ascending must contain only booleans")
        else:
            raise TypeError("ascending must be a boolean or a sequence of booleans")
        if not isinstance(has_headers, bool):
            raise TypeError("has_headers must be a boolean")
        if has_headers and self.shape[0] < 2:
            raise ValueError("a sort with headers needs at least two rows")

        for table in self.sheet.tables:
            table_range = table.range
            if table_range is None:
                continue
            if (
                self.row <= table_range.row + table_range.shape[0] - 1
                and table_range.row <= self.row + self.shape[0] - 1
                and self.column <= table_range.column + table_range.shape[1] - 1
                and table_range.column <= self.column + self.shape[1] - 1
            ):
                raise ValueError(
                    "Range.sort() does not support ranges intersecting a table"
                )

        self.impl.sort(normalized_keys, normalized_ascending, has_headers)

    def remove_duplicates(
        self, columns: int | Sequence[int], has_headers: bool = False
    ) -> None:
        """Remove duplicate rows within this range, keeping the first occurrence.

        Args:
            columns: One-based column positions within this range used to identify duplicates.
            has_headers: Keep the first row as a header.

        Only cells inside this range are shifted. Ranges intersecting an Excel table are not supported. On macOS this method isn't supported and raises `NotImplementedError`.
        """
        if isinstance(columns, bool):
            raise TypeError("columns must be one-based column positions")
        if isinstance(columns, int):
            normalized = [columns]
        elif isinstance(columns, Sequence) and not isinstance(columns, (str, bytes)):
            normalized = list(columns)
        else:
            raise TypeError("columns must be an integer or a sequence of integers")
        if not normalized:
            raise ValueError("columns must contain at least one column")
        if any(
            not isinstance(column, int) or isinstance(column, bool)
            for column in normalized
        ):
            raise TypeError("columns must contain only integers")
        if any(column < 1 or column > self.shape[1] for column in normalized):
            raise ValueError("columns must be within the range's columns")
        if len(set(normalized)) != len(normalized):
            raise ValueError("columns must be unique")
        if not isinstance(has_headers, bool):
            raise TypeError("has_headers must be a boolean")
        if has_headers and self.shape[0] < 2:
            raise ValueError("duplicate removal with headers needs at least two rows")
        for table in self.sheet.tables:
            table_range = table.range
            if table_range is None:
                continue
            if (
                self.row < table_range.row + table_range.shape[0]
                and table_range.row < self.row + self.shape[0]
                and self.column < table_range.column + table_range.shape[1]
                and table_range.column < self.column + self.shape[1]
            ):
                raise ValueError(
                    "Range.remove_duplicates() does not support ranges intersecting a table"
                )
        self.impl.remove_duplicates(normalized, has_headers)

    def get_special_cells(
        self,
        cell_type: Literal["blanks", "constants", "formulas", "visible"],
        value_type: Literal["numbers", "text", "logical", "errors"] | None = None,
    ) -> list[Range] | Awaitable[list[Range]]:
        """Return the rectangular areas of matching cells within this range.

        `cell_type` is `"blanks"`, `"constants"`, `"formulas"`, or `"visible"`. For constants or formulas, `value_type` may be `"numbers"`, `"text"`, `"logical"`, or `"errors"`; omitting it selects all value types. Returns an empty list when no cells match. Desktop Python returns the list directly; in xlwings Lite use `await range.get_special_cells(...)`.
        """
        if not isinstance(cell_type, str):
            raise TypeError("cell_type must be a string")
        if cell_type not in ("blanks", "constants", "formulas", "visible"):
            raise ValueError(
                "cell_type must be 'blanks', 'constants', 'formulas', or 'visible'"
            )
        if value_type is not None:
            if not isinstance(value_type, str):
                raise TypeError("value_type must be a string or None")
            if cell_type not in ("constants", "formulas"):
                raise ValueError(
                    "value_type is only supported for constants and formulas"
                )
            if value_type not in ("numbers", "text", "logical", "errors"):
                raise ValueError(
                    "value_type must be 'numbers', 'text', 'logical', or 'errors'"
                )
        areas = self.impl.get_special_cells(cell_type, value_type)
        if inspect.isawaitable(areas):

            async def await_areas() -> list[Range]:
                return [Range(impl=area) for area in await areas]

            return await_areas()
        return [Range(impl=area) for area in areas]

    def find(
        self,
        text: str,
        *,
        whole: bool = False,
        direction: str = "forward",
        order: str = "rows",
        match_case: bool = False,
    ) -> Range | None | Awaitable[Range | None]:
        """Find the first matching cell in this range, or return `None`.

        Classic xlwings returns the result directly. In xlwings Lite, await the result because Excel must be queried asynchronously. The search starts at the first cell in the requested traversal direction and is restricted to this range.

        Args:
            text: Text to find. An empty string is not allowed.
            whole: Match the entire cell rather than part of it.
            direction: `"forward"` or `"backward"`.
            order: Search by `"rows"` or `"columns"`.
            match_case: Whether matching is case-sensitive.

        Examples:
            In desktop Python:

            ```python
            import xlwings as xw

            sheet = xw.Book().sheets[0]
            sheet["A1:A3"].value = [["North"], ["South"], ["North"]]
            found = sheet["A1:A3"].find("South", whole=True)
            print(found.address if found else None)  # $A$2
            ```

            In xlwings Lite, await the same search:

            ```python
            found = await sheet["A1:A3"].find("South", whole=True)
            ```
        """
        if not isinstance(text, str):
            raise TypeError("text must be a string")
        if not text:
            raise ValueError("text must not be empty")
        for name, value in (("whole", whole), ("match_case", match_case)):
            if not isinstance(value, bool):
                raise TypeError(f"{name} must be a boolean")
        if direction not in ("forward", "backward"):
            raise ValueError("direction must be 'forward' or 'backward'")
        if order not in ("rows", "columns"):
            raise ValueError("order must be 'rows' or 'columns'")

        found = self.impl.find(text, whole, direction, order, match_case)
        if inspect.isawaitable(found):

            async def await_found() -> Range | None:
                impl = await found
                return Range(impl=impl) if impl is not None else None

            return await_found()
        return Range(impl=found) if found is not None else None

    def replace_all(
        self,
        old: str,
        new: str,
        *,
        whole: bool = False,
        match_case: bool = False,
    ) -> None:
        """Replace matching text within this range.

        An empty replacement string is allowed; an empty search string is not.

        Examples:
            ```python
            import xlwings as xw

            sheet = xw.Book().sheets[0]
            sheet["A1:A2"].value = [["Draft"], ["Draft report"]]
            sheet["A1:A2"].replace_all("Draft", "Final")
            print(sheet["A2"].value)  # Final report
            ```
        """
        if not isinstance(old, str) or not isinstance(new, str):
            raise TypeError("old and new must be strings")
        if not old:
            raise ValueError("old must not be empty")
        for name, value in (("whole", whole), ("match_case", match_case)):
            if not isinstance(value, bool):
                raise TypeError(f"{name} must be a boolean")
        self.impl.replace_all(old, new, whole, match_case)

    @property
    def has_array(self) -> bool:
        """`True` if the range is part of a legacy CSE Array formula
        and `False` otherwise.
        """
        return self.impl.has_array

    def end(self, direction: str) -> Range:
        """Returns a Range object that represents the cell at the end of the region that
        contains the source range. Equivalent to pressing Ctrl+Up, Ctrl+down,
        Ctrl+left, or Ctrl+right.

        Args:
            direction:

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = xw.sheets[0]
            >>> sheet1.range('A1:B2').value = 1
            >>> sheet1.range('A1').end('down')
            <Range [Book1]Sheet1!$A$2>
            >>> sheet1.range('B2').end('right')
            <Range [Book1]Sheet1!$B$2>
            ```

        ```{versionadded} 0.9.0
        ```
        """
        return Range(impl=self.impl.end(direction))

    @property
    def formula(self) -> str | list[str] | list[list[str]]:
        """Gets or sets the formula for the given Range."""
        return self.impl.formula

    @formula.setter
    def formula(self, value: str | list[str] | list[list[str]]) -> None:
        self.impl.formula = value

    @property
    def formula2(self) -> str | list[str] | list[list[str]]:
        """Gets or sets the formula2 for the given Range."""
        return self.impl.formula2

    @formula2.setter
    def formula2(self, value: str | list[str] | list[list[str]]) -> None:
        self.impl.formula2 = value

    @property
    def formula_array(self) -> str | None:
        """Gets or sets an  array formula for the given Range.

        ```{versionadded} 0.7.1
        ```
        """
        return self.impl.formula_array

    @formula_array.setter
    def formula_array(self, value: str) -> None:
        self.impl.formula_array = value

    @property
    def font(self) -> Font:
        return Font(impl=self.impl.font)

    @property
    def borders(self) -> Borders:
        """Returns the {class}`Borders <xlwings.main.Borders>` collection of the
        range, which gives access to the eight individual
        {class}`Border <xlwings.main.Border>` sides.

        Examples:
            ```pycon
            >>> myrange = sheet["A1:D10"]
            >>> myrange.borders.line_style = "continuous"  # edges + inside borders
            >>> myrange.borders["edge_bottom"].weight = "thick"
            >>> myrange.borders.set("outside", line_style="double", color="#ff0000")
            >>> myrange.borders.clear()
            ```

        ```{versionadded} 0.37.1
        ```
        """
        return Borders(impl=self.impl.borders)

    @property
    def data_validation(self) -> DataValidation:
        """Returns the data validation object for the range.

        Use it to create, replace, or remove a validation rule. On xlwings Lite,
        use {meth}`Range.get_data_validation` instead.

        Examples:
            ```python
            sheet["A1:A10"].data_validation.set_list(["Open", "Closed"])
            sheet["B1:B10"].data_validation.set_list(sheet["D1:D3"])
            sheet["C1:C10"].data_validation.set_list(book.names["Statuses"])
            sheet["E1:E10"].data_validation.set_whole_number("between", 1, 10)
            sheet["F1:F10"].data_validation.set_custom("=F1<>\"\"")
            sheet["A1:A10"].data_validation.delete()
            ```

        ```{versionadded} 0.37.5
        ```
        """
        return DataValidation(impl=self.impl.data_validation, parent=self)

    @property
    def autofilter(self) -> AutoFilter:
        """Returns the AutoFilter for this range.

        The first row is treated as the header row and `field` arguments are one-based column positions relative to the range.

        Examples:
            ```python
            data = sheet["A1:C100"]
            data.autofilter.apply_values(1, ["East", "West"])
            data.autofilter.apply_comparison(3, "greater_than_or_equal", 10)
            data.autofilter.clear(1)
            data.autofilter.clear()
            ```

        ```{versionadded} 0.37.5
        ```
        """
        return AutoFilter(impl=self.impl.autofilter, parent=self)

    @property
    def conditional_formats(self) -> ConditionalFormats:
        """Returns the conditional-format rules for this range.

        In xlwings Lite, use
        `await sheet["A1:D10"].get_conditional_formats()` for inspection;
        `sheet["A1:D10"].conditional_formats.clear()` remains available.

        ```{versionadded} 0.37.5
        ```
        """
        return ConditionalFormats(impl=self.impl.conditional_formats)

    @property
    def characters(self) -> Characters:
        return Characters(impl=self.impl.characters)

    @property
    def column_width(self) -> float | None:
        """Gets or sets the width of a Range.

        The unit depends on the engine: **characters** on the classic, locally
        installed xlwings, where one unit is the width of one character in the
        Normal style (for proportional fonts, the character 0), and **points**
        on xlwings Server and xlwings Lite.

        If all columns in the Range have the same width, returns the width.
        If columns in the Range have different widths, returns None.

        In characters, column_width must be in the range 0 <= column_width <=
        255. In points it only has to be positive.

        Note: If the Range is outside the used range of the Worksheet, and columns in
        the Range have different widths, returns the width of the first column.

        ```{versionadded} 0.4.0
        ```
        """
        return self.impl.column_width

    @column_width.setter
    def column_width(self, value: float) -> None:
        self.impl.column_width = value

    @property
    def row_height(self) -> float | None:
        """Gets or sets the height, in points, of a Range.
        If all rows in the Range have the same height, returns the height.
        If rows in the Range have different heights, returns None.

        row_height must be in the range:
        0 <= row_height <= 409.5

        Note: If the Range is outside the used range of the Worksheet, and rows in the
        Range have different heights, returns the height of the first row.

        ```{versionadded} 0.4.0
        ```
        """
        return self.impl.row_height

    @row_height.setter
    def row_height(self, value: float) -> None:
        self.impl.row_height = value

    @property
    def width(self) -> float:
        """Returns the width, in points, of a Range. Read-only.

        ```{versionadded} 0.4.0
        ```
        """
        return self.impl.width

    @property
    def height(self) -> float:
        """Returns the height, in points, of a Range. Read-only.

        ```{versionadded} 0.4.0
        ```
        """
        return self.impl.height

    @property
    def left(self) -> float:
        """Returns the distance, in points, from the left edge of column A to the left
        edge of the range. Read-only.

        ```{versionadded} 0.6.0
        ```
        """
        return self.impl.left

    @property
    def top(self) -> float:
        """Returns the distance, in points, from the top edge of row 1 to the top edge of
        the range. Read-only.

        ```{versionadded} 0.6.0
        ```
        """
        return self.impl.top

    @property
    def number_format(self) -> str:
        """Gets and sets the number_format of a Range.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = wb.sheets[0]
            >>> sheet1.range('A1').number_format
            'General'
            >>> sheet1.range('A1:C3').number_format = '0.00%'
            >>> sheet1.range('A1:C3').number_format
            '0.00%'
            ```

        ```{versionadded} 0.2.3
        ```
        """
        return self.impl.number_format

    @number_format.setter
    def number_format(self, value: str) -> None:
        self.impl.number_format = value

    def get_address(
        self,
        row_absolute: bool = True,
        column_absolute: bool = True,
        include_sheetname: bool = False,
        external: bool = False,
    ) -> str:
        """Returns the address of the range in the specified format. `address` can be
        used instead if none of the defaults need to be changed.

        Args:
            row_absolute: Set to True to return the row part of the reference as an absolute
                reference.

            column_absolute: Set to True to return the column part of the reference as an absolute
                reference.

            include_sheetname: Set to True to include the Sheet name in the address. Ignored if
                external=True.

            external: Set to True to return an external reference with workbook and worksheet
                name.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = wb.sheets[0]
            >>> sheet1.range((1,1)).get_address()
            '$A$1'
            >>> sheet1.range((1,1)).get_address(False, False)
            'A1'
            >>> sheet1.range((1,1), (3,3)).get_address(True, False, True)
            'Sheet1!A$1:C$3'
            >>> sheet1.range((1,1), (3,3)).get_address(True, False, external=True)
            '[Book1]Sheet1!A$1:C$3'
            ```

        ```{versionadded} 0.2.3
        ```
        """

        if include_sheetname and not external:
            # TODO: when the Workbook name contains spaces but not the Worksheet name,
            #  it will still be surrounded
            # by '' when include_sheetname=True. Also, should probably changed to regex
            temp_str = self.impl.get_address(row_absolute, column_absolute, True)

            if temp_str.find("[") > -1:
                results_address = temp_str[temp_str.rfind("]") + 1 :]
                if results_address.find("'") > -1:
                    results_address = "'" + results_address
                return results_address
            else:
                return temp_str

        else:
            return self.impl.get_address(row_absolute, column_absolute, external)

    @property
    def address(self) -> str:
        """Returns a string value that represents the range reference.
        Use `get_address()` to be able to provide parameters.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.address

    @property
    def current_region(self) -> Range:
        """This property returns a Range object representing a range bounded by (but not
        including) any combination of blank rows and blank columns or the edges of the
        worksheet. It corresponds to `Ctrl-*` on Windows and `Shift-Ctrl-Space` on
        Mac.
        """

        return Range(impl=self.impl.current_region)

    def autofit(self) -> None:
        """Autofits the width and height of all cells in the range.

        * To autofit only the width of the columns use
          `myrange.columns.autofit()`
        * To autofit only the height of the rows use
          `myrange.rows.autofit()`

        ```{versionchanged} 0.9.0
        ```
        """
        return self.impl.autofit()

    @property
    def color(self) -> tuple[int, int, int] | None:
        """Gets and sets the background color of the specified Range.

        To set the color, either use an RGB tuple `(0, 0, 0)` or a hex string
        like `#efefef` or an Excel color constant.
        To remove the background, set the color to `None`, see Examples.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = xw.sheets[0]
            >>> sheet1.range('A1').color = (255, 255, 255)  # or '#ffffff'
            >>> sheet1.range('A2').color
            (255, 255, 255)
            >>> sheet1.range('A2').color = None
            >>> sheet1.range('A2').color is None
            True
            ```

            ```{versionadded} 0.3.0
            ```
        """
        return self.impl.color

    @color.setter
    def color(self, color_or_rgb: tuple[int, int, int] | int | str | None) -> None:
        self.impl.color = color_or_rgb

    @property
    def name(self) -> Name | None:
        """Sets or gets the name of a Range.

        ```{versionadded} 0.4.0
        ```
        """
        impl = self.impl.name
        return impl and Name(impl=impl)

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    def __call__(self, *args: int) -> Range:
        return Range(impl=self.impl(*args))

    @property
    def rows(self) -> RangeRows:
        """Returns a `RangeRows` object that represents the rows in the specified
        range.

        ```{versionadded} 0.9.0
        ```
        """
        return RangeRows(self)

    @property
    def columns(self) -> RangeColumns:
        """Returns a `RangeColumns` object that represents the columns in the
        specified range.

        ```{versionadded} 0.9.0
        ```
        """
        return RangeColumns(self)

    @property
    def shape(self) -> tuple[int, int]:
        """Tuple of Range dimensions.

        ```{versionadded} 0.3.0
        ```
        """
        return self.impl.shape

    @property
    def size(self) -> int:
        """Number of elements in the Range.

        ```{versionadded} 0.3.0
        ```
        """
        a, b = self.shape
        return a * b

    @property
    def value(self) -> Any:
        """Gets and sets the values for the given Range. See `xlwings.Range.options`
        about how to set options, e.g., to transform it into a DataFrame or how to set
        a chunksize.
        """
        return conversion.read(self, None, self._options)

    @value.setter
    def value(self, data: Any) -> None:
        conversion.write(data, self, self._options)

    async def get_value(self) -> Any:
        """Fetch values on demand.

        Requires xlwings Lite.
        """
        return await conversion.async_read(
            self,
            None,
            self._options,
            pipeline_overrides=self._impl.get_async_pipeline_overrides(self._options),
        )

    async def get_formula(self) -> str | list[str] | list[list[str]]:
        """Fetch formulas on demand.

        The returned shape follows the same rules as reading `value`: a single
        cell gives a string, a 1-by-n or n-by-1 range a flat list, and anything
        else a nested list. `options(ndim=...)` applies as usual.

        Requires xlwings Lite.
        """
        # Prevent circular imports
        from .conversion.framework import ConversionContext
        from .conversion.standard import AdjustDimensionsStage

        # Reuse the stage that `.value` reads go through, so the shape rules
        # (and `ndim`) stay in one place.
        c = ConversionContext(rng=self, value=await self._impl.get_formula())
        AdjustDimensionsStage(self._options)(c)
        return c.value

    async def get_formula_array(self) -> str | None:
        """Fetch the array formula for this range on demand.

        A single string, or `None` if the range holds no array formula. Unlike
        `get_formula()`, this isn't a value per cell.

        Requires xlwings Lite.
        """
        return await self._impl.get_formula_array()

    async def get_number_format(self) -> str | None:
        """Fetch the number format on demand.

        A single format string, or `None` if the range's cells don't share one.

        Requires xlwings Lite.
        """
        return await self._impl.get_number_format()

    async def get_color(self) -> tuple[int, int, int] | None:
        """Fetch the fill color on demand, as an RGB tuple.

        Returns `None` if the range has no fill.

        Requires xlwings Lite.
        """
        return await self._impl.get_color()

    async def get_colors(self) -> list[list[tuple[int, int, int] | None]]:
        """Returns the fill color of every cell as a two-dimensional list.

        Each entry is an RGB tuple, or `None` for no fill color. The result always has the range's row and column dimensions, including `[[color]]` for a single cell; conversion options such as `ndim` and `transpose` do not affect it.

        Reads direct cell fills, excluding colors supplied by conditional formatting or table styles. For patterned fills, returns the background fill color, not the pattern color or rendered appearance.

        A call supports at most 100,000 cells.

        Examples:
            ```python
            colors = await sheet["A1:B2"].get_colors()
            # [[(255, 0, 0), None], [(255, 255, 255), (0, 0, 255)]]
            ```

        See {meth}`get_color <xlwings.Range.get_color>` for a single range-level fill color.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        return await self._impl.get_colors()

    def set_colors(
        self,
        colors: Sequence[
            Sequence[tuple[int, int, int] | list[int] | int | str | None | EllipsisType]
        ],
    ) -> None:
        """Set direct fill colors cell by cell without changing cell contents.

        `colors` must be a two-dimensional matrix exactly matching the range's shape, including `[[color]]` for one cell. An RGB tuple or list or a `#RRGGBB` hex string. `None` removes the fill; `...` leaves that cell's existing fill unchanged. Conversion options do not change the required matrix shape.

        Examples:

            ```python
            sheet["A1:C1"].set_colors([[(0, 128, 0), ..., None]])
            ```

        ```{versionadded} 0.37.5
        ```
        """
        # The remote engine represents a non-cell selection (such as a Shape)
        # with arg1=None. Other range mutations no-op through append_json_action.
        if getattr(self._impl, "arg1", ...) is None:
            return
        rows, columns = self.shape
        if rows * columns > 10_000:
            raise ValueError(
                "Range.set_colors() supports at most 10,000 cells per call"
            )
        if (
            not isinstance(colors, Sequence)
            or isinstance(colors, (str, bytes))
            or len(colors) != rows
        ):
            raise ValueError(f"Expected {rows} rows of colors")

        normalized = []
        has_changes = False
        for row_index, row in enumerate(colors):
            if (
                not isinstance(row, Sequence)
                or isinstance(row, (str, bytes))
                or len(row) != columns
            ):
                raise ValueError(f"Expected {columns} colors in row {row_index + 1}")
            normalized_row = []
            for column_index, color in enumerate(row):
                if color is ...:
                    normalized_row.append(...)
                    continue
                has_changes = True
                if color is None:
                    normalized_row.append(None)
                    continue
                if isinstance(color, str):
                    if re.fullmatch(r"#?[0-9a-fA-F]{6}", color) is None:
                        raise ValueError(
                            f"Invalid color at ({row_index + 1}, {column_index + 1})"
                        )
                    normalized_row.append(utils.hex_to_rgb(color))
                elif isinstance(color, int) and not isinstance(color, bool):
                    if not 0 <= color <= 0xFFFFFF:
                        raise ValueError(
                            f"Invalid color at ({row_index + 1}, {column_index + 1})"
                        )
                    normalized_row.append(utils.int_to_rgb(color))
                elif (
                    isinstance(color, (tuple, list))
                    and len(color) == 3
                    and all(
                        isinstance(component, int)
                        and not isinstance(component, bool)
                        and 0 <= component <= 255
                        for component in color
                    )
                ):
                    normalized_row.append(tuple(color))
                else:
                    raise ValueError(
                        f"Invalid color at ({row_index + 1}, {column_index + 1})"
                    )
            normalized.append(normalized_row)

        if not has_changes:
            return
        self._impl.set_colors(normalized)

    async def get_conditional_formats(self) -> ConditionalFormats:
        """Fetch the ordered conditional-format rules on demand.

        Rules are returned from highest to lowest evaluation priority. Requires
        xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        return ConditionalFormats(impl=await self._impl.get_conditional_formats())

    async def get_wrap_text(self) -> bool | None:
        """Fetch the wrap text setting on demand.

        `None` if the range doesn't have a uniform wrap setting.

        Requires xlwings Lite.
        """
        return await self._impl.get_wrap_text()

    async def get_horizontal_alignment(self) -> HorizontalAlignment | None:
        """Fetch the horizontal alignment on demand.

        `None` if the cells in the range don't all have the same alignment.

        Requires xlwings Lite.
        """
        return await self._impl.get_horizontal_alignment()

    async def get_vertical_alignment(self) -> VerticalAlignment | None:
        """Fetch the vertical alignment on demand.

        `None` if the cells in the range don't all have the same alignment.

        Requires xlwings Lite.
        """
        return await self._impl.get_vertical_alignment()

    async def get_column_width(self) -> float | None:
        """Fetch the column width on demand, in points.

        Returns `None` if the range's columns aren't all the same width.

        Requires xlwings Lite.
        """
        return await self._impl.get_column_width()

    async def get_row_height(self) -> float | None:
        """Fetch the row height on demand, in points.

        Returns `None` if the range's rows aren't all the same height.

        Requires xlwings Lite.
        """
        return await self._impl.get_row_height()

    async def get_left(self) -> float:
        """Fetch the distance from the sheet's left edge, in points, on demand.

        Requires xlwings Lite.
        """
        return await self._impl.get_left()

    async def get_top(self) -> float:
        """Fetch the distance from the sheet's top edge, in points, on demand.

        Requires xlwings Lite.
        """
        return await self._impl.get_top()

    async def get_width(self) -> float:
        """Fetch the range's width in points, on demand.

        Requires xlwings Lite.
        """
        return await self._impl.get_width()

    async def get_height(self) -> float:
        """Fetch the range's height in points, on demand.

        Requires xlwings Lite.
        """
        return await self._impl.get_height()

    async def get_hyperlink(self) -> str:
        """Fetch this cell's hyperlink address on demand.

        The async equivalent of `hyperlink`: same result, including for cells
        that use a `HYPERLINK()` formula. Raises if the cell has no hyperlink.

        Requires xlwings Lite.
        """
        formula = await self.get_formula()
        if isinstance(formula, str) and formula.lower().startswith("="):
            # A HYPERLINK() formula keeps its target in the formula string
            # rather than in the cell's hyperlink object.
            match = re.compile(r"\"(.+?)\"").search(formula)
            if match is None:
                raise Exception("The cell doesn't seem to contain a hyperlink!")
            return match.group(1)
        address = await self._impl.get_hyperlink()
        if address is None:
            # The desktop engines raise rather than returning nothing.
            raise Exception("The cell doesn't seem to contain a hyperlink!")
        return address

    async def get_current_region(self) -> Range:
        """Fetch the current region on demand.

        The region bounded by blank rows and columns around this range, i.e.
        `Ctrl-*`.

        Requires xlwings Lite.
        """
        return Range(impl=await self._impl.get_current_region())

    async def get_merge_area(self) -> Range:
        """Fetch the merged range containing this cell, on demand.

        Returns this range itself if it isn't part of a merged range.

        Requires xlwings Lite.
        """
        return Range(impl=await self._impl.get_merge_area())

    async def get_merge_cells(self) -> bool | None:
        """Fetch whether this range contains merged cells, on demand.

        `True` if the whole range is merged, `False` if none of it is, and
        `None` if it's only partly merged.

        Requires xlwings Lite.
        """
        return await self._impl.get_merge_cells()

    async def get_table(self) -> Table | None:
        """Fetch the Table this range is part of, on demand.

        Returns `None` if the range isn't part of a table.

        Requires xlwings Lite.
        """
        impl = await self._impl.get_table()
        return Table(impl=impl) if impl else None

    async def get_data_validation(self) -> DataValidation:
        """Fetch this range's data-validation rule for the range.

        Returns ``"none"`` when the range has no validation,
        ``"mixed_criteria"`` when only some cells have validation, and
        ``"inconsistent"`` when cells have different rules.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        return DataValidation(impl=await self._impl.get_data_validation(), parent=self)

    def expand(self, mode: str = "table") -> Range:
        """Expands the range according to the mode provided. Ignores empty top-left cells
        (unlike `Range.end()`).

        Args:
            mode: One of `'table'` (=down and right), `'down'`, `'right'`.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = wb.sheets[0]
            >>> sheet1.range('A1').value = [[None, 1], [2, 3]]
            >>> sheet1.range('A1').expand().address
            $A$1:$B$2
            >>> sheet1.range('A1').expand('right').address
            $A$1:$B$1
            ```

        ```{versionadded} 0.9.0
        ```
        """
        return expansion.expanders.get(mode, mode).expand(self)

    def __getitem__(self, key: tuple[int | slice, int | slice] | int | slice) -> Range:
        if type(key) is tuple:
            row, col = key

            n = self.shape[0]
            if isinstance(row, slice):
                row1, row2, step = row.indices(n)
                if step != 1:
                    raise ValueError("Slice steps not supported.")
                row2 -= 1
            elif isinstance(row, int):
                if row < 0:
                    row += n
                if row < 0 or row >= n:
                    raise IndexError("Row index %s out of range (%s rows)." % (row, n))
                row1 = row2 = row
            else:
                raise TypeError(
                    "Row indices must be integers or slices, not %s"
                    % type(row).__name__
                )

            n = self.shape[1]
            if isinstance(col, slice):
                col1, col2, step = col.indices(n)
                if step != 1:
                    raise ValueError("Slice steps not supported.")
                col2 -= 1
            elif isinstance(col, int):
                if col < 0:
                    col += n
                if col < 0 or col >= n:
                    raise IndexError(
                        "Column index %s out of range (%s columns)." % (col, n)
                    )
                col1 = col2 = col
            else:
                raise TypeError(
                    "Column indices must be integers or slices, not %s"
                    % type(col).__name__
                )

            return self.sheet.range(
                (
                    self.row + row1,
                    self.column + col1,
                    max(0, row2 - row1 + 1),
                    max(0, col2 - col1 + 1),
                )
            )

        elif isinstance(key, slice):
            if self.shape[0] > 1 and self.shape[1] > 1:
                raise IndexError(
                    "One-dimensional slicing is not allowed on two-dimensional ranges"
                )

            if self.shape[0] > 1:
                return self[key, :]
            else:
                return self[:, key]

        elif isinstance(key, int):
            n = len(self)
            k = key + n if key < 0 else key
            if k < 0 or k >= n:
                raise IndexError("Index %s out of range (%s elements)." % (key, n))
            else:
                return self(k + 1)

        else:
            raise TypeError(
                "Cell indices must be integers or slices, not %s" % type(key).__name__
            )

    def __repr__(self) -> str:
        return "<Range [{1}]{0}!{2}>".format(
            self.sheet.name, self.sheet.book.name, self.address
        )

    def insert(
        self, shift: str, copy_origin: str = "format_from_left_or_above"
    ) -> None:
        """Insert a cell or range of cells into the sheet.

        Args:
            shift: Use `right` or `down`.
            copy_origin: Use `format_from_left_or_above` or `format_from_right_or_below`.
                Note that copy_origin is only supported on Windows.

        ```{versionchanged} 0.30.3
        `shift` is now a required argument.
        ```
        """
        self.impl.insert(shift, copy_origin)

    def delete(self, shift: str | None = None) -> None:
        """Deletes a cell or range of cells.

        Args:
            shift: Use `left` or `up`. If omitted, Excel decides based on the shape of
                the range.
        """
        self.impl.delete(shift)

    def copy(self, destination: Range | None = None) -> None:
        """Copy a range to a destination range or clipboard.

        Args:
            destination: xlwings Range to which the specified range will be copied.
                If omitted, the range is copied to the clipboard.
        """
        self.impl.copy(destination)

    def copy_from(
        self,
        source_range: Range,
        copy_type: str = "all",
        skip_blanks: bool = False,
        transpose: bool = False,
    ) -> None:
        """A newer variant of copy that replaces copy/paste.

        Args:
            source_range
            copy_type: One of "all", "formats", "formulas", "link", "values"
            skip_blanks
            transpose
        """
        self.impl.copy_from(source_range, copy_type, skip_blanks, transpose)

    def paste(
        self,
        paste: str | None = None,
        operation: str | None = None,
        skip_blanks: bool = False,
        transpose: bool = False,
    ) -> None:
        """Pastes a range from the clipboard into the specified range.

        Args:
            paste: One of `all_merging_conditional_formats`, `all`, `all_except_borders`,
                `all_using_source_theme`, `column_widths`, `comments`, `formats`,
                `formulas`, `formulas_and_number_formats`, `validation`, `values`,
                `values_and_number_formats`.
            operation: One of "add", "divide", "multiply", "subtract".
            skip_blanks: Set to `True` to skip over blank cells
            transpose: Set to `True` to transpose rows and columns.
        """
        self.impl.paste(
            paste=paste,
            operation=operation,
            skip_blanks=skip_blanks,
            transpose=transpose,
        )

    @property
    def hyperlink(self) -> str:
        """Returns the hyperlink address of the specified Range (single Cell only)

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = wb.sheets[0]
            >>> sheet1.range('A1').value
            'www.xlwings.org'
            >>> sheet1.range('A1').hyperlink
            'http://www.xlwings.org'
            ```

        ```{versionadded} 0.3.0
        ```
        """
        if self.formula.lower().startswith("="):
            # If it's a formula, extract the URL from the formula string
            formula = self.formula
            try:
                return re.compile(r"\"(.+?)\"").search(formula).group(1)
            except AttributeError:
                raise Exception("The cell doesn't seem to contain a hyperlink!")
        else:
            # If it has been set pragmatically
            return self.impl.hyperlink

    def add_hyperlink(
        self,
        address: str,
        text_to_display: str | None = None,
        screen_tip: str | None = None,
    ) -> None:
        """Adds a hyperlink to the specified Range (single Cell)

        Args:
            address: The address of the hyperlink.
            text_to_display: The text to be displayed for the hyperlink. Defaults to the hyperlink
                address.
            screen_tip: The screen tip to be displayed when the mouse pointer is paused over the
                hyperlink. Default is set to '<address> - Click once to follow. Click and
                hold to select this cell.'

        ```{versionadded} 0.3.0
        ```
        """
        if text_to_display is None:
            text_to_display = address
        if address[:4] == "www.":
            address = "http://" + address
        if screen_tip is None:
            screen_tip = (
                address + " - Click once to follow. Click and hold to select this cell."
            )
        self.impl.add_hyperlink(address, text_to_display, screen_tip)

    def resize(
        self, row_size: int | None = None, column_size: int | None = None
    ) -> Range:
        """Resizes the specified Range

        Args:
            row_size: The number of rows in the new range (if None, the number of rows
                in the range is unchanged).
            column_size: The number of columns in the new range (if None, the number of
                columns in the range is unchanged).

        ```{versionadded} 0.3.0
        ```
        """

        if row_size is not None:
            assert row_size > 0
        else:
            row_size = self.shape[0]
        if column_size is not None:
            assert column_size > 0
        else:
            column_size = self.shape[1]

        return Range(self(1, 1), self(row_size, column_size)).options(**self._options)

    def offset(self, row_offset: int = 0, column_offset: int = 0) -> Range:
        """Returns a Range object that represents a Range that's offset from the
        specified range.

        ```{versionadded} 0.3.0
        ```
        """
        return Range(
            self(row_offset + 1, column_offset + 1),
            self(row_offset + self.shape[0], column_offset + self.shape[1]),
        ).options(**self._options)

    @property
    def last_cell(self) -> Range:
        """Returns the bottom right cell of the specified range. Read-only.

        Example:
            ```pycon
            >>> import xlwings as xw
            >>> wb = xw.Book()
            >>> sheet1 = wb.sheets[0]
            >>> myrange = sheet1.range('A1:E4')
            >>> myrange.last_cell.row, myrange.last_cell.column
            (4, 5)
            ```

        ```{versionadded} 0.3.5
        ```
        """
        return self(self.shape[0], self.shape[1]).options(**self._options)

    def select(self) -> None:
        """Selects the range. Select only works on the active book.

        ```{versionadded} 0.9.0
        ```
        """
        self.impl.select()

    @property
    def merge_area(self) -> Range:
        """Returns a Range object that represents the merged Range containing the
        specified cell. If the specified cell isn't in a merged range, this property
        returns the specified cell.
        """
        return Range(impl=self.impl.merge_area)

    @property
    def merge_cells(self) -> bool:
        """Returns `True` if the Range contains merged cells, otherwise `False`"""
        return self.impl.merge_cells

    def merge(self, across: bool = False) -> None:
        """Creates a merged cell from the specified Range object.

        Args:
            across: True to merge cells in each row of the specified Range as separate
                merged cells.
        """
        with self.sheet.book.app.properties(display_alerts=False):
            self.impl.merge(across)

    def unmerge(self) -> None:
        """Separates a merged area into individual cells."""
        self.impl.unmerge()

    @property
    def table(self) -> Table | None:
        """Returns a Table object if the range is part of one, otherwise `None`.

        ```{versionadded} 0.21.0
        ```
        """
        if self.impl.table:
            return Table(impl=self.impl.table)
        else:
            return None

    @property
    def wrap_text(self) -> bool | None:
        """Returns `True` if the wrap_text property is enabled and `False` if it's
        disabled. If not all cells have the same value in a range, on Windows it returns
        `None` and on macOS `False`.

        ```{versionadded} 0.23.2
        ```
        """
        return self.impl.wrap_text

    @wrap_text.setter
    def wrap_text(self, value: bool) -> None:
        self.impl.wrap_text = value

    @property
    def horizontal_alignment(self) -> HorizontalAlignment | None:
        """Returns or sets the horizontal alignment of the range.

        One of `'general'`, `'left'`, `'center'`, `'right'`, `'fill'`,
        `'justify'`, `'center_across_selection'` or `'distributed'`. Returns
        `None` if the cells in the range don't all have the same alignment.
        The default is `'general'`, which right-aligns numbers and dates and
        left-aligns text.

        Reading this property synchronously requires a locally installed Excel.
        Setting it is also supported on xlwings Lite
        and xlwings Server; in xlwings Lite, read it via
        {meth}`get_horizontal_alignment() <xlwings.Range.get_horizontal_alignment>`.

        Examples:
            ```pycon
            >>> sheet["A1"].horizontal_alignment = "center"
            >>> sheet["A1"].horizontal_alignment
            'center'
            ```

        ```{versionadded} 0.37.3
        ```
        """
        return self.impl.horizontal_alignment

    @horizontal_alignment.setter
    def horizontal_alignment(self, value: HorizontalAlignment) -> None:
        self.impl.horizontal_alignment = _horizontal_alignment(value)

    @property
    def vertical_alignment(self) -> VerticalAlignment | None:
        """Returns or sets the vertical alignment of the range.

        One of `'top'`, `'center'`, `'bottom'`, `'justify'` or `'distributed'`.
        Returns `None` if the cells in the range don't all have the same
        alignment. The default is `'bottom'`.

        Reading this property synchronously requires a locally installed Excel.
        Setting it is alos supported with xlwings Lite
        and xlwings Server; in xlwings Lite, read it via
        {meth}`get_vertical_alignment() <xlwings.Range.get_vertical_alignment>`.

        Examples:
            ```pycon
            >>> sheet["A1"].vertical_alignment = "top"
            >>> sheet["A1"].vertical_alignment
            'top'
            ```

        ```{versionadded} 0.37.3
        ```
        """
        return self.impl.vertical_alignment

    @vertical_alignment.setter
    def vertical_alignment(self, value: VerticalAlignment) -> None:
        self.impl.vertical_alignment = _vertical_alignment(value)

    @property
    def note(self) -> Note | None:
        """Returns a Note object.
        Before the introduction of threaded comments, a Note was called a Comment.

        ```{versionadded} 0.24.2
        ```
        """
        return Note(impl=self.impl.note) if self.impl.note else None

    def add_note(self, text: str) -> Note:
        """Add a note to this single cell and return it.

        Raises `TypeError` for non-text content and `ValueError` for empty text, a multi-cell range, or a cell that already has a note.
        """
        if not isinstance(text, str):
            raise TypeError("Note text must be a string")
        if not text:
            raise ValueError("Note text must not be empty")
        if self.shape != (1, 1):
            raise ValueError("A note can only be added to a single cell")
        if self.note is not None:
            raise ValueError("This cell already has a note")
        return Note(impl=self.impl.add_note(text))

    @property
    def comment(self) -> Comment | None:
        """The cell's threaded comment. In xlwings Lite, use `await get_comment()`."""
        if self.shape != (1, 1):
            raise ValueError("A comment location must be a single cell")
        impl = self.impl.comment
        return Comment(impl=impl) if impl is not None else None

    async def get_comment(self) -> Comment | None:
        """Fetch the cell's threaded comment, or `None`.

        Requires xlwings Lite.
        """
        if self.shape != (1, 1):
            raise ValueError("A comment location must be a single cell")
        impl = await self.impl.get_comment()
        return Comment(impl=impl) if impl is not None else None

    def add_comment(self, text: str) -> Comment:
        """Add a plain-text threaded comment to one cell and return its handle.

        Raises `TypeError` for non-text content and `ValueError` for empty text or a multi-cell range. Excel rejects a second comment on the same cell.
        """
        _validate_comment_text(text)
        if self.shape != (1, 1):
            raise ValueError("A comment can only be added to a single cell")
        return Comment(impl=self.impl.add_comment(text))

    def copy_picture(self, appearance: str = "screen", format: str = "picture") -> None:
        """Copies the range to the clipboard as picture.

        Args:
            appearance: Either 'screen' or 'printer'.
            format: Either 'picture' or 'bitmap'.

        ```{versionadded} 0.24.8
        ```
        """
        self.impl.copy_picture(appearance, format)

    def to_png(self, path: str | PathLike[str] | None = None) -> None:
        """Exports the range as PNG picture.

        Args:
            path: Path where you want to store the picture. Defaults to the name of the range
                in the same directory as the Excel file if the Excel file is stored and to
                the current working directory otherwise.

        ```{versionadded} 0.24.8
        ```
        """
        path = utils.fspath(path)
        if sys.platform == "emscripten":
            if path is None:
                raise ValueError("path is required in xlwings Lite")
            self.impl.to_png(path)
            return
        if not PIL and self.sheet.book.app.engine.name != "remote":
            raise XlwingsError("Range.to_png() requires an installation of Pillow.")
        if path is None:
            # TODO: factor this out as it's used in multiple locations
            directory, _ = os.path.split(self.sheet.book.fullname)
            default_name = (
                str(self)
                .replace("<", "")
                .replace(">", "")
                .replace(":", "_")
                .replace(" ", "")
            )
            if directory:
                path = os.path.join(directory, default_name + ".png")
            else:
                path = str(Path.cwd() / default_name) + ".png"
        self.impl.to_png(path)

    def to_pdf(
        self,
        path: str | PathLike[str] | None = None,
        layout: str | PathLike[str] | None = None,
        show: bool | None = None,
        quality: str = "standard",
    ) -> str:
        """Exports the range as PDF.

        Args:
            path: Path where you want to store the pdf. Defaults to the address of the range
                in the same directory as the Excel file if the Excel file is stored and to
                the current working directory otherwise.
            layout: This argument requires xlwings `PRO`.
                Path to a PDF file on which the report will be printed. This is ideal for
                headers and footers as well as borderless printing of graphics/artwork. The
                PDF file either needs to have only 1 page (every report page uses the same
                layout) or otherwise needs the same amount of pages as the report (each
                report page is printed on the respective page in the layout PDF).
            show: Once created, open the PDF file with the default application.
            quality: Quality of the PDF file. Can either be `'standard'` or `'minimum'`.

        ```{versionadded} 0.26.2
        ```
        """
        return utils.to_pdf(self, path=path, layout=layout, show=show, quality=quality)

    def autofill(self, destination: Range, type_: str = "fill_default") -> None:
        """Autofills the destination Range. Note that the destination Range must include
        the origin Range.

        Args:
            destination: The origin.

            type_: One of the following strings: `"fill_copy"`, `"fill_days"`,
                `"fill_default"`, `"fill_formats"`, `"fill_months"`,
                `"fill_series"`, `"fill_values"`, `"fill_weekdays"`, `"fill_years"`,
                `"growth_trend"`, `"linear_trend"`, `"flash_fill`

        ```{versionadded} 0.30.1
        ```
        """
        self.impl.autofill(destination=destination, type_=type_)


class AutoFilterCriteria:
    """The applied AutoFilter criterion for one field.

    Instances are read-only entries returned by {attr}`AutoFilter.criteria` and {meth}`AutoFilter.get_criteria`.

    ```{versionadded} 0.37.5
    ```
    """

    def __init__(self, impl: Mapping[str, Any]) -> None:
        self.impl = impl

    @property
    def field(self) -> int:
        """The one-based field position relative to the filtered range or table."""
        return int(self.impl["field"])

    @property
    def type(self) -> AutoFilterCriteriaType:
        """The normalized criterion type."""
        value = self.impl.get("type", "unknown")
        return cast(
            AutoFilterCriteriaType,
            value if value in AUTOFILTER_CRITERIA_TYPES else "unknown",
        )

    @property
    def values(self) -> list[str] | None:
        """The included values for a values filter, otherwise `None`."""
        values = self.impl.get("values")
        return list(values) if values is not None else None

    @property
    def operator(self) -> AutoFilterComparisonOperator | None:
        """The comparison operator, otherwise `None`."""
        value = self.impl.get("operator")
        return cast(
            AutoFilterComparisonOperator | None,
            value if value in AUTOFILTER_COMPARISON_OPERATORS else None,
        )

    @property
    def value1(self) -> str | None:
        """The first normalized comparison operand, otherwise `None`."""
        return self.impl.get("value1")

    @property
    def value2(self) -> str | None:
        """The second normalized comparison operand, otherwise `None`."""
        return self.impl.get("value2")

    @property
    def count(self) -> int | None:
        """The number of items for a top/bottom items filter, otherwise `None`.

        This may be `None` when the native desktop engine only exposes the calculated cutoff value rather than the requested item count.
        """
        return self.impl.get("count")

    @property
    def percent(self) -> float | None:
        """The percentage for a top/bottom percent filter, otherwise `None`.

        This may be `None` when the native desktop engine only exposes the calculated cutoff value rather than the requested percentage.
        """
        return self.impl.get("percent")


class AutoFilter:
    """An AutoFilter belonging to a range or table.

    Do not construct this class directly; access it through {attr}`Range.autofilter <xlwings.Range.autofilter>` or {attr}`Table.autofilter <xlwings.main.Table.autofilter>`.

    Fields are one-based column positions relative to the range or table. Value filters accept strings, finite numbers, and booleans. Comparison filters additionally accept Python dates and timezone-naive datetimes. Date and datetime values are not supported by `apply_values()`; to filter for a single exact date or datetime, use `apply_comparison()` with `"equal_to"`. Comparison operators are `"between"`, `"not_between"`, `"equal_to"`, `"not_equal_to"`, `"greater_than"`, `"less_than"`, `"greater_than_or_equal"`, and `"less_than_or_equal"`.

    Examples:
        ```python
        from datetime import date

        import xlwings as xw

        sheet = xw.Book().sheets[0]
        myrange = sheet["A1:C6"]
        myrange.value = [
            ["Region", "Order date", "Amount"],
            ["East", date(2025, 1, 1), 10],
            ["West", date(2025, 1, 2), 20],
            ["East", date(2025, 1, 3), 30],
            ["North", date(2025, 1, 1), 40],
            ["West", date(2025, 1, 4), 50],
        ]

        myrange.autofilter.apply_values(1, ["East", "West"])
        myrange.autofilter.apply_comparison(3, "between", 10, 20)
        # Use a comparison for an exact date instead of apply_values().
        myrange.autofilter.apply_comparison(2, "equal_to", date(2025, 1, 1))
        myrange.autofilter.apply_top_items(3, 2)
        myrange.autofilter.apply_comparison(2, "equal_to", None)
        myrange.autofilter.clear(2)
        myrange.autofilter.clear()
        ```

    ```{versionadded} 0.37.5
    ```
    """

    def __init__(self, impl: Any, parent: Range | Table) -> None:
        self.impl = impl
        self.parent = parent

    def _validate_field(self, field: int) -> int:
        if isinstance(field, bool) or not isinstance(field, int):
            raise TypeError("field must be an integer")
        column_count = (
            self.parent.range.shape[1]
            if isinstance(self.parent, Table)
            else self.parent.shape[1]
        )
        if not 1 <= field <= column_count:
            raise ValueError(
                f"field must be between 1 and {column_count} for this AutoFilter"
            )
        return field

    @staticmethod
    def _normalize_value(value: str | int | float | bool) -> str:
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, str):
            return value
        if isinstance(value, int):
            return str(value)
        if isinstance(value, float):
            if not math.isfinite(value):
                raise ValueError("AutoFilter values must be finite")
            return str(value)
        raise TypeError("AutoFilter values must be strings, numbers, or booleans")

    @staticmethod
    def _normalize_comparison_value(
        value: str | int | float | bool | dt.date | dt.datetime,
    ) -> str | dict[str, str]:
        if isinstance(value, dt.datetime):
            if value.tzinfo is not None:
                raise ValueError("AutoFilter datetimes must be timezone-naive")
            return {"type": "datetime", "value": value.isoformat()}
        if isinstance(value, dt.date):
            return {"type": "date", "value": value.isoformat()}
        return AutoFilter._normalize_value(value)

    @property
    def criteria(self) -> list[AutoFilterCriteria]:
        """Returns the criteria for all fields.

        The list contains one entry per field, including entries whose type is `"none"`. In xlwings Lite, use {meth}`get_criteria` instead.
        """
        return [AutoFilterCriteria(impl=entry) for entry in self.impl.criteria]

    async def get_criteria(self) -> list[AutoFilterCriteria]:
        """Returns the criteria for all fields from Excel.

        The list contains one entry per field, including entries whose type is `"none"`. Unsupported native criteria are reported as `"unknown"`.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        return [
            AutoFilterCriteria(impl=entry) for entry in await self.impl.get_criteria()
        ]

    def apply_values(
        self, field: int, values: Sequence[str | int | float | bool]
    ) -> None:
        """Filters a field to rows matching any of the supplied values.

        Dates and datetimes are not supported. Use `apply_comparison(field, "equal_to", value)` to filter for a single exact date or datetime.

        Args:
            field: One-based column position relative to the range or table.
            values: One or more exact values to include.

        Raises:
            TypeError: If `field` isn't an integer or `values` isn't a sequence of supported scalar values.
            ValueError: If `field` is outside the target, `values` is empty, or a number isn't finite.
        """
        field = self._validate_field(field)
        if isinstance(values, (str, bytes)) or not isinstance(values, Sequence):
            raise TypeError("values must be a sequence, not a string")
        if not values:
            raise ValueError("values must not be empty")
        self.impl.apply_values(field, [self._normalize_value(v) for v in values])

    def apply_comparison(
        self,
        field: int,
        operator: AutoFilterComparisonOperator,
        value1: str | int | float | bool | dt.date | dt.datetime | None,
        value2: str | int | float | bool | dt.date | dt.datetime | None = None,
    ) -> None:
        """Filters a field using a comparison.

        `None` represents blanks with `"equal_to"` and nonblanks with `"not_equal_to"`. `"between"` and `"not_between"` require a second value; all other operators reject one.

        Args:
            field: One-based column position relative to the range or table.
            operator: The comparison to apply.
            value1: A string, finite number, boolean, date, timezone-naive datetime, or `None`.
            value2: The upper bound for `"between"` and `"not_between"`; omit it for every other operator.

        Raises:
            TypeError: If a value has an unsupported type.
            ValueError: If a field, operator, operand combination, or number is invalid.
        """
        field = self._validate_field(field)
        if operator not in AUTOFILTER_COMPARISON_OPERATORS:
            raise ValueError(
                "operator must be one of " + ", ".join(AUTOFILTER_COMPARISON_OPERATORS)
            )
        if operator in ("between", "not_between"):
            if value1 is None or value2 is None:
                raise ValueError(f"{operator} requires value1 and value2")
        elif value2 is not None:
            raise ValueError(f"{operator} does not accept value2")
        if value1 is None and operator not in ("equal_to", "not_equal_to"):
            raise ValueError("None is only supported with equal_to and not_equal_to")
        normalized1 = (
            None if value1 is None else self._normalize_comparison_value(value1)
        )
        normalized2 = (
            None if value2 is None else self._normalize_comparison_value(value2)
        )
        self.impl.apply_comparison(field, operator, normalized1, normalized2)

    @staticmethod
    def _validate_item_count(count: int) -> int:
        if isinstance(count, bool) or not isinstance(count, int):
            raise TypeError("count must be an integer")
        if not 1 <= count <= 255:
            raise ValueError("count must be between 1 and 255")
        return count

    @staticmethod
    def _validate_percent(percent: int | float) -> float:
        if isinstance(percent, bool) or not isinstance(percent, numbers.Real):
            raise TypeError("percent must be a number")
        normalized = float(percent)
        if not math.isfinite(normalized) or not 0 <= normalized <= 100:
            raise ValueError("percent must be between 0 and 100")
        return normalized

    def apply_top_items(self, field: int, count: int) -> None:
        """Shows the highest-valued items in a field."""
        self.impl.apply_top_items(
            self._validate_field(field), self._validate_item_count(count)
        )

    def apply_bottom_items(self, field: int, count: int) -> None:
        """Shows the lowest-valued items in a field."""
        self.impl.apply_bottom_items(
            self._validate_field(field), self._validate_item_count(count)
        )

    def apply_top_percent(self, field: int, percent: int | float) -> None:
        """Shows the highest-valued percentage of items in a field."""
        self.impl.apply_top_percent(
            self._validate_field(field), self._validate_percent(percent)
        )

    def apply_bottom_percent(self, field: int, percent: int | float) -> None:
        """Shows the lowest-valued percentage of items in a field."""
        self.impl.apply_bottom_percent(
            self._validate_field(field), self._validate_percent(percent)
        )

    def clear(self, field: int | None = None) -> None:
        """Clears one field's criteria, or all criteria when `field` is omitted.

        Args:
            field: Optional one-based column position relative to the range or table.
        """
        if field is not None:
            field = self._validate_field(field)
        self.impl.clear(field)


# These have to be after definition of Range to resolve circular reference
from . import conversion, expansion


class Ranges:
    pass


class RangeRows(Ranges):
    """Represents the rows of a range. Do not construct this class directly, use
    `Range.rows` instead.

    Example:
        ```python
        import xlwings as xw

        wb = xw.Book("MyBook.xlsx")
        sheet1 = wb.sheets[0]
        myrange = sheet1.range('A1:C4')

        assert len(myrange.rows) == 4  # or myrange.rows.count

        myrange.rows[0].value = 'a'

        assert myrange.rows[2] == sheet1.range('A3:C3')
        assert myrange.rows(2) == sheet1.range('A2:C2')

        for r in myrange.rows:
        print(r.address)
        ```
    """

    def __init__(self, rng: Range) -> None:
        self.rng = rng

    def __len__(self) -> int:
        """Returns the number of rows.

        ```{versionadded} 0.9.0
        ```
        """
        return self.rng.shape[0]

    count = property(__len__)

    @property
    def hidden(self) -> bool | None:
        """Whether all represented worksheet rows are hidden.

        Setting this property hides or shows the entire worksheet rows represented by the range. Returns `None` when some rows are hidden and others are visible. In xlwings Lite, use `await rng.rows.get_hidden()` to read this state.
        """
        return self.rng.impl.row_hidden

    @hidden.setter
    def hidden(self, value: bool) -> None:
        if not isinstance(value, bool):
            raise TypeError("hidden must be a boolean")
        self.rng.impl.row_hidden = value

    async def get_hidden(self) -> bool | None:
        """Fetch row visibility in xlwings Lite; return `None` for a mixed selection."""
        return await self.rng.impl.get_row_hidden()

    def autofit(self) -> None:
        """Autofits the height of the rows."""
        self.rng.impl.autofit(axis="r")

    def __iter__(self) -> Iterator[Range]:
        for i in range(0, self.rng.shape[0]):
            yield self.rng[i, :]

    def __call__(self, key: int) -> Range:
        return self.rng[key - 1, :]

    @overload
    def __getitem__(self, key: int) -> Range:
        ...

    @overload
    def __getitem__(self, key: slice) -> RangeRows:
        ...

    def __getitem__(self, key: int | slice) -> Range | RangeRows:
        if isinstance(key, slice):
            return RangeRows(rng=self.rng[key, :])
        elif isinstance(key, int):
            return self.rng[key, :]
        else:
            raise TypeError(
                "Indices must be integers or slices, not %s" % type(key).__name__
            )

    def __repr__(self) -> str:
        return "{}({})".format(self.__class__.__name__, repr(self.rng))


class RangeColumns(Ranges):
    """Represents the columns of a range. Do not construct this class directly, use
    `Range.columns` instead.

    Example:
        ```python
        import xlwings as xw

        wb = xw.Book("MyFile.xlsx")
        sheet1 = wb.sheets[0]
        myrange = sheet1.range('A1:C4')

        assert len(myrange.columns) == 3  # or myrange.columns.count

        myrange.columns[0].value = 'a'

        assert myrange.columns[2] == sheet1.range('C1:C4')
        assert myrange.columns(2) == sheet1.range('B1:B4')

        for c in myrange.columns:
        print(c.address)
        ```
    """

    def __init__(self, rng: Range) -> None:
        self.rng = rng

    def __len__(self) -> int:
        """Returns the number of columns.

        ```{versionadded} 0.9.0
        ```
        """
        return self.rng.shape[1]

    count = property(__len__)

    @property
    def hidden(self) -> bool | None:
        """Whether all represented worksheet columns are hidden.

        Setting this property hides or shows the entire worksheet columns represented by the range. Returns `None` when some columns are hidden and others are visible. In xlwings Lite, use `await rng.columns.get_hidden()` to read this state.
        """
        return self.rng.impl.column_hidden

    @hidden.setter
    def hidden(self, value: bool) -> None:
        if not isinstance(value, bool):
            raise TypeError("hidden must be a boolean")
        self.rng.impl.column_hidden = value

    async def get_hidden(self) -> bool | None:
        """Fetch column visibility in xlwings Lite; return `None` for a mixed selection."""
        return await self.rng.impl.get_column_hidden()

    def autofit(self) -> None:
        """Autofits the width of the columns."""
        self.rng.impl.autofit(axis="c")

    def __iter__(self) -> Iterator[Range]:
        for j in range(0, self.rng.shape[1]):
            yield self.rng[:, j]

    def __call__(self, key: int) -> Range:
        return self.rng[:, key - 1]

    @overload
    def __getitem__(self, key: int) -> Range:
        ...

    @overload
    def __getitem__(self, key: slice) -> RangeColumns:
        ...

    def __getitem__(self, key: int | slice) -> Range | RangeColumns:
        if isinstance(key, slice):
            return RangeColumns(rng=self.rng[:, key])
        elif isinstance(key, int):
            return self.rng[:, key]
        else:
            raise TypeError(
                "Indices must be integers or slices, not %s" % type(key).__name__
            )

    def __repr__(self) -> str:
        return "{}({})".format(self.__class__.__name__, repr(self.rng))


class Shape:
    """The shape object is a member of the `shapes` collection:

    ```pycon
    >>> import xlwings as xw
    >>> sheet = xw.books['Book1'].sheets[0]
    >>> sheet.shapes[0]  # or sheet.shapes['ShapeName']
    <Shape 'Rectangle 1' in Sheet1>
    ```

    ```{versionchanged} 0.9.0
    ```
    """

    def __init__(self, *args: Any, **options: Any) -> None:
        impl = options.pop("impl", None)
        if impl is None:
            if len(args) == 1:
                impl = sheets.active.shapes(args[0]).impl

            else:
                raise ValueError("Invalid arguments")

        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj) of the engine
        being used.

        ```{versionadded} 0.19.2
        ```
        """
        return self.impl.api

    @property
    def name(self) -> str:
        """Returns or sets the name of the shape.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    @property
    def type(self) -> str:
        """Returns the type of the shape.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.type

    @property
    def left(self) -> float:
        """Returns or sets the number of points that represent the horizontal position
        of the shape.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.left

    @left.setter
    def left(self, value: float) -> None:
        self.impl.left = value

    @property
    def top(self) -> float:
        """Returns or sets the number of points that represent the vertical position of
        the shape.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.top

    @top.setter
    def top(self, value: float) -> None:
        self.impl.top = value

    @property
    def width(self) -> float:
        """Returns or sets the number of points that represent the width of the shape.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.width

    @width.setter
    def width(self, value: float) -> None:
        self.impl.width = value

    @property
    def height(self) -> float:
        """Returns or sets the number of points that represent the height of the shape.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.height

    @height.setter
    def height(self, value: float) -> None:
        self.impl.height = value

    def delete(self) -> None:
        """Deletes the shape.

        ```{versionadded} 0.5.0
        ```
        """
        self.impl.delete()

    def activate(self) -> None:
        """Activates the shape.

        ```{versionadded} 0.5.0
        ```
        """
        self.impl.activate()

    def scale_height(
        self,
        factor: float,
        relative_to_original_size: bool = False,
        scale: str = "scale_from_top_left",
    ) -> None:
        """
        Args:
            factor: For example 1.5 to scale it up to 150%
            relative_to_original_size: If `False`, it scales relative to current
                height (default). For `True` must be a picture or OLE object.
            scale: One of `scale_from_top_left` (default), `scale_from_bottom_right`,
                `scale_from_middle`

        ```{versionadded} 0.19.2
        ```
        """
        self.impl.scale_height(
            factor=factor,
            relative_to_original_size=relative_to_original_size,
            scale=scale,
        )

    def scale_width(
        self,
        factor: float,
        relative_to_original_size: bool = False,
        scale: str = "scale_from_top_left",
    ) -> None:
        """
        Args:
            factor: For example 1.5 to scale it up to 150%
            relative_to_original_size: If `False`, it scales relative to current
                width (default). For `True` must be a picture or OLE object.
            scale: One of `scale_from_top_left` (default), `scale_from_bottom_right`,
                `scale_from_middle`

        ```{versionadded} 0.19.2
        ```
        """
        self.impl.scale_width(
            factor=factor,
            relative_to_original_size=relative_to_original_size,
            scale=scale,
        )

    @property
    def text(self) -> str:
        """Returns or sets the text of a shape.

        ```{versionadded} 0.21.4
        ```
        """
        return self.impl.text

    @text.setter
    def text(self, value: Any) -> None:
        if xlwings.__pro__:
            from xlwings.pro import Markdown
            from xlwings.pro.reports.markdown import format_text, render_text

            if isinstance(value, Markdown):
                self.impl.text = render_text(value.text, value.style)
                format_text(self, value.text, value.style)
            else:
                self.impl.text = value
        else:
            self.impl.text = value

    @property
    def font(self) -> Font:
        return Font(impl=self.impl.font)

    @property
    def characters(self) -> Characters:
        return Characters(impl=self.impl.characters)

    @property
    def parent(self) -> Sheet:
        """Returns the parent of the shape.

        ```{versionadded} 0.9.0
        ```
        """
        return Sheet(impl=self.impl.parent)

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, Shape)
            and other.parent == self.parent
            and other.name == self.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        return "<Shape '{0}' in {1}>".format(self.name, self.parent.name)

    async def get_text(self) -> str | None:
        """Fetch the shape's text on demand.

        `None` if the shape holds no text.

        Requires xlwings Lite.
        """
        return await self.impl.get_text()


class Shapes(Collection[Shape]):
    """A collection of all `shape` objects on the specified sheet:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books['Book1'].sheets[0].shapes
    Shapes([<Shape 'Oval 1' in Sheet1>,
            <Shape 'Rectangle 1' in Sheet1>])
    ```

    ```{versionadded} 0.9.0
    ```
    """

    _wrap = Shape


class PageSetup:
    """Represents a PageSetup object.

    ```{versionadded} 0.24.2
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def print_area(self) -> str | None:
        """Gets or sets the range address that defines the print area.

        Examples:
            ```pycon
            >>> mysheet.page_setup.print_area = '$A$1:$B$3'
            >>> mysheet.page_setup.print_area
            '$A$1:$B$3'
            >>> mysheet.page_setup.print_area = None  # clear the print_area
            ```
        """
        return self.impl.print_area

    @print_area.setter
    def print_area(self, value: str | None) -> None:
        self.impl.print_area = value


def _conditional_format_operator(value: Any) -> ConditionalFormatOperator:
    if isinstance(value, str) and value in CONDITIONAL_FORMAT_OPERATORS:
        return cast(ConditionalFormatOperator, value)
    raise ValueError(
        f"Invalid conditional-format operator {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in CONDITIONAL_FORMAT_OPERATORS)}."
    )


def _conditional_format_value(value: Any, name: str) -> str:
    if isinstance(value, str):
        if value:
            return value
    elif (
        isinstance(value, numbers.Real)
        and not isinstance(value, bool)
        and math.isfinite(value)
    ):
        return str(value)
    raise ValueError(f"{name} must be a non-empty string or a finite number.")


def _conditional_format_formula(value: Any) -> str:
    if isinstance(value, str) and value.startswith("=") and len(value) > 1:
        return value
    raise ValueError("formula must be a non-empty A1 formula starting with '='.")


def _conditional_format_bool(value: Any, name: str) -> bool:
    if isinstance(value, bool):
        return value
    raise TypeError(f"{name} must be a boolean.")


def _conditional_format_threshold_type(value: Any) -> ConditionalFormatThresholdType:
    if isinstance(value, str) and value in CONDITIONAL_FORMAT_THRESHOLD_TYPES:
        return cast(ConditionalFormatThresholdType, value)
    raise ValueError(
        f"Invalid conditional-format threshold type {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in CONDITIONAL_FORMAT_THRESHOLD_TYPES)}."
    )


def _conditional_format_threshold(
    value: Any, threshold_type: str, name: str
) -> int | float:
    if (
        not isinstance(value, numbers.Real)
        or isinstance(value, bool)
        or not math.isfinite(value)
    ):
        raise ValueError(f"{name} must be a finite number.")
    if threshold_type in {"percent", "percentile"} and not 0 <= value <= 100:
        raise ValueError(f"{name} must be between 0 and 100 for {threshold_type!r}.")
    return value


def _conditional_format_thresholds(
    values: Any,
    *,
    count: int,
    threshold_type: ConditionalFormatThresholdType,
    name: str = "thresholds",
) -> tuple[int | float, ...]:
    if isinstance(values, (str, bytes)):
        raise TypeError(f"{name} must be a sequence of numbers.")
    try:
        result = tuple(values)
    except TypeError:
        raise TypeError(f"{name} must be a sequence of numbers.") from None
    if len(result) != count:
        raise ValueError(f"{name} must contain exactly {count} values.")
    result = tuple(
        _conditional_format_threshold(value, threshold_type, f"{name}[{index}]")
        for index, value in enumerate(result)
    )
    if any(left >= right for left, right in zip(result, result[1:])):
        raise ValueError(f"{name} must be strictly increasing.")
    return result


def _conditional_format_colors(values: Any) -> tuple[tuple[int, int, int], ...]:
    if isinstance(values, (str, bytes)):
        raise TypeError("colors must be a sequence containing two or three colors.")
    try:
        values = tuple(values)
    except TypeError:
        raise TypeError(
            "colors must be a sequence containing two or three colors."
        ) from None
    if len(values) not in {2, 3}:
        raise ValueError("colors must contain exactly two or three colors.")
    return tuple(_border_color(value) for value in values)


def _conditional_format_icon_set(value: Any) -> ConditionalFormatIconSet:
    if isinstance(value, str) and value in CONDITIONAL_FORMAT_ICON_SETS:
        return cast(ConditionalFormatIconSet, value)
    raise ValueError(
        f"Invalid conditional-format icon set {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in CONDITIONAL_FORMAT_ICON_SETS)}."
    )


def _validate_cell_value_rule(operator: Any, formula1: Any, formula2: Any) -> None:
    if operator is None or formula1 is None:
        raise ValueError("Cell-value rules require operator and formula1.")
    wants_formula2 = operator in {"between", "not_between"}
    if wants_formula2 and formula2 is None:
        raise ValueError(f"formula2 is required for operator {operator!r}.")
    if not wants_formula2 and formula2 is not None:
        raise ValueError("formula2 is only valid for between/not_between rules.")


def _add_conditional_format_changes(
    changes: dict[str, Any],
    *,
    fill_color: Any,
    font_color: Any,
    font_bold: Any,
    font_italic: Any,
    stop_if_true: Any,
) -> None:
    if fill_color is not _UNSET:
        changes["fill_color"] = _border_color(fill_color)
    if font_color is not _UNSET:
        changes["font_color"] = _border_color(font_color)
    if font_bold is not _UNSET:
        changes["font_bold"] = _conditional_format_bool(font_bold, "font_bold")
    if font_italic is not _UNSET:
        changes["font_italic"] = _conditional_format_bool(font_italic, "font_italic")
    if stop_if_true is not _UNSET:
        changes["stop_if_true"] = _conditional_format_bool(stop_if_true, "stop_if_true")


def _add_conditional_format_creation_style(
    spec: dict[str, Any],
    *,
    fill_color: Any,
    font_color: Any,
    font_bold: Any,
    font_italic: Any,
) -> None:
    values = {
        "fill_color": fill_color,
        "font_color": font_color,
        "font_bold": font_bold,
        "font_italic": font_italic,
    }
    for name, value in values.items():
        if value is None:
            continue
        if name.endswith("_color"):
            spec[name] = _border_color(value)
        else:
            spec[name] = _conditional_format_bool(value, name)


class ConditionalFormat:
    """Represents one conditional-format rule that applies to a range.

    ```{versionadded} 0.37.5
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def type(self) -> ConditionalFormatType:
        """The normalized rule type.

        Rule types outside the initially supported cell-value, custom-formula,
        color-scale, data-bar and icon-set families are reported as
        `"unknown"` rather than omitted.
        """
        rule_type = self.impl.type
        if rule_type not in CONDITIONAL_FORMAT_TYPES:
            return "unknown"
        return cast(ConditionalFormatType, rule_type)

    @property
    def stop_if_true(self) -> bool | None:
        """Whether lower-priority rules stop when this rule matches.

        `None` is returned for color scales, data bars and icon sets, which
        don't have stop-if-true behavior.
        """
        return self.impl.stop_if_true

    @property
    def operator(self) -> ConditionalFormatOperator | None:
        """The comparison operator for a cell-value rule, otherwise `None`."""
        return self.impl.operator

    @property
    def formula1(self) -> str | None:
        """The first operand for a cell-value rule, otherwise `None`."""
        return self.impl.formula1

    @property
    def formula2(self) -> str | None:
        """The second operand for a between/not-between rule, otherwise `None`."""
        return self.impl.formula2

    @property
    def formula(self) -> str | None:
        """The formula for a custom-formula rule, otherwise `None`."""
        return self.impl.formula

    @property
    def fill_color(self) -> tuple[int, int, int] | None:
        """The rule's fill color as an RGB tuple, or `None` if unset."""
        return self.impl.fill_color

    @property
    def font_color(self) -> tuple[int, int, int] | None:
        """The rule's font color as an RGB tuple, or `None` if unset."""
        return self.impl.font_color

    @property
    def font_bold(self) -> bool | None:
        """The rule's bold setting, or `None` if it doesn't set bold."""
        return self.impl.font_bold

    @property
    def font_italic(self) -> bool | None:
        """The rule's italic setting, or `None` if it doesn't set italic."""
        return self.impl.font_italic

    @property
    def colors(self) -> tuple[tuple[int, int, int], ...] | None:
        """The ordered colors of a color-scale rule, otherwise `None`.

        Colors run from the minimum criterion to the maximum criterion.
        """
        return self.impl.colors

    @property
    def bar_color(self) -> tuple[int, int, int] | None:
        """The positive fill color of a data-bar rule, otherwise `None`."""
        return self.impl.bar_color

    @property
    def gradient(self) -> bool | None:
        """Whether a data bar uses a gradient fill, otherwise `None`."""
        return self.impl.gradient

    @property
    def show_value(self) -> bool | None:
        """Whether cell values remain visible for a data bar or icon set."""
        return self.impl.show_value

    @property
    def icon_set(self) -> ConditionalFormatIconSet | None:
        """The built-in style of an icon-set rule, otherwise `None`."""
        return self.impl.icon_set

    @property
    def reverse_order(self) -> bool | None:
        """Whether an icon set's icon order is reversed, otherwise `None`."""
        return self.impl.reverse_order

    @property
    def threshold_types(self) -> tuple[ConditionalFormatCriterionType, ...] | None:
        """The ordered criterion types for a visual rule, otherwise `None`.

        Color scales include all criteria, data bars include the lower and
        upper bounds, and icon sets include only the effective thresholds
        between icons.
        """
        return self.impl.threshold_types

    @property
    def thresholds(self) -> tuple[int | float | str | None, ...] | None:
        """The values corresponding to
        {attr}`threshold_types <xlwings.ConditionalFormat.threshold_types>`.

        Criteria such as `"automatic"`, `"lowest_value"` and
        `"highest_value"` have a value of `None`.
        """
        return self.impl.thresholds

    def set(
        self,
        *,
        operator: ConditionalFormatOperator = _UNSET,
        formula1: str | int | float = _UNSET,
        formula2: str | int | float | None = _UNSET,
        formula: str = _UNSET,
        fill_color: tuple[int, int, int] | str | int = _UNSET,
        font_color: tuple[int, int, int] | str | int = _UNSET,
        font_bold: bool = _UNSET,
        font_italic: bool = _UNSET,
        stop_if_true: bool = _UNSET,
    ) -> None:
        """Change selected attributes of this rule in place.

        Omitted attributes remain unchanged. Cell-value rules accept
        `operator`, `formula1` and `formula2`; custom-formula rules accept
        `formula`. Formatting and `stop_if_true` apply to either family.
        Other rule types can't be edited by this initial API.

        Examples:
            ```python
            formats = await sheet["B2:B12"].get_conditional_formats()
            formats[0].set(formula1=70, stop_if_true=True)
            ```
        """
        changes: dict[str, Any] = {}
        rule_type = self.type
        if rule_type not in {"cell_value", "custom"}:
            raise NotImplementedError(
                f"Editing {rule_type!r} conditional-format rules isn't supported."
            )
        if rule_type == "cell_value":
            if formula is not _UNSET:
                raise ValueError("formula is only valid for custom-formula rules.")
            if operator is not _UNSET:
                changes["operator"] = _conditional_format_operator(operator)
            if formula1 is not _UNSET:
                changes["formula1"] = _conditional_format_value(formula1, "formula1")
            if formula2 is not _UNSET:
                changes["formula2"] = (
                    None
                    if formula2 is None
                    else _conditional_format_value(formula2, "formula2")
                )
            effective_operator = changes.get("operator", self.operator)
            effective_formula1 = changes.get("formula1", self.formula1)
            effective_formula2 = changes.get("formula2", self.formula2)
            if (
                operator is not _UNSET
                and formula2 is _UNSET
                and effective_operator not in {"between", "not_between"}
            ):
                effective_formula2 = None
            _validate_cell_value_rule(
                effective_operator, effective_formula1, effective_formula2
            )
            if effective_operator not in {"between", "not_between"} and (
                operator is not _UNSET or formula2 is not _UNSET
            ):
                changes["formula2"] = None
        else:
            if any(value is not _UNSET for value in (operator, formula1, formula2)):
                raise ValueError(
                    "operator, formula1 and formula2 are only valid for cell-value rules."
                )
            if formula is not _UNSET:
                changes["formula"] = _conditional_format_formula(formula)
        _add_conditional_format_changes(
            changes,
            fill_color=fill_color,
            font_color=font_color,
            font_bold=font_bold,
            font_italic=font_italic,
            stop_if_true=stop_if_true,
        )
        if changes:
            self.impl.set(changes)

    def delete(self) -> None:
        """Delete this complete rule from all ranges to which it applies."""
        self.impl.delete()

    def __repr__(self) -> str:
        return f"<ConditionalFormat type={self.type!r}>"


class ConditionalFormats(Collection[ConditionalFormat]):
    """An ordered collection of conditional-format rules for a range.

    New rules are inserted at the top of Excel's conditional-formatting rule
    order. Rules are evaluated from highest to lowest priority. If a matching
    rule has `stop_if_true=True`, Excel skips lower-priority rules.

    In xlwings Lite, use
    `await sheet["A1:D10"].get_conditional_formats()` instead of
    `sheet["A1:D10"].conditional_formats`.

    ```{versionadded} 0.37.5
    ```
    """

    _wrap = ConditionalFormat

    def add_cell_value(
        self,
        operator: ConditionalFormatOperator,
        formula1: str | int | float,
        formula2: str | int | float | None = None,
        *,
        fill_color: tuple[int, int, int] | str | int | None = None,
        font_color: tuple[int, int, int] | str | int | None = None,
        font_bold: bool | None = None,
        font_italic: bool | None = None,
        stop_if_true: bool = False,
    ) -> ConditionalFormat:
        """Add a cell-value rule.

        `formula2` is required for `"between"` and `"not_between"` and
        rejected for the other operators. Colors accept the same RGB tuple,
        hex string, or Excel color integer forms as other xlwings color APIs.

        Examples:
            ```python
            sheet["B2:B12"].conditional_formats.add_cell_value(
                "less_than", 60, fill_color="#ffff00", font_italic=True
            )
            ```
        """
        operator = _conditional_format_operator(operator)
        formula1 = _conditional_format_value(formula1, "formula1")
        formula2 = (
            None
            if formula2 is None
            else _conditional_format_value(formula2, "formula2")
        )
        _validate_cell_value_rule(operator, formula1, formula2)
        spec: dict[str, Any] = {
            "operator": operator,
            "formula1": formula1,
            "formula2": formula2,
            "stop_if_true": _conditional_format_bool(stop_if_true, "stop_if_true"),
        }
        _add_conditional_format_creation_style(
            spec,
            fill_color=fill_color,
            font_color=font_color,
            font_bold=font_bold,
            font_italic=font_italic,
        )
        return ConditionalFormat(impl=self.impl.add_cell_value(spec))

    def add_custom(
        self,
        formula: str,
        *,
        fill_color: tuple[int, int, int] | str | int | None = None,
        font_color: tuple[int, int, int] | str | int | None = None,
        font_bold: bool | None = None,
        font_italic: bool | None = None,
        stop_if_true: bool = False,
    ) -> ConditionalFormat:
        """Add a custom-formula rule.

        Examples:
            ```python
            sheet["A2:D20"].conditional_formats.add_custom(
                '=$D2="Late"', fill_color="#ffc7ce"
            )
            ```
        """
        spec: dict[str, Any] = {
            "formula": _conditional_format_formula(formula),
            "stop_if_true": _conditional_format_bool(stop_if_true, "stop_if_true"),
        }
        _add_conditional_format_creation_style(
            spec,
            fill_color=fill_color,
            font_color=font_color,
            font_bold=font_bold,
            font_italic=font_italic,
        )
        return ConditionalFormat(impl=self.impl.add_custom(spec))

    def add_color_scale(
        self,
        colors: Sequence[tuple[int, int, int] | str | int],
        *,
        thresholds: Sequence[int | float] | None = None,
        threshold_type: ConditionalFormatThresholdType = "number",
    ) -> ConditionalFormat:
        """Add a two- or three-color scale.

        `colors` contains two or three colors ordered from the minimum to
        the maximum. Without `thresholds`, a two-color scale uses the lowest
        and highest values, while a three-color scale adds the 50th percentile
        as its midpoint. Custom thresholds must match the number of colors and
        be strictly increasing. `threshold_type` can be `"number"`,
        `"percent"` or `"percentile"`.

        Examples:
            ```python
            sheet["B2:B20"].conditional_formats.add_color_scale(
                ["#f8696b", "#ffeb84", "#63be7b"],
                thresholds=[0, 50, 100],
                threshold_type="number",
            )
            ```
        """
        colors = _conditional_format_colors(colors)
        threshold_type = _conditional_format_threshold_type(threshold_type)
        if thresholds is None:
            if len(colors) == 2:
                threshold_types = ("lowest_value", "highest_value")
                threshold_values = (None, None)
            else:
                threshold_types = ("lowest_value", "percentile", "highest_value")
                threshold_values = (None, 50, None)
        else:
            threshold_values = _conditional_format_thresholds(
                thresholds,
                count=len(colors),
                threshold_type=threshold_type,
            )
            threshold_types = (threshold_type,) * len(colors)
        spec = {
            "colors": colors,
            "threshold_types": threshold_types,
            "thresholds": threshold_values,
        }
        return ConditionalFormat(impl=self.impl.add_color_scale(spec))

    def add_data_bar(
        self,
        color: tuple[int, int, int] | str | int,
        *,
        minimum: int | float | None = None,
        maximum: int | float | None = None,
        threshold_type: ConditionalFormatThresholdType = "number",
        gradient: bool = True,
        show_value: bool = True,
    ) -> ConditionalFormat:
        """Add a data bar.

        Omitted bounds are automatic. Supplied bounds use `threshold_type`,
        which can be `"number"`, `"percent"` or `"percentile"`.
        """
        threshold_type = _conditional_format_threshold_type(threshold_type)
        minimum = (
            None
            if minimum is None
            else _conditional_format_threshold(minimum, threshold_type, "minimum")
        )
        maximum = (
            None
            if maximum is None
            else _conditional_format_threshold(maximum, threshold_type, "maximum")
        )
        if minimum is not None and maximum is not None and minimum >= maximum:
            raise ValueError("minimum must be less than maximum.")
        spec = {
            "bar_color": _border_color(color),
            "gradient": _conditional_format_bool(gradient, "gradient"),
            "show_value": _conditional_format_bool(show_value, "show_value"),
            "threshold_types": (
                threshold_type if minimum is not None else "automatic",
                threshold_type if maximum is not None else "automatic",
            ),
            "thresholds": (minimum, maximum),
        }
        return ConditionalFormat(impl=self.impl.add_data_bar(spec))

    def add_icon_set(
        self,
        icon_set: ConditionalFormatIconSet,
        *,
        thresholds: Sequence[int | float] | None = None,
        threshold_type: ConditionalFormatThresholdType = "number",
        show_value: bool = True,
        reverse_order: bool = False,
    ) -> ConditionalFormat:
        """Add a built-in icon set.

        Custom thresholds contain one fewer value than the number of icons and
        must be strictly increasing. Without them, the icons use equal percent
        bands (for example, 33 and 67 for a three-icon set).

        Valid styles are `"3_arrows"`, `"3_arrows_gray"`, `"3_flags"`,
        `"3_traffic_lights_1"`, `"3_traffic_lights_2"`, `"3_signs"`,
        `"3_symbols"`, `"3_symbols_2"`, `"4_arrows"`,
        `"4_arrows_gray"`, `"4_red_to_black"`, `"4_rating"`,
        `"4_traffic_lights"`, `"5_arrows"`, `"5_arrows_gray"`,
        `"5_rating"`, `"5_quarters"`, `"3_stars"`,
        `"3_triangles"` and `"5_boxes"`.

        Examples:
            ```python
            sheet["C2:C20"].conditional_formats.add_icon_set(
                "3_traffic_lights_1", thresholds=[60, 80]
            )
            ```
        """
        icon_set = _conditional_format_icon_set(icon_set)
        threshold_type = _conditional_format_threshold_type(threshold_type)
        count = int(icon_set[0])
        if thresholds is None:
            threshold_values = tuple(
                round(index * 100 / count) for index in range(1, count)
            )
            threshold_types = ("percent",) * (count - 1)
        else:
            threshold_values = _conditional_format_thresholds(
                thresholds,
                count=count - 1,
                threshold_type=threshold_type,
            )
            threshold_types = (threshold_type,) * (count - 1)
        spec = {
            "icon_set": icon_set,
            "show_value": _conditional_format_bool(show_value, "show_value"),
            "reverse_order": _conditional_format_bool(reverse_order, "reverse_order"),
            "threshold_types": threshold_types,
            "thresholds": threshold_values,
        }
        return ConditionalFormat(impl=self.impl.add_icon_set(spec))

    def clear(self) -> None:
        """Clear all conditional formats active on the represented range.

        Rules that also apply outside the range remain active there.
        """
        self.impl.clear()


class Notes:
    """A collection of notes on one worksheet (`sheet.notes`) or across all worksheets in a workbook (`book.notes`).

    Iterate over `sheet.notes` to inspect one worksheet, or `book.notes` to inspect every worksheet. If you already know the cell, access its note directly with `sheet["A1"].note`. Collections also support zero-based indexing and lookup by cell address (`sheet.notes`) or a single-cell {class}`Range <xlwings.Range>` (`book.notes`).

    Examples:
        ```python
        import xlwings as xw

        book = xw.Book()
        sheet = book.sheets[0]
        other_sheet = book.sheets.add(after=sheet)
        sheet["A1"].add_note("Review")
        other_sheet["B2"].add_note("Check")

        for note in sheet.notes:
            print(note.location.address, note.text)
        for note in book.notes:
            print(note.location.sheet.name, note.location.address, note.text)
        ```
    """

    def __init__(self, parent: Book | Sheet) -> None:
        self.parent = parent

    def __iter__(self) -> Iterator[Note]:
        if isinstance(self.parent, Book):
            for sheet in self.parent.sheets:
                yield from sheet.notes
        else:
            for impl in self.parent.impl.notes:
                yield Note(impl=impl)

    def __len__(self) -> int:
        return sum(1 for _ in self)

    @property
    def count(self) -> int:
        """Number of notes in this collection."""
        return len(self)

    def __getitem__(self, key: int | str | Range) -> Note:
        if isinstance(key, int):
            notes = list(self)
            return notes[key]
        if isinstance(key, Range):
            cell = key
            if cell.shape != (1, 1) or cell.sheet.book != (
                self.parent if isinstance(self.parent, Book) else self.parent.book
            ):
                raise ValueError("The cell must belong to this workbook")
            if isinstance(self.parent, Sheet) and cell.sheet != self.parent:
                raise ValueError("The cell must belong to this worksheet")
        elif isinstance(key, str) and isinstance(self.parent, Sheet):
            cell = self.parent.range(key)
        else:
            raise TypeError("Use a cell Range for workbook lookup")
        if cell.shape != (1, 1):
            raise ValueError("A note location must be a single cell")
        note = cell.note
        if note is None:
            raise KeyError(key)
        return note


class Note:
    """Represents a cell Note.

    Before the introduction of threaded comments, a Note was called a Comment.

    Examples:
        ```python
        import xlwings as xw

        book = xw.Book()
        cell = book.sheets[0]["A1"]
        note = cell.add_note("Review this value")
        print(note.text)
        ```

    ```{versionadded} 0.24.2
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.24.2
        ```
        """
        return self.impl.api

    @property
    def text(self) -> str:
        """Gets or sets the text of a note. Keep in mind that the note must already
        exist!

        Examples:
            ```pycon
            >>> sheet = xw.Book(...).sheets[0]
            >>> sheet['A1'].note.text = 'mynote'
            >>> sheet['A1'].note.text
            >>> 'mynote'
            ```

        ```{versionadded} 0.24.2
        ```
        """
        return self.impl.text

    @text.setter
    def text(self, value: str) -> None:
        self.impl.text = value

    def delete(self) -> None:
        """Delete the note.

        ```{versionadded} 0.24.2
        ```
        """
        self.impl.delete()

    async def get_text(self) -> str | None:
        """Fetch the note's text on demand.

        Requires xlwings Lite.

        ```{versionadded} 0.37.0
        ```
        """
        return await self.impl.get_text()

    @property
    def author(self) -> str:
        """The note's author. In xlwings Lite, use `await get_author()`.

        ```{versionadded} 0.37.5
        ```
        """
        return self.impl.author

    async def get_author(self) -> str | None:
        """Read the note's author from Excel; return `None` if the note is gone.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        return await self.impl.get_author()

    @property
    def location(self) -> Range:
        """The cell containing this note. In xlwings Lite, use `await get_location()`.

        ```{versionadded} 0.37.5
        ```
        """
        return Range(impl=self.impl.location)

    async def get_location(self) -> Range | None:
        """Read the note's cell from Excel; return `None` if it is gone.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        impl = await self.impl.get_location()
        return Range(impl=impl) if impl is not None else None


def _validate_comment_text(text: str) -> None:
    if not isinstance(text, str):
        raise TypeError("Comment text must be a string")
    if not text:
        raise ValueError("Comment text must not be empty")


class Comments:
    """Threaded comments on a worksheet or in a workbook.

    In xlwings Lite, obtain the collection with `await sheet.get_comments()` or `await book.get_comments()`.

    Examples:
        ```python
        import xlwings as xw

        book = xw.Book()
        sheet = book.sheets[0]
        sheet["A1"].add_comment("Review")
        for comment in book.comments:
            print(comment.location.address, comment.text)
        print(sheet.comments["A1"].text)
        ```
    """

    def __init__(
        self, parent: Book | Sheet, items: list[Comment] | None = None
    ) -> None:
        self.parent = parent
        self._items = items

    def __iter__(self) -> Iterator[Comment]:
        if self._items is not None:
            yield from self._items
        elif isinstance(self.parent, Book):
            for sheet in self.parent.sheets:
                yield from sheet.comments
        else:
            for impl in self.parent.impl.comments:
                yield Comment(impl=impl)

    def __len__(self) -> int:
        return sum(1 for _ in self)

    @property
    def count(self) -> int:
        """Number of comments in this collection."""
        return len(self)

    def __getitem__(self, key: int | str | Range) -> Comment:
        if isinstance(key, int):
            return list(self)[key]
        if isinstance(key, str) and isinstance(self.parent, Sheet):
            cell = self.parent.range(key)
        elif isinstance(key, Range):
            cell = key
        else:
            raise TypeError("Use a cell Range for workbook lookup")
        if cell.shape != (1, 1):
            raise ValueError("A comment location must be a single cell")
        expected_book = (
            self.parent if isinstance(self.parent, Book) else self.parent.book
        )
        if cell.sheet.book != expected_book or (
            isinstance(self.parent, Sheet) and cell.sheet != self.parent
        ):
            raise ValueError("The cell must belong to this collection")
        for comment in self:
            location = getattr(comment.impl, "range", None)
            if location is None:
                location = comment.location
            if (
                location.sheet.name == cell.sheet.name
                and location.address == cell.address
            ):
                return comment
        raise KeyError(key)


class Comment:
    """A modern threaded comment attached to one cell, distinct from a [](note.md).

    Examples:
        ```python
        import xlwings as xw

        cell = xw.Book().sheets[0]["A1"]
        comment = cell.add_comment("Review this value")
        comment.text = "Review the updated value"
        print(comment.author, comment.text)
        comment.delete()
        ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def text(self) -> str:
        """Comment text. In xlwings Lite, use `await get_text()` to read it."""
        return self.impl.text

    @text.setter
    def text(self, value: str) -> None:
        _validate_comment_text(value)
        self.impl.text = value

    async def get_text(self) -> str | None:
        """Read the comment text, or `None` if it was deleted.

        Requires xlwings Lite.
        """
        return await self.impl.get_text()

    @property
    def author(self) -> str:
        """Author name. In xlwings Lite, use `await get_author()`."""
        return self.impl.author

    async def get_author(self) -> str | None:
        """Read the author's name.

        Requires xlwings Lite.
        """
        return await self.impl.get_author()

    @property
    def creation_date(self) -> dt.datetime | None:
        """Creation date, when Excel has one. In xlwings Lite, use `await get_creation_date()`."""
        return self.impl.creation_date

    async def get_creation_date(self) -> dt.datetime | None:
        """Read the creation date.

        Requires xlwings Lite.
        """
        return await self.impl.get_creation_date()

    @property
    def resolved(self) -> bool:
        """Thread resolution state. In xlwings Lite, use `await get_resolved()`."""
        return self.impl.resolved

    async def get_resolved(self) -> bool | None:
        """Read the resolution state.

        Requires xlwings Lite.
        """
        return await self.impl.get_resolved()

    @property
    def location(self) -> Range:
        """The comment's cell. In xlwings Lite, use `await get_location()`."""
        return Range(impl=self.impl.location)

    async def get_location(self) -> Range | None:
        """Read the comment's cell.

        Requires xlwings Lite.
        """
        impl = await self.impl.get_location()
        return Range(impl=impl) if impl is not None else None

    @property
    def replies(self) -> list[CommentReply]:
        """Replies to this comment. In xlwings Lite, use `await get_replies()`."""
        return [CommentReply(impl=impl) for impl in self.impl.replies]

    async def get_replies(self) -> list[CommentReply]:
        """Fetch replies.

        Requires xlwings Lite.
        """
        return [CommentReply(impl=impl) for impl in await self.impl.get_replies()]

    def add_reply(self, text: str) -> None:
        """Add a plain-text reply."""
        _validate_comment_text(text)
        self.impl.add_reply(text)

    def resolve(self) -> None:
        """Resolve this thread."""
        self.impl.set_resolved(True)

    def reopen(self) -> None:
        """Reopen this thread."""
        self.impl.set_resolved(False)

    def delete(self) -> None:
        """Delete the thread and all its replies."""
        self.impl.delete()


class CommentReply:
    """A plain-text reply to a threaded comment.

    Examples:
        ```python
        import xlwings as xw

        comment = xw.Book().sheets[0]["A1"].add_comment("Review")
        comment.add_reply("Checked")
        print(comment.replies[0].text)
        ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def text(self) -> str:
        """Reply text. In xlwings Lite, use `await get_text()`."""
        return self.impl.text

    async def get_text(self) -> str | None:
        """Read the reply text, or `None` if it was deleted.

        Requires xlwings Lite.
        """
        return await self.impl.get_text()


class Table:
    """The table object is a member of the `tables` collection:

    ```pycon
    >>> import xlwings as xw
    >>> sheet = xw.books['Book1'].sheets[0]
    >>> sheet.tables[0]  # or sheet.tables['TableName']
    <Table 'Table 1' in Sheet1>
    ```

    ```{versionadded} 0.21.0
    ```
    """

    def __init__(self, *args: Any, **options: Any) -> None:
        impl = options.pop("impl", None)
        if impl is None:
            if len(args) == 1:
                impl = sheets.active.tables(args[0]).impl
            else:
                raise ValueError("Invalid arguments")
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def parent(self) -> Sheet:
        """Returns the parent of the table."""
        return Sheet(impl=self.impl.parent)

    @property
    def name(self) -> str:
        """Returns or sets the name of the Table."""
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    @property
    def data_body_range(self) -> Range | None:
        """Returns an xlwings range object that represents the range of values,
        excluding the header row
        """
        return (
            Range(impl=self.impl.data_body_range) if self.impl.data_body_range else None
        )

    @property
    def display_name(self) -> str:
        """Returns or sets the display name for the specified Table object"""
        return self.impl.display_name

    @display_name.setter
    def display_name(self, value: str) -> None:
        self.impl.display_name = value

    @property
    def header_row_range(self) -> Range | None:
        """Returns an xlwings range object that represents the range of the header
        row
        """
        if self.impl.header_row_range:
            return Range(impl=self.impl.header_row_range)
        else:
            return None

    @property
    def insert_row_range(self) -> Range | None:
        """Returns an xlwings range object representing the row where data is going to
        be inserted. This is only available for empty tables, otherwise it'll return
        `None`
        """
        if self.impl.insert_row_range:
            return Range(impl=self.impl.insert_row_range)
        else:
            return None

    @property
    def range(self) -> Range:
        """Returns an xlwings range object of the table."""
        return Range(impl=self.impl.range)

    @property
    def autofilter(self) -> AutoFilter:
        """Returns the AutoFilter for this table.

        `field` arguments are one-based column positions relative to the table.

        ```{versionadded} 0.37.5
        ```
        """
        return AutoFilter(impl=self.impl.autofilter, parent=self)

    @property
    def rows(self) -> TableRows:
        """Data rows of this table, excluding headers and totals."""
        return TableRows(impl=self.impl.rows)

    @property
    def show_autofilter(self) -> bool:
        """Turn the autofilter on or off by setting it to `True` or `False`
        (read/write boolean)
        """
        return self.impl.show_autofilter

    @show_autofilter.setter
    def show_autofilter(self, value: bool) -> None:
        self.impl.show_autofilter = value

    @property
    def show_headers(self) -> bool:
        """Show or hide the header (read/write)"""
        return self.impl.show_headers

    @show_headers.setter
    def show_headers(self, value: bool) -> None:
        self.impl.show_headers = value

    @property
    def show_table_style_column_stripes(self) -> bool:
        """Returns or sets if the Column Stripes table style is used for
        (read/write boolean)
        """
        return self.impl.show_table_style_column_stripes

    @show_table_style_column_stripes.setter
    def show_table_style_column_stripes(self, value: bool) -> None:
        self.impl.show_table_style_column_stripes = value

    @property
    def show_table_style_first_column(self) -> bool:
        """Returns or sets if the first column is formatted (read/write boolean)"""
        return self.impl.show_table_style_first_column

    @show_table_style_first_column.setter
    def show_table_style_first_column(self, value: bool) -> None:
        self.impl.show_table_style_first_column = value

    @property
    def show_table_style_last_column(self) -> bool:
        """Returns or sets if the last column is displayed (read/write boolean)"""
        return self.impl.show_table_style_last_column

    @show_table_style_last_column.setter
    def show_table_style_last_column(self, value: bool) -> None:
        self.impl.show_table_style_last_column = value

    @property
    def show_table_style_row_stripes(self) -> bool:
        """Returns or sets if the Row Stripes table style is used
        (read/write boolean)
        """
        return self.impl.show_table_style_row_stripes

    @show_table_style_row_stripes.setter
    def show_table_style_row_stripes(self, value: bool) -> None:
        self.impl.show_table_style_row_stripes = value

    @property
    def show_totals(self) -> bool:
        """Gets or sets a boolean to show/hide the Total row."""
        return self.impl.show_totals

    @show_totals.setter
    def show_totals(self, value: bool) -> None:
        self.impl.show_totals = value

    @property
    def table_style(self) -> str:
        """Gets or sets the table style.
        See `Tables.add` for possible values.
        """
        return self.impl.table_style

    @table_style.setter
    def table_style(self, value: str) -> None:
        self.impl.table_style = value

    @property
    def columns(self) -> TableColumns:
        """The columns belonging to this table. Integer collection lookup is zero-based."""
        return TableColumns(impl=self.impl.columns)

    @property
    def totals_row_range(self) -> Range | None:
        """Returns an xlwings range object representing the Total row"""
        if self.impl.totals_row_range:
            return Range(impl=self.impl.totals_row_range)
        else:
            return None

    def update(self, data: Any, index: bool = True) -> Table:
        """Updates the Excel table with the provided data.
        Currently restricted to DataFrames.

        ```{versionchanged} 0.24.0
        ```

        Args:
            data: Currently restricted to pandas DataFrames.
            index: Whether or not the index of a pandas DataFrame should be written to the
                Excel table.

        Examples:
            ```python
            import pandas as pd
            import xlwings as xw

            sheet = xw.Book('Book1.xlsx').sheets[0]
            table_name = 'mytable'

            # Sample DataFrame
            nrows, ncols = 3, 3
            df = pd.DataFrame(data=nrows * [ncols * ['test']],
                          columns=['col ' + str(i) for i in range(ncols)])

            # Hide the index, then insert a new table if it doesn't exist yet,
            # otherwise update the existing one
            df = df.set_index('col 0')
            if table_name in [table.name for table in sheet.tables]:
            sheet.tables[table_name].update(df)
            else:
            mytable = sheet.tables.add(source=sheet['A1'],
                                       name=table_name).update(df)
            ```
        """
        type_error_msg = "Currently, only pandas DataFrames are supported by update"
        if pd:
            if not isinstance(data, pd.DataFrame):
                raise TypeError(type_error_msg)
            if data.empty:
                nrows_data = 1
            else:
                nrows_data = len(data)
            nrows_table = len(self.data_body_range.rows) if self.data_body_range else 1
            row_diff = nrows_table - nrows_data
            if data.empty:
                ncols_data = 1
            else:
                ncols_data = (
                    len(data.columns)
                    if not index
                    else len(data.columns) + len(data.index.names)
                )
            ncols_table = len(self.range.columns)
            col_diff = ncols_table - ncols_data
            cols_to_be_cleared = None
            if col_diff > 0:
                cols_to_be_cleared = self.range[:, ncols_table - col_diff :]
            rows_to_be_cleared = None
            if row_diff > 0 and self.data_body_range:
                rows_to_be_cleared = self.data_body_range[nrows_table - row_diff :, :]
            self.resize(
                self.range[0, 0].resize(
                    row_size=nrows_data + 1 if self.header_row_range else nrows_data,
                    column_size=ncols_data,
                )
            )
            # Clearing must happen after resizing as table headers will be replaced
            # with Column1 etc. if deleted while still being part of table
            if cols_to_be_cleared:
                cols_to_be_cleared.clear_contents()
            if rows_to_be_cleared:
                rows_to_be_cleared.clear_contents()
            if self.header_row_range:
                # Tables with 'Header Row' checked
                header = (
                    (list(data.index.names) + list(data.columns))
                    if index
                    else list(data.columns)
                )
                # Replace None in the header with a unique number of spaces
                n_empty = len([i for i in header if isinstance(i, str) and i.isspace()])
                header = [
                    " " * (i + n_empty + 1) if name is None else name
                    for i, name in enumerate(header)
                ]
                self.header_row_range.value = header
                self.range[1, 0].options(index=index, header=False).value = data
            else:
                # Tables with 'Header Row' unchecked
                self.resize(self.range[0, 0])  # Otherwise the table will be deleted
                self.range[0, 0].options(index=index, header=False).value = data
                # If the top-left cell isn't empty, it doesn't manage to resize the
                # columns automatically
                self.resize(
                    self.range[0, 0].resize(row_size=nrows_data, column_size=ncols_data)
                )
            return self
        else:
            raise TypeError(type_error_msg)

    def resize(self, range: Range) -> None:
        """Resize a Table by providing an xlwings range object

        ```{versionadded} 0.24.4
        ```
        """
        self.impl.resize(range)

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, Table)
            and other.parent == self.parent
            and other.name == self.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        return "<Table '{0}' in {1}>".format(self.name, self.parent.name)


class TableRow:
    """A data row in an Excel table. Row objects refer to a position, so obtain them again after sorting or changing the table structure.

    Examples:
        ```python
        import xlwings as xw

        table = xw.Book().sheets[0].tables["Table1"]
        row = table.rows[0]  # First data row; row.index is 1
        print(row.range.value)
        row.delete()
        ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def index(self) -> int:
        """One-based position within the table's data rows."""
        return self.impl.index

    @property
    def range(self) -> Range:
        """Cells in this row. In xlwings Lite, use `await get_range()`."""
        return Range(impl=self.impl.range)

    async def get_range(self) -> Range:
        """Fetch this row's cells. Use this method for xlwings Lite readback."""
        return Range(impl=await self.impl.get_range())

    def delete(self) -> None:
        """Delete this table row. Excel may shift cells below the table upward."""
        self.impl.delete()


class TableRows(Collection[TableRow]):
    """Collection of data rows in a table. Row indexes are one-based; square-bracket lookup is zero-based. In xlwings Lite, `len(rows)` uses loaded metadata; use `await rows.get_count()` for the current count.

    Examples:
        ```python
        import xlwings as xw

        rows = xw.Book().sheets[0].tables["Table1"].rows
        rows.add(["Pencil", 2])  # Append
        rows.add(["Pen", 3], index=1)  # Insert before the first data row
        print(rows[0].range.value)  # ["Pen", 3]
        ```
    """

    _wrap = TableRow

    def __getitem__(self, key: int) -> TableRow:
        if not isinstance(key, int) or isinstance(key, bool):
            raise TypeError("Table rows use integer indexes")
        return super().__getitem__(key)

    async def get_count(self) -> int:
        """Fetch the current row count. Use this method for xlwings Lite readback."""
        return await self.impl.get_count()

    def add(
        self,
        values: list[str | int | float | bool | None]
        | tuple[str | int | float | bool | None, ...]
        | None = None,
        index: int | None = None,
    ) -> TableRow:
        """Add one row before one-based `index`, or append when it is `None`.

        `values` must contain exactly one value per table column. Omit it to let Excel create a blank row and fill calculated columns. Excel may shift cells below the table downward.
        """
        if index is not None:
            if not isinstance(index, int) or isinstance(index, bool):
                raise TypeError("index must be an integer or None")
            if index < 1 or index > len(self) + 1:
                raise IndexError("Table row index out of range")
        if values is not None:
            if not isinstance(values, (list, tuple)):
                raise TypeError("values must be a one-dimensional list or tuple")
            if len(values) != self.impl.column_count:
                raise ValueError("values must match the table column count")
            for value in values:
                if value is not None and not isinstance(value, (str, int, float, bool)):
                    raise TypeError(
                        "table row values must be strings, numbers, booleans, or None"
                    )
                if isinstance(value, float) and not math.isfinite(value):
                    raise ValueError("table row numbers must be finite")
            values = list(values)
        return TableRow(impl=self.impl.add(values, index))


class TableColumn:
    """A column in an Excel table. Obtain it again after changing table structure.

    Examples:
        ```python
        import xlwings as xw

        table = xw.Book().sheets[0].tables["Table1"]
        column = table.columns["MyColumn"]
        print(column.index)
        print(column.data_body_range.value)
        column.delete()
        ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def name(self) -> str:
        """The column header."""
        return self.impl.name

    @property
    def index(self) -> int:
        """One-based position within the table."""
        return self.impl.index

    @property
    def range(self) -> Range:
        """All cells in this column. In xlwings Lite, use `await get_range()`."""
        return Range(impl=self.impl.range)

    async def get_range(self) -> Range:
        """Fetch this column's current range in xlwings Lite."""
        return Range(impl=await self.impl.get_range())

    @property
    def data_body_range(self) -> Range | None:
        """Data cells, excluding header and totals. In xlwings Lite, use `await get_data_body_range()`."""
        impl = self.impl.data_body_range
        return Range(impl=impl) if impl else None

    async def get_data_body_range(self) -> Range | None:
        """Fetch this column's current data cells in xlwings Lite."""
        impl = await self.impl.get_data_body_range()
        return Range(impl=impl) if impl else None

    def delete(self) -> None:
        """Delete the column from its table. Excel may move cells beside the table."""
        self.impl.delete()


class TableColumns(Collection[TableColumn]):
    """Table columns. Collection lookup is zero-based; column indexes are one-based. For a newly created table in xlwings Lite, call `await book.flush()` and `await sheet.load()` before accessing its columns, then obtain the table again.

    Examples:
        ```python
        import xlwings as xw

        columns = xw.Book().sheets[0].tables["Table1"].columns
        columns.add("Tax", index=2)
        print(columns[1].name)
        ```
    """

    _wrap = TableColumn

    async def get_count(self) -> int:
        """Fetch the current column count in xlwings Lite."""
        return await self.impl.get_count()

    def add(self, name: str, index: int | None = None) -> TableColumn:
        """Insert a named column before one-based `index`, or append when omitted. Excel may move cells beside the table."""
        if not isinstance(name, str):
            raise TypeError("name must be a string")
        if not name.strip():
            raise ValueError("name must not be empty")
        if index is not None:
            if not isinstance(index, int) or isinstance(index, bool):
                raise TypeError("index must be an integer or None")
            if not 1 <= index <= len(self) + 1:
                raise IndexError("Table column index out of range")
        if name.casefold() in (column.name.casefold() for column in self):
            raise ValueError(f"Table column named {name!r} already exists")
        return TableColumn(impl=self.impl.add(name, index))


class Tables(Collection[Table]):
    """A collection of all `table` objects on the specified sheet:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books['Book1'].sheets[0].tables
    Tables([<Table 'Table1' in Sheet1>,
            <Table 'Table2' in Sheet1>])
    ```

    ```{versionadded} 0.21.0
    ```
    """

    _wrap = Table

    def add(
        self,
        source: Range | None = None,
        name: str | None = None,
        source_type: str | None = None,
        link_source: bool | None = None,
        has_headers: bool = True,
        destination: Range | None = None,
        table_style_name: str = "TableStyleMedium2",
    ) -> Table:
        """Creates a Table to the specified sheet.

        Args:
            source: An xlwings range object, representing the data source.
            name: The name of the Table. By default, it uses the autogenerated name that is
                assigned by Excel.
            source_type: This currently defaults to `xlSrcRange`, i.e. expects an xlwings range
                object. No other options are allowed at the moment.
            link_source: Currently not implemented as this is only in case `source_type` is
                `xlSrcExternal`.
            has_headers: Whether the source range has column labels. Defaults to `True`. When `False`, Excel generates headers above the source data.
            destination: Currently not implemented as this is used in case `source_type` is
                `xlSrcExternal`.
            table_style_name: Possible strings: `'TableStyleLightN'` (where N is 1-21),
                `'TableStyleMediumN'` (where N is 1-28),
                `'TableStyleDarkN'` (where N is 1-11)

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> sheet = xw.Book().sheets[0]
            >>> sheet['A1'].value = [['a', 'b'], [1, 2]]
            >>> table = sheet.tables.add(source=sheet['A1'].expand(), name='MyTable')
            >>> table
            <Table 'MyTable' in Sheet1>
            ```
        """

        if not isinstance(has_headers, bool):
            raise TypeError("has_headers must be True or False")

        impl = self.impl.add(
            source_type=source_type,
            source=source,
            link_source=link_source,
            has_headers=has_headers,
            destination=destination,
            table_style_name=table_style_name,
            name=name,
        )

        return Table(impl=impl)


def _chart_type(value: Any) -> str:
    if isinstance(value, str) and str(value) in CHART_TYPES:
        return str(value)
    raise ValueError(
        f"Invalid chart type {value!r}. Must be one of: "
        f"{', '.join(repr(v) for v in CHART_TYPES)}."
    )


def _chart_plot_by(value: Any) -> str:
    if isinstance(value, str) and str(value) in CHART_PLOT_BY:
        return str(value)
    raise ValueError(
        f"Invalid plot_by {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in CHART_PLOT_BY)}."
    )


def _chart_legend_position(value: Any) -> str:
    if isinstance(value, str) and str(value) in CHART_LEGEND_POSITIONS:
        return str(value)
    raise ValueError(
        f"Invalid legend position {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in CHART_LEGEND_POSITIONS)}."
    )


def _chart_style(value: Any) -> int:
    # bool is an Integral subclass, but True/False as a chart style is a bug
    if isinstance(value, numbers.Integral) and not isinstance(value, bool):
        value = int(value)
        if 1 <= value <= 48 or 201 <= value <= 248:
            return value
    raise ValueError(
        f"Invalid style {value!r}. Must be an integer from 1 to 48 or 201 to 248."
    )


def _chart_axis_scale(value: Any, name: str, *, positive: bool = False) -> float | None:
    if value is None:
        return None
    if isinstance(value, numbers.Real) and not isinstance(value, bool):
        value = float(value)
        if math.isfinite(value) and (not positive or value > 0):
            return value
    requirement = "a positive finite number" if positive else "a finite number"
    raise ValueError(f"Invalid {name} {value!r}. Must be {requirement} or None.")


def _chart_marker_style(value: Any) -> ChartMarkerStyle:
    if isinstance(value, str) and value in CHART_MARKER_STYLES:
        return cast(ChartMarkerStyle, value)
    raise ValueError(
        f"Invalid marker_style {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in CHART_MARKER_STYLES)}."
    )


def _chart_marker_size(value: Any) -> int:
    if isinstance(value, numbers.Integral) and not isinstance(value, bool):
        value = int(value)
        if 2 <= value <= 72:
            return value
    raise ValueError(f"Invalid marker_size {value!r}. Must be an integer from 2 to 72.")


def _chart_series_name(value: Any) -> str:
    if isinstance(value, str) and len(value) <= 255:
        return value
    raise ValueError(
        f"Invalid series name {value!r}. Must be a string of at most 255 characters."
    )


def _chart_series_color(value: Any, name: str) -> tuple[int, int, int]:
    try:
        return _border_color(value)
    except ValueError:
        raise ValueError(
            f"Invalid {name} {value!r}. Must be an RGB tuple, hex string, or "
            "Excel color integer."
        ) from None


class Chart:
    """The chart object is a member of the `charts` collection:

    ```pycon
    >>> import xlwings as xw
    >>> sheet = xw.books['Book1'].sheets[0]
    >>> sheet.charts[0]  # or sheet.charts['ChartName']
    <Chart 'Chart 1' in Sheet1>
    ```
    """

    def __init__(
        self, name_or_index: str | int | None = None, impl: Any = None
    ) -> None:
        if impl is not None:
            self.impl = impl
        elif name_or_index is not None:
            self.impl = sheets.active.charts(name_or_index).impl
        else:
            self.impl = sheets.active.charts.add().impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    @property
    def name(self) -> str:
        """Returns or sets the name of the chart."""
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    @property
    def parent(self) -> Sheet:
        """Returns the parent of the chart.

        ```{versionadded} 0.9.0
        ```
        """
        # Chart sheet (parent is Book) is not supported
        return Sheet(impl=self.impl.parent)

    @property
    def chart_type(self) -> str:
        """Returns and sets the chart type of the chart.
        The following chart types are available:

        `3d_area`,
        `3d_area_stacked`,
        `3d_area_stacked_100`,
        `3d_bar_clustered`,
        `3d_bar_stacked`,
        `3d_bar_stacked_100`,
        `3d_column`,
        `3d_column_clustered`,
        `3d_column_stacked`,
        `3d_column_stacked_100`,
        `3d_line`,
        `3d_pie`,
        `3d_pie_exploded`,
        `area`,
        `area_stacked`,
        `area_stacked_100`,
        `bar_clustered`,
        `bar_of_pie`,
        `bar_stacked`,
        `bar_stacked_100`,
        `bubble`,
        `bubble_3d_effect`,
        `column_clustered`,
        `column_stacked`,
        `column_stacked_100`,
        `combination`,
        `cone_bar_clustered`,
        `cone_bar_stacked`,
        `cone_bar_stacked_100`,
        `cone_col`,
        `cone_col_clustered`,
        `cone_col_stacked`,
        `cone_col_stacked_100`,
        `cylinder_bar_clustered`,
        `cylinder_bar_stacked`,
        `cylinder_bar_stacked_100`,
        `cylinder_col`,
        `cylinder_col_clustered`,
        `cylinder_col_stacked`,
        `cylinder_col_stacked_100`,
        `doughnut`,
        `doughnut_exploded`,
        `line`,
        `line_markers`,
        `line_markers_stacked`,
        `line_markers_stacked_100`,
        `line_stacked`,
        `line_stacked_100`,
        `pie`,
        `pie_exploded`,
        `pie_of_pie`,
        `pyramid_bar_clustered`,
        `pyramid_bar_stacked`,
        `pyramid_bar_stacked_100`,
        `pyramid_col`,
        `pyramid_col_clustered`,
        `pyramid_col_stacked`,
        `pyramid_col_stacked_100`,
        `radar`,
        `radar_filled`,
        `radar_markers`,
        `stock_hlc`,
        `stock_ohlc`,
        `stock_vhlc`,
        `stock_vohlc`,
        `surface`,
        `surface_top_view`,
        `surface_top_view_wireframe`,
        `surface_wireframe`,
        `xy_scatter`,
        `xy_scatter_lines`,
        `xy_scatter_lines_no_markers`,
        `xy_scatter_smooth`,
        `xy_scatter_smooth_no_markers`

        ```{versionadded} 0.1.1
        ```
        """
        return self.impl.chart_type

    @chart_type.setter
    def chart_type(self, value: str) -> None:
        self.impl.chart_type = _chart_type(value)

    @property
    def title(self) -> str | None:
        """Returns or sets the chart title. Setting it to `None` hides the title,
        setting it to a string shows it.

        ```pycon
        >>> chart.title = "Sales 2026"
        >>> chart.title = None  # hides the title
        ```

        On xlwings Lite and xlwings Server, reading the title only works after it
        has been set in the same script.

        ```{versionadded} 0.37.3
        ```
        """
        return self.impl.title

    @title.setter
    def title(self, value: str | None) -> None:
        if value is not None and not isinstance(value, str):
            raise ValueError(
                f"Invalid title {value!r}. Must be a string or None to hide it."
            )
        self.impl.title = value

    @property
    def legend(self) -> ChartLegend:
        """Returns the {class}`ChartLegend <xlwings.main.ChartLegend>` of the
        chart.

        ```pycon
        >>> chart.legend.visible = True
        >>> chart.legend.position = "bottom"
        ```

        ```{versionadded} 0.37.3
        ```
        """
        return ChartLegend(impl=self.impl.legend)

    @property
    def category_axis(self) -> ChartAxis:
        """Returns the chart's primary category axis.

        ```{versionadded} 0.37.5
        ```
        """
        return ChartAxis(impl=self.impl.category_axis)

    @property
    def value_axis(self) -> ChartAxis:
        """Returns the chart's primary value axis.

        ```{versionadded} 0.37.5
        ```
        """
        return ChartAxis(impl=self.impl.value_axis)

    @property
    def series(self) -> ChartSeriesCollection:
        """Returns the chart's ordered series collection.

        In xlwings Lite, use {meth}`get_series` before inspecting or indexing
        the collection.

        ```{versionadded} 0.37.5
        ```
        """
        return ChartSeriesCollection(impl=self.impl.series)

    async def get_series(self) -> ChartSeriesCollection:
        """Fetches the chart's current ordered series collection.

        A newly created chart must first be dispatched with `await book.flush()` so Excel can create its series from the source data.

        Requires xlwings Lite.

        ```{versionadded} 0.37.5
        ```
        """
        return ChartSeriesCollection(impl=await self.impl.get_series())

    @property
    def plot_by(self) -> str:
        """Returns or sets whether the data series come from the rows or from the
        columns of the source data: either `"rows"` or `"columns"`.

        On xlwings Lite and xlwings Server, reading it only works after it has
        been set in the same script, either via this property or via
        `set_source_data(plot_by=...)`.

        ```{versionadded} 0.37.3
        ```
        """
        return self.impl.plot_by

    @plot_by.setter
    def plot_by(self, value: ChartPlotBy) -> None:
        self.impl.plot_by = _chart_plot_by(value)

    @property
    def style(self) -> int:
        """Returns or sets the built-in chart style.

        Valid values are the legacy styles from 1 to 48 and the modern styles
        from 201 to 248. The style numbers shown by Excel's chart gallery can
        differ from the values exposed by the object model; use the value
        produced by Excel's macro recorder to reproduce a gallery style.

        On xlwings Lite and xlwings Server, reading it only works after it has
        been set in the same script.

        ```{versionadded} 0.37.3
        ```
        """
        return self.impl.style

    @style.setter
    def style(self, value: int) -> None:
        self.impl.style = _chart_style(value)

    def set_source_data(
        self, source: Range, plot_by: ChartPlotBy | None = None
    ) -> None:
        """Sets the source data range for the chart.

        Args:
            source: Range object, e.g. `xw.books['Book1'].sheets[0].range('A1')`
            plot_by: Whether the data series come from the `"rows"` or from the
                `"columns"` of the source range. Defaults to letting Excel decide.
                *New in version 0.37.3.*
        """
        self.impl.set_source_data(
            source.impl, None if plot_by is None else _chart_plot_by(plot_by)
        )

    def set_x_axis_values(self, source: Range) -> None:
        """Sets the x-axis values (category labels) for every series in the chart.

        This is useful when Excel would otherwise interpret a numeric category
        column as another data series. Create the chart from the value columns,
        then assign the category column separately:

        ```python
        chart = sheet.charts.add(
            source=sheet["B1:B11"],
            chart_type="line",
            plot_by="columns",
        )
        chart.set_x_axis_values(sheet["A2:A11"])
        ```

        Args:
            source: Range containing one x-axis value or category label per data
                point. Do not include the header cell.
        """
        self.impl.set_x_axis_values(source.impl)

    @property
    def left(self) -> float:
        """Returns or sets the number of points that represent the horizontal position
        of the chart.
        """
        return self.impl.left

    @left.setter
    def left(self, value: float) -> None:
        self.impl.left = value

    @property
    def top(self) -> float:
        """Returns or sets the number of points that represent the vertical position
        of the chart.
        """
        return self.impl.top

    @top.setter
    def top(self, value: float) -> None:
        self.impl.top = value

    @property
    def width(self) -> float:
        """Returns or sets the number of points that represent the width of the
        chart.
        """
        return self.impl.width

    @width.setter
    def width(self, value: float) -> None:
        self.impl.width = value

    @property
    def height(self) -> float:
        """Returns or sets the number of points that represent the height of the
        chart.
        """
        return self.impl.height

    @height.setter
    def height(self, value: float) -> None:
        self.impl.height = value

    def delete(self) -> None:
        """Deletes the chart."""
        self.impl.delete()

    def to_png(self, path: str | PathLike[str] | None = None) -> None:
        """Exports the chart as PNG picture.

        Args:
            path: Path where you want to store the picture. Defaults to the name of the
                chart in the same directory as the Excel file if the Excel file is
                stored and to the current working directory otherwise.


        ```{versionadded} 0.24.8
        ```
        """
        path = utils.fspath(path)
        if path is None:
            directory, _ = os.path.split(self.parent.book.fullname)
            if directory:
                path = os.path.join(directory, self.name + ".png")
            else:
                path = str(Path.cwd() / self.name) + ".png"
        self.impl.to_png(path)

    def to_pdf(
        self,
        path: str | PathLike[str] | None = None,
        show: bool | None = None,
        quality: str = "standard",
    ) -> str:
        """Exports the chart as PDF.

        Args:
            path: Path where you want to store the pdf. Defaults to the name of the
                chart in the same directory as the Excel file if the Excel file is
                stored and to the current working directory otherwise.
            show: Once created, open the PDF file with the default application.
            quality: Quality of the PDF file. Can either be `'standard'` or `'minimum'`.

        ```{versionadded} 0.26.2
        ```
        """
        return utils.to_pdf(self, path=path, show=show, quality=quality)

    def __repr__(self) -> str:
        return "<Chart '{0}' in {1}>".format(self.name, self.parent.name)

    async def get_png(self) -> str:
        """Fetch the chart as a base64-encoded PNG, on demand.

        Returns the image data rather than writing a file, which is what
        `to_png()` does.

        Requires xlwings Lite.
        """
        return await self.impl.get_png()


class ChartAxis:
    """A primary chart axis, accessed through {attr}`Chart.category_axis <xlwings.Chart.category_axis>` or {attr}`Chart.value_axis <xlwings.Chart.value_axis>`.

    Use {meth}`set` to change several attributes in one operation. On xlwings Lite, use the asynchronous getters to fetch the current values from Excel.

    ```pycon
    >>> chart = xw.books["Book1"].sheets[0].charts[0]
    >>> chart.value_axis.set(
    ...     title="Revenue", minimum_scale=0, major_unit=10_000
    ... )
    ```

    ```{versionadded} 0.37.5
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native `pywin32` object on Windows."""
        return self.impl.api

    @property
    def title(self) -> str | None:
        """Returns or sets the axis title. Setting it to `None` hides the title; setting it to a string shows the axis and its title."""
        return self.impl.title

    @title.setter
    def title(self, value: str | None) -> None:
        self.set(title=value)

    @property
    def minimum_scale(self) -> float:
        """Returns or sets the minimum scale. Set to `None` to restore Excel's automatic scale; reads return the resolved numeric value."""
        return self.impl.minimum_scale

    @minimum_scale.setter
    def minimum_scale(self, value: float | None) -> None:
        self.set(minimum_scale=value)

    @property
    def maximum_scale(self) -> float:
        """Returns or sets the maximum scale. Set to `None` to restore Excel's automatic scale; reads return the resolved numeric value."""
        return self.impl.maximum_scale

    @maximum_scale.setter
    def maximum_scale(self, value: float | None) -> None:
        self.set(maximum_scale=value)

    @property
    def major_unit(self) -> float:
        """Returns or sets the interval between major tick marks. Set to `None` to restore Excel's automatic interval; reads return the resolved value."""
        return self.impl.major_unit

    @major_unit.setter
    def major_unit(self, value: float | None) -> None:
        self.set(major_unit=value)

    @property
    def number_format(self) -> str:
        """Returns or sets the format code for the axis tick labels."""
        return self.impl.number_format

    @number_format.setter
    def number_format(self, value: str) -> None:
        self.set(number_format=value)

    @property
    def visible(self) -> bool:
        """Returns or sets whether the axis is shown."""
        return self.impl.visible

    @visible.setter
    def visible(self, value: bool) -> None:
        self.set(visible=value)

    def set(
        self,
        *,
        title: str | None = _UNSET,
        minimum_scale: float | None = _UNSET,
        maximum_scale: float | None = _UNSET,
        major_unit: float | None = _UNSET,
        number_format: str = _UNSET,
        visible: bool = _UNSET,
    ) -> None:
        """Sets one or more axis attributes in one operation.

        Only supplied attributes are changed, and all arguments are validated before anything is written. `visible=True` is applied before the other attributes; `visible=False` is applied last so it describes the final state.

        Args:
            title: Axis title, or `None` to hide it.
            minimum_scale: Minimum scale, or `None` for automatic scaling.
            maximum_scale: Maximum scale, or `None` for automatic scaling.
            major_unit: Positive major-unit interval, or `None` for automatic.
            number_format: Format code for the tick labels.
            visible: Whether the axis is shown.
        """
        if title is not _UNSET and title is not None and not isinstance(title, str):
            raise ValueError(
                f"Invalid title {title!r}. Must be a string or None to hide it."
            )
        if minimum_scale is not _UNSET:
            minimum_scale = _chart_axis_scale(minimum_scale, "minimum_scale")
        if maximum_scale is not _UNSET:
            maximum_scale = _chart_axis_scale(maximum_scale, "maximum_scale")
        if major_unit is not _UNSET:
            major_unit = _chart_axis_scale(major_unit, "major_unit", positive=True)
        if number_format is not _UNSET and not isinstance(number_format, str):
            raise ValueError(
                f"Invalid number_format {number_format!r}. Must be a string."
            )
        if visible is not _UNSET and not isinstance(visible, bool):
            raise ValueError(f"Invalid visible {visible!r}. Must be True or False.")
        if all(
            value is _UNSET
            for value in (
                title,
                minimum_scale,
                maximum_scale,
                major_unit,
                number_format,
                visible,
            )
        ):
            return
        self.impl.set(
            title=title,
            minimum_scale=minimum_scale,
            maximum_scale=maximum_scale,
            major_unit=major_unit,
            number_format=number_format,
            visible=visible,
        )

    async def get_title(self) -> str | None:
        """Fetches the axis title. Returns `None` if the axis or title is hidden.

        Requires xlwings Lite.
        """
        return await self.impl.get_title()

    async def get_minimum_scale(self) -> float:
        """Fetches the resolved minimum scale.

        Requires xlwings Lite.
        """
        return await self.impl.get_minimum_scale()

    async def get_maximum_scale(self) -> float:
        """Fetches the resolved maximum scale.

        Requires xlwings Lite.
        """
        return await self.impl.get_maximum_scale()

    async def get_major_unit(self) -> float:
        """Fetches the resolved major-unit interval.

        Requires xlwings Lite.
        """
        return await self.impl.get_major_unit()

    async def get_number_format(self) -> str:
        """Fetches the tick-label number format.

        Requires xlwings Lite.
        """
        return await self.impl.get_number_format()

    async def get_visible(self) -> bool:
        """Fetches whether the axis is shown.

        Requires xlwings Lite.
        """
        return await self.impl.get_visible()

    def __repr__(self) -> str:
        return "<ChartAxis>"


class ChartSeries:
    """A chart data series.

    {attr}`Chart.series <xlwings.Chart.series>` and {meth}`Chart.get_series <xlwings.Chart.get_series>` return a {class}`ChartSeriesCollection <xlwings.main.ChartSeriesCollection>`. Indexing or iterating that collection returns `ChartSeries` objects.

    Use {meth}`set` to change several attributes in one operation. On xlwings Lite, use the asynchronous getters to fetch current values from Excel.

    ```pycon
    >>> chart = xw.books["Book1"].sheets[0].charts[0]
    >>> series = chart.series[0]
    >>> series.set(name="Revenue", marker_style="circle", marker_size=8)
    ```

    ```{versionadded} 0.37.5
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native `pywin32` or `appscript` series object."""
        return self.impl.api

    @property
    def name(self) -> str:
        """Returns or sets the displayed series name."""
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.set(name=value)

    @property
    def marker_style(self) -> ChartMarkerStyle:
        """Returns or sets the marker style."""
        return self.impl.marker_style

    @marker_style.setter
    def marker_style(self, value: ChartMarkerStyle) -> None:
        self.set(marker_style=value)

    @property
    def marker_size(self) -> int:
        """Returns or sets the marker size in points, from 2 through 72."""
        return self.impl.marker_size

    @marker_size.setter
    def marker_size(self, value: int) -> None:
        self.set(marker_size=value)

    @property
    def marker_foreground_color(self) -> tuple[int, int, int] | None:
        """Returns or sets the marker foreground color."""
        return self.impl.marker_foreground_color

    @marker_foreground_color.setter
    def marker_foreground_color(self, value: tuple[int, int, int] | str | int) -> None:
        self.set(marker_foreground_color=value)

    @property
    def marker_background_color(self) -> tuple[int, int, int] | None:
        """Returns or sets the marker background color."""
        return self.impl.marker_background_color

    @marker_background_color.setter
    def marker_background_color(self, value: tuple[int, int, int] | str | int) -> None:
        self.set(marker_background_color=value)

    @property
    def line_color(self) -> tuple[int, int, int] | None:
        """Returns or sets the series line color."""
        return self.impl.line_color

    @line_color.setter
    def line_color(self, value: tuple[int, int, int] | str | int) -> None:
        self.set(line_color=value)

    @property
    def fill_color(self) -> tuple[int, int, int] | None:
        """Returns or sets the solid series fill color."""
        return self.impl.fill_color

    @fill_color.setter
    def fill_color(self, value: tuple[int, int, int] | str | int) -> None:
        self.set(fill_color=value)

    def set(
        self,
        *,
        name: str = _UNSET,
        marker_style: ChartMarkerStyle = _UNSET,
        marker_size: int = _UNSET,
        marker_foreground_color: tuple[int, int, int] | str | int = _UNSET,
        marker_background_color: tuple[int, int, int] | str | int = _UNSET,
        line_color: tuple[int, int, int] | str | int = _UNSET,
        fill_color: tuple[int, int, int] | str | int = _UNSET,
    ) -> None:
        """Sets one or more series attributes in one operation.

        Only supplied attributes are changed, and all arguments are validated
        before anything is written.
        """
        if name is not _UNSET:
            name = _chart_series_name(name)
        if marker_style is not _UNSET:
            marker_style = _chart_marker_style(marker_style)
        if marker_size is not _UNSET:
            marker_size = _chart_marker_size(marker_size)
        for attribute in (
            "marker_foreground_color",
            "marker_background_color",
            "line_color",
            "fill_color",
        ):
            value = locals()[attribute]
            if value is not _UNSET:
                normalized = _chart_series_color(value, attribute)
                if attribute == "marker_foreground_color":
                    marker_foreground_color = normalized
                elif attribute == "marker_background_color":
                    marker_background_color = normalized
                elif attribute == "line_color":
                    line_color = normalized
                else:
                    fill_color = normalized
        if all(
            value is _UNSET
            for value in (
                name,
                marker_style,
                marker_size,
                marker_foreground_color,
                marker_background_color,
                line_color,
                fill_color,
            )
        ):
            return
        self.impl.set(
            name=name,
            marker_style=marker_style,
            marker_size=marker_size,
            marker_foreground_color=marker_foreground_color,
            marker_background_color=marker_background_color,
            line_color=line_color,
            fill_color=fill_color,
        )

    async def get_name(self) -> str:
        """Fetches the displayed series name.

        Requires xlwings Lite.
        """
        return await self.impl.get_name()

    async def get_marker_style(self) -> ChartMarkerStyle:
        """Fetches the marker style.

        Requires xlwings Lite.
        """
        return await self.impl.get_marker_style()

    async def get_marker_size(self) -> int:
        """Fetches the marker size.

        Requires xlwings Lite.
        """
        return await self.impl.get_marker_size()

    async def get_marker_foreground_color(self) -> tuple[int, int, int] | None:
        """Fetches the marker foreground color.

        Requires xlwings Lite.
        """
        return await self.impl.get_marker_foreground_color()

    async def get_marker_background_color(self) -> tuple[int, int, int] | None:
        """Fetches the marker background color.

        Requires xlwings Lite.
        """
        return await self.impl.get_marker_background_color()

    async def get_line_color(self) -> tuple[int, int, int] | None:
        """Fetches the series line color.

        Requires xlwings Lite.
        """
        return await self.impl.get_line_color()

    async def get_fill_color(self) -> tuple[int, int, int] | None:
        """Fetches the solid series fill color.

        Requires xlwings Lite.
        """
        return await self.impl.get_fill_color()

    def __repr__(self) -> str:
        return "<ChartSeries>"


class ChartSeriesCollection(Collection[ChartSeries]):
    """An ordered, integer-indexed collection of chart series.

    Series names aren't unique in Excel, so string lookup isn't supported.

    ```pycon
    >>> chart = xw.books["Book1"].sheets[0].charts[0]
    >>> series = chart.series
    >>> len(series)
    2
    >>> series[0].set(name="Revenue", marker_style="circle", marker_size=8)
    ```

    In xlwings Lite, use `series = await chart.get_series()` instead of `chart.series`.

    ```{versionadded} 0.37.5
    ```
    """

    _wrap = ChartSeries


class ChartLegend:
    """The legend of a chart, accessed via `mychart.legend`:

    ```pycon
    >>> chart = xw.books['Book1'].sheets[0].charts[0]
    >>> chart.legend.position = "bottom"
    >>> chart.legend.visible = False
    ```

    ```{versionadded} 0.37.3
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def visible(self) -> bool:
        """Returns or sets whether the legend is shown.

        On xlwings Lite and xlwings Server, reading it only works after it has
        been set in the same script.
        """
        return self.impl.visible

    @visible.setter
    def visible(self, value: bool) -> None:
        self.impl.visible = bool(value)

    @property
    def position(self) -> str | None:
        """Returns or sets the position of the legend: `"top"`, `"bottom"`,
        `"left"`, `"right"` or `"corner"`. Returns `None` if the legend is hidden.
        Setting a position shows the legend.

        On xlwings Lite and xlwings Server, reading it only works after it has
        been set in the same script.
        """
        return self.impl.position

    @position.setter
    def position(self, value: ChartLegendPosition) -> None:
        self.impl.position = _chart_legend_position(value)

    def __repr__(self) -> str:
        return "<ChartLegend>"


class Charts(Collection[Chart]):
    """A collection of all `chart` objects on the specified sheet:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books['Book1'].sheets[0].charts
    Charts([<Chart 'Chart 1' in Sheet1>,
            <Chart 'Chart 1' in Sheet1>])
    ```

    ```{versionadded} 0.9.0
    ```
    """

    _wrap = Chart

    @property
    def parent(self) -> Sheet:
        return Sheet(impl=self.impl.parent)

    def add(
        self,
        left: float = 0,
        top: float = 0,
        width: float = 355,
        height: float = 211,
        chart_type: str | None = None,
        source: Range | None = None,
        plot_by: ChartPlotBy | None = None,
        name: str | None = None,
        anchor: Range | None = None,
        style: int | None = 227,
    ) -> Chart:
        """Creates a new chart on the specified sheet.

        Args:
            left: left position in points. If you use `top`/`left`, you must not
                provide a value for `anchor`.
            top: top position in points. If you use `top`/`left`, you must not
                provide a value for `anchor`.
            width: width in points
            height: height in points
            chart_type: Chart type, see
                {attr}`Chart.chart_type <xlwings.Chart.chart_type>`.
                *New in version 0.37.3.*
            source: Source data range, see
                {meth}`Chart.set_source_data <xlwings.Chart.set_source_data>`.
                *New in version 0.37.3.*
            plot_by: `"rows"` or `"columns"`, requires `source`.
                *New in version 0.37.3.*
            name: Excel chart name. Defaults to Excel standard name if not provided,
                e.g., 'Chart 1'. *New in version 0.37.3.*
            anchor: The xlwings Range object of where you want to insert the chart.
                If you use `anchor`, you must not provide values for `top`/`left`.
                *New in version 0.37.3.*
            style: Built-in chart style. Defaults to the modern Excel style 227.
                Use `None` to retain the host application's native creation
                default. See {attr}`Chart.style <xlwings.Chart.style>`.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> sheet = xw.Book().sheets[0]
            >>> sheet.range('A1').value = [['Foo1', 'Foo2'], [1, 2]]
            >>> chart = sheet.charts.add(
            ...     source=sheet.range('A1').expand(),
            ...     chart_type='line',
            ...     anchor=sheet.range('D1'),
            ... )
            >>> chart.title = 'My chart'
            ```

            The same in steps:

            ```pycon
            >>> chart = sheet.charts.add()
            >>> chart.set_source_data(sheet.range('A1').expand())
            >>> chart.chart_type = 'line'
            >>> chart.name
            'Chart 1'
            ```
        """
        if anchor:
            if top or left:
                raise ValueError(
                    "You must either provide 'anchor' or 'top'/'left', but not both."
                )
        if chart_type is not None:
            chart_type = _chart_type(chart_type)
        if style is not None:
            style = _chart_style(style)
        if plot_by is not None:
            if source is None:
                raise ValueError("'plot_by' requires 'source'.")
            plot_by = _chart_plot_by(plot_by)
        if name and name in self:
            raise ShapeAlreadyExists(
                f"'{name}' is already present on {self.parent.name}."
            )

        impl = self.impl.add(
            left,
            top,
            width,
            height,
            chart_type=chart_type,
            source=None if source is None else source.impl,
            plot_by=plot_by,
            name=name,
            anchor=anchor,
            style=style,
        )

        return Chart(impl=impl)


def _pivot_function(value: Any) -> PivotFunction:
    if isinstance(value, str) and str(value) in PIVOT_FUNCTIONS:
        return cast(PivotFunction, str(value))
    raise ValueError(
        f"Invalid function {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in PIVOT_FUNCTIONS)}."
    )


def _pivot_layout(value: Any) -> PivotLayout:
    if isinstance(value, str) and str(value) in PIVOT_LAYOUTS:
        return cast(PivotLayout, str(value))
    raise ValueError(
        f"Invalid layout {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in PIVOT_LAYOUTS)}."
    )


def _pivot_field_list(value: Any, what: str) -> list[str]:
    """Normalize the rows/columns/filters arguments of PivotTables.add()."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    names = list(value)
    for name in names:
        if not isinstance(name, str):
            raise TypeError(f"'{what}' must be a field name or a list of field names.")
    return names


def _pivot_value_specs(values: Any) -> list[tuple[str, PivotFunction | None]]:
    """Normalize the `values` argument of PivotTables.add() into
    (field, function) tuples."""
    if values is None:
        return []
    if isinstance(values, str):
        return [(values, None)]
    if isinstance(values, Mapping):
        items = list(values.items())
    else:
        items = []
        for item in values:
            if isinstance(item, str):
                items.append((item, None))
            else:
                try:
                    field, function = item
                except (TypeError, ValueError):
                    raise TypeError(
                        "'values' must be a field name, a list of field names or "
                        "(field, function) tuples, or a {field: function} mapping."
                    ) from None
                items.append((field, function))
    for field, _ in items:
        if not isinstance(field, str):
            raise TypeError("The field name must be a string.")
    return [
        (field, None if function is None else _pivot_function(function))
        for field, function in items
    ]


class PivotTable:
    """The pivot table object is a member of the
    {attr}`pivot_tables <xlwings.Sheet.pivot_tables>` collection:

    ```pycon
    >>> import xlwings as xw
    >>> mysheet = xw.books['Book1'].sheets[0]
    >>> mysheet.pivot_tables[0]  # or mysheet.pivot_tables['PivotTable1']
    <PivotTable 'PivotTable1' in Sheet1>
    ```

    Fields are placed via the four areas of Excel's field list, see
    {attr}`rows <xlwings.PivotTable.rows>`,
    {attr}`columns <xlwings.PivotTable.columns>`,
    {attr}`filters <xlwings.PivotTable.filters>` and
    {attr}`values <xlwings.PivotTable.values>`:

    ```pycon
    >>> pt = mysheet.pivot_tables['PivotTable1']
    >>> pt.rows.add('Region')
    >>> pt.values.add('Sales', function='sum', number_format='#,##0')
    >>> pt.layout = 'tabular'
    >>> pt.refresh()
    ```

    ```{versionadded} 0.37.3
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def parent(self) -> Sheet:
        """Returns the sheet the pivot table is on."""
        return Sheet(impl=self.impl.parent)

    @property
    def name(self) -> str:
        """Returns or sets the name of the pivot table."""
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    @property
    def field_names(self) -> list[str]:
        """The names of the source fields (the column headers of the source
        data), i.e. what can be passed to `rows.add()`, `columns.add()`,
        `filters.add()` and `values.add()`.
        """
        return list(self.impl.field_names)

    @property
    def rows(self) -> PivotFields:
        """The fields in the *Rows* area, see
        {class}`PivotFields <xlwings.PivotFields>`.
        """
        return PivotFields(impl=self.impl.rows)

    @property
    def columns(self) -> PivotFields:
        """The fields in the *Columns* area, see
        {class}`PivotFields <xlwings.PivotFields>`.
        """
        return PivotFields(impl=self.impl.columns)

    @property
    def filters(self) -> PivotFields:
        """The fields in the *Filters* area, see
        {class}`PivotFields <xlwings.PivotFields>`.
        """
        return PivotFields(impl=self.impl.filters)

    @property
    def values(self) -> PivotValueFields:
        """The fields in the *Values* area, see
        {class}`PivotValueFields <xlwings.PivotValueFields>`.
        """
        return PivotValueFields(impl=self.impl.values)

    @property
    def layout(self) -> PivotLayout | None:
        """Returns or sets the report layout: `"compact"`, `"outline"` or
        `"tabular"`. Returns `None` if the row fields use mixed layouts.

        On xlwings Lite and xlwings Server, reading it returns the layout as it
        was when the script started, or the value set in the same script.
        """
        return self.impl.layout

    @layout.setter
    def layout(self, value: PivotLayout) -> None:
        self.impl.layout = _pivot_layout(value)

    @property
    def show_row_grand_totals(self) -> bool:
        """Returns or sets whether the grand totals for rows are shown."""
        return self.impl.show_row_grand_totals

    @show_row_grand_totals.setter
    def show_row_grand_totals(self, value: bool) -> None:
        self.impl.show_row_grand_totals = bool(value)

    @property
    def show_column_grand_totals(self) -> bool:
        """Returns or sets whether the grand totals for columns are shown."""
        return self.impl.show_column_grand_totals

    @show_column_grand_totals.setter
    def show_column_grand_totals(self, value: bool) -> None:
        self.impl.show_column_grand_totals = bool(value)

    @property
    def range(self) -> Range:
        """The range of the pivot table report, excluding the filters area.

        In xlwings Lite, use `await get_range()`.
        """
        return Range(impl=self.impl.range)

    async def get_range(self) -> Range:
        """Fetch the current pivot table report range, excluding the filters area.

        Not available on xlwings Server.
        """
        return Range(impl=await self.impl.get_range())

    @property
    def data_body_range(self) -> Range | None:
        """The range of the values area, or `None` if the pivot table has no value fields.

        In xlwings Lite, use `await get_data_body_range()`.
        """
        impl = self.impl.data_body_range
        return Range(impl=impl) if impl is not None else None

    async def get_data_body_range(self) -> Range | None:
        """Fetch the current values area, or `None` if the pivot table has no value fields.

        Not available on xlwings Server.
        """
        impl = await self.impl.get_data_body_range()
        return Range(impl=impl) if impl is not None else None

    def refresh(self) -> None:
        """Refreshes the pivot table from its source data."""
        self.impl.refresh()

    def delete(self) -> None:
        """Deletes the pivot table."""
        self.impl.delete()

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, PivotTable)
            and other.parent == self.parent
            and other.name == self.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        return "<PivotTable '{0}' in {1}>".format(self.name, self.parent.name)


class PivotField:
    """A source field placed in the *Rows*, *Columns* or *Filters* area of a
    pivot table, accessed via the {class}`PivotFields <xlwings.PivotFields>`
    collections:

    ```pycon
    >>> pt = xw.books['Book1'].sheets[0].pivot_tables[0]
    >>> field = pt.rows.add('Region')
    >>> field.name
    'Region'
    >>> field.parent
    <PivotTable 'PivotTable1' in Sheet1>
    >>> field.remove()
    ```

    ```{versionadded} 0.37.3
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def parent(self) -> PivotTable:
        """Returns the pivot table the field belongs to."""
        return PivotTable(impl=self.impl.parent)

    @property
    def name(self) -> str:
        """The name of the source field."""
        return self.impl.name

    def remove(self) -> None:
        """Removes the field from its area."""
        self.impl.remove()

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, PivotField)
            and other.parent == self.parent
            and other.name == self.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        return "<PivotField '{0}' in '{1}'>".format(self.name, self.parent.name)


class PivotFields(Collection[PivotField]):
    """The fields in one area of a pivot table, i.e. `pt.rows`, `pt.columns`
    or `pt.filters`. Iteration follows the field order.

    ```pycon
    >>> pt = xw.books['Book1'].sheets[0].pivot_tables[0]
    >>> pt.rows
    PivotFields([<PivotField 'Region' in 'PivotTable1'>])
    >>> pt.rows[0]  # or pt.rows['Region']
    <PivotField 'Region' in 'PivotTable1'>
    ```

    ```{versionadded} 0.37.3
    ```
    """

    _wrap = PivotField

    @property
    def parent(self) -> PivotTable:
        """Returns the pivot table the area belongs to."""
        return PivotTable(impl=self.impl.parent)

    def add(self, name: str) -> PivotField:
        """Places a source field in this area, after the existing fields.

        A field that is already in this area stays where it is; a field in
        another of the rows/columns/filters areas is moved here.

        Args:
            name: Name of the source field, see
                {attr}`PivotTable.field_names <xlwings.PivotTable.field_names>`.
        """
        if not isinstance(name, str):
            raise TypeError("The field name must be a string.")
        return PivotField(impl=self.impl.add(name))


class PivotValueField:
    """A field in the *Values* area of a pivot table, accessed via {class}`PivotValueFields <xlwings.PivotValueFields>`:

    ```pycon
    >>> pt = xw.books['Book1'].sheets[0].pivot_tables[0]
    >>> value_field = pt.values.add('Sales')
    >>> value_field.name, value_field.function
    ('Sum of Sales', 'sum')
    >>> value_field.function = 'average'
    >>> value_field.number_format = '#,##0.00'
    >>> value_field.name = 'Average Sales'
    >>> pt.values['Average Sales'].source_field
    'Sales'
    ```

    ```{versionadded} 0.37.3
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.
        """
        return self.impl.api

    @property
    def parent(self) -> PivotTable:
        """Returns the pivot table the field belongs to."""
        return PivotTable(impl=self.impl.parent)

    @property
    def name(self) -> str:
        """Returns or sets the caption, e.g. `"Sum of Sales"`. Excel rejects a
        name that equals the name of a source field.

        On xlwings Lite and xlwings Server, reading it only works for value
        fields that already existed when the script started or if the name
        was set in the same script. The automatic caption of a value field
        added in the same script can't be read.
        """
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    @property
    def source_field(self) -> str:
        """The name of the source field this value field summarizes."""
        return self.impl.source_field

    @property
    def function(self) -> PivotFunction | None:
        """Returns or sets the summary function: `"sum"`, `"count"`,
        `"average"`, `"max"`, `"min"`, `"product"`, `"count_numbers"`,
        `"stdev"`, `"stdevp"`, `"var"` or `"varp"`. Returns `None` if the
        engine only knows that Excel picked the default.
        """
        return self.impl.function

    @function.setter
    def function(self, value: PivotFunction) -> None:
        self.impl.function = _pivot_function(value)

    @property
    def number_format(self) -> str:
        """Returns or sets the number format of the value field.

        On xlwings Lite and xlwings Server, reading it only works for value
        fields that already existed when the script started or if the format
        was set in the same script.
        """
        return self.impl.number_format

    @number_format.setter
    def number_format(self, value: str) -> None:
        self.impl.number_format = value

    def remove(self) -> None:
        """Removes the field from the values area."""
        self.impl.remove()

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, PivotValueField)
            and other.parent == self.parent
            and other.name == self.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        try:
            name = self.name
        except NotImplementedError:
            name = "?"
        return "<PivotValueField '{0}' in '{1}'>".format(name, self.parent.name)


class PivotValueFields(Collection[PivotValueField]):
    """The fields in the *Values* area of a pivot table, i.e. `pt.values`.
    Iteration follows the field order.

    ```pycon
    >>> pt = xw.books['Book1'].sheets[0].pivot_tables[0]
    >>> pt.values
    PivotValueFields([<PivotValueField 'Sum of Sales' in 'PivotTable1'>])
    >>> pt.values[0]  # or pt.values['Sum of Sales']
    <PivotValueField 'Sum of Sales' in 'PivotTable1'>
    ```

    ```{versionadded} 0.37.3
    ```
    """

    _wrap = PivotValueField

    @property
    def parent(self) -> PivotTable:
        """Returns the pivot table the area belongs to."""
        return PivotTable(impl=self.impl.parent)

    def add(
        self,
        field: str,
        function: PivotFunction | None = None,
        name: str | None = None,
        number_format: str | None = None,
    ) -> PivotValueField:
        """Adds a source field to the values area, after the existing value
        fields. The same source field can be added more than once, e.g. as a
        sum and as a count.

        Args:
            field: Name of the source field, see
                {attr}`PivotTable.field_names <xlwings.PivotTable.field_names>`.
            function: Summary function, see
                {attr}`PivotValueField.function <xlwings.PivotValueField.function>`.
                Defaults to Excel's choice: `"sum"` for numeric fields,
                `"count"` otherwise.
            name: Caption, e.g. `"Total Sales"`. Defaults to Excel's caption,
                e.g. `"Sum of Sales"`. Excel rejects a name that equals the
                name of a source field.
            number_format: Number format, e.g. `"#,##0.00"`.
        """
        if not isinstance(field, str):
            raise TypeError("The field name must be a string.")
        if function is not None:
            function = _pivot_function(function)
        return PivotValueField(
            impl=self.impl.add(
                field, function=function, name=name, number_format=number_format
            )
        )


class PivotTables(Collection[PivotTable]):
    """A collection of all {class}`PivotTable <xlwings.PivotTable>`
    objects on the specified sheet:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books['Book1'].sheets[0].pivot_tables
    PivotTables([<PivotTable 'PivotTable1' in Sheet1>])
    ```

    ```{versionadded} 0.37.3
    ```
    """

    _wrap = PivotTable

    @property
    def parent(self) -> Sheet:
        """Returns the sheet the collection belongs to."""
        return Sheet(impl=self.impl.parent)

    def add(
        self,
        source: Range | Table,
        destination: Range,
        name: str | None = None,
        rows: str | list[str] | None = None,
        columns: str | list[str] | None = None,
        filters: str | list[str] | None = None,
        values: (
            str
            | list[str | tuple[str, PivotFunction | None]]
            | dict[str, PivotFunction | None]
            | None
        ) = None,
        layout: PivotLayout | None = None,
    ) -> PivotTable:
        """Creates a pivot table on the sheet of this collection.

        On macOS, only the first pivot table on a sheet can be created; a
        second one on the same sheet raises `NotImplementedError`. Existing
        pivot tables can be modified without that restriction.

        Args:
            source: The source data, either a range including the header row
                or a {class}`Table <xlwings.main.Table>`. Can be on another sheet.
                On xlwings Lite, `expand()` doesn't see values written in the
                same script until you run `await book.flush()` followed by
                `await sheet.load()`; on xlwings Server, spell out the range.
            destination: The cell where the top-left corner of the pivot
                table goes. Must be on the sheet of this collection.
            name: Name of the pivot table. Defaults to Excel's standard
                name, e.g. `"PivotTable1"`.
            rows: Field name(s) for the *Rows* area.
            columns: Field name(s) for the *Columns* area.
            filters: Field name(s) for the *Filters* area.
            values: Field name(s) for the *Values* area. Use a mapping
                (`{"Sales": "sum"}`) or `(field, function)` tuples to pick the
                summary function; `None` keeps Excel's default. The same field
                can only be listed twice via tuples, see
                {meth}`PivotValueFields.add <xlwings.PivotValueFields.add>`.
            layout: `"compact"`, `"outline"` or `"tabular"`.

        Examples:
            ```pycon
            >>> import xlwings as xw
            >>> book = xw.Book()
            >>> data = book.sheets[0]
            >>> report = book.sheets.add('Report', after=data)
            >>> data['A1'].value = [['Region', 'Year', 'Sales'],
            ...                     ['North', 2023, 100], ['South', 2024, 200]]
            >>> pt = report.pivot_tables.add(
            ...     source=data['A1:C3'],
            ...     destination=report['A3'],
            ...     rows='Region',
            ...     columns='Year',
            ...     values={'Sales': 'sum'},
            ... )
            >>> pt.values[0].number_format = '#,##0'
            ```

            The same in steps:

            ```pycon
            >>> pt = report.pivot_tables.add(data['A1:C3'], report['A3'])
            >>> pt.rows.add('Region')
            >>> pt.columns.add('Year')
            >>> pt.values.add('Sales', function='sum', number_format='#,##0')
            ```
        """
        if not isinstance(source, (Range, Table)):
            raise TypeError("'source' must be a Range or a Table.")
        if not isinstance(destination, Range):
            raise TypeError("'destination' must be a Range.")
        if destination.sheet != self.parent:
            raise ValueError(
                "'destination' must be on the sheet of this collection "
                f"({self.parent.name!r}), not on {destination.sheet.name!r}."
            )
        if isinstance(source, Range) and source.shape == (1, 1):
            raise ValueError(
                f"'source' must cover the header row and the data, but is the "
                f"single cell {source.address}. On xlwings Lite, expand() only "
                "sees values written in the same script after 'await "
                "book.flush()' and 'await sheet.load()'; on xlwings Server, use "
                "an explicit range."
            )
        rows = _pivot_field_list(rows, "rows")
        columns = _pivot_field_list(columns, "columns")
        filters = _pivot_field_list(filters, "filters")
        value_specs = _pivot_value_specs(values)
        if layout is not None:
            layout = _pivot_layout(layout)
        if name and name in self:
            raise XlwingsError(
                f"A pivot table named {name!r} already exists on {self.parent.name!r}."
            )

        impl = self.impl.add(
            source=source.impl, destination=destination.impl, name=name
        )
        pt = PivotTable(impl=impl)
        for field in rows:
            pt.rows.add(field)
        for field in columns:
            pt.columns.add(field)
        for field in filters:
            pt.filters.add(field)
        for field, function in value_specs:
            pt.values.add(field, function=function)
        if layout is not None:
            pt.layout = layout
        return pt


class Picture:
    """The picture object is a member of the `pictures`
    collection:

    ```pycon
    >>> import xlwings as xw
    >>> sheet = xw.books['Book1'].sheets[0]
    >>> sheet.pictures[0]  # or sheet.charts['PictureName']
    <Picture 'Picture 1' in Sheet1>
    ```

    ```{versionchanged} 0.9.0
    ```
    """

    def __init__(self, impl: Any = None) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj) of the engine
        being used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    @property
    def parent(self) -> Sheet:
        """Returns the parent of the picture.

        ```{versionadded} 0.9.0
        ```
        """
        return Sheet(impl=self.impl.parent)

    @property
    def name(self) -> str:
        """Returns or sets the name of the picture.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        if value in self.parent.pictures:
            if value == self.name:
                return
            else:
                raise ShapeAlreadyExists(
                    f"'{value}' is already present on {self.parent.name}."
                )

        self.impl.name = value

    @property
    def left(self) -> float:
        """Returns or sets the number of points that represent the horizontal position
        of the picture.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.left

    @left.setter
    def left(self, value: float) -> None:
        self.impl.left = value

    @property
    def top(self) -> float:
        """Returns or sets the number of points that represent the vertical position
        of the picture.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.top

    @top.setter
    def top(self, value: float) -> None:
        self.impl.top = value

    @property
    def width(self) -> float:
        """Returns or sets the number of points that represent the width of the picture.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.width

    @width.setter
    def width(self, value: float) -> None:
        self.impl.width = value

    @property
    def height(self) -> float:
        """Returns or sets the number of points that represent the height of the
        picture.

        ```{versionadded} 0.5.0
        ```
        """
        return self.impl.height

    @height.setter
    def height(self, value: float) -> None:
        self.impl.height = value

    def delete(self) -> None:
        """Deletes the picture.

        ```{versionadded} 0.5.0
        ```
        """
        self.impl.delete()

    def __eq__(self, other: object) -> bool:
        return (
            isinstance(other, Picture)
            and other.parent == self.parent
            and other.name == self.name
        )

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __repr__(self) -> str:
        return "<Picture '{0}' in {1}>".format(self.name, self.parent.name)

    def update(
        self,
        image: str | PathLike[str] | Any,
        format: str | None = None,
        export_options: dict[str, Any] | None = None,
    ) -> Picture:
        """Replaces an existing picture with a new one, taking over the attributes of
        the existing picture.

        Args:
            image: Either a filepath or a Matplotlib figure object.
            format: See under `Pictures.add()`
            export_options: See under `Pictures.add()`

        ```{versionadded} 0.5.0
        ```
        """

        filename, is_temp_file = utils.process_image(
            image,
            format="png" if not format else format,
            export_options=export_options,
        )

        picture = Picture(impl=self.impl.update(filename))

        # Cleanup temp file
        if is_temp_file:
            try:
                os.unlink(filename)
            except:  # noqa: E722
                pass

        return picture

    @property
    def lock_aspect_ratio(self) -> bool:
        """`True` will keep the original proportion,
        `False` will allow you to change height and width independently of each other
        (read/write).

        ```{versionadded} 0.24.0
        ```
        """
        return self.impl.lock_aspect_ratio

    @lock_aspect_ratio.setter
    def lock_aspect_ratio(self, value: bool) -> None:
        self.impl.lock_aspect_ratio = value


class Pictures(Collection[Picture]):
    """A collection of all `picture` objects on the specified sheet:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books['Book1'].sheets[0].pictures
    Pictures([<Picture 'Picture 1' in Sheet1>,
              <Picture 'Picture 2' in Sheet1>])
    ```

    ```{versionadded} 0.9.0
    ```
    """

    _wrap = Picture

    @property
    def parent(self) -> Sheet:
        return Sheet(impl=self.impl.parent)

    def add(
        self,
        image: str | PathLike[str] | Any,
        link_to_file: bool = False,
        save_with_document: bool = True,
        left: float | None = None,
        top: float | None = None,
        width: float | None = None,
        height: float | None = None,
        name: str | None = None,
        update: bool = False,
        scale: float | None = None,
        format: str | None = None,
        anchor: Range | None = None,
        export_options: dict[str, Any] | None = None,
    ) -> Picture:
        """Adds a picture to the specified sheet.

        Args:
            image: Either a filepath or a Matplotlib figure object.
            left: Left position in points, defaults to 0. If you use `top`/`left`, you
                must not provide a value for `anchor`.
            top: Top position in points, defaults to 0. If you use `top`/`left`,
                you must not provide a value for `anchor`.
            width: Width in points. Defaults to original width.
            height: Height in points. Defaults to original height.
            name: Excel picture name. Defaults to Excel standard name if not provided,
                e.g., 'Picture 1'.
            update: Replace an existing picture with the same name. Requires `name` to
                be set.
            scale: Scales your picture by the provided factor.
            format: Only used if image is a Matplotlib or Plotly plot. By default, the
                plot is inserted in the "png" format, but you may want to change this to
                a vector-based format like "svg" on Windows (may require Microsoft 365)
                or "eps" on macOS for better print quality. If you use `'vector'`, it
                will be using `'svg'` on Windows and `'eps'` on macOS. To find out which
                formats your version of Excel supports, see:
                https://support.microsoft.com/en-us/topic/support-for-eps-images-has-been-turned-off-in-office-a069d664-4bcf-415e-a1b5-cbb0c334a840
            anchor: The xlwings Range object of where you want to insert the picture. If
                you use `anchor`, you must not provide values for `top`/`left`.
                *New in version 0.24.3.*
            export_options: For Matplotlib plots, this dictionary is passed on to
                `image.savefig()` with the following defaults:
                `{"bbox_inches": "tight", "dpi": 200}`, so if you want to leave the
                picture uncropped and increase dpi to 300, use:
                `export_options={"dpi": 300}`. For Plotly, the options are passed to
                `write_image()`. *New in version 0.27.7.*

        Examples:
            1. Picture

            ```pycon
            >>> import xlwings as xw
            >>> sheet = xw.Book().sheets[0]
            >>> sheet.pictures.add(r'C:\\path\\to\\file.png')
            <Picture 'Picture 1' in Sheet1>
            ```

            2. Matplotlib

            ```pycon
            >>> import matplotlib.pyplot as plt
            >>> fig = plt.figure()
            >>> plt.plot([1, 2, 3, 4, 5])
            >>> sheet.pictures.add(fig, name='MyPlot', update=True)
            <Picture 'MyPlot' in Sheet1>
            ```
        """
        if anchor:
            if top or left:
                raise ValueError(
                    "You must either provide 'anchor' or 'top'/'left', but not both."
                )
        if update:
            if name is None:
                raise ValueError("If update is true then name must be specified")
            else:
                try:
                    pic = self[name]
                    return pic.update(
                        image, format=format, export_options=export_options
                    )
                except KeyError:
                    pass

        if name and name in self.parent.pictures:
            raise ShapeAlreadyExists(
                f"'{name}' is already present on {self.parent.name}."
            )

        filename, is_temp_file = utils.process_image(
            image,
            format="png" if not format else format,
            export_options=export_options,
        )

        if not (link_to_file or save_with_document):
            raise Exception(
                "Arguments link_to_file and save_with_document cannot both be false"
            )

        if (
            (height and width is None)
            or (width and height is None)
            or (width is None and height is None)
        ):
            # If only height or width are provided, it will be scaled after adding it
            # with the original dimensions
            im_width, im_height = -1, -1
        else:
            im_width, im_height = width, height

        picture = Picture(
            impl=self.impl.add(
                filename,
                link_to_file,
                save_with_document,
                left if left else None,
                top if top else None,
                width=im_width,
                height=im_height,
                anchor=anchor,
            )
        )

        if (height and width is None) or (width and height is None):
            # If only height or width are provided, lock aspect ratio so the picture
            # won't be distorted
            picture.lock_aspect_ratio = True
            if height:
                picture.height = height
            else:
                picture.width = width

        if scale:
            self.parent.shapes[picture.name].scale_width(
                factor=scale, relative_to_original_size=True
            )
            self.parent.shapes[picture.name].scale_height(
                factor=scale, relative_to_original_size=True
            )

        if name is not None:
            picture.name = name

        # Cleanup temp file
        if is_temp_file:
            try:
                os.unlink(filename)
            except:  # noqa: E722
                pass
        return picture


class Names:
    """A collection of defined `name` objects in the workbook.

    Excel's internal ``_xlfn.*`` and ``_xlpm.*`` names are excluded. Hidden
    user-defined names remain available. The native collection is unchanged.
    Iteration snapshots name objects so new internal names cannot shift it.

    Examples:

    ```pycon
    >>> import xlwings as xw
    >>> book = xw.books['Book1']  # book scope and sheet scope
    >>> book.names
    [<Name 'MyName': =Sheet1!$A$3>]
    >>> book.sheets[0].names  # sheet scope only
    ```

    ```{versionadded} 0.9.0
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine beingused.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    @staticmethod
    def _is_internal_name(name: str) -> bool:
        return name.rsplit("!", 1)[-1].lower().startswith(("_xlfn.", "_xlpm."))

    def _name_snapshot(self) -> list[Any]:
        return [
            impl
            for name, impl in self.impl.snapshot()
            if not self._is_internal_name(name)
        ]

    def __call__(self, name_or_index: int | str) -> Name:
        if isinstance(name_or_index, numbers.Number):
            if name_or_index < 1:
                raise IndexError("Name indices start at 1")
            return Name(impl=self._name_snapshot()[name_or_index - 1])
        elif self._is_internal_name(name_or_index):
            raise KeyError(name_or_index)
        return Name(impl=self.impl(name_or_index))

    def contains(self, name_or_index: int | str) -> bool:
        if isinstance(name_or_index, numbers.Number):
            return 1 <= name_or_index <= len(self)
        return not self._is_internal_name(name_or_index) and self.impl.contains(
            name_or_index
        )

    def __len__(self) -> int:
        return len(self._name_snapshot())

    @property
    def count(self) -> int:
        """Returns the number of objects in the collection."""
        return len(self)

    def add(self, name: str, refers_to: str) -> Name:
        """Defines a new name for a range, constant, or formula (including a LAMBDA).

        Full support for named constants and formulas requires Excel desktop, xlwings Lite, or xlwings Server. Google Sheets supports named ranges only; Office Scripts only returns named ranges in its snapshot.

        Args:
            name: Specifies the text to use as the name. Names cannot include spaces and
                cannot be formatted as cell references.

            refers_to: Describes what the name refers to, in English, using A1-style
                notation.

        ```{versionadded} 0.9.0
        ```
        """
        return Name(impl=self.impl.add(name, refers_to))

    def __getitem__(self, item: int | str) -> Name:
        if isinstance(item, numbers.Number):
            return Name(impl=self._name_snapshot()[item])
        else:
            return self(item)

    def __setitem__(self, key: str, value: Range | str) -> None:
        if isinstance(value, Range):
            value.name = key
        elif key in self:
            self[key].refers_to = value
        else:
            self.add(key, value)

    def __contains__(self, item: int | str) -> bool:
        if isinstance(item, numbers.Number):
            return 0 <= item < len(self)
        else:
            return self.contains(item)

    def __delitem__(self, key: int | str) -> None:
        if key in self:
            self[key].delete()
        else:
            raise KeyError(key)

    def __iter__(self) -> Iterator[Name]:
        names = self._name_snapshot()
        return (Name(impl=name) for name in names)

    def __repr__(self) -> str:
        r = []
        for i, n in enumerate(self):
            if i == 3:
                r.append("...")
                break
            else:
                r.append(repr(n))
        return "[" + ", ".join(r) + "]"


class Name:
    """The name object is a member of the `names` collection:

    ```pycon
    >>> import xlwings as xw
    >>> sheet = xw.books['Book1'].sheets[0]
    >>> sheet.names[0]  # or sheet.names['MyName']
    <Name 'MyName': =Sheet1!$A$3>
    ```

    ```{versionadded} 0.9.0
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.api

    def delete(self) -> None:
        """Deletes the name.

        ```{versionadded} 0.9.0
        ```
        """
        self.impl.delete()

    @property
    def name(self) -> str:
        """Returns or sets the name of the name object.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    @property
    def refers_to(self) -> str | None:
        """Returns or sets the formula that the name is defined to refer to,
        in A1-style notation, beginning with an equal sign.

        Returns ``None`` when an older remote client supplies neither the
        definition nor single-range coordinates for the name.

        ```{versionadded} 0.9.0
        ```
        """
        return self.impl.refers_to

    @refers_to.setter
    def refers_to(self, value: str) -> None:
        self.impl.refers_to = value

    @property
    def refers_to_range(self) -> Range:
        """Returns the Range object referred to by a Name object.

        ```{versionadded} 0.9.0
        ```
        """
        return Range(impl=self.impl.refers_to_range)

    def __repr__(self) -> str:
        return "<Name '%s': %s>" % (self.name, self.refers_to)

    def __eq__(self, other: object) -> bool:
        return (
            type(other) is Name
            and other.name == self.name
            and other.refers_to == self.refers_to
        )


class DataValidation:
    """Data validation for a range.

    Do not construct this class directly; access it through
    {attr}`Range.data_validation <xlwings.Range.data_validation>`.

    Comparison setters accept these operators: ``"between"``, ``"not_between"``,
    ``"equal_to"``, ``"not_equal_to"``, ``"greater_than"``, ``"less_than"``,
    ``"greater_than_or_equal"``, and ``"less_than_or_equal"``.

    Examples:
        Create a dropdown from literal values:

        ```python
        sheet["A1:A10"].data_validation.set_list(["Open", "Closed"])
        ```

        Require whole numbers between 1 and 10:

        ```python
        sheet["B1:B10"].data_validation.set_whole_number("between", 1, 10)
        ```

    ```{versionadded} 0.37.5
    ```
    """

    def __init__(self, impl: Any, parent: Range) -> None:
        self.impl = impl
        self.parent = parent

    @property
    def api(self) -> Any:
        """Returns the native data validation object of the engine being used."""
        return self.impl.api

    @property
    def type(self) -> DataValidationType:
        """The normalized validation type for this range.

        ``"none"`` means that no cell has validation, ``"mixed_criteria"`` means
        that only some cells have validation, and ``"inconsistent"`` means that
        cells have different validation rules. Unsupported native rule types are
        reported as ``"unknown"``.
        """
        value = self.impl.type
        return cast(
            DataValidationType,
            value if value in DATA_VALIDATION_TYPES else "unknown",
        )

    @property
    def operator(self) -> DataValidationOperator | None:
        """The comparison operator, or ``None`` for list and custom rules."""
        return self.impl.operator

    @property
    def formula1(self) -> str | None:
        """The first comparison operand as an Excel formula string."""
        return self._normalized_formula(self.impl.formula1)

    @property
    def formula2(self) -> str | None:
        """The second operand for between/not-between rules."""
        return self._normalized_formula(self.impl.formula2)

    @property
    def formula(self) -> str | None:
        """The formula for a custom validation rule."""
        return self.impl.formula

    @property
    def source(self) -> str | None:
        """The source string for a list validation rule."""
        return self.impl.source

    @property
    def in_cell_dropdown(self) -> bool | None:
        """Whether a list rule displays an in-cell dropdown."""
        return self.impl.in_cell_dropdown

    @property
    def ignore_blank(self) -> bool | None:
        """Whether blank cells are ignored by the validation rule."""
        return self.impl.ignore_blank

    @property
    def input_title(self) -> str | None:
        """The input-prompt title."""
        return self.impl.input_title

    @property
    def input_message(self) -> str | None:
        """The input-prompt message."""
        return self.impl.input_message

    @property
    def show_input(self) -> bool | None:
        """Whether the input prompt is shown."""
        return self.impl.show_input

    @property
    def error_title(self) -> str | None:
        """The validation-error title."""
        return self.impl.error_title

    @property
    def error_message(self) -> str | None:
        """The validation-error message."""
        return self.impl.error_message

    @property
    def show_error(self) -> bool | None:
        """Whether invalid entries display an error alert."""
        return self.impl.show_error

    @property
    def alert_style(self) -> DataValidationAlertStyle | None:
        """The error-alert style.

        One of `"stop"`, `"warning"`, or `"information"`.
        """
        return self.impl.alert_style

    @staticmethod
    def _literal_source(
        source: Sequence[str | int | float | bool],
    ) -> list[str]:
        if isinstance(source, (str, bytes, bytearray)) or not isinstance(
            source, Sequence
        ):
            raise TypeError("source must be a non-empty sequence, Range, or Name")
        if not source:
            raise ValueError("source must not be empty")

        values = []
        for value in source:
            if isinstance(value, bool):
                text = "TRUE" if value else "FALSE"
            elif isinstance(value, str):
                text = value
            elif isinstance(value, int):
                text = str(value)
            elif isinstance(value, float) and math.isfinite(value):
                text = str(value)
            else:
                raise TypeError(
                    "literal list values must be strings, numbers, or booleans"
                )
            if "," in text or ";" in text:
                raise ValueError(
                    "literal list values cannot contain ',' or ';'; use a Range "
                    "or Name source for values containing separators"
                )
            values.append(text)

        if len(",".join(values)) > 255:
            raise ValueError(
                "a literal list source cannot exceed 255 characters; use a Range "
                "or Name source instead"
            )
        return values

    def _range_source(self, source: Range) -> Any:
        if source.sheet.book != self.parent.sheet.book:
            raise ValueError("source must belong to the same workbook as the target")
        if source.shape[0] != 1 and source.shape[1] != 1:
            raise ValueError("a list validation source Range must be one-dimensional")
        return source.impl

    def set_list(
        self,
        source: Sequence[str | int | float | bool] | Range | Name,
        *,
        in_cell_dropdown: bool = True,
    ) -> None:
        """Creates or updates a list validation on the range.

        Existing input prompts and error alerts are preserved. The source can be a
        non-empty sequence of strings, numbers, or booleans, a one-dimensional Range,
        or a Name that refers to a one-dimensional range in the same workbook.

        Args:
            source: Allowed list values, a worksheet range, or a named range.
            in_cell_dropdown: Whether Excel shows the list's in-cell dropdown.
        """
        if not isinstance(in_cell_dropdown, bool):
            raise TypeError("in_cell_dropdown must be a bool")
        if isinstance(source, Range):
            normalized_source = self._range_source(source)
        elif isinstance(source, Name):
            self._range_source(source.refers_to_range)
            normalized_source = source.impl
        else:
            normalized_source = self._literal_source(source)
        self.impl.set_list(normalized_source, in_cell_dropdown)

    @staticmethod
    def _operator(value: Any) -> DataValidationOperator:
        if isinstance(value, str) and value in DATA_VALIDATION_OPERATORS:
            return cast(DataValidationOperator, value)
        raise ValueError(
            f"Invalid data-validation operator {value!r}. Valid values are: "
            f"{', '.join(repr(v) for v in DATA_VALIDATION_OPERATORS)}."
        )

    @staticmethod
    def _normalized_formula(value: Any) -> str | None:
        if value is None:
            return None
        formula = str(value)
        return formula if formula.startswith("=") else f"={formula}"

    @staticmethod
    def _operand(value: Any, name: str, kind: str) -> str:
        if isinstance(value, bool):
            raise TypeError(f"{name} must not be a bool")
        if kind == "date" and isinstance(value, (dt.datetime, dt.date)):
            if isinstance(value, dt.datetime) and value.tzinfo is not None:
                raise ValueError(f"{name} must be a timezone-naive datetime")
            date_formula = f"=DATE({value.year},{value.month},{value.day})"
            if isinstance(value, dt.datetime) and value.time() != dt.time():
                seconds: int | float = value.second
                if value.microsecond:
                    seconds += value.microsecond / 1_000_000
                date_formula += f"+TIME({value.hour},{value.minute},{seconds})"
            value = date_formula
        elif kind == "time" and isinstance(value, dt.time):
            if value.tzinfo is not None:
                raise ValueError(f"{name} must be a timezone-naive time")
            seconds = value.second
            if value.microsecond:
                seconds += value.microsecond / 1_000_000
            value = f"=TIME({value.hour},{value.minute},{seconds})"
        elif isinstance(value, (dt.datetime, dt.date, dt.time)):
            raise TypeError(f"{name} isn't valid for {kind} validation")

        if isinstance(value, str):
            if not value:
                raise ValueError(f"{name} must not be empty")
            text = value if value.startswith("=") else f"={value}"
        elif isinstance(value, numbers.Real) and math.isfinite(value):
            text = f"={value}"
        else:
            raise TypeError(f"{name} must be a formula string or a finite number")
        if len(text) > 255:
            raise ValueError(f"{name} cannot exceed 255 characters")
        return text

    def _set_comparison(
        self,
        rule_type: str,
        operator: DataValidationOperator,
        formula1: Any,
        formula2: Any,
    ) -> None:
        operator = self._operator(operator)
        formula1 = self._operand(formula1, "formula1", rule_type)
        if operator in {"between", "not_between"}:
            if formula2 is None:
                raise ValueError(f"formula2 is required for operator {operator!r}")
            formula2 = self._operand(formula2, "formula2", rule_type)
        elif formula2 is not None:
            raise ValueError(f"formula2 isn't valid for operator {operator!r}")
        self.impl.set_rule(rule_type, operator, formula1, formula2)

    def set_whole_number(
        self,
        operator: DataValidationOperator,
        formula1: int | float | str,
        formula2: int | float | str | None = None,
    ) -> None:
        """Create or update a whole-number validation rule.

        ``formula2`` is required for ``"between"`` and ``"not_between"`` and
        rejected for every other operator. Existing prompts and error alerts are
        preserved.
        """
        self._set_comparison("whole_number", operator, formula1, formula2)

    def set_decimal(
        self,
        operator: DataValidationOperator,
        formula1: int | float | str,
        formula2: int | float | str | None = None,
    ) -> None:
        """Create or update a decimal validation rule.

        ``formula2`` is required for ``"between"`` and ``"not_between"`` and
        rejected for every other operator. Existing prompts and error alerts are
        preserved.
        """
        self._set_comparison("decimal", operator, formula1, formula2)

    def set_date(
        self,
        operator: DataValidationOperator,
        formula1: dt.date | dt.datetime | int | float | str,
        formula2: dt.date | dt.datetime | int | float | str | None = None,
    ) -> None:
        """Create or update a date validation rule.

        Operands may be Python dates, naive datetimes, Excel serial numbers, or Excel formula strings. Existing prompts and error alerts are preserved.
        """
        self._set_comparison("date", operator, formula1, formula2)

    def set_time(
        self,
        operator: DataValidationOperator,
        formula1: dt.time | int | float | str,
        formula2: dt.time | int | float | str | None = None,
    ) -> None:
        """Create or update a time validation rule.

        Operands may be naive Python times, Excel day fractions, or Excel formula strings. Existing prompts and error alerts are preserved.
        """
        self._set_comparison("time", operator, formula1, formula2)

    def set_text_length(
        self,
        operator: DataValidationOperator,
        formula1: int | float | str,
        formula2: int | float | str | None = None,
    ) -> None:
        """Create or update a text-length validation rule.

        ``formula2`` is required for ``"between"`` and ``"not_between"`` and
        rejected for every other operator. Existing prompts and error alerts are
        preserved.
        """
        self._set_comparison("text_length", operator, formula1, formula2)

    def set_custom(self, formula: str) -> None:
        """Create or update a custom-formula validation rule.

        The formula must be an A1-style formula starting with ``=``. Existing
        prompts and error alerts are preserved.
        """
        if not isinstance(formula, str):
            raise TypeError("formula must be a string")
        if not formula.startswith("=") or len(formula) == 1:
            raise ValueError("formula must be a non-empty A1 formula starting with '='")
        if len(formula) > 255:
            raise ValueError("formula cannot exceed 255 characters")
        self.impl.set_rule("custom", None, formula, None)

    def delete(self) -> None:
        """Removes data validation from the range."""
        self.impl.delete()


def view(
    obj: Any, sheet: Sheet | None = None, table: bool = True, chunksize: int = 5000
) -> None:
    """Opens a new workbook and displays an object on its first sheet by default. If you
    provide a sheet object, it will clear the sheet before displaying the object on the
    existing sheet.

    ```{note}
    Only use this in an interactive context like e.g., a Jupyter notebook! Don't use
    this in a script as it depends on the active book.
    ```

    Args:
        obj: the object to display, e.g. numbers, strings, lists, numpy arrays, pandas
            DataFrames
        sheet: Sheet object. If none provided, the first sheet of a new workbook is used.
        table: If your object is a pandas DataFrame, by default it is formatted as an
            Excel
            Table
        chunksize: Chunks the loading of big arrays.

    Examples:
        ```pycon
        >>> import xlwings as xw
        >>> import pandas as pd
        >>> import numpy as np
        >>> df = pd.DataFrame(np.random.rand(10, 4), columns=['a', 'b', 'c', 'd'])
        >>> xw.view(df)
        ```

    See also: `load`

    ```{versionchanged} 0.22.0
    ```
    """
    if sheet is None:
        sheet = Book().sheets.active
    else:
        sheet.clear()

    app = sheet.book.app
    app.activate(steal_focus=True)

    with app.properties(screen_updating=False):
        if pd and isinstance(obj, pd.DataFrame):
            if table:
                sheet["A1"].options(
                    assign_empty_index_names=True, chunksize=chunksize
                ).value = obj
                sheet.tables.add(sheet["A1"].expand())
            else:
                sheet["A1"].options(
                    assign_empty_index_names=False, chunksize=chunksize
                ).value = obj
        else:
            sheet["A1"].value = obj
        sheet.autofit()


def load(index: bool | int = 1, header: bool | int = 1, chunksize: int = 5000) -> Any:
    """Loads the selected cell(s) of the active workbook into a pandas DataFrame. If you
    select a single cell that has adjacent cells, the range is auto-expanded (via
    current region) and turned into a pandas DataFrame. If you don't have pandas
    installed, it returns the values as nested lists.

    ```{note}
    Only use this in an interactive context like e.g. a Jupyter notebook! Don't use
    this in a script as it depends on the active book.
    ```

    Args:
        index: Defines the number of columns on the left that will be turned into the
            DataFrame's index
        header: Defines the number of rows at the top that will be turned into the DataFrame's
            columns
        chunksize: Chunks the loading of big arrays.

    Examples:
        ```pycon
        >>> import xlwings as xw
        >>> xw.load()
        ```

    See also: `view`

    ```{versionchanged} 0.23.1
    ```
    """
    selection = books.active.selection
    if selection.shape == (1, 1):
        selection = selection.current_region
    if pd:
        values = selection.options(
            pd.DataFrame, index=index, header=header, chunksize=chunksize
        ).value
    else:
        values = selection.options(chunksize=chunksize).value
    return values


class Macro:
    def __init__(self, app: App, macro: str) -> None:
        self.app = app
        self.macro = macro

    def run(self, *args: Any) -> Any:
        args = [
            (
                i.api
                if isinstance(i, (App, Book, Sheet, Range, Shape, Chart, Picture, Name))
                else i
            )
            for i in args
        ]
        return self.app.impl.run(self.macro, args)

    __call__ = run


class Characters:
    """The characters object can be accessed as an attribute of the range or shape
    object.

    * `mysheet['A1'].characters`
    * `mysheet.shapes[0].characters`

    ```{note}
    On macOS, `characters` are currently not supported due to bugs/lack of
    support in AppleScript.
    ```

    ```{versionadded} 0.23.0
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj) of the engine
        being used.

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.api

    @property
    def text(self) -> str:
        """Returns or sets the text property of a `characters` object.

        ```pycon
        >>> sheet['A1'].value = 'Python'
        >>> sheet['A1'].characters[:3].text
        Pyt
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.text

    @property
    def font(self) -> Font:
        """Returns or sets the text property of a `characters` object.

        ```pycon
        >>> sheet['A1'].characters[1:3].font.bold = True
        >>> sheet['A1'].characters[1:3].font.bold
        True
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return Font(self.impl.font)

    def __getitem__(self, item: int | slice) -> Characters:
        if (
            isinstance(item, slice)
            and (item.start and item.stop)
            and (item.start == item.stop)
        ):
            raise ValueError(
                self.__class__.__name__ + " object does not support empty slices"
            )
        if isinstance(item, slice) and item.step is not None:
            raise ValueError(
                self.__class__.__name__
                + " object does not support slicing with non-default steps"
            )
        if isinstance(item, slice):
            return Characters(self.impl[item.start : item.stop])
        else:
            return Characters(self.impl[item])

    async def get_text(self) -> str | None:
        """Fetch the characters' text on demand.

        `None` if the shape holds no text.

        Requires xlwings Lite.
        """
        return await self.impl.get_text()


class Font:
    """The font object can be accessed as an attribute of the range or shape object.

    * `mysheet['A1'].font`
    * `mysheet.shapes[0].font`

    ```{versionadded} 0.23.0
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.api

    @property
    def bold(self) -> bool | None:
        """Returns or sets the bold property (boolean).

        ```pycon
        >>> sheet['A1'].font.bold = True
        >>> sheet['A1'].font.bold
        True
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.bold

    @bold.setter
    def bold(self, value: bool) -> None:
        self.impl.bold = value

    @property
    def italic(self) -> bool | None:
        """Returns or sets the italic property (boolean).

        ```pycon
        >>> sheet['A1'].font.italic = True
        >>> sheet['A1'].font.italic
        True
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.italic

    @italic.setter
    def italic(self, value: bool) -> None:
        self.impl.italic = value

    @property
    def size(self) -> float | None:
        """Returns or sets the size (float).

        ```pycon
        >>> sheet['A1'].font.size = 13
        >>> sheet['A1'].font.size
        13
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.size

    @size.setter
    def size(self, value: float) -> None:
        self.impl.size = value

    @property
    def color(self) -> tuple[int, int, int] | None:
        """Returns or sets the color property (tuple).

        ```pycon
        >>> sheet['A1'].font.color = (255, 0, 0)  # or '#ff0000'
        >>> sheet['A1'].font.color
        (255, 0, 0)
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.color

    @color.setter
    def color(self, value: tuple[int, int, int] | str) -> None:
        self.impl.color = value

    @property
    def name(self) -> str | None:
        """Returns or sets the name of the font (str).

        ```pycon
        >>> sheet['A1'].font.name = 'Calibri'
        >>> sheet['A1'].font.name
        Calibri
        ```

        ```{versionadded} 0.23.0
        ```
        """
        return self.impl.name

    @name.setter
    def name(self, value: str) -> None:
        self.impl.name = value

    async def get_bold(self) -> bool | None:
        """Fetch the bold property on demand.

        `None` if the range's cells don't all agree.

        Requires xlwings Lite.
        """
        return await self.impl.get_bold()

    async def get_italic(self) -> bool | None:
        """Fetch the italic property on demand.

        `None` if the range's cells don't all agree.

        Requires xlwings Lite.
        """
        return await self.impl.get_italic()

    async def get_size(self) -> float | None:
        """Fetch the font size on demand.

        `None` if the range's cells don't all agree.

        Requires xlwings Lite.
        """
        return await self.impl.get_size()

    async def get_color(self) -> tuple[int, int, int] | None:
        """Fetch the font color on demand, as an RGB tuple.

        `None` if unset or if the range's cells don't all agree.

        Requires xlwings Lite.
        """
        return await self.impl.get_color()

    async def get_name(self) -> str | None:
        """Fetch the font name on demand.

        `None` if the range's cells don't all agree.

        Requires xlwings Lite.
        """
        return await self.impl.get_name()


_BORDER_GROUPS: dict[str, tuple[str, ...]] = {
    "outside": ("edge_top", "edge_bottom", "edge_left", "edge_right"),
    "inside": ("inside_vertical", "inside_horizontal"),
    "all": BORDER_GRID_SIDES,
    "everything": BORDER_SIDES,
}
_BORDER_LINE_STYLES: tuple[str, ...] = get_args(BorderLineStyle)
_BORDER_WEIGHTS: tuple[str, ...] = get_args(BorderWeight)


def _border_side(key: Any) -> str:
    """Validate one side name and return it as a plain string."""
    if isinstance(key, str):
        if str(key) in BORDER_SIDES:
            return str(key)
        if str(key) in _BORDER_GROUPS:
            raise ValueError(
                f"{key!r} is a group of borders, which can only be used with "
                "set() and clear(). Valid sides are: "
                f"{', '.join(repr(side) for side in BORDER_SIDES)}."
            )
    raise ValueError(
        f"Invalid border side {key!r}. Valid sides are: "
        f"{', '.join(repr(side) for side in BORDER_SIDES)}."
    )


def _border_sides(which: Any) -> list[str]:
    """Expand a side name, a group alias or a list of side names into the
    canonical side names, in documented order and without duplicates."""
    if isinstance(which, str):
        if str(which) in _BORDER_GROUPS:
            return list(_BORDER_GROUPS[str(which)])
        return [_border_side(which)]
    try:
        keys = list(which)
    except TypeError:
        raise ValueError(
            f"Invalid border selector {which!r}. Use a side name, a group "
            f"({', '.join(repr(group) for group in _BORDER_GROUPS)}) or a list "
            "of side names."
        ) from None
    sides: list[str] = []
    for key in keys:
        side = _border_side(key)
        if side not in sides:
            sides.append(side)
    return sides


def _border_line_style(value: Any) -> str | None:
    """Normalize a line style to its plain string, with `None` meaning "no
    border" (`None` and `"none"` are equivalent)."""
    if value is None:
        return None
    if isinstance(value, str) and str(value) in _BORDER_LINE_STYLES:
        return None if str(value) == "none" else str(value)
    raise ValueError(
        f"Invalid line_style {value!r}. Valid values are: "
        f"{', '.join(repr(style) for style in _BORDER_LINE_STYLES)}, "
        "or None to remove the border."
    )


def _border_weight(value: Any) -> str:
    if value is None:
        raise ValueError(
            "weight can't be None. To remove a border, set line_style=None or "
            "use clear()."
        )
    if isinstance(value, str) and str(value) in _BORDER_WEIGHTS:
        return str(value)
    raise ValueError(
        f"Invalid weight {value!r}. Valid values are: "
        f"{', '.join(repr(weight) for weight in _BORDER_WEIGHTS)}."
    )


def _horizontal_alignment(value: Any) -> str:
    if isinstance(value, str) and str(value) in HORIZONTAL_ALIGNMENTS:
        return str(value)
    raise ValueError(
        f"Invalid horizontal_alignment {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in HORIZONTAL_ALIGNMENTS)}."
    )


def _vertical_alignment(value: Any) -> str:
    if isinstance(value, str) and str(value) in VERTICAL_ALIGNMENTS:
        return str(value)
    raise ValueError(
        f"Invalid vertical_alignment {value!r}. Valid values are: "
        f"{', '.join(repr(v) for v in VERTICAL_ALIGNMENTS)}."
    )


def _border_color(value: Any) -> tuple[int, int, int]:
    """Normalize the color forms `Range.color` accepts into an RGB tuple.

    Unlike `Range.color`, `None` isn't a valid border color: removing a border
    is what `line_style=None`/`clear()` are for.
    """
    if value is None:
        raise ValueError(
            "Border color can't be None. To remove a border, set line_style=None "
            "or use clear()."
        )
    error = ValueError(
        "Color must be an RGB tuple like (255, 0, 0), a hex string like "
        f"'#ff0000' or an Excel color integer, not {value!r}."
    )
    if isinstance(value, str):
        hex_value = value[1:] if value.startswith("#") else value
        if len(hex_value) != 6:
            raise error
        try:
            red, green, blue = utils.hex_to_rgb(hex_value)
        except ValueError:
            raise error from None
        return red, green, blue
    if isinstance(value, bool):
        raise error
    if isinstance(value, int):
        return utils.int_to_rgb(value)
    try:
        red, green, blue = value
        rgb = (int(red), int(green), int(blue))
    except (TypeError, ValueError):
        raise error from None
    if not all(0 <= channel <= 255 for channel in rgb):
        raise error
    return rgb


class Border:
    """A single side of a range's borders, accessed via
    {class}`Borders <xlwings.main.Borders>`:

    `mysheet['A1:D10'].borders['edge_bottom']`

    Side names are

    * `"edge_top"`
    * `"edge_bottom"`
    * `"edge_left"`
    * `"edge_right"`
    * `"inside_vertical"`
    * `"inside_horizontal"`
    * `"diagonal_down"`
    * `"diagonal_up"`

    ```{versionadded} 0.37.1
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.api

    @property
    def line_style(self) -> str | None:
        """Returns or sets the line style (str). Available styles:

        * `"continuous"`
        * `"dash"`
        * `"dash_dot"`
        * `"dash_dot_dot"`
        * `"dot"`
        * `"double"`
        * `"slant_dash_dot"`
        * `"none"`

        Setting it to `None` or `"none"` removes the border. Reads `"none"` for a
        missing border. Excel doesn't flag a range whose cells don't all agree, so a
        mixed range reports one of its values; read a single cell for an
        unambiguous answer.

        Excel's border attributes influence one another, so a line style may
        change the weight (and vice versa), and setting a weight or color on a
        removed border makes it visible again. Getters always report the
        resulting native values.

        ```pycon
        >>> sheet['A1'].borders['edge_bottom'].line_style = 'double'
        >>> sheet['A1'].borders['edge_bottom'].line_style
        'double'
        >>> sheet['A1'].borders['edge_bottom'].line_style = None
        >>> sheet['A1'].borders['edge_bottom'].line_style
        'none'
        ```

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.line_style

    @line_style.setter
    def line_style(self, value: BorderLineStyle | None) -> None:
        self.impl.line_style = _border_line_style(value)

    @property
    def weight(self) -> str | None:
        """Returns or sets the weight (str). Available weihts:

        * `"hairline"`
        * `"thin"`
        * `"medium"`
        * `"thick"`

        A range whose cells don't all agree reports one of its values, see
        {attr}`line_style <xlwings.main.Border.line_style>`. Setting the
        weight of a removed border makes it visible.

        ```pycon
        >>> sheet['A1'].borders['edge_bottom'].weight = 'thick'
        >>> sheet['A1'].borders['edge_bottom'].weight
        'thick'
        ```

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.weight

    @weight.setter
    def weight(self, value: BorderWeight) -> None:
        self.impl.weight = _border_weight(value)

    @property
    def color(self) -> tuple[int, int, int] | None:
        """Returns or sets the color (tuple).

        To set the color, use an RGB tuple `(255, 0, 0)`, a hex string like
        `'#ff0000'` or an Excel color constant. Unlike `Range.color`, `None`
        isn't accepted: remove a border via `line_style = None`. Reads `None`
        for a removed border. A range whose cells don't all agree reports one
        of its values, see {attr}`line_style <xlwings.main.Border.line_style>`,
        and a multi-cell range reads `None` for its diagonals even when a
        color was set. Setting the color of a removed border makes it
        visible.

        ```pycon
        >>> sheet['A1'].borders['edge_bottom'].color = (255, 0, 0)  # or '#ff0000'
        >>> sheet['A1'].borders['edge_bottom'].color
        (255, 0, 0)
        ```

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.color

    @color.setter
    def color(self, value: tuple[int, int, int] | str | int) -> None:
        self.impl.color = _border_color(value)

    async def get_line_style(self) -> str | None:
        """Fetch the line style on demand.

        `"none"` for a missing border. No engine detects a side whose
        segments differ from cell to cell, but xlwings Lite and xlwings Server
        report a different value than the desktop engines do: an edge reports
        its first segment's value rather than the range's, and an inside
        border of a range whose cells don't share the same border formatting
        reads `"none"` even though every cell's own borders are intact.

        Requires xlwings Lite.
        """
        return await self.impl.get_line_style()

    async def get_weight(self) -> str | None:
        """Fetch the weight on demand.

        xlwings Lite and xlwings Server report a mixed side differently than
        the desktop engines, see
        {meth}`get_line_style() <xlwings.main.Border.get_line_style>`.

        Requires xlwings Lite.
        """
        return await self.impl.get_weight()

    async def get_color(self) -> tuple[int, int, int] | None:
        """Fetch the color on demand, as an RGB tuple.

        `None` for a removed border. xlwings Lite and xlwings Server report a
        mixed side differently than the desktop engines, see
        {meth}`get_line_style() <xlwings.main.Border.get_line_style>`.

        Requires xlwings Lite.
        """
        return await self.impl.get_color()


class Borders:
    """The borders of a range, accessed via `myrange.borders`.

    Use `set()` to write several attributes in one go or to target a group of
    sides, and `clear()` to remove borders.

    Examples:
        ```pycon
        >>> myrange = sheet["A1:D10"]
        >>> myrange.borders.line_style = "continuous"
        >>> myrange.borders.weight = "thin"
        >>> myrange.borders.color = "#000000"
        >>> myrange.borders["edge_bottom"].weight = "thick"
        >>> myrange.borders.set("outside", line_style="double", color=(255, 0, 0))
        >>> myrange.borders.clear("inside")
        >>> myrange.borders.clear()
        >>> [border.line_style for border in myrange.borders]  # 8 sides, in table order
        ```

    ```{versionadded} 0.37.1
    ```
    """

    def __init__(self, impl: Any) -> None:
        self.impl = impl

    @property
    def api(self) -> Any:
        """Returns the native object (`pywin32` or `appscript` obj)
        of the engine being used.

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.api

    @property
    def line_style(self) -> str | None:
        """Returns or sets the line style of the four edges and the two inside
        borders, i.e. Excel's "All Borders", see
        {attr}`Border.line_style <xlwings.main.Border.line_style>`. Reads the
        common value, or `None` if they differ.

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.line_style

    @line_style.setter
    def line_style(self, value: BorderLineStyle | None) -> None:
        self.set("all", line_style=value)

    @property
    def weight(self) -> str | None:
        """Returns or sets the weight of the four edges and the two inside
        borders, i.e. Excel's "All Borders", see
        {attr}`Border.weight <xlwings.main.Border.weight>`. Reads the common
        value, or `None` if they differ.

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.weight

    @weight.setter
    def weight(self, value: BorderWeight) -> None:
        self.set("all", weight=value)

    @property
    def color(self) -> tuple[int, int, int] | None:
        """Returns or sets the color of the four edges and the two inside
        borders, i.e. Excel's "All Borders", see
        {attr}`Border.color <xlwings.main.Border.color>`. Reads the common
        value, or `None` if they differ.

        ```{versionadded} 0.37.1
        ```
        """
        return self.impl.color

    @color.setter
    def color(self, value: tuple[int, int, int] | str | int) -> None:
        self.set("all", color=value)

    async def get_line_style(self) -> str | None:
        """Fetch the common line style of the four edges and the two inside
        borders on demand.

        `None` if they differ. Segments that differ from cell to cell
        within a side aren't detected on any engine, see
        {meth}`Border.get_line_style() <xlwings.main.Border.get_line_style>`.

        Requires xlwings Lite.
        """
        return await self.impl.get_line_style()

    async def get_weight(self) -> str | None:
        """Fetch the common weight of the four edges and the two inside borders
        on demand.

        `None` if they differ. Segments that differ from cell to cell
        within a side aren't detected on any engine, see
        {meth}`Border.get_line_style() <xlwings.main.Border.get_line_style>`.

        Requires xlwings Lite.
        """
        return await self.impl.get_weight()

    async def get_color(self) -> tuple[int, int, int] | None:
        """Fetch the common color of the four edges and the two inside borders
        on demand, as an RGB tuple.

        `None` if they differ. Segments that differ from cell to cell
        within a side aren't detected on any engine, see
        {meth}`Border.get_line_style() <xlwings.main.Border.get_line_style>`.

        Requires xlwings Lite.
        """
        return await self.impl.get_color()

    def __getitem__(self, key: BorderSide | str) -> Border:
        return Border(impl=self.impl[_border_side(key)])

    def __iter__(self) -> Iterator[Border]:
        for side in BORDER_SIDES:
            yield self[side]

    def __len__(self) -> int:
        return len(BORDER_SIDES)

    def set(
        self,
        which: BorderSide | BorderGroup | str | list[BorderSide | str] = "all",
        *,
        line_style: BorderLineStyle | None = _UNSET,
        weight: BorderWeight = _UNSET,
        color: tuple[int, int, int] | str | int = _UNSET,
    ) -> None:
        """Sets one or more attributes on one or more sides in one go.

        Only the attributes you pass are written. For each side, they're
        applied in the order color, weight, line style, so that the line
        style is what survives when Excel can't represent a combination (for
        instance, `"dash_dot_dot"` with `"thick"` reads back as `"thin"`).
        Validation happens before anything is written; if the host rejects a
        combination, the error propagates and earlier writes stay in place.

        Args:
            which: A side name (`"edge_top"`, ...), a list of side names, or one
                of the groups `"outside"` (the four edges), `"inside"` (the two
                inside borders), `"all"` (outside + inside, the default) and
                `"everything"` (all eight sides, including the diagonals).
            line_style: See
                {attr}`Border.line_style <xlwings.main.Border.line_style>`.
                `None` or `"none"` removes the selected borders.
            weight: See {attr}`Border.weight <xlwings.main.Border.weight>`.
                `None` isn't allowed.
            color: See {attr}`Border.color <xlwings.main.Border.color>`.
                `None` isn't allowed.

        Examples:
            ```pycon
            >>> myrange = sheet["A1:D10"]
            >>> myrange.borders.set("outside", line_style="continuous", weight="thin")
            >>> myrange.borders.set(["edge_top", "edge_bottom"], line_style="double")
            >>> myrange.borders.set("inside", line_style=None)  # same as clear("inside")
            ```

        ```{versionadded} 0.37.1
        ```
        """
        sides = _border_sides(which)
        if line_style is not _UNSET:
            line_style = _border_line_style(line_style)
        if weight is not _UNSET:
            weight = _border_weight(weight)
        if color is not _UNSET:
            color = _border_color(color)
        if line_style is _UNSET and weight is _UNSET and color is _UNSET:
            return
        self.impl.set(sides, line_style=line_style, weight=weight, color=color)

    def clear(
        self,
        which: BorderSide | BorderGroup | str | list[BorderSide | str] = "everything",
    ) -> None:
        """Removes borders. Same as `set(which, line_style=None)`.

        Args:
            which: A side name, a list of side names or a group, see
                {meth}`set() <xlwings.main.Borders.set>`. Defaults to
                `"everything"`, i.e. all eight sides including the diagonals;
                `clear("all")` leaves the diagonals alone.

        Examples:
            ```pycon
            >>> myrange.borders.clear()           # all eight sides
            >>> myrange.borders.clear("inside")   # the two inside borders only
            ```

        ```{versionadded} 0.37.1
        ```
        """
        self.set(which, line_style=None)


class FreezePanes:
    """Freeze panes interface. Use via `mysheet.freeze_panes`."""

    def __init__(self, impl: Any, sheet: Sheet) -> None:
        self.impl = impl
        self.sheet = sheet

    def freeze_at(self, frozen_range: str | Range) -> None:
        """Sets the frozen cells in the sheet.

        Args:
            frozen_range: E.g., "A1", "A:A", or "1:1" or mysheet["A1"], etc.

        """
        if isinstance(frozen_range, Range):
            if self.sheet != frozen_range.sheet:
                raise ValueError("Range object is on a different sheet.")
            frozen_range = frozen_range.address
        self.impl.freeze_at(frozen_range)

    def unfreeze(self) -> None:
        """Removes all frozen panes in the sheet."""
        self.impl.unfreeze()


class Books(Collection[Book]):
    """A collection of all `book` objects:

    ```pycon
    >>> import xlwings as xw
    >>> xw.books  # active app
    Books([<Book [Book1]>, <Book [Book2]>])
    >>> xw.apps[10559].books  # specific app, get the PIDs via xw.apps.keys()
    Books([<Book [Book1]>, <Book [Book2]>])
    ```

    ```{versionadded} 0.9.0
    ```
    """

    _wrap = Book

    @property
    def active(self) -> Book:
        """Returns the active Book."""
        return Book(impl=self.impl.active)

    async def get_active(self) -> Book:
        """Returns the active Book without pre-loading values.

        This is the entry point to the async API, which reads on demand
        (lazy loading) instead of snapshotting the whole workbook up front.

        Requires xlwings Lite.

        Use `await myrange.get_value()` to read cell values on demand.

        ```{versionadded} 0.35.0
        ```
        """
        return Book(impl=await self.impl.get_active())

    def add(self) -> Book:
        """Creates a new Book. The new Book becomes the active Book. Returns a Book object."""
        return Book(impl=self.impl.add())

    def open(
        self,
        fullname: str | PathLike[str] | None = None,
        update_links: bool | None = None,
        read_only: bool | None = None,
        format: str | None = None,
        password: str | None = None,
        write_res_password: str | None = None,
        ignore_read_only_recommended: bool | None = None,
        origin: int | None = None,
        delimiter: str | None = None,
        editable: bool | None = None,
        notify: bool | None = None,
        converter: int | None = None,
        add_to_mru: bool | None = None,
        local: bool | None = None,
        corrupt_load: int | None = None,
        json: dict[str, Any] | None = None,
    ) -> Book:
        """Opens a Book if it is not open yet and returns it. If it is already open,
        it doesn't raise an exception but simply returns the Book object.

        Args:
            fullname: filename or fully qualified filename, e.g., `r'C:\\path\\to\\file.xlsx'`
                or `'file.xlsm'`. Without a full path, it looks for the file in the
                current working directory.

            Other Parameters
            see: `xlwings.Book()`


        """
        if self.impl.app.engine.type == "remote":
            return Book(impl=self.impl.open(json=json))

        fullname = utils.fspath(fullname)
        if not os.path.exists(fullname):
            raise FileNotFoundError("No such file: '%s'" % fullname)
        fullname = os.path.realpath(fullname)
        _, name = os.path.split(fullname)

        if self.impl.app.engine.type == "reader":
            return Book(impl=self.impl.open(filename=fullname))

        try:
            impl = self.impl(name)
            if not os.path.samefile(impl.fullname, fullname):
                raise ValueError(
                    "Cannot open two workbooks named '%s', even if they are saved in"
                    "different locations." % name
                )
        except KeyError:
            impl = self.impl.open(
                fullname,
                update_links,
                read_only,
                format,
                password,
                write_res_password,
                ignore_read_only_recommended,
                origin,
                delimiter,
                editable,
                notify,
                converter,
                add_to_mru,
                local,
                corrupt_load,
            )
        return Book(impl=impl)


class Sheets(Collection[Sheet]):
    """A collection of all `sheet` objects:

    ```pycon
    >>> import xlwings as xw
    >>> xw.sheets  # active book
    Sheets([<Sheet [Book1]Sheet1>, <Sheet [Book1]Sheet2>])
    >>> xw.Book('Book1').sheets  # specific book
    Sheets([<Sheet [Book1]Sheet1>, <Sheet [Book1]Sheet2>])
    ```

    ```{versionadded} 0.9.0
    ```
    """

    _wrap = Sheet

    @property
    def active(self) -> Sheet:
        """Returns the active Sheet."""
        return Sheet(impl=self.impl.active)

    async def get_active(self) -> Sheet:
        """Returns the active Sheet, fetched live from Excel.

        Requires xlwings Lite.

        ```{versionadded} 0.35.0
        ```
        """
        return Sheet(impl=await self.impl.get_active())

    def __call__(self, name_or_index: int | str | Sheet) -> Sheet:
        if isinstance(name_or_index, Sheet):
            return name_or_index
        else:
            return Sheet(impl=self.impl(name_or_index))

    def __delitem__(self, name_or_index: int | str) -> None:
        self[name_or_index].delete()

    def add(
        self,
        name: str | None = None,
        before: Sheet | None = None,
        after: Sheet | None = None,
    ) -> Sheet:
        """Creates a new Sheet and makes it the active sheet. Returns the added sheet.

        Args:
            name: Name of the new sheet. If None, will default to Excel's default name.
            before: An object that specifies the sheet before which the new sheet is
                added.
            after: An object that specifies the sheet after which the new sheet is
                added.
        """
        if name is not None:
            if name.lower() in (s.name.lower() for s in self):
                raise ValueError("Sheet named '%s' already present in workbook" % name)
        if before is not None and not isinstance(before, Sheet):
            before = self(before)
        if after is not None and not isinstance(after, Sheet):
            after = self(after)
        impl = self.impl.add(before and before.impl, after and after.impl, name)
        return Sheet(impl=impl)


class ActiveEngineApps(Apps):
    def __init__(self) -> None:
        pass

    _name = "Apps"

    @property
    def impl(self) -> Any:
        if engines.active is None:
            if not (
                sys.platform.startswith("darwin") or sys.platform.startswith("win")
            ):
                raise XlwingsError(
                    "The interactive mode of xlwings is only supported on Windows and "
                    "macOS. On Linux, you can use xlwings Server or xlwings Reader."
                )
            elif sys.platform.startswith("darwin"):
                raise XlwingsError(
                    'Make sure to have "appscript" and "psutil", '
                    "dependencies of xlwings, installed."
                )
            elif sys.platform.startswith("win"):
                raise XlwingsError(
                    'Make sure to have "pywin32", a dependency of xlwings, installed.'
                )
        return engines.active.apps.impl


class ActiveAppBooks(Books):
    def __init__(self) -> None:
        pass

    # override class name which appears in repr
    _name = "Books"

    @property
    def impl(self) -> Any:
        if not apps:
            raise XlwingsError("Couldn't find any active App!")
        return apps.active.books.impl


class ActiveBookSheets(Sheets):
    def __init__(self) -> None:
        pass

    # override class name which appears in repr
    _name = "Sheets"

    @property
    def impl(self) -> Any:
        return books.active.sheets.impl


apps = ActiveEngineApps()

books = ActiveAppBooks()

sheets = ActiveBookSheets()
