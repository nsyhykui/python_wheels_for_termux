from __future__ import annotations

import os
from collections.abc import Iterable, Mapping
from datetime import datetime, timezone
from functools import partial, wraps
from itertools import chain
from pathlib import Path
from weakref import WeakValueDictionary

import numpy as np
import typing_extensions as tp

from static_frame.core.exception import (
    ErrorInitStore,
    StoreFileMutation,
    StoreParameterConflict,
)
from static_frame.core.frame import Frame
from static_frame.core.store_config import StoreConfigBase, StoreConfigMap
from static_frame.core.util import (
    NOT_IN_CACHE_SENTINEL,
    TCallableAny,
    bytes_to_size_label,
    path_filter,
)

if tp.TYPE_CHECKING:
    from static_frame.core.generic_aliases import TFrameAny
    from static_frame.core.store_config import TVStoreConfigMapInitializer
    from static_frame.core.util import (
        TLabel,
        TPathSpecifier,
    )

    TNDArrayAny: tp.TypeAlias = np.ndarray[tp.Any, tp.Any]
    TDtypeAny: tp.TypeAlias = np.dtype[tp.Any]


# -------------------------------------------------------------------------------
# decorators


TVCallableAny = tp.TypeVar('TVCallableAny', bound=TCallableAny)


def store_coherent_non_write(f: TVCallableAny) -> TVCallableAny:
    @wraps(f)
    def wrapper(*args: tp.Any, **kwargs: tp.Any) -> tp.Any:
        """Decorator for derived Store class implementation of read(), labels()."""
        args[0]._mtime_coherent()
        return f(*args, **kwargs)

    return wrapper  # type: ignore


def store_coherent_write(f: TVCallableAny) -> TVCallableAny:
    """Decorator for derived Store classes implementation of write()"""

    @wraps(f)
    def wrapper(*args: tp.Any, **kwargs: tp.Any) -> tp.Any:
        post = f(*args, **kwargs)
        args[0]._mtime_update()
        return post

    return wrapper  # type: ignore


# -------------------------------------------------------------------------------
class InventoryMetrics(tp.NamedTuple):
    path: str
    last_modified: str
    size: str


class InventoryDescriptor:
    @staticmethod
    def get_metrics(fp: str, last_modified: float) -> InventoryMetrics:
        pfp = Path(fp)
        size = bytes_to_size_label(pfp.stat().st_size)
        utc = datetime.fromtimestamp(last_modified, timezone.utc).isoformat()
        return InventoryMetrics(str(pfp), utc, size)

    def __get__(
        self,
        obj: None | StoreBase,
        cls: type[StoreBase] | None = None,
    ) -> tp.Callable[[], Iterable[InventoryMetrics]]:
        if obj is None:  # this is the class

            def func_cls() -> Iterable[InventoryMetrics]:
                yield InventoryMetrics('', '', '')

            return func_cls

        def func() -> Iterable[InventoryMetrics]:
            if isinstance(obj, Store):  # it has an fp
                yield self.get_metrics(obj._fp, obj._last_modified)
            elif isinstance(obj, StoreManifest):
                for fp, lm in zip(
                    obj._label_to_fp.values(), obj._label_to_last_modified.values()
                ):
                    yield self.get_metrics(fp, lm)
            else:
                raise NotImplementedError()  # pragma: no cover

        return func


# -------------------------------------------------------------------------------
class StoreBase:
    __slots__ = ('_weak_cache',)

    _weak_cache: WeakValueDictionary[TLabel, TFrameAny]

    iter_inventory = InventoryDescriptor()

    def _mtime_update(self) -> None:
        raise NotImplementedError()  # pragma: no cover

    def _mtime_coherent(self) -> None:
        raise NotImplementedError()  # pragma: no cover

    def __getstate__(self) -> tuple[None, dict[str, tp.Any]]:
        # https://docs.python.org/3/library/pickle.html#object.__getstate__
        # staying consistent with __slots__ only objects by using None as first value in tuple
        # Walk the MRO to collect slots from all classes in the hierarchy.
        slots = (s for cls in type(self).__mro__ for s in getattr(cls, '__slots__', ()))
        return (
            None,
            {attr: getattr(self, attr) for attr in slots if attr != '_weak_cache'},
        )

    def __setstate__(self, state: tuple[None, dict[str, tp.Any]]) -> None:
        for key, value in state[1].items():
            setattr(self, key, value)
        self._weak_cache = WeakValueDictionary()

    # ---------------------------------------------------------------------------
    @staticmethod
    def get_field_names_and_dtypes(
        *,
        frame: TFrameAny,
        include_index: bool,
        include_index_name: bool,
        include_columns: bool,
        include_columns_name: bool,
        force_str_names: bool = False,
        force_brackets: bool = False,
    ) -> tuple[tp.Sequence[str], tp.Sequence[TDtypeAny]]:
        # NOTE: this routine is similar to routines in DBQuery; this has more configuration.
        index = frame.index
        columns = frame.columns
        columns_values: tp.Sequence[TLabel] = columns.values  # type: ignore

        if include_index_name and include_columns_name:
            raise StoreParameterConflict(
                'cannot include_index_name and include_columns_name with this Store'
            )

        if columns.depth > 1:
            # The str() of an array produces a space-delimited representation that includes list brackets; we could trim these brackets here, but need them for SQLite usage; thus, clients will have to trim if necessary.
            columns_values = tuple(str(c) for c in columns_values)

        field_names: tp.Sequence[TLabel]
        dtypes: list[TDtypeAny]

        if not include_index:
            if include_columns_name:
                raise StoreParameterConflict(
                    'cannot include_columns_name when include_index is False'
                )
            dtypes = frame._blocks.dtypes.tolist()
            if include_columns:
                field_names = columns_values
            else:  # name fields with integers?
                field_names = range(frame._blocks.shape[1])
        else:
            if index.depth == 1:
                dtypes = [index.dtype]  # type: ignore
            else:
                dtypes = index.dtypes.values.tolist()  # type: ignore [attr-defined]
            # Get a list to mutate.
            if include_index_name:
                field_names = list(index.names)
            elif include_columns_name and index.depth == columns.depth:
                field_names = list(columns.names)
            elif include_columns_name and index.depth == 1 and columns.depth > 1:
                field_names = [
                    tuple(str(c) for c in columns.names),
                ]
            else:  # if index_depth > 1 and not equal t columns_depth
                raise StoreParameterConflict(
                    'cannot determine field names over index; set one of include_index_name or include_columns_name'
                )

            # add frame dtypes t0 those from index
            dtypes.extend(frame._blocks.dtypes)

            # add index names in front of column names
            if include_columns:
                field_names.extend(columns_values)  # pyright: ignore
            else:  # name fields with integers?
                field_names.extend(range(frame._blocks.shape[1]))  # pyright: ignore

        field_names_post: tp.Sequence[str]
        if force_str_names:
            field_names_post = [str(n) for n in field_names]
        elif force_brackets:

            def gen() -> tp.Iterator[str]:
                for name in field_names:
                    name_str = str(name)
                    if name_str.startswith('[') and name_str.endswith(']'):
                        yield name_str
                    elif isinstance(name, tuple):
                        # make look like it came from the array
                        yield f'[{" ".join((repr(n) for n in name))}]'
                    else:
                        yield f'[{name_str}]'

            field_names_post = list(gen())
        else:
            field_names_post = field_names  # type: ignore

        return field_names_post, dtypes

    @staticmethod
    def _get_row_iterator(
        frame: TFrameAny, include_index: bool
    ) -> tp.Callable[[], tp.Iterator[tp.Sequence[tp.Any]]]:
        if include_index:
            index = frame._index
            index_values = index.values

            def values() -> tp.Iterator[tp.Sequence[tp.Any]]:
                # NOTE: using iter_array here forces coercion
                for idx, row in enumerate(frame.iter_array(axis=1)):
                    if index.depth > 1:
                        index_row = index_values[idx]  # this is an array
                    else:
                        index_row = (index_values[idx],)
                    yield tuple(chain(index_row, row))

            return values

        return partial(frame.iter_array, axis=1)  # type: ignore

    @staticmethod
    def get_column_iterator(
        frame: TFrameAny, include_index: bool
    ) -> tp.Iterator[TNDArrayAny]:
        if include_index:
            index_depth = frame._index.depth

            if index_depth == 1:
                index_values = frame._index.values
                return chain((index_values,), frame._blocks.iter_columns_arrays())
            return chain(
                (frame._index.values_at_depth(d) for d in range(index_depth)),
                frame._blocks.iter_columns_arrays(),
            )
        # avoid creating a Series per column by going to blocks
        return frame._blocks.iter_columns_arrays()

    # ---------------------------------------------------------------------------
    def read_many(self, labels: tp.Iterable[TLabel]) -> tp.Iterator[TFrameAny]:
        """Read many Frame, given by `labels`, from the Store. Return an iterator of instances of `Frame`."""
        raise NotImplementedError()  # pragma: no cover

    @store_coherent_non_write
    def read(self, label: TLabel) -> TFrameAny:
        """Read a single Frame, given by `label`, from the Store. Return a `Frame`. This is a convenience method using ``read_many``."""
        return next(self.read_many((label,)))

    def write(
        self,
        items: tp.Iterable[tuple[str, TFrameAny]],
    ) -> None:
        """Write all ``Frames`` in the Store."""
        raise NotImplementedError()  # pragma: no cover

    def labels(
        self,
        *,
        strip_ext: bool = True,
    ) -> tp.Iterator[TLabel]:
        raise NotImplementedError()  # pragma: no cover


# -------------------------------------------------------------------------------

TVStoreConfig = tp.TypeVar('TVStoreConfig', bound='StoreConfigBase')


class Store(tp.Generic[TVStoreConfig], StoreBase):
    _EXT: tp.FrozenSet[str]
    _EXPORTER: tp.ClassVar[TCallableAny]
    _STORE_CONFIG_CLASS: type[TVStoreConfig]

    __slots__ = (
        '_fp',
        '_last_modified',
        '_config',
    )

    _config: StoreConfigMap[TVStoreConfig]

    def __init__(
        self,
        fp: TPathSpecifier,
        config: TVStoreConfigMapInitializer[TVStoreConfig] = None,
    ) -> None:
        # Redefine fp variable as only string after the filter.
        filtered_fp: str = path_filter(fp)  # type: ignore

        if os.path.splitext(filtered_fp)[1] not in self._EXT:
            raise ErrorInitStore(
                f'file path {filtered_fp} does not match one of the required extensions: {self._EXT}'
            )

        self._fp = filtered_fp
        self._last_modified = np.nan
        self._mtime_update()
        self._weak_cache = WeakValueDictionary()
        self._config = StoreConfigMap[TVStoreConfig].from_initializer(
            config if config is not None else self._STORE_CONFIG_CLASS()
        )

        # Typehints do not enforce runtime! Prevent late AttributeErrors if user
        # provides invalid config class for this specific Store.
        # We only need to check the `default` config since `StoreConfigMap` already
        # enforces internal consistency
        if not isinstance(cfg := self._config.default, self._STORE_CONFIG_CLASS):
            raise ErrorInitStore(
                f'Invalid store config for {type(self).__name__}: '
                f'expected {self._STORE_CONFIG_CLASS.__name__}, '
                f'got {type(cfg).__name__}'
            )

    def _mtime_update(self) -> None:
        if os.path.exists(self._fp):
            self._last_modified = os.path.getmtime(self._fp)
        else:
            self._last_modified = np.nan

    def _mtime_coherent(self) -> None:
        """Raise if a file exists at self._fp and its mtime is not as expected"""
        if os.path.exists(self._fp):
            if os.path.getmtime(self._fp) != self._last_modified:
                raise StoreFileMutation(f'file {self._fp} was unexpectedly changed')
        elif not np.isnan(self._last_modified):
            # file existed previously and we got a modification time, but now it does not exist
            raise StoreFileMutation(f'expected file {self._fp} no longer exists')

    # def __copy__(self) -> 'Store':
    #     '''
    #     Return a new Store instance linked to the same file.
    #     '''
    #     return self.__class__(fp=self._fp)


# -------------------------------------------------------------------------------
class StoreManifest(StoreBase):
    _EXT: frozenset[str] = frozenset(('.pickle', '.npz'))

    __slots__ = (
        '_label_to_fp',
        '_label_to_last_modified',
        '_stripped_to_label',
    )

    def __init__(
        self,
        label_to_fp_or_fps: Mapping[TLabel, TPathSpecifier] | Iterable[TPathSpecifier],
        /,
    ) -> None:
        label_to_fp = {}

        def insert(label: TLabel, fp: str) -> None:
            if os.path.isdir(fp):  # an NPY
                label_to_fp[label] = fp
            elif os.path.splitext(fp)[1] not in self._EXT:
                raise ErrorInitStore(
                    f'file path {fp} does not match one of the required extensions: {self._EXT}'
                )
            else:
                label_to_fp[label] = fp

        if isinstance(label_to_fp_or_fps, Mapping):
            for label, fp in label_to_fp_or_fps.items():
                # Redefine fp variable as only string after the filter.
                filtered_fp: str = path_filter(fp)  # type: ignore
                insert(label, filtered_fp)
        else:
            for label in label_to_fp_or_fps:
                filtered_fp: str = path_filter(label)  # type: ignore
                label = os.path.basename(filtered_fp)
                # NOTE: we keep extensions on filter on labels()
                insert(label, filtered_fp)

        self._label_to_fp = label_to_fp
        self._label_to_last_modified: dict[TLabel, float] = {}
        # only store strings in stripped
        self._stripped_to_label: dict[str, str] = {}
        self._mtime_update()
        self._weak_cache = WeakValueDictionary()

    def _mtime_update(self) -> None:
        for label, fp in self._label_to_fp.items():
            if os.path.exists(fp):
                self._label_to_last_modified[label] = os.path.getmtime(fp)
            else:
                self._label_to_last_modified[label] = np.nan

    def _mtime_coherent(self) -> None:
        """Raise if a file exists and its mtime is not as expected"""
        for label, fp in self._label_to_fp.items():
            if os.path.exists(fp):
                if os.path.getmtime(fp) != self._label_to_last_modified[label]:
                    raise StoreFileMutation(f'file {fp} was unexpectedly changed')
            elif not np.isnan(self._label_to_last_modified[label]):
                # file existed previously and we got a modification time, but now it does not exist
                raise StoreFileMutation(f'expected file {fp} no longer exists')

    @store_coherent_non_write
    def labels(
        self,
        *,
        strip_ext: bool = True,
    ) -> tp.Iterator[TLabel]:
        for label, fp in self._label_to_fp.items():
            if (
                strip_ext
                and isinstance(label, str)
                and not os.path.isdir(fp)
                and (ext := os.path.splitext(label)[-1])
            ):
                stripped = label.replace(ext, '')
                # store label without extension for quick lookup
                self._stripped_to_label[stripped] = label
                yield stripped
            else:
                yield label

    @store_coherent_non_write
    def read_many(
        self,
        labels: tp.Iterable[TLabel],
    ) -> tp.Iterator[TFrameAny]:
        for stripped in labels:
            # must normalize string labels first; label could be None or falsy
            label: TLabel
            if isinstance(stripped, str):
                label = self._stripped_to_label.get(stripped, stripped)
            else:
                label = stripped

            cache_lookup = self._weak_cache.get(label, NOT_IN_CACHE_SENTINEL)
            if cache_lookup is not NOT_IN_CACHE_SENTINEL:
                yield cache_lookup  # pyright: ignore
                continue

            fp = self._label_to_fp[label]
            if os.path.isdir(fp):
                f = Frame.from_npy(fp)
            else:
                ext = os.path.splitext(fp)[-1]
                if ext == '.pickle':
                    f = Frame.from_pickle(fp)
                elif ext == '.npz':
                    f = Frame.from_npz(fp)
                else:
                    raise NotImplementedError(
                        f'no support for ext {ext}'
                    )  # pragma: no cover

            self._weak_cache[label] = f
            yield f
