from __future__ import annotations

import pickle
import tempfile
from itertools import product

import numpy as np
import typing_extensions as tp

from static_frame.core.exception import (
    ErrorInitStore,
    ErrorInitStoreConfig,
    StoreParameterConflict,
)
from static_frame.core.frame import Frame
from static_frame.core.store import Store
from static_frame.core.store_config import (
    StoreConfigBase,
    StoreConfigCSV,
    StoreConfigMap,
    StoreConfigNPY,
    StoreConfigTSV,
    StoreConfigXLSX,
)
from static_frame.core.store_zip import StoreZipCSV
from static_frame.test.test_case import TestCase


class MockStore(Store):
    _EXT = frozenset({'.tst'})
    _STORE_CONFIG_CLASS = StoreConfigBase


class TestUnit(TestCase):
    # ---------------------------------------------------------------------------

    def test_store_init_a(self) -> None:
        class StoreDerived(Store):
            _EXT = frozenset(('.txt',))
            _STORE_CONFIG_CLASS = StoreConfigBase

        st = StoreDerived(fp='foo.txt')
        self.assertTrue(np.isnan(st._last_modified))

    def test_store_config_map_init_a(self) -> None:
        maps = {
            'a': StoreConfigXLSX(index_depth=2),
            'b': StoreConfigXLSX(index_depth=3, label_encoder=str),
        }

        with self.assertRaises(ErrorInitStoreConfig):
            sc1m = StoreConfigMap.from_initializer(maps)

    def test_store_config_map_init_b(self) -> None:
        maps = {
            'a': StoreConfigXLSX(index_depth=2, label_encoder=str),
            'b': StoreConfigXLSX(index_depth=3, label_encoder=str),
        }
        default = StoreConfigXLSX(label_encoder=str)

        sc1m = StoreConfigMap(maps, default=default)
        self.assertEqual(sc1m.default.label_encoder, str)

    def test_store_config_map_init_c(self) -> None:
        maps1 = {
            'a': StoreConfigXLSX(read_max_workers=2),
            'b': StoreConfigXLSX(read_max_workers=3),
        }

        default = StoreConfigXLSX(read_max_workers=2)

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps1, default=default)  # Config has conflicting info

        maps2 = {
            'a': StoreConfigXLSX(read_max_workers=2),
            'b': StoreConfigXLSX(read_max_workers=2),
        }

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps2)  # Default is None

        sc1m = StoreConfigMap(maps2, default=default)
        self.assertEqual(sc1m.default.read_max_workers, 2)

    def test_store_config_map_init_d(self) -> None:
        maps1 = {
            'a': StoreConfigXLSX(read_chunksize=2),
            'b': StoreConfigXLSX(read_chunksize=3),
        }

        default = StoreConfigXLSX(read_chunksize=2)

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps1, default=default)  # Config has conflicting info

        maps2 = {
            'a': StoreConfigXLSX(read_chunksize=2),
            'b': StoreConfigXLSX(read_chunksize=2),
        }

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps2)  # Default is 1

        sc1m = StoreConfigMap(maps2, default=default)
        self.assertEqual(sc1m.default.read_chunksize, 2)

    def test_store_config_map_init_e(self) -> None:
        maps1 = {
            'a': StoreConfigXLSX(write_max_workers=2),
            'b': StoreConfigXLSX(write_max_workers=3),
        }

        default = StoreConfigXLSX(write_max_workers=2)

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps1, default=default)  # Config has conflicting info

        maps2 = {
            'a': StoreConfigXLSX(write_max_workers=2),
            'b': StoreConfigXLSX(write_max_workers=2),
        }

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps2)  # Default is None

        sc1m = StoreConfigMap(maps2, default=default)
        self.assertEqual(sc1m.default.write_max_workers, 2)

    def test_store_config_map_init_f(self) -> None:
        maps1 = {
            'a': StoreConfigXLSX(write_chunksize=2),
            'b': StoreConfigXLSX(write_chunksize=3),
        }

        default = StoreConfigXLSX(write_chunksize=2)

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps1, default=default)  # Config has conflicting info

        maps2 = {
            'a': StoreConfigXLSX(write_chunksize=2),
            'b': StoreConfigXLSX(write_chunksize=2),
        }

        with self.assertRaises(ErrorInitStoreConfig):
            StoreConfigMap(maps2)  # Default is 1

        sc1m = StoreConfigMap(maps2, default=default)
        self.assertEqual(sc1m.default.write_chunksize, 2)

    # ---------------------------------------------------------------------------
    def test_store_config_pickleable_a(self) -> None:
        kwargs = dict(
            index_depth=1,
            columns_depth=1,
            consolidate_blocks=True,
            skip_header=1,
            skip_footer=1,
            trim_nadir=True,
            include_index=True,
            include_index_name=True,
            include_columns=True,
            include_columns_name=True,
            merge_hierarchical_labels=True,
        )

        kwargs_with_unhashable_components = dict(
            **kwargs,
            label_encoder=lambda x: x,
            label_decoder=lambda x: x,
        )

        for depth_levels, columns_select, dtypes in product(
            (None, 1, [1, 2], (1, 2)),
            (None, ['a'], ('a',)),
            (None, 'int', int, np.int64, [int], (int,), {'a': int}),
        ):
            config = StoreConfigXLSX(
                **kwargs,  # type: ignore [arg-type]
                index_name_depth_level=depth_levels,
                columns_name_depth_level=depth_levels,
                columns_select=columns_select,
                dtypes=dtypes,
            )

            config_known_pickleable = StoreConfigXLSX(
                **kwargs_with_unhashable_components,  # type: ignore [arg-type]
                index_name_depth_level=depth_levels,
                columns_name_depth_level=depth_levels,
                columns_select=columns_select,
                dtypes=dtypes,
            )
            fco1 = config.to_frame_ctor_config()
            fco2 = config_known_pickleable.to_frame_ctor_config()

            self.assertNotEqual(config, config_known_pickleable)
            self.assertEqual(fco1, fco2)
            self.assertEqual(pickle.dumps(fco1), pickle.dumps(fco2))

    def test_store_config_pickleable_b(self) -> None:
        config1 = StoreConfigXLSX(index_depth=1)
        config2 = StoreConfigXLSX(index_depth=2)
        self.assertNotEqual(config1, config2)

        self.assertTrue(config1 is not None)
        self.assertFalse(config1 is None)

        config1 = StoreConfigXLSX(columns_select=['a'])
        config2 = StoreConfigXLSX(columns_select=('b',))
        self.assertNotEqual(config1, config2)

        config1 = StoreConfigXLSX(dtypes=str)
        config2 = StoreConfigXLSX(dtypes=int)
        self.assertNotEqual(config1, config2)

        config1 = StoreConfigXLSX(dtypes=str)
        config2 = StoreConfigXLSX(dtypes=dict(a=int))
        self.assertNotEqual(config1, config2)

        config1 = StoreConfigXLSX(index_name_depth_level=None)
        config2 = StoreConfigXLSX(index_name_depth_level=(1, 2))
        self.assertNotEqual(config1, config2)

    def test_store_config_pickleable_eq(self) -> None:
        config1 = StoreConfigXLSX(index_depth=1)
        self.assertFalse(config1 == None)

    # ---------------------------------------------------------------------------
    def test_store_config_map_a(self) -> None:
        sc1 = StoreConfigXLSX(index_depth=3, columns_depth=3)
        sc1m = StoreConfigMap.from_initializer(sc1)
        self.assertEqual(sc1m['a'].index_depth, 3)
        self.assertEqual(sc1m['b'].index_depth, 3)

        sc2 = StoreConfigXLSX(include_index=False)
        sc2m = StoreConfigMap.from_initializer(sc2)
        self.assertEqual(sc2m['a'].include_index, False)
        self.assertEqual(sc2m['b'].include_index, False)

    def test_store_config_map_b(self) -> None:
        maps = {'a': StoreConfigXLSX(index_depth=2), 'b': StoreConfigXLSX(index_depth=3)}
        sc1m = StoreConfigMap(maps)
        self.assertEqual(sc1m['a'].index_depth, 2)
        self.assertEqual(sc1m['b'].index_depth, 3)
        self.assertEqual(sc1m['c'].index_depth, 0)

    def test_store_config_map_c(self) -> None:
        sc1 = StoreConfigXLSX(index_depth=3, columns_depth=3)
        maps = {'a': StoreConfigXLSX(index_depth=2), 'b': StoreConfigXLSX(index_depth=3)}
        sc1m = StoreConfigMap(maps)

        sc2m = StoreConfigMap.from_initializer(sc1)
        self.assertEqual(sc2m['a'].index_depth, 3)

        sc3m = StoreConfigMap.from_initializer(sc1m)
        self.assertEqual(sc3m['a'].index_depth, 2)
        self.assertEqual(sc3m['b'].index_depth, 3)

        sc4m = StoreConfigMap.from_initializer(maps)
        self.assertEqual(sc4m['a'].index_depth, 2)
        self.assertEqual(sc4m['b'].index_depth, 3)

    def test_store_config_map_d(self) -> None:
        with self.assertRaises(ErrorInitStoreConfig):
            _ = StoreConfigMap({'a': object()})  # type: ignore

        with self.assertRaises(ErrorInitStoreConfig):
            _ = StoreConfigMap(default=object())  # type: ignore

    def test_store_get_field_names_and_dtypes_a(self) -> None:
        f1 = Frame.from_records(
            (('a', True, None),), index=(('a',)), columns=(('x', 'y', 'z'))
        )

        field_names, dtypes = Store.get_field_names_and_dtypes(
            frame=f1,
            include_index=False,
            include_index_name=True,
            include_columns=False,
            include_columns_name=False,
        )
        self.assertEqual(field_names, range(3))
        self.assertEqual(dtypes, [np.dtype('<U1'), np.dtype('bool'), np.dtype('O')])

    def test_store_get_field_names_and_dtypes_b(self) -> None:
        f1 = Frame.from_records(
            (('a', True, None),), index=(('a',)), columns=(('x', 'y', 'z'))
        )

        field_names, dtypes = Store.get_field_names_and_dtypes(
            frame=f1,
            include_index=False,
            include_index_name=True,
            include_columns=True,
            include_columns_name=False,
        )

        self.assertEqual(field_names.tolist(), ['x', 'y', 'z'])  # type: ignore
        self.assertEqual(dtypes, [np.dtype('<U1'), np.dtype('bool'), np.dtype('O')])

    def test_store_get_field_names_and_dtypes_c(self) -> None:
        f1 = Frame.from_records(
            (('a', True, None),), index=(('a',)), columns=(('x', 'y', 'z'))
        ).rename(columns='foo')

        with self.assertRaises(StoreParameterConflict):
            field_names, dtypes = Store.get_field_names_and_dtypes(
                frame=f1,
                include_index=False,
                include_index_name=True,
                include_columns=True,
                include_columns_name=True,
            )

        field_names, dtypes = Store.get_field_names_and_dtypes(
            frame=f1,
            include_index=True,
            include_index_name=False,
            include_columns=True,
            include_columns_name=True,
        )
        self.assertEqual(field_names, ['foo', 'x', 'y', 'z'])
        self.assertTrue(len(field_names) == len(dtypes))

    def test_store_get_field_names_and_dtypes_d(self) -> None:
        from static_frame.core.index_hierarchy import IndexHierarchy

        columns = IndexHierarchy.from_labels(
            ((1, 'a'), (1, 'b'), (2, 'c')), name=('foo', 'bar')
        )
        f1 = Frame.from_records((('a', True, None),), index=(('a',)), columns=columns)

        field_names, dtypes = Store.get_field_names_and_dtypes(
            frame=f1,
            include_index=True,
            include_index_name=False,
            include_columns=True,
            include_columns_name=True,
        )
        self.assertEqual(field_names, [('foo', 'bar'), "[1 'a']", "[1 'b']", "[2 'c']"])
        self.assertTrue(len(field_names) == len(dtypes))

        field_names, dtypes = Store.get_field_names_and_dtypes(
            frame=f1,
            include_index=True,
            include_index_name=False,
            include_columns=True,
            include_columns_name=True,
            force_brackets=True,
        )
        self.assertEqual(field_names, ["['foo' 'bar']", "[1 'a']", "[1 'b']", "[2 'c']"])

        with self.assertRaises(StoreParameterConflict):
            field_names, dtypes = Store.get_field_names_and_dtypes(
                frame=f1,
                include_index=True,
                include_index_name=False,
                include_columns=True,
                include_columns_name=False,
            )

        with self.assertRaises(StoreParameterConflict):
            field_names, dtypes = Store.get_field_names_and_dtypes(
                frame=f1,
                include_index=False,
                include_index_name=False,
                include_columns=True,
                include_columns_name=True,
            )

    # ---------------------------------------------------------------------------

    def test_store_config_map_get_default_a(self) -> None:
        maps = {'a': StoreConfigXLSX(index_depth=2), 'b': StoreConfigXLSX(index_depth=3)}

        sc1m = StoreConfigMap.from_initializer(maps)
        self.assertTrue(sc1m.default == StoreConfigXLSX())

    # ---------------------------------------------------------------------------

    def test_store_pickle_excludes_weak_cache(self) -> None:
        s1 = MockStore('/test.tst')

        s1._weak_cache['abc'] = Frame()

        s2 = pickle.loads(pickle.dumps(s1))

        assert 'abc' not in s2._weak_cache
        assert not s2._weak_cache

    def test_store_invalid_config(self) -> None:
        with tempfile.NamedTemporaryFile(suffix='.zip') as tmp_fp:
            # Invalid config defined as default
            with self.assertRaises(ErrorInitStore) as e_info:
                StoreZipCSV(tmp_fp.name, config=StoreConfigNPY())

            [e_msg] = e_info.exception.args
            assert (
                e_msg
                == 'Invalid store config for StoreZipCSV: expected StoreConfigCSV, got StoreConfigNPY'
            )

            # Invalid config defined as mapping
            with self.assertRaises(ErrorInitStore) as e_info:
                StoreZipCSV(tmp_fp.name, config=dict(test_label=StoreConfigTSV()))

            [e_msg] = e_info.exception.args
            assert (
                e_msg
                == 'Invalid store config for StoreZipCSV: expected StoreConfigCSV, got StoreConfigTSV'
            )

            # Default config is not fine
            with self.assertRaises(ErrorInitStore) as e_info:
                StoreZipCSV(tmp_fp.name, config=StoreConfigBase())

            [e_msg] = e_info.exception.args
            assert (
                e_msg
                == 'Invalid store config for StoreZipCSV: expected StoreConfigCSV, got StoreConfigBase'
            )

            # Default config is not fine
            with self.assertRaises(ErrorInitStore) as e_info:
                StoreZipCSV(tmp_fp.name, config=dict(test_label=StoreConfigBase()))

            [e_msg] = e_info.exception.args
            assert (
                e_msg
                == 'Invalid store config for StoreZipCSV: expected StoreConfigCSV, got StoreConfigBase'
            )

    @classmethod
    def _yield_leaf_subclassses(cls, klass: type) -> tp.Iterator[type]:
        if subclasses := klass.__subclasses__():
            for subclass in subclasses:
                yield from cls._yield_leaf_subclassses(subclass)
            return

        yield klass

    @staticmethod
    def _discover_typehint(klass: type) -> type[StoreConfigBase] | None:
        for base in tp.get_original_bases(klass):
            if tp.get_origin(base) is None:
                continue

            match tp.get_args(base):
                case (config_type,) if isinstance(config_type, type) and issubclass(
                    config_type, StoreConfigBase
                ):
                    return config_type  # type: ignore
                case _:
                    pass

        return None

    def test_store_subclasses_typehints_match_defined_store_config_class(self) -> None:
        def assert_typehint_and_static_match() -> None:
            classes_w_typehints = [
                (typehint, cls._STORE_CONFIG_CLASS)
                for cls in self._yield_leaf_subclassses(Store)
                if (typehint := self._discover_typehint(cls)) is not None
            ]
            assert classes_w_typehints
            assert all(t == c for t, c in classes_w_typehints)

        assert_typehint_and_static_match()

        class MockStoreInvalid(Store[StoreConfigXLSX]):
            _EXT = frozenset({'.tst'})
            _STORE_CONFIG_CLASS = StoreConfigNPY  # type: ignore

        with self.assertRaises(AssertionError, msg=MockStoreInvalid):
            assert_typehint_and_static_match()


if __name__ == '__main__':
    import unittest

    unittest.main()
