#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""This module provides helper code to make type annotation within Airflow codebase easier."""

from __future__ import annotations

__all__ = ["Literal", "ParamSpec", "Self", "TypeAlias", "TypeGuard", "Unpack", "assert_never"]

import sys

# Keeping this for backwards-compat with old providers
from typing import Literal, ParamSpec, TypeAlias, TypeGuard

if sys.version_info >= (3, 11):
    from typing import Self, Unpack, assert_never
else:
    # TODO: Remove once Python 3.10 support is dropped (EOL 2026)
    from typing_extensions import Self, Unpack, assert_never
