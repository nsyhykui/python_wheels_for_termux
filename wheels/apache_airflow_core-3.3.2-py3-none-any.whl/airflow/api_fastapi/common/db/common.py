# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""
Database helpers for Airflow REST API.

:meta private:
"""

from __future__ import annotations

from collections.abc import AsyncGenerator, Generator, Sequence
from typing import TYPE_CHECKING, Annotated, Literal, overload

from fastapi import Depends
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session

from airflow.utils.db import get_query_count, get_query_count_async
from airflow.utils.session import NEW_SESSION, create_session, create_session_async, provide_session

if TYPE_CHECKING:
    from sqlalchemy.sql import Select

    from airflow.api_fastapi.core_api.base import OrmClause

# Rows a single scan reads. Result sets that fit are counted exactly; wider ones report a floor.
# Shared by the dashboard's historical metrics and by cursor-paginated listings, which surface an
# item count without counting every matching row — the point of cursor pagination on large tables.
EXACT_COUNT_LIMIT = 50_000


def _get_session() -> Generator[Session, None, None]:
    with create_session(scoped=False) as session:
        yield session


SessionDep = Annotated[Session, Depends(_get_session, scope="function")]


def apply_filters_to_select(
    *, statement: Select, filters: Sequence[OrmClause | None] | None = None
) -> Select:
    if filters is None:
        return statement
    for f in filters:
        if f is None:
            continue
        statement = f.to_orm(statement)

    return statement


def bounded_total_entries(
    *,
    statement: Select,
    filters: Sequence[OrmClause | None] | None = None,
    session: Session,
) -> tuple[int, int]:
    """
    Count the rows a cursor-paginated listing matches, reading at most ``EXACT_COUNT_LIMIT``.

    Returns ``(total, limit)`` where ``total`` is ``min(actual_count, EXACT_COUNT_LIMIT)`` — a
    ``total`` equal to ``limit`` means only that at least that many rows match — and ``limit`` is
    the cap that was applied, for the caller to surface as ``total_entries_limit``.

    The ``LIMIT`` sits inside the counted subquery so the database stops scanning once the cap is
    reached, keeping the count cheap on tables that cursor pagination exists to handle. ORDER BY is
    stripped for the same reason :func:`~airflow.utils.db.get_query_count` strips it: it cannot
    change a count and only constrains the planner.
    """
    statement = apply_filters_to_select(statement=statement, filters=filters)
    bounded = statement.order_by(None).limit(EXACT_COUNT_LIMIT).subquery()
    total = session.scalar(select(func.count()).select_from(bounded)) or 0
    return total, EXACT_COUNT_LIMIT


async def _get_async_session() -> AsyncGenerator[AsyncSession, None]:
    async with create_session_async() as session:
        yield session


AsyncSessionDep = Annotated[AsyncSession, Depends(_get_async_session)]


@overload
async def paginated_select_async(
    *,
    statement: Select,
    filters: Sequence[OrmClause] | None = None,
    order_by: OrmClause | None = None,
    offset: OrmClause | None = None,
    limit: OrmClause | None = None,
    session: AsyncSession,
    return_total_entries: Literal[True] = True,
) -> tuple[Select, int]: ...


@overload
async def paginated_select_async(
    *,
    statement: Select,
    filters: Sequence[OrmClause] | None = None,
    order_by: OrmClause | None = None,
    offset: OrmClause | None = None,
    limit: OrmClause | None = None,
    session: AsyncSession,
    return_total_entries: Literal[False],
) -> tuple[Select, None]: ...


async def paginated_select_async(
    *,
    statement: Select,
    filters: Sequence[OrmClause | None] | None = None,
    order_by: OrmClause | None = None,
    offset: OrmClause | None = None,
    limit: OrmClause | None = None,
    session: AsyncSession,
    return_total_entries: bool = True,
) -> tuple[Select, int | None]:
    statement = apply_filters_to_select(
        statement=statement,
        filters=filters,
    )

    total_entries = None
    if return_total_entries:
        total_entries = await get_query_count_async(statement, session=session)

    statement = apply_filters_to_select(
        statement=statement,
        filters=[order_by, offset, limit],
    )

    return statement, total_entries


@overload
def paginated_select(
    *,
    statement: Select,
    filters: Sequence[OrmClause] | None = None,
    order_by: OrmClause | None = None,
    offset: OrmClause | None = None,
    limit: OrmClause | None = None,
    session: Session = NEW_SESSION,
    return_total_entries: Literal[True] = True,
) -> tuple[Select, int]: ...


@overload
def paginated_select(
    *,
    statement: Select,
    filters: Sequence[OrmClause] | None = None,
    order_by: OrmClause | None = None,
    offset: OrmClause | None = None,
    limit: OrmClause | None = None,
    session: Session = NEW_SESSION,
    return_total_entries: Literal[False],
) -> tuple[Select, None]: ...


@provide_session
def paginated_select(
    *,
    statement: Select,
    filters: Sequence[OrmClause] | None = None,
    order_by: OrmClause | None = None,
    offset: OrmClause | None = None,
    limit: OrmClause | None = None,
    session: Session = NEW_SESSION,
    return_total_entries: bool = True,
) -> tuple[Select, int | None]:
    statement = apply_filters_to_select(
        statement=statement,
        filters=filters,
    )

    total_entries = None
    if return_total_entries:
        total_entries = get_query_count(statement, session=session)

    statement = apply_filters_to_select(statement=statement, filters=[order_by, offset, limit])

    return statement, total_entries
