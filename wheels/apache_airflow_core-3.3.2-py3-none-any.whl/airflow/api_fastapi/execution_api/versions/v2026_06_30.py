# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from __future__ import annotations

from cadwyn import (
    ResponseInfo,
    VersionChange,
    convert_response_to_previous_version_for,
    endpoint,
    schema,
)

from airflow.api_fastapi.execution_api.datamodels.taskinstance import (
    AssetEventDagRunReference,
    DagRun,
    TaskInstance,
    TIAwaitingInputStatePayload,
    TIRetryStatePayload,
    TIRunContext,
)


class AddVariableKeysEndpoint(VersionChange):
    """Add GET /variables/keys endpoint for listing variable keys with optional prefix filter."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (endpoint("/variables/keys", ["GET"]).didnt_exist,)


class AddConnectionTestEndpoint(VersionChange):
    """Add connection-tests endpoints for the async connection-test workflow."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (
        endpoint("/connection-tests/{connection_test_id}", ["PATCH"]).didnt_exist,
        endpoint("/connection-tests/{connection_test_id}/connection", ["GET"]).didnt_exist,
    )


class AddTaskInstanceQueueField(VersionChange):
    """Add the `queue` field to the TaskInstance model."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (schema(TaskInstance).field("queue").didnt_exist,)


class AddAwaitingInputStatePayload(VersionChange):
    """Add the awaiting_input task instance state transition payload (Human-in-the-loop, no trigger)."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (
        schema(TIAwaitingInputStatePayload).field("state").didnt_exist,
        schema(TIAwaitingInputStatePayload).field("timeout").didnt_exist,
        schema(TIAwaitingInputStatePayload).field("next_method").didnt_exist,
        schema(TIAwaitingInputStatePayload).field("next_kwargs").didnt_exist,
        schema(TIAwaitingInputStatePayload).field("rendered_map_index").didnt_exist,
    )


class AddRetryPolicyFields(VersionChange):
    """Add retry_delay_seconds and retry_reason fields to TIRetryStatePayload for pluggable retry policies."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (
        schema(TIRetryStatePayload).field("retry_delay_seconds").didnt_exist,
        schema(TIRetryStatePayload).field("retry_reason").didnt_exist,
    )


class AddTeamNameField(VersionChange):
    """Add the ``team_name`` field to DagRun model."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (schema(DagRun).field("team_name").didnt_exist,)

    @convert_response_to_previous_version_for(TIRunContext)  # type: ignore[arg-type]
    def remove_team_name_field(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Remove the ``team_name`` field from dag_run for older API versions."""
        if "dag_run" in response.body and isinstance(response.body["dag_run"], dict):
            response.body["dag_run"].pop("team_name", None)

    @convert_response_to_previous_version_for(DagRun)  # type: ignore[arg-type]
    def remove_team_name_from_dag_run_response(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Remove the ``team_name`` field from responses returning a DagRun directly."""
        if isinstance(response.body, dict):
            response.body.pop("team_name", None)

    # Schema-based converters are matched against the route's response model by identity, so a
    # route annotated ``DagRun | None`` never matches ``DagRun`` and has to be addressed by path.
    @convert_response_to_previous_version_for("/dag-runs/previous", ["GET"])  # type: ignore[arg-type]
    def remove_team_name_from_previous_dag_run(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Remove the ``team_name`` field from the previous-run response."""
        if isinstance(response.body, dict):
            response.body.pop("team_name", None)


class AddAssetsByAliasEndpoint(VersionChange):
    """Add endpoint to resolve assets from an AssetAlias."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (endpoint("/assets/by-alias", ["GET"]).didnt_exist,)


class AddTaskAndAssetStateStoreEndpoints(VersionChange):
    """Add task state store and asset state store API endpoints."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (
        endpoint("/store/ti/{task_instance_id}/{key:path}", ["GET"]).didnt_exist,
        endpoint("/store/ti/{task_instance_id}/{key:path}", ["PUT"]).didnt_exist,
        endpoint("/store/ti/{task_instance_id}/{key:path}", ["DELETE"]).didnt_exist,
        endpoint("/store/ti/{task_instance_id}", ["DELETE"]).didnt_exist,
        endpoint("/store/asset/by-name/value", ["GET"]).didnt_exist,
        endpoint("/store/asset/by-name/value", ["PUT"]).didnt_exist,
        endpoint("/store/asset/by-name/value", ["DELETE"]).didnt_exist,
        endpoint("/store/asset/by-name/clear", ["DELETE"]).didnt_exist,
        endpoint("/store/asset/by-uri/value", ["GET"]).didnt_exist,
        endpoint("/store/asset/by-uri/value", ["PUT"]).didnt_exist,
        endpoint("/store/asset/by-uri/value", ["DELETE"]).didnt_exist,
        endpoint("/store/asset/by-uri/clear", ["DELETE"]).didnt_exist,
    )


class AddPartitionDateField(VersionChange):
    """Expose the consumer DagRun's partition datetime on the execution API so consumer tasks can template it."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (schema(DagRun).field("partition_date").didnt_exist,)

    @convert_response_to_previous_version_for(TIRunContext)  # type: ignore[arg-type]
    def remove_partition_date_from_dag_run(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Strip ``partition_date`` from the nested ``dag_run`` payload for older clients."""
        if "dag_run" in response.body and isinstance(response.body["dag_run"], dict):
            response.body["dag_run"].pop("partition_date", None)

    @convert_response_to_previous_version_for(DagRun)  # type: ignore[arg-type]
    def remove_partition_date_from_dag_run_response(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Strip ``partition_date`` from responses returning a DagRun directly."""
        if isinstance(response.body, dict):
            response.body.pop("partition_date", None)

    # See remove_team_name_from_previous_dag_run: ``DagRun | None`` needs a path-based converter.
    @convert_response_to_previous_version_for("/dag-runs/previous", ["GET"])  # type: ignore[arg-type]
    def remove_partition_date_from_previous_dag_run(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Strip ``partition_date`` from the previous-run response."""
        if isinstance(response.body, dict):
            response.body.pop("partition_date", None)


class AddConsumedAssetEventPartitionKeyField(VersionChange):
    """Expose the upstream partition key on the asset events that triggered a consumer Dag run."""

    description = __doc__

    instructions_to_migrate_to_previous_version = (
        schema(AssetEventDagRunReference).field("partition_key").didnt_exist,
    )

    # Only ``TIRunContext`` can carry these events: ``DagRun.safe_extract_from_orm`` defaults
    # ``consumed_asset_events`` to ``[]`` whenever the relationship is not already loaded, and
    # ``/run`` is the only route that loads it -- so bare ``DagRun`` responses never carry one.
    @convert_response_to_previous_version_for(TIRunContext)  # type: ignore[arg-type]
    def remove_partition_key_from_consumed_asset_events(response: ResponseInfo) -> None:  # type: ignore[misc]
        """Strip ``partition_key`` from each consumed asset event for older clients."""
        dag_run = response.body.get("dag_run")
        if isinstance(dag_run, dict):
            for event in dag_run.get("consumed_asset_events") or ():
                if isinstance(event, dict):
                    event.pop("partition_key", None)
