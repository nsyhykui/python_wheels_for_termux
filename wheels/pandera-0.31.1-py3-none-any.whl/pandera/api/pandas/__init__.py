"""Pandas core."""
