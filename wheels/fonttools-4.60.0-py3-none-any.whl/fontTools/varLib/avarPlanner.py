def main(args=None):
    from .avar.plan import main

    main(args)


if __name__ == "__main__":
    main()
