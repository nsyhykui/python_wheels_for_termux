import datetime as dt

import pytest

from pandas_datareader import tsp as tsp

pytestmark = pytest.mark.stable


class TestTSPFunds(object):
    def test_get_allfunds(self):
        tspdata = tsp.TSPReader(start="2015-11-2", end="2015-11-2").read()

        assert len(tspdata) == 1

        assert round(tspdata["I Fund"][dt.datetime(2015, 11, 2)], 5) == 25.0058

    def test_get_one_fund(self):
        tspdata = tsp.TSPReader(
            start="2015-11-2", end="2015-11-2", symbols=("I Fund",)
        ).read()

        assert len(tspdata) == 1

        assert tspdata.columns.values.tolist() == ["I Fund"]

    def test_sanitize_response(self):
        class response(object):
            pass

        r = response()
        r.text = " , "
        ret = tsp.TSPReader._sanitize_response(r)
        assert ret == ""
        r.text = " a,b "
        ret = tsp.TSPReader._sanitize_response(r)
        assert ret == "a,b"
