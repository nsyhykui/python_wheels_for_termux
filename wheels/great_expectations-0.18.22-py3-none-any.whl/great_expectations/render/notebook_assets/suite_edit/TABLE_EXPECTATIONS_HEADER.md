### Table Expectation(s)
