import importlib
import warnings
from importlib.metadata import version
from pathlib import Path


def lazy_load():
    toga_core_imports = {}
    pyi = Path(__file__).with_suffix(".pyi")
    with pyi.open(encoding="utf-8") as f:
        for line in f:
            match line.split():
                case "from", module_name, "import", class_name, "as", _:
                    toga_core_imports[class_name] = module_name
    return toga_core_imports


toga_core_imports = lazy_load()

__all__ = list(toga_core_imports.keys())


def __getattr__(name):
    try:
        module_name = toga_core_imports[name]
    except KeyError:
        raise AttributeError(f"module '{__name__}' has no attribute '{name}'") from None
    else:
        module = importlib.import_module(module_name)
        value = getattr(module, name)
        globals()[name] = value
        return value


class NotImplementedWarning(RuntimeWarning):
    # pytest.warns() requires that Warning() subclasses are constructed by passing a
    # single argument (the warning message). Use a factory method to avoid reproducing
    # the message format and the warn invocation.
    @classmethod
    def warn(cls, platform: str, feature: str) -> None:
        """Raise a warning that a feature isn't implemented on a platform."""
        warnings.warn(
            NotImplementedWarning(f"[{platform}] Not implemented: {feature}"),
            stacklevel=2,
        )


__version__ = version("toga-core")
