# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Compatibility imports for core trigger base classes across Airflow 2 and Airflow 3."""

from __future__ import annotations

from typing import TYPE_CHECKING

from airflow.providers.common.compat._compat_utils import create_module_getattr

if TYPE_CHECKING:
    from airflow.triggers.base import BaseEventTrigger as BaseEventTrigger


# Airflow 3.0 added BaseEventTrigger to mark triggers usable as event-driven scheduling sources.
# Airflow 2.x has no such marker, so it falls back to BaseTrigger: subclasses still work as
# deferred triggers there, they just cannot drive an asset watcher.
_RENAME_MAP: dict[str, tuple[str, str, str]] = {
    "BaseEventTrigger": ("airflow.triggers.base", "airflow.triggers.base", "BaseTrigger"),
}

__getattr__ = create_module_getattr(import_map={}, rename_map=_RENAME_MAP)

__all__ = list(_RENAME_MAP.keys())
