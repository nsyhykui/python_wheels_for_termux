"""Debounce (trailing-edge / settle) admission control dependency.

Waits for submissions to settle, then fires once.  Uses two Redis keys
(winner + last_seen) so only one task bounces while the rest immediately
drop.
"""

from __future__ import annotations

import time
from datetime import timedelta
from types import TracebackType
from typing import Any

from .._lua import Arg, Key, redis_script
from .._redis import RedisClient
from ._base import AdmissionBlocked, Dependency, current_docket, current_execution

_ACTION_PROCEED = 1
_ACTION_RESCHEDULE = 2
_ACTION_DROP = 3


@redis_script
async def _debounce(
    redis: RedisClient,
    *,
    winner_key: Key[str],
    seen_key: Key[str],
    execution_key: Arg[str],
    settle_ms: Arg[int],
    now_ms: Arg[int],
    ttl_ms: Arg[int],
) -> list[int]: ...


class Debounce(Dependency["Debounce"]):
    """Wait for submissions to settle, then fire once.

    Uses two Redis keys per scope — a "winner" key (which execution gets
    to proceed) and a "last_seen" timestamp.  Only the winner bounces
    via reschedule; all other submissions are immediately dropped.

    Works both as a default parameter and as ``Annotated`` metadata::

        # Per-task: wait for 5s of quiet, then execute once
        async def process_webhooks(
            debounce: Debounce = Debounce(timedelta(seconds=5)),
        ) -> None: ...

        # Per-parameter: independent settle window per customer
        async def sync_customer(
            customer_id: Annotated[int, Debounce(timedelta(seconds=5))],
        ) -> None: ...
    """

    single: bool = True

    def __init__(self, settle: timedelta, *, scope: str | None = None) -> None:
        self.settle = settle
        self.scope = scope
        self._argument_name: str | None = None
        self._argument_value: Any = None

    def bind_to_parameter(self, name: str, value: Any) -> Debounce:
        bound = Debounce(self.settle, scope=self.scope)
        bound._argument_name = name
        bound._argument_value = value
        return bound

    async def __aenter__(self) -> Debounce:
        execution = current_execution.get()
        docket = current_docket.get()

        scope = self.scope or docket.name
        if self._argument_name is not None:
            hash_tag = f"{self._argument_name}:{self._argument_value}"
            base_key = f"{scope}:debounce:{hash_tag}"
        else:
            hash_tag = execution.function_name
            base_key = f"{scope}:debounce:{hash_tag}"

        # Use a Redis hash tag {…} so both keys land on the same cluster slot
        winner_key = f"{base_key}:{{{hash_tag}}}:winner"
        seen_key = f"{base_key}:{{{hash_tag}}}:last_seen"

        settle_ms = int(self.settle.total_seconds() * 1000)
        now_ms = int(time.time() * 1000)
        ttl_ms = settle_ms * 10

        async with docket.redis() as redis:
            result = await _debounce(
                redis,
                winner_key=winner_key,
                seen_key=seen_key,
                execution_key=execution.key,
                settle_ms=settle_ms,
                now_ms=now_ms,
                ttl_ms=ttl_ms,
            )

        action = result[0]
        remaining_ms = result[1]

        if action == _ACTION_PROCEED:
            return self

        reason = f"debounce ({self.settle}) on {base_key}"

        if action == _ACTION_RESCHEDULE:
            raise AdmissionBlocked(
                execution,
                reason=reason,
                retry_delay=timedelta(milliseconds=remaining_ms),
            )

        # DROP
        raise AdmissionBlocked(execution, reason=reason, reschedule=False)

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        pass
