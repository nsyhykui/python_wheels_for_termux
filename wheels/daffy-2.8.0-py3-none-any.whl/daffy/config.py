"""Configuration handling for DAFFY."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from types import MappingProxyType
from typing import Any

import tomli

# Configuration keys
_KEY_STRICT = "strict"
_KEY_LAZY = "lazy"
_KEY_STRICT_SPECS = "strict_specs"
_KEY_ROW_VALIDATION_MAX_ERRORS = "row_validation_max_errors"
_KEY_CHECKS_MAX_SAMPLES = "checks_max_samples"
_KEY_ALLOW_EMPTY = "allow_empty"

# Default values
_DEFAULT_STRICT = False
_DEFAULT_LAZY = False
_DEFAULT_STRICT_SPECS = False
_DEFAULT_MAX_ERRORS = 5
_DEFAULT_CHECKS_MAX_SAMPLES = 5
_DEFAULT_ALLOW_EMPTY = True


_DEFAULTS: dict[str, Any] = {
    _KEY_STRICT: _DEFAULT_STRICT,
    _KEY_LAZY: _DEFAULT_LAZY,
    _KEY_STRICT_SPECS: _DEFAULT_STRICT_SPECS,
    _KEY_ROW_VALIDATION_MAX_ERRORS: _DEFAULT_MAX_ERRORS,
    _KEY_CHECKS_MAX_SAMPLES: _DEFAULT_CHECKS_MAX_SAMPLES,
    _KEY_ALLOW_EMPTY: _DEFAULT_ALLOW_EMPTY,
}


def load_config(cwd: Path | None = None) -> dict[str, Any]:
    """Load daffy configuration from pyproject.toml."""
    config = dict(_DEFAULTS)

    config_path = find_config_file(cwd)
    if not config_path:
        return config

    try:
        with Path(config_path).open("rb") as f:
            daffy_config = tomli.load(f).get("tool", {}).get("daffy", {})

        for key, default_value in _DEFAULTS.items():
            if key in daffy_config:
                val = daffy_config[key]
                if isinstance(default_value, bool):
                    if not isinstance(val, bool):
                        raise TypeError(f"Config '{key}' must be a boolean, got {type(val).__name__}: {val!r}")
                else:  # isinstance(default_value, int)
                    if not isinstance(val, int) or isinstance(val, bool):
                        raise TypeError(f"Config '{key}' must be an integer, got {type(val).__name__}: {val!r}")
                    if val < 1:
                        raise ValueError(f"Config '{key}' must be >= 1, got {val}")
                config[key] = val
    except (FileNotFoundError, tomli.TOMLDecodeError):
        pass

    return config


def find_config_file(cwd: Path | None = None) -> str | None:
    """Find pyproject.toml in the current working directory or any parent directory."""
    current_dir = cwd.resolve() if cwd is not None else Path.cwd().resolve()
    for parent in [current_dir, *current_dir.parents]:
        path = parent / "pyproject.toml"
        if path.is_file():
            return str(path)
    return None


@lru_cache(maxsize=128)
def _get_config_for_cwd(cwd: str) -> MappingProxyType[str, Any]:
    """Load and cache configuration for a specific current working directory."""
    return MappingProxyType(load_config(Path(cwd)))


def get_config() -> MappingProxyType[str, Any]:
    """Get the daffy configuration, cached by current working directory.

    Returns an immutable view of the configuration to prevent accidental modification.
    """
    cwd = str(Path.cwd().resolve())
    return _get_config_for_cwd(cwd)


def clear_config_cache() -> None:
    """Clear the configuration cache. Primarily for testing."""
    _get_config_for_cwd.cache_clear()


def _get_bool_config(param: bool | None, key: str) -> bool:
    """Return param if provided, otherwise config value."""
    if param is not None:
        return param
    return bool(get_config()[key])


def _get_int_config(param: int | None, key: str, min_value: int = 1) -> int:
    """Return param if provided, otherwise config value. Validates minimum."""
    value = param if param is not None else int(get_config()[key])
    if value < min_value:
        raise ValueError(f"{key} must be >= {min_value}, got {value}")
    return value


def get_strict(strict_param: bool | None = None) -> bool:
    """Get the strict mode setting, with explicit parameter taking precedence over configuration.

    Args:
        strict_param: Explicitly provided strict parameter value, or None to use config

    Returns:
        bool: The effective strict mode setting

    """
    return _get_bool_config(strict_param, _KEY_STRICT)


def get_lazy(lazy_param: bool | None = None) -> bool:
    """Get the lazy mode setting, with explicit parameter taking precedence over configuration.

    When lazy=True, validation collects all errors before raising instead of stopping at the first.

    Args:
        lazy_param: Explicitly provided lazy parameter value, or None to use config

    Returns:
        bool: The effective lazy mode setting

    """
    return _get_bool_config(lazy_param, _KEY_LAZY)


def get_strict_specs(strict_specs_param: bool | None = None) -> bool:
    """Get strict_specs setting, with explicit parameter taking precedence over configuration.

    When strict_specs=True, invalid column spec keys/types raise errors instead of being ignored.

    Args:
        strict_specs_param: Explicitly provided strict_specs value, or None to use config

    Returns:
        bool: The effective strict_specs setting

    """
    return _get_bool_config(strict_specs_param, _KEY_STRICT_SPECS)


def get_row_validation_max_errors() -> int:
    """Get max_errors setting for row validation."""
    return _get_int_config(None, _KEY_ROW_VALIDATION_MAX_ERRORS)


def get_checks_max_samples(max_samples: int | None = None) -> int:
    """Get max_samples setting for value checks."""
    return _get_int_config(max_samples, _KEY_CHECKS_MAX_SAMPLES)


def get_allow_empty(allow_empty_param: bool | None = None) -> bool:
    """Get the allow_empty setting, with explicit parameter taking precedence over configuration.

    When allow_empty=False, empty DataFrames (0 rows) will raise an error.

    Args:
        allow_empty_param: Explicitly provided allow_empty parameter value, or None to use config

    Returns:
        bool: The effective allow_empty setting

    """
    return _get_bool_config(allow_empty_param, _KEY_ALLOW_EMPTY)
