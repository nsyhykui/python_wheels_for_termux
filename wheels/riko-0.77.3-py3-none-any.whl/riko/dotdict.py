# vim: sw=4:ts=4:expandtab
"""
Provides a class for creating case insensitive dicts with dot notation access
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from datetime import date
from decimal import Decimal
from functools import reduce
from logging import Logger
from typing import TYPE_CHECKING, Any, Self, TypeGuard, TypeVar, cast, overload

import pygogo as gogo
from requests.structures import CaseInsensitiveDict

from riko._objectify import Objectify
from riko._strutils import replacer
from riko.cast import CAST_SWITCH, CastType, cast_value
from riko.types._collections import Key, RikoList, RikoValue
from riko.types._guards import (
    is_known_sequence,
    is_mapping,
    is_mapping_seq,
    is_sentinel,
    is_type_value,
    is_value_seq,
)
from riko.types._rss import RSSEntry
from riko.types._scalars import BasicValue, PrimitiveValue
from riko.types._sentinels import Sentinel, SentinelValue
from riko.types._streams import Item, Stream
from riko.types.modules import ConfArg

if TYPE_CHECKING:
    from _typeshed import SupportsKeysAndGetItem

logger: Logger = gogo.Gogo(__name__, monolog=True).logger


TV_KEYS = ("type", "value")
WIRE_KEYS = ("id", "src", "tgt")
PASSTHROUGH_TYPES = (str, int, float, date, Decimal, Objectify)

D = TypeVar("D")
VT = TypeVar("VT")
type Data = Iterable[tuple[str, VT]] | RSSEntry


def parse_key(key: Key | None = None) -> list[str]:
    if isinstance(key, str):
        if "." in key:
            keys = key.rstrip(".").split(".")
        else:
            keys = [key] if key else []
    elif key and (subkey := key.get("subkey")):
        keys = [subkey]
    else:
        keys = []

    return keys


def match_key(data: object, key: str) -> str | None:
    if is_mapping(data):
        if key in data:
            matched = key
        else:
            lowered = key.lower()
            keys = (k for k in data if k.lower() == lowered)
            matched = next(keys, None)
    else:
        matched = None

    return matched


def raw_get[VT](data: Mapping[str, VT], key: str) -> VT:
    if isinstance(data, CaseInsensitiveDict):
        value = CaseInsensitiveDict.__getitem__(data, key)  # noqa: PLC2801
    else:
        value = data[key]

    return value


@overload
def parse_sentinel(  # noqa: E704  # pyright: ignore[reportOverlappingOverload]
    value: ConfArg, default: object | None = ...
) -> PrimitiveValue: ...
@overload  # noqa: E302
def parse_sentinel[D](  # noqa: E704
    value: Sentinel, default: D | None = ..., **kwargs: object
) -> Item | D | None: ...
@overload  # noqa: E302
def parse_sentinel[D, VT](  # noqa: E704
    value: Mapping[str, VT],
    default: D | None = ...,  # pyright: ignore[reportInvalidTypeVarUse]
    **kwargs: VT,
) -> dict[str, VT]: ...
def parse_sentinel[D, VT](  # noqa: E302
    value: Sentinel | Mapping[str, VT], default: D | None = None, **kwargs: VT
) -> Item | D | dict[str, VT] | PrimitiveValue:
    if is_sentinel(value, **kwargs):
        key = replacer(value[SentinelValue], "")

        if stream := kwargs.get(key):
            stream = cast(Stream, stream)
            parsed = next(stream, default)
        else:
            parsed = default
    elif is_type_value(value):
        parsed = value["value"]

        if (
            not (type_ := value.get("type"))
            or (type_ == CastType.TEXT)
            and isinstance(parsed, str)
        ):
            pass
        elif type_ == CastType.LOCATION:
            logger.warning(f"Location type not supported! Not casting {parsed=}.")
        elif type_ in CAST_SWITCH:
            parsed = cast_value(parsed, type_=CastType(type_))
        elif type_ != "module":
            logger.warning(f"Invalid cast type={type_}! Not casting {parsed=}.")
    else:
        _parsed = {}

        for k, v in value.items():
            _parsed[k] = parse_sentinel(v, v, **kwargs) if is_mapping(v) else v

        parsed = cast(dict[str, VT], _parsed)

    return parsed


def parse_map[VT](
    *keys: str, data: Mapping[str, VT], **kwargs: VT
) -> Iterator[tuple[str, VT | None]]:
    for key in keys:
        value = DotDict(data).get(key, **kwargs)
        v = next(gen_dict(value, default_key=None))
        yield (key.lower(), v)


def parse_dotdict[VT](*keys: str, data: DotDict[VT]) -> Iterator[tuple[str, VT | None]]:
    for key in keys:
        if key in data:
            value = raw_get(data, key)
            v = next(gen_dict(value, default_key=None))
        else:
            v = None

        yield (key.lower(), cast(VT, v))


@overload
def gen_dict[VT](  # noqa: E704
    data: DotDict[VT] | Mapping[str, VT],
    key: Key | None = ...,
    default_key: str = ...,
    **kwargs: VT,
) -> Iterator[tuple[str, VT | None]]: ...
@overload  # noqa: E302
def gen_dict[VT](  # noqa: E704
    data: DotDict[VT] | Mapping[str, VT], key: Key, default_key: None, **kwargs: VT
) -> Iterator[dict[str, VT | None]]: ...
@overload  # noqa: E302
def gen_dict[VT](  # noqa: E704
    data: list[VT] | tuple[VT, ...],
    key: Key | None = ...,
    default_key: str = ...,
    **kwargs: VT,
) -> Iterator[dict[str, VT | None]]: ...
@overload  # noqa: E302
def gen_dict[VT](  # noqa: E704
    data: list[VT | None] | tuple[VT, ...],
    key: Key | None = ...,
    *,
    default_key: None,
    **kwargs: VT,
) -> Iterator[list[VT | None]]: ...
@overload  # noqa: E302
def gen_dict[VT](  # noqa: E704
    data: VT, key: Key | None = ..., default_key: str = ...
) -> Iterator[tuple[str, VT | None]]: ...
@overload  # noqa: E302
def gen_dict[VT](  # noqa: E704
    data: Sentinel | ConfArg, key: Key | None = ..., *, default_key: None, **kwargs: VT
) -> Iterator[VT | None]: ...
@overload  # noqa: E302
def gen_dict[VT](  # noqa: E704
    data: VT, key: Key | None = ..., *, default_key: None, **kwargs: VT
) -> Iterator[VT | None]: ...
def gen_dict[VT](  # noqa: E302
    data: Sentinel
    | ConfArg
    | DotDict[VT]
    | Mapping[str, VT]
    | list[VT]
    | tuple[VT, ...]
    | VT
    | None,
    key: Key | None = None,
    default_key: str | None = "self",
    **kwargs: VT,
) -> Iterator[
    tuple[str, VT | None] | VT | list[VT | None] | dict[str, VT | None] | None
]:
    """
    >>> r = DotDict({'a': {'value': 'bar'}})
    >>> r
    {'a': {'value': 'bar'}}
    >>> dict(gen_dict(r))
    {'a': {'value': 'bar'}}
    >>> r = DotDict({'a': {'value': 'baz', 'type': 'text'}})
    >>> r
    {'a': 'baz'}
    >>> dict(gen_dict(r))
    {'a': 'baz'}
    """
    if key:
        keys = parse_key(key)
    else:
        if is_mapping(data):
            if DotDict.is_self(data) and not kwargs:
                data = parse_sentinel(cast(DotDict[VT], data), default=data)
            else:
                data = DotDict(cast(Mapping[str, VT], data)).get(**kwargs)

        keys = []

    if is_mapping(data):
        keys = keys or data.keys()

        if DotDict.is_self(data) and not kwargs:
            items = parse_dotdict(*keys, data=data)
        else:
            items = parse_map(*keys, data=data, **kwargs)

        items = cast(Iterator[tuple[str, VT]], items)

        if default_key:
            yield from items
        else:
            yield dict(items)
    elif is_known_sequence(data) and default_key:
        for d in data:
            yield dict(gen_dict(d, default_key=default_key))
    elif is_known_sequence(data):
        yield [next(gen_dict(d, default_key=None)) for d in data]
    elif default_key:
        yield (default_key, data)
    else:
        yield data


# def is_wire(val) -> TypeIs[Wire]:
#     if is_mapping(val) and len(val) == 3 and all(s in val for s in WIRE_KEYS):
#         x = val["src"]
#         x
#         success = is_mapping(val["src"]) and is_mapping(val["tgt"])
#     else:
#         success = False
#
#     return success
#
#
class DotDict(CaseInsensitiveDict[VT]):
    """
    A dictionary whose keys can be accessed using dot notation

    Examples:
        >>> r = DotDict({'a': {'content': 'value'}})
        >>> r.get('a')
        {'content': 'value'}
        >>> r.get('a.content')
        'value'
        >>> r.get('b.content')
        >>> r['a.content']
        'value'
        >>> param = {
        ...     "value": {"type": "text", "value": "foo"},
        ...     "key": {"type": "text", "value": "q"},
        ... }
        >>> r = DotDict({"param": param})
        >>> r.get('param')
        {'value': 'foo', 'key': 'q'}
        >>> r.asdict()
        {'param': {'value': 'foo', 'key': 'q'}}
        >>> DotDict({"title": "baz"}).get({"subkey": "title"})
        'baz'
        >>> r = DotDict({'KEY': 'bar'})
        >>> 'key' in r
        True
        >>> r.get('key')
        'bar'
        >>> list(r)
        ['KEY']
        >>> [k for k in r]
        ['KEY']
        >>> data = {
        ...     "value": {'value': 'the title', 'type': 'text'},
        ...     "key": 'title',
        ... }
        >>> r = DotDict(data)
        >>> list(r)
        ['value', 'key']
        >>> [k for k in r]
        ['value', 'key']
        >>> DotDict({'start': 0, 'count': {'type': 'int', 'value': '5'}})
        {'start': 0, 'count': 5}
        >>> DotDict(**{'a': 1, 'b': 2})
        {'a': 1, 'b': 2}

    """

    def __init__(self, data: Mapping[str, VT] | Data | None = None, **kwargs: VT):
        super().__init__()
        self.update(data, **kwargs)

    @classmethod
    def is_self[V](cls, value: Mapping[str, V]) -> TypeGuard[DotDict[V]]:
        return isinstance(value, DotDict)

    @overload
    @classmethod
    def dictize[V](cls, value: Mapping[str, V]) -> DotDict[V]: ...  # noqa: E704
    @overload  # noqa: E301
    @classmethod
    def dictize[V](cls, value: Mapping[str, V], key: Key) -> V: ...  # noqa: E704
    @overload  # noqa: E301
    @classmethod
    def dictize[T, V](  # noqa: E704
        cls,
        value: Mapping[str, V],
        key: Key | None = ...,
        default: T | None = ...,
        **kwargs: V,
    ) -> T | None: ...
    @overload  # noqa: E301
    @classmethod
    def dictize[V](cls, value: V) -> V: ...  # noqa: E704
    @overload  # noqa: E301
    @classmethod
    def dictize[V](  # noqa: E704 # pyright: ignore[reportOverlappingOverload]
        cls, value: Mapping[str, V] | V
    ) -> DotDict[V] | V: ...
    @classmethod  # noqa: E301
    def dictize[T, V](
        cls,
        value: Mapping[str, V] | V,
        key: Key | None = None,
        default: T | None = None,
        **kwargs: V,
    ) -> DotDict[V] | V | T | None:
        if is_mapping(value):
            if cls.is_self(value):
                result = value
            else:
                result = cast(DotDict[V], cls(cast(Mapping[str, Any], value)))

            if key or kwargs:
                result = result.get(key=key, default=default, **kwargs)
        else:
            result = value

        return result

    @overload
    def _parse_value(  # noqa: E704
        self,
        value: Mapping[str, VT],
        key: str | int,
        default: D | None = ...,
        **kwargs: VT,
    ) -> VT | dict[str, VT] | Item | RikoValue | D | None: ...
    @overload  # noqa: E301
    def _parse_value(  # noqa: E704
        self,
        value: list[VT] | tuple[VT, ...],
        key: str | int,
        default: object | None = ...,
        **kwargs: VT,
    ) -> RikoList | BasicValue: ...
    @overload  # noqa: E301
    def _parse_value(  # noqa: E704
        self, value: object, key: str | int, default: D | None = ..., **kwargs: VT
    ) -> D | None: ...
    def _parse_value(  # noqa: E301
        self,
        value: list[VT] | tuple[VT, ...] | Mapping[str, VT] | object,
        key: str | int,
        default: D | None = None,
        **kwargs: VT,
    ) -> VT | D | Any:
        """
        >>> dd = DotDict()
        >>> dd._parse_value([10, 20], 1, 'missing')
        20
        >>> dd._parse_value([10, 20], 5, 'missing')
        'missing'
        >>> dd._parse_value([{'b': 1}, {'b': 2}], 'b', 'missing')
        [1, 2]
        >>> dd._parse_value([{'b': 1}, {'b': 2}], 'z', 'missing')
        'missing'
        """
        parsed = default
        msg = f"Ignoring unsupported key {key} to access {{0}} value {{1}}."

        if is_mapping(value):
            if isinstance(key, str):
                dd_value = value if self.is_self(value) else DotDict(value)

                if key in dd_value:
                    parsed = dd_value[key]
                elif is_sentinel(value, **kwargs):
                    parsed = parse_sentinel(value, default=default, **kwargs)

                    if is_mapping(parsed) and key in parsed:
                        parsed = parsed[key]
                    elif key:
                        parsed = default
            else:
                logger.warning(msg.format("Mapping", value))
        elif is_known_sequence(value):
            if is_mapping_seq(value):
                if isinstance(key, str):
                    try:
                        parsed = cast(RikoList, [v[key] for v in value])
                    except (KeyError, IndexError):
                        parsed = default
                else:
                    logger.warning(msg.format("submapping", value[0]))
            elif is_value_seq(value):
                if isinstance(key, int):
                    try:
                        parsed = value[key]
                    except IndexError:
                        parsed = default
                else:
                    logger.warning(msg.format("submapping", value[0]))
            else:
                parsed = list(value)
        elif value is not None:
            parsed = value

        return parsed

    def __getitem__(self, key: Key) -> VT:
        """
        >>> r = DotDict({'key': 'bar'})
        >>> r['key']
        'bar'
        >>> r['KEY']
        'bar'
        """
        keys = parse_key(key)
        value = raw_get(self, keys[0])

        if len(keys) > 1:
            key = ".".join(keys[1:])
            msg = f"Ignoring unsupported key {key} to access non-mapping value {value}."

            if is_mapping(value):
                value = cast(VT, value[key])
            else:
                logger.warning(msg)

        result = value

        if is_mapping(value):
            parsed = parse_sentinel(value, default=value)
            result = cast(VT, self.dictize(parsed))

        return result

    def __setitem__(self, key: str, value: VT) -> None:
        """
        >>> r = DotDict({'author': 'bar'})
        >>> r
        {'author': 'bar'}
        >>> r['author.name'] = 'bar'
        >>> r
        {'author': {'name': 'bar'}}
        >>> r['author.url'] = 'example.com'
        >>> r
        {'author': {'name': 'bar', 'url': 'example.com'}}
        >>> c = DotDict({'count': 0})
        >>> c['count.total'] = 1
        >>> c
        {'count': {'total': 1}}
        """

        def reducer(item: Self, key: str) -> Self:
            if item and key in item:
                existing = raw_get(item, key)

                if existing is not None and not is_mapping(existing):
                    del item[key]
                    existing = None
            else:
                existing = None

            if existing is None:
                existing = item[key] = cast(VT, {})
                # CaseInsensitiveDict.__setitem__(item, key, existing)

            return cast(Self, existing)

        keys = parse_key(key)

        if len(keys) == 1:
            CaseInsensitiveDict.__setitem__(self, key, value)
        else:
            item = self.copy()
            rest, last = keys[:-1], keys[-1]
            reduced = reduce(reducer, rest, item)
            reduced[last] = value
            CaseInsensitiveDict.update(self, item)

    def __or__[V](self, other: Mapping[str, V]) -> Self:
        """
        >>> r = DotDict({'key': 'bar'})
        >>> r | {'key': 'baz'}
        {'key': 'baz'}
        >>> r | DotDict({'key': 'baz'})
        {'key': 'baz'}
        """
        dd = self.copy()
        dd.update(other)
        return dd

    @overload
    def get(  # noqa: E704
        self, key: Key | None, default: None = None
    ) -> VT | None: ...
    @overload
    def get(self, key: Key | None, default: D) -> D: ...  # noqa: E704
    @overload  # noqa: E301
    def get(  # noqa: E704  # pyright: ignore[reportOverlappingOverload]
        self, key: Key | None, default: D | VT
    ) -> D | VT: ...
    @overload
    def get(self) -> VT: ...  # noqa: E704
    @overload
    def get(self, **kwargs: VT) -> VT | None: ...  # noqa: E704
    def get(  # noqa: E301  # pyright: ignore[reportInconsistentOverload]
        self, key: Key | None = None, default: D | None = None, **kwargs: VT
    ) -> Self | VT | D | Item | dict[str, VT] | PrimitiveValue:
        """
        >>> r = DotDict({'key': 'bar'})
        >>> r.get('key')
        'bar'
        >>> r.get('KEY')
        'bar'
        >>> r.get('KEY')
        'bar'
        >>> r.get('baz')
        >>> r = DotDict({"terminal": "attrs_1", "type": "text"})
        >>> r.get()
        {'terminal': 'attrs_1', 'type': 'text'}
        >>> r.get(attrs_1=iter(['baz']))
        'baz'
        >>> r.get(attrs_1=iter([{'content': 'baz'}]))
        {'content': 'baz'}
        >>> r.get('subkey')
        >>> attrs = {
        ...     "value": {"terminal": "attrs_1", "type": "text"},
        ...     "key": {"type": "text", "value": "title"},
        ... }
        >>> r = DotDict({'attrs': attrs})
        >>> r.get('attrs')
        {'value': {'terminal': 'attrs_1', 'type': 'text'}, 'key': 'title'}
        >>> r.get('attrs.key')
        'title'
        >>> r.get('attrs.value')
        {'terminal': 'attrs_1', 'type': 'text'}
        >>> r.get('subkey')
        >>> r.get('attrs.value', attrs_1=iter([{'content': 'baz'}]))
        {'content': 'baz'}
        >>> r.get('attrs.value.content', attrs_1=iter([{'content': 'baz'}]))
        'baz'
        >>> r.get('attrs.value.foo', attrs_1=iter([{'content': 'baz'}]))
        >>> r = DotDict({'stanzas': {'verses': ['verse1', 'verse2']}})
        >>> r.get('stanzas.verses')
        ['verse1', 'verse2']
        >>> r.get('stanzas.verses.1')
        'verse2'
        """
        keys = parse_key(key)
        item = self

        if keys:
            for k in keys:
                try:
                    k = int(k)
                except ValueError:
                    pass

                item = self._parse_value(item, k, default=default, **kwargs)
        else:
            item = parse_sentinel(item, default=item, **kwargs)

        if is_mapping(item) and is_sentinel(item, **kwargs):
            item = parse_sentinel(item, default=default, **kwargs)

        return self.dictize(item)

    def copy(self) -> Self:
        return type(self)(self)

    def delete(self, key: str) -> None:
        """
        Delete a root or nested key. Matching is case-insensitive at every
        level, including nested plain-dict values.

        Examples:
            >>> r = DotDict({'author': 'bar', 'title': 'foo'})
            >>> r.delete('author')
            >>> r.asdict()
            {'title': 'foo'}
            >>> r = DotDict({'author': {'name': 'bar', 'url': 'x.com'}})
            >>> r.delete('author.name')
            >>> r.asdict()
            {'author': {'url': 'x.com'}}
            >>> r = DotDict({'author': {'name': 'bar', 'url': 'x.com'}})
            >>> r.delete('AUTHOR.NAME')
            >>> r.asdict()
            {'author': {'url': 'x.com'}}
            >>> r.delete('missing.key')
            >>> r.asdict()
            {'author': {'url': 'x.com'}}

        """

        def reducer(item: Self | None, key: str) -> Self | None:
            if item and key and (matched := match_key(item, key)):
                value = raw_get(item, matched)
            else:
                value = None

            return cast(Self, value) if is_mapping(value) else None

        keys = parse_key(key)
        rest, last = keys[:-1], keys[-1]

        if len(keys) == 1 and match_key(self, key):
            CaseInsensitiveDict.__delitem__(self, key)  # noqa: PLC2801
        elif (reduced := reduce(reducer, rest, self)) is not None and (
            matched := match_key(reduced, last)
        ) is not None:
            del reduced[matched]

    @overload
    def update(  # noqa: E704
        self, data: SupportsKeysAndGetItem[str, VT]
    ) -> None: ...
    @overload  # noqa: E301
    def update(  # noqa: E704
        self, data: SupportsKeysAndGetItem[str, VT], **kwargs: VT
    ) -> None: ...
    @overload
    def update(self, data: Data) -> None: ...  # noqa: E704
    @overload  # noqa: E301
    def update(  # noqa: E704
        self, data: Data, **kwargs: VT
    ) -> None: ...
    @overload
    def update[V](self, data: Mapping[str, V]) -> None: ...  # noqa: E704
    @overload
    def update(self, **kwargs: VT) -> None: ...  # noqa: E704
    @overload
    def update(self, data: None) -> None: ...  # noqa: E704
    def update(  # noqa: E301  # pyright: ignore[reportInconsistentOverload]
        self, data: SupportsKeysAndGetItem[str, VT] | Data | None = None, **kwargs: VT
    ):
        """
        >>> r = DotDict({'author': 'bar'})
        >>> r
        {'author': 'bar'}
        >>> r.update({'author.name': 'bar', 'author.url': 'example.com'})
        >>> r
        {'author': {'name': 'bar', 'url': 'example.com'}}
        >>> r = DotDict({'author.name': 'bar', 'author.url': 'example.com'})
        >>> r
        {'author': {'name': 'bar', 'url': 'example.com'}}
        """
        if is_mapping(data):
            data = cast(Mapping[str, VT], data)
            if self.is_self(data):
                if kwargs:
                    _dict = data | kwargs
                else:
                    return self._store.update(data._store)
            elif kwargs or any("." in k for k in data):
                _dict = cast(dict[str, VT], {**data, **kwargs})
            else:
                for key, value in data.items():
                    CaseInsensitiveDict.__setitem__(self, key, value)  # noqa: PLC2801

                return
        elif data:
            _dict = dict(data, **kwargs)
        else:
            _dict = kwargs

        if dot_keys := [k for k in _dict if "." in k]:
            # skip key if a subkey redefines it
            # i.e., 'author.name' has precedence over 'author'
            skip_keys = {".".join(parse_key(key)[:-1]) for key in dot_keys}
            items = [(k, _dict[k]) for k in _dict if k not in skip_keys]
        else:
            items = _dict.items()

        for key, value in items:
            self[key] = value

    def asdict(self, key: Key | None = None, **kwargs: VT) -> dict[str, VT | None]:
        """
        >>> r = DotDict({'a': {'value': 'bar'}})
        >>> r
        {'a': {'value': 'bar'}}
        >>> r.asdict()
        {'a': {'value': 'bar'}}
        >>> r = DotDict({'a': {'value': 'baz', 'type': 'text'}})
        >>> r
        {'a': 'baz'}
        >>> r.asdict()
        {'a': 'baz'}
        """
        items = gen_dict(self, key=key, default_key="self", **kwargs)
        return dict(items)
