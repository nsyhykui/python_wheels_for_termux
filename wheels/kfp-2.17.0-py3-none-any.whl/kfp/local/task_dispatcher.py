# Copyright 2023 The Kubeflow Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Code for dispatching a local task execution."""

import copy
import logging
from typing import Any, Dict, Tuple

from kfp import local
from kfp.local import config

# docker import fix
try:
    from kfp.local import docker_task_handler
    _DOCKER_AVAILABLE = True
except ImportError:
    docker_task_handler = None
    _DOCKER_AVAILABLE = False

from kfp.local import executor_input_utils
from kfp.local import executor_output_utils
from kfp.local import logging_utils
from kfp.local import placeholder_utils
from kfp.local import status
from kfp.local import subprocess_task_handler
from kfp.local import task_handler_interface
from kfp.local import utils
from kfp.pipeline_spec import pipeline_spec_pb2


def run_single_task(
    pipeline_spec: pipeline_spec_pb2.PipelineSpec,
    arguments: Dict[str, Any],
) -> Dict[str, Any]:
    """Runs a single component from its compiled PipelineSpec."""
    config.LocalExecutionConfig.validate()
    component_name, component_spec = list(pipeline_spec.components.items())[0]
    executor_spec = get_executor_spec(
        pipeline_spec,
        component_spec.executor_label,
    )
    executor_spec = utils.struct_to_executor_spec(executor_spec)
    pipeline_resource_name = executor_input_utils.get_local_pipeline_resource_name(
        pipeline_spec.pipeline_info.name)

    outputs, _ = run_single_task_implementation(
        pipeline_resource_name=pipeline_resource_name,
        component_name=component_name,
        component_spec=component_spec,
        executor_spec=executor_spec,
        arguments=arguments,
        pipeline_root=config.LocalExecutionConfig.instance.pipeline_root,
        runner=config.LocalExecutionConfig.instance.runner,
        raise_on_error=config.LocalExecutionConfig.instance.raise_on_error,
        block_input_artifact=True,
        unique_pipeline_id=placeholder_utils.make_random_id())
    return outputs


def get_executor_spec(
    pipeline_spec: pipeline_spec_pb2.PipelineSpec,
    executor_label: str,
) -> pipeline_spec_pb2.PipelineDeploymentConfig.ExecutorSpec:
    return pipeline_spec.deployment_spec['executors'][executor_label]


Outputs = Dict[str, Any]


def _extract_container_env_vars(
    container: pipeline_spec_pb2.PipelineDeploymentConfig.PipelineContainerSpec
) -> Dict[str, str]:
    return {env_var.name: env_var.value for env_var in container.env}


def _normalize_environment_config(environment: Any) -> Dict[str, Any]:
    """Normalize Docker-style environment config to a dict for merging."""
    if environment is None:
        return {}
    if isinstance(environment, dict):
        return dict(environment)
    if isinstance(environment, (list, tuple)):
        normalized = {}
        for item in environment:
            if isinstance(item, str):
                key, _, value = item.partition('=')
                normalized[key] = value
            elif isinstance(item, (list, tuple)) and len(item) == 2:
                key, value = item
                normalized[key] = value
            else:
                raise ValueError(
                    'DockerRunner environment must be a dict or a sequence '
                    'of KEY=VALUE strings / (key, value) pairs for local execution.'
                )
        return normalized
    raise ValueError(
        'DockerRunner environment must be a dict or a sequence of KEY=VALUE '
        'strings / (key, value) pairs for local execution.')


def _prepare_runner_and_env_vars(
    runner: config.LocalRunnerType,
    env_vars: Dict[str, str],
) -> Tuple[config.LocalRunnerType, Dict[str, str]]:
    """Apply runner-level env override policy before launching a task."""
    if not isinstance(runner, local.DockerRunner):
        return runner, env_vars

    runner_env = _normalize_environment_config(
        runner.container_run_args.get('environment'))
    merged_env = {**env_vars, **runner_env}

    runner_copy = copy.copy(runner)
    runner_copy.container_run_args = dict(runner.container_run_args)
    runner_copy.container_run_args.pop('environment', None)
    return runner_copy, merged_env


def run_single_task_implementation(
    pipeline_resource_name: str,
    component_name: str,
    component_spec: pipeline_spec_pb2.ComponentSpec,
    executor_spec: pipeline_spec_pb2.PipelineDeploymentConfig.ExecutorSpec,
    arguments: Dict[str, Any],
    pipeline_root: str,
    runner: config.LocalRunnerType,
    raise_on_error: bool,
    block_input_artifact: bool,
    unique_pipeline_id: str,
) -> Tuple[Outputs, status.Status]:

    task_resource_name = executor_input_utils.get_local_task_resource_name(
        component_name)
    task_root = executor_input_utils.construct_local_task_root(
        pipeline_root=pipeline_root,
        pipeline_resource_name=pipeline_resource_name,
        task_resource_name=task_resource_name,
    )
    executor_input = executor_input_utils.construct_executor_input(
        component_spec=component_spec,
        arguments=arguments,
        task_root=task_root,
        block_input_artifact=block_input_artifact,
    )

    container = executor_spec.container
    image = container.image
    full_command = list(container.command) + list(container.args)

    env_vars = _extract_container_env_vars(container)
    runner, env_vars = _prepare_runner_and_env_vars(runner, env_vars)

    executor_input_dict = executor_input_utils.executor_input_to_dict(
        executor_input=executor_input,
        component_spec=component_spec,
    )
    full_command = placeholder_utils.replace_placeholders(
        full_command=full_command,
        executor_input_dict=executor_input_dict,
        pipeline_resource_name=pipeline_resource_name,
        task_resource_name=task_resource_name,
        pipeline_root=pipeline_root,
        unique_pipeline_id=unique_pipeline_id,
    )

    runner_type = type(runner)

    # Safe TaskHandler map fix
    task_handler_map: Dict[
        local.LocalRunnerType, task_handler_interface.ITaskHandler] = {
            local.SubprocessRunner:
                subprocess_task_handler.SubprocessTaskHandler,
        }

    if _DOCKER_AVAILABLE:
        task_handler_map[
            local.DockerRunner] = docker_task_handler.DockerTaskHandler
    elif runner_type is local.DockerRunner:
        raise RuntimeError('DockerRunner selected but docker is not installed. '
                           'Install docker or switch to SubprocessRunner.')

    TaskHandler = task_handler_map[runner_type]

    with logging_utils.local_logger_context():
        task_name_for_logs = logging_utils.format_task_name(task_resource_name)

        logging.info(f'Executing task {task_name_for_logs}')
        task_handler = TaskHandler(
            image=image,
            full_command=full_command,
            pipeline_root=pipeline_root,
            runner=runner,
            env_vars=env_vars,
        )

        # separate logs visually
        logging.info(f'Streamed logs:\n')

        with logging_utils.indented_print():
            task_status = task_handler.run()

        if task_status == status.Status.SUCCESS:
            logging.info(
                f'Task {task_name_for_logs} finished with status {logging_utils.format_status(task_status)}'
            )

            outputs = executor_output_utils.get_outputs_for_task(
                executor_input=executor_input,
                component_spec=component_spec,
            )
            if outputs:
                output_string = [
                    f'Task {task_name_for_logs} outputs:',
                    *logging_utils.make_log_lines_for_outputs(outputs),
                ]
                logging.info('\n'.join(output_string))
            else:
                logging.info(f'Task {task_name_for_logs} has no outputs')

        elif task_status == status.Status.FAILURE:
            msg = f'Task {task_name_for_logs} finished with status {logging_utils.format_status(task_status)}'
            if raise_on_error:
                raise RuntimeError(msg)
            else:
                logging.error(msg)
            outputs = {}

        else:
            raise ValueError(f'Got unknown status: {task_status}')

        logging_utils.print_horizontal_line()

        return outputs, task_status
