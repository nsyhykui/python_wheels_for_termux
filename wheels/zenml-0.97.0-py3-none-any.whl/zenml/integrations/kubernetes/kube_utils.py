#  Copyright (c) ZenML GmbH 2022. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at:
#
#       https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
#  or implied. See the License for the specific language governing
#  permissions and limitations under the License.
#
# Copyright 2020 Google LLC. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Utilities for Kubernetes related functions.

Internal interface: no backwards compatibility guarantees.
Adjusted from https://github.com/tensorflow/tfx/blob/master/tfx/utils/kube_utils.py.
"""

import enum
import functools
import json
import math
import re
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
    cast,
)

from kubernetes import client as k8s_client
from kubernetes import config as k8s_config
from kubernetes.client.rest import ApiException
from pydantic import ValidationError
from urllib3.exceptions import ReadTimeoutError

from zenml.config.resource_settings import ByteUnit
from zenml.integrations.kubernetes.constants import (
    ENV_ZENML_KUBERNETES_MAIN_ADDRESS,
    ENV_ZENML_KUBERNETES_MAIN_PORT,
    ENV_ZENML_KUBERNETES_POD_COUNT,
    MULTI_POD_MAIN_PORT,
    STEP_NAME_ANNOTATION_KEY,
)
from zenml.integrations.kubernetes.manifest_utils import (
    build_namespace_manifest,
    build_role_binding_manifest_for_service_account,
    build_secret_manifest,
    build_service_account_manifest,
)
from zenml.integrations.kubernetes.pod_settings import KubernetesPodSettings
from zenml.integrations.kubernetes.serialization_utils import (
    normalize_resource_to_dict,
)
from zenml.logger import get_logger
from zenml.utils.time_utils import utc_now

if TYPE_CHECKING:
    from zenml.config.base_settings import BaseSettings
    from zenml.config.resource_settings import ResourceSettings
    from zenml.models import ResourceRequestResponse

logger = get_logger(__name__)

R = TypeVar("R")
SettingsT = TypeVar("SettingsT", bound="BaseSettings")


# This is to fix a bug in the kubernetes client which has some wrong
# client-side validations that means the `on_exit_codes` field is
# unusable. See https://github.com/kubernetes-client/python/issues/2056
class PatchedFailurePolicyRule(k8s_client.V1PodFailurePolicyRule):  # type: ignore[misc]
    """Patched failure policy rule."""

    @property
    def on_pod_conditions(self):  # type: ignore[no-untyped-def]
        """On pod conditions.

        Returns:
            On pod conditions.
        """  # noqa: DOC106, DOC107
        return self._on_pod_conditions

    @on_pod_conditions.setter
    def on_pod_conditions(self, on_pod_conditions):  # type: ignore[no-untyped-def]
        """On pod conditions.

        Args:
            on_pod_conditions: On pod conditions.
        """  # noqa: DOC106, DOC107
        self._on_pod_conditions = on_pod_conditions


k8s_client.V1PodFailurePolicyRule = PatchedFailurePolicyRule
k8s_client.models.V1PodFailurePolicyRule = PatchedFailurePolicyRule


class PodPhase(enum.Enum):
    """Phase of the Kubernetes pod.

    Pod phases are defined in
    https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#pod-phase.
    """

    PENDING = "Pending"
    RUNNING = "Running"
    SUCCEEDED = "Succeeded"
    FAILED = "Failed"
    UNKNOWN = "Unknown"


class JobStatus(enum.Enum):
    """Status of a Kubernetes job."""

    RUNNING = "Running"
    SUCCEEDED = "Succeeded"
    FAILED = "Failed"


def is_inside_kubernetes() -> bool:
    """Check whether we are inside a Kubernetes cluster or on a remote host.

    Returns:
        True if inside a Kubernetes cluster, else False.
    """
    try:
        k8s_config.load_incluster_config()
        return True
    except k8s_config.ConfigException:
        return False


def load_kube_config(
    incluster: bool = False, context: Optional[str] = None
) -> None:
    """Load the Kubernetes client config.

    Args:
        incluster: Whether to load the in-cluster config.
        context: Name of the Kubernetes context. If not provided, uses the
            currently active context. Will be ignored if `incluster` is True.
    """
    if incluster:
        k8s_config.load_incluster_config()
    else:
        k8s_config.load_kube_config(context=context)


def sanitize_label(label: str) -> str:
    """Sanitize a string for use as a Kubernetes `metadata.name` DNS label.

    Matches RFC 1123-style DNS labels: lowercase alphanumerics and hyphens,
    starting and ending with alphanumeric. For Kubernetes *label values*, use
    `sanitize_label_value` instead, which allows `_`, `.`, and mixed case.

    See https://kubernetes.io/docs/concepts/overview/working-with-objects/names/#dns-label-names

    Args:
        label: The label name to sanitize.

    Returns:
        The sanitized label name.
    """
    label = re.sub(r"[^a-z0-9-]", "-", label.lower())
    label = re.sub(r"^[-]+", "", label)
    label = re.sub(r"[-]+", "-", label)
    label = label[:63]
    # Remove trailing dashes after truncation to make sure we end with an
    # alphanumeric character
    label = re.sub(r"[-]+$", "", label)

    return label


def sanitize_label_value(label: str) -> str:
    """Sanitize a string for use as a Kubernetes label `value`.

    Follows the label value rules (63 characters max; non-empty values must
    start and end with `[A-Za-z0-9]`; `-`, `_`, `.`, and alphanumerics
    are allowed between).

    See https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/#syntax-and-character-set

    Args:
        label: The label value to sanitize.

    Returns:
        The sanitized label value (at most 63 characters; may be empty).
    """
    label = re.sub(r"[^A-Za-z0-9._-]+", "-", label)
    label = label.strip("._-")
    if not label:
        return ""

    label = label[:63]
    label = re.sub(r"[^A-Za-z0-9]+$", "", label)
    label = re.sub(r"^[^A-Za-z0-9]+", "", label)
    return label


def multi_pod_job_name(job_name: str, pod_count: int) -> str:
    """Adjust a sanitized job name for use as a multi-pod job name.

    Args:
        job_name: The sanitized job name.
        pod_count: The number of pods.

    Returns:
        The adjusted job name.
    """
    # The name doubles as the name of the headless service, which must
    # start with a letter.
    if not job_name[:1].isalpha():
        job_name = f"j{job_name}"

    # Kubernetes sets the hostname of indexed-job pods to
    # `<job-name>-<index>`, and hostnames are capped at 63 characters.
    max_length = 62 - len(str(pod_count - 1))
    return job_name[:max_length].rstrip("-")


def multi_pod_environment(
    job_name: str, namespace: str, pod_count: int
) -> Dict[str, str]:
    """Environment for the pods of a multi-pod job.

    Args:
        job_name: The job name (also the headless service name).
        namespace: The Kubernetes namespace.
        pod_count: The number of pods.

    Returns:
        Environment variables shared by all pods of the job.
    """
    # Indexed-job pods get the hostname `<job-name>-<index>`. With the
    # pod spec's subdomain pointing at the headless service, index 0
    # resolves at this stable DNS name.
    return {
        ENV_ZENML_KUBERNETES_POD_COUNT: str(pod_count),
        ENV_ZENML_KUBERNETES_MAIN_ADDRESS: f"{job_name}-0.{job_name}.{namespace}.svc",
        ENV_ZENML_KUBERNETES_MAIN_PORT: str(MULTI_POD_MAIN_PORT),
    }


def pod_is_not_pending(pod: k8s_client.V1Pod) -> bool:
    """Check if pod status is not 'Pending'.

    Args:
        pod: Kubernetes pod.

    Returns:
        False if the pod status is 'Pending' else True.
    """
    return pod.status.phase != PodPhase.PENDING.value  # type: ignore[no-any-return]


def pod_failed(pod: k8s_client.V1Pod) -> bool:
    """Check if pod status is 'Failed'.

    Args:
        pod: Kubernetes pod.

    Returns:
        True if pod status is 'Failed' else False.
    """
    return pod.status.phase == PodPhase.FAILED.value  # type: ignore[no-any-return]


def pod_is_done(pod: k8s_client.V1Pod) -> bool:
    """Check if pod status is 'Succeeded'.

    Args:
        pod: Kubernetes pod.

    Returns:
        True if pod status is 'Succeeded' else False.
    """
    return pod.status.phase == PodPhase.SUCCEEDED.value  # type: ignore[no-any-return]


def get_pod(
    core_api: k8s_client.CoreV1Api,
    pod_name: str,
    namespace: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> Optional[k8s_client.V1Pod]:
    """Get a pod from Kubernetes metadata API.

    Args:
        core_api: Client of `CoreV1Api` of Kubernetes API.
        pod_name: The name of the pod.
        namespace: The namespace of the pod.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Raises:
        RuntimeError: When it sees unexpected errors from Kubernetes API.

    Returns:
        The found pod object. None if it's not found.
    """
    try:
        return retry_on_api_exception(
            core_api.read_namespaced_pod,
            api_request_timeout=api_request_timeout,
            max_retries=max_retries,
        )(name=pod_name, namespace=namespace)
    except k8s_client.rest.ApiException as e:
        if e.status == 404:
            return None
        raise RuntimeError from e


def create_pod(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    pod_manifest: k8s_client.V1Pod,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Create a Kubernetes pod.

    Args:
        core_api: Client of `CoreV1Api` of Kubernetes API.
        namespace: The namespace in which to create the pod.
        pod_manifest: The manifest of the pod to create.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.
    """
    retry_on_api_exception(
        core_api.create_namespaced_pod,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        body=pod_manifest,
    )


def delete_pod(
    core_api: k8s_client.CoreV1Api,
    pod_name: str,
    namespace: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Delete a Kubernetes pod.

    Args:
        core_api: Client of `CoreV1Api` of Kubernetes API.
        pod_name: The name of the pod to delete.
        namespace: The namespace of the pod.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Raises:
        k8s_client.rest.ApiException: If the pod deletion failed for any
            reason other than the pod not being found.
    """
    try:
        retry_on_api_exception(
            core_api.delete_namespaced_pod,
            api_request_timeout=api_request_timeout,
            max_retries=max_retries,
        )(
            name=pod_name,
            namespace=namespace,
            propagation_policy="Foreground",
        )
    except k8s_client.rest.ApiException as e:
        if e.status != 404:
            raise


def wait_pod(
    kube_client_fn: Callable[[], k8s_client.ApiClient],
    pod_name: str,
    namespace: str,
    exit_condition_lambda: Callable[[k8s_client.V1Pod], bool],
    timeout_sec: int = 0,
    exponential_backoff: bool = False,
    stream_logs: bool = False,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1Pod:
    """Wait for a pod to meet an exit condition.

    Args:
        kube_client_fn: the kube client fn is a function that is called
            periodically and is used to get a `CoreV1Api` client for
            the Kubernetes API. It should cache the client to avoid
            unnecessary overhead but should also instantiate a new client if
            the previous one is using credentials that are about to expire.
        pod_name: The name of the pod.
        namespace: The namespace of the pod.
        exit_condition_lambda: A lambda
            which will be called periodically to wait for a pod to exit. The
            function returns True to exit.
        timeout_sec: Timeout in seconds to wait for pod to reach exit
            condition, or 0 to wait for an unlimited duration.
            Defaults to unlimited.
        exponential_backoff: Whether to use exponential back off for polling.
            Defaults to False.
        stream_logs: Whether to stream the pod logs to
            `zenml.logger.info()`. Defaults to False.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Raises:
        RuntimeError: when the function times out.

    Returns:
        The pod object which meets the exit condition.
    """
    start_time = utc_now()

    # Link to exponential back-off algorithm used here:
    # https://cloud.google.com/storage/docs/exponential-backoff
    backoff_interval = 1
    maximum_backoff = 32

    logged_lines = 0

    while True:
        kube_client = kube_client_fn()
        core_api = k8s_client.CoreV1Api(kube_client)

        resp = get_pod(
            core_api,
            pod_name,
            namespace,
            api_request_timeout=api_request_timeout,
            max_retries=max_retries,
        )

        if resp is None:
            raise RuntimeError(f"Pod `{namespace}:{pod_name}` not found.")

        # Stream logs to `zenml.logger.info()`.
        # TODO: can we do this without parsing all logs every time?
        if stream_logs and pod_is_not_pending(resp):
            try:
                response = core_api.read_namespaced_pod_log(
                    name=pod_name,
                    namespace=namespace,
                    _preload_content=False,
                )
            except ApiException as e:
                logger.error(f"Error reading pod logs: {e}. Retrying...")
            else:
                raw_data = response.data
                decoded_log = raw_data.decode("utf-8", errors="replace")
                logs = decoded_log.splitlines()
                if len(logs) > logged_lines:
                    for line in logs[logged_lines:]:
                        logger.info(line)
                    logged_lines = len(logs)

        # Raise an error if the pod failed.
        if pod_failed(resp):
            raise RuntimeError(f"Pod `{namespace}:{pod_name}` failed.")

        # Check if pod is in desired state (e.g. finished / running / ...).
        if exit_condition_lambda(resp):
            return resp

        # Check if wait timed out.
        elapse_time = utc_now() - start_time
        if elapse_time.seconds >= timeout_sec and timeout_sec != 0:
            raise RuntimeError(
                f"Waiting for pod `{namespace}:{pod_name}` timed out after "
                f"{timeout_sec} seconds."
            )

        # Wait (using exponential backoff).
        time.sleep(backoff_interval)
        if exponential_backoff and backoff_interval < maximum_backoff:
            backoff_interval *= 2


FuncT = TypeVar("FuncT", bound=Callable[..., Any])


def _if_not_exists(create_fn: FuncT) -> FuncT:
    """Wrap a Kubernetes function to handle creation if already exists.

    Args:
        create_fn: Kubernetes function to be wrapped.

    Returns:
        Wrapped Kubernetes function.
    """

    def create_if_not_exists(*args: Any, **kwargs: Any) -> None:
        try:
            create_fn(*args, **kwargs)
        except ApiException as exc:
            if exc.status != 409:
                raise
            logger.debug(
                f"Didn't execute {create_fn.__name__} because already exists."
            )

    return cast(FuncT, create_if_not_exists)


def create_edit_service_account(
    core_api: k8s_client.CoreV1Api,
    rbac_api: k8s_client.RbacAuthorizationV1Api,
    service_account_name: str,
    namespace: str,
    role_binding_name: str = "zenml-edit",
) -> None:
    """Create a new Kubernetes service account with "edit" rights.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        rbac_api: Client of Rbac Authorization V1 API of Kubernetes API.
        service_account_name: Name of the service account.
        namespace: Kubernetes namespace. Defaults to "default".
        role_binding_name: Name of the role binding. Defaults to "zenml-edit".
    """
    rb_manifest = build_role_binding_manifest_for_service_account(
        name=role_binding_name,
        role_name="edit",
        service_account_name=service_account_name,
        namespace=namespace,
    )
    _if_not_exists(rbac_api.create_namespaced_role_binding)(
        namespace=namespace, body=rb_manifest
    )

    sa_manifest = build_service_account_manifest(
        name=service_account_name, namespace=namespace
    )
    _if_not_exists(core_api.create_namespaced_service_account)(
        namespace=namespace,
        body=sa_manifest,
    )


def create_namespace(core_api: k8s_client.CoreV1Api, namespace: str) -> None:
    """Create a Kubernetes namespace.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        namespace: Kubernetes namespace. Defaults to "default".
    """
    manifest = build_namespace_manifest(namespace)
    _if_not_exists(core_api.create_namespace)(body=manifest)


def create_secret(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    secret_name: str,
    data: Dict[str, Optional[str]],
) -> None:
    """Create a Kubernetes secret.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        namespace: The namespace in which to create the secret.
        secret_name: The name of the secret to create.
        data: The secret data.
    """
    core_api.create_namespaced_secret(
        namespace=namespace,
        body=build_secret_manifest(name=secret_name, data=data),
    )


def update_secret(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    secret_name: str,
    data: Dict[str, Optional[str]],
) -> None:
    """Update a Kubernetes secret.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        namespace: The namespace in which to update the secret.
        secret_name: The name of the secret to update.
        data: The secret data. If the value is None, the key will be removed
            from the secret.
    """
    core_api.patch_namespaced_secret(
        namespace=namespace,
        name=secret_name,
        body=build_secret_manifest(name=secret_name, data=data),
    )


def create_or_update_secret(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    secret_name: str,
    data: Dict[str, Optional[str]],
) -> None:
    """Create a Kubernetes secret if it doesn't exist, or update it if it does.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        namespace: The namespace in which to create or update the secret.
        secret_name: The name of the secret to create or update.
        data: The secret data. If the value is None, the key will be removed
            from the secret.

    Raises:
        ApiException: If the secret creation failed for any reason other than
            the secret already existing.
    """
    try:
        create_secret(core_api, namespace, secret_name, data)
    except ApiException as e:
        if e.status != 409:
            raise
        update_secret(core_api, namespace, secret_name, data)


def delete_secret(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    secret_name: str,
) -> None:
    """Delete a Kubernetes secret.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        namespace: The namespace in which to delete the secret.
        secret_name: The name of the secret to delete.
    """
    core_api.delete_namespaced_secret(
        name=secret_name,
        namespace=namespace,
    )


def create_and_wait_for_pod_to_start(
    core_api: k8s_client.CoreV1Api,
    pod_display_name: str,
    pod_name: str,
    pod_manifest: k8s_client.V1Pod,
    namespace: str,
    startup_max_retries: int,
    startup_failure_delay: float,
    startup_failure_backoff: float,
    startup_timeout: float,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Create a pod and wait for it to reach a desired state.

    Args:
        core_api: Client of Core V1 API of Kubernetes API.
        pod_display_name: The display name of the pod to use in logs.
        pod_name: The name of the pod to create.
        pod_manifest: The manifest of the pod to create.
        namespace: The namespace in which to create the pod.
        startup_max_retries: The maximum number of retries for the pod startup.
        startup_failure_delay: The delay between retries for the pod startup.
        startup_failure_backoff: The backoff factor for the pod startup.
        startup_timeout: The maximum time to wait for the pod to start.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Raises:
        TimeoutError: If the pod is still in a pending state after the maximum
            wait time has elapsed.
        Exception: If the pod fails to start after the maximum number of
            retries.
    """
    retries = 0

    while retries < startup_max_retries:
        try:
            # Create and run pod.
            core_api.create_namespaced_pod(
                namespace=namespace,
                body=pod_manifest,
            )
            break
        except Exception as e:
            retries += 1
            if retries < startup_max_retries:
                logger.debug(f"The {pod_display_name} failed to start: {e}")
                message = ""
                try:
                    if isinstance(e, ApiException) and e.body:
                        exception_body = json.loads(e.body)
                        message = exception_body.get("message", "")
                except Exception:
                    pass
                logger.error(
                    f"Failed to create {pod_display_name}. "
                    f"Retrying in {startup_failure_delay} seconds..."
                    "\nReason: " + message
                    if message
                    else ""
                )
                time.sleep(startup_failure_delay)
                startup_failure_delay *= startup_failure_backoff
            else:
                logger.error(
                    f"Failed to create {pod_display_name} after "
                    f"{startup_max_retries} retries. Exiting."
                )
                raise

    # Wait for pod to start
    logger.info(f"Waiting for {pod_display_name} to start...")
    max_wait = startup_timeout
    total_wait: float = 0
    delay = startup_failure_delay
    while True:
        pod = get_pod(
            core_api=core_api,
            pod_name=pod_name,
            namespace=namespace,
            api_request_timeout=api_request_timeout,
            max_retries=max_retries,
        )
        if not pod or pod_is_not_pending(pod):
            break
        if total_wait >= max_wait:
            # Have to delete the pending pod so it doesn't start running
            # later on.
            try:
                core_api.delete_namespaced_pod(
                    name=pod_name,
                    namespace=namespace,
                )
            except Exception:
                pass
            raise TimeoutError(
                f"The {pod_display_name} is still in a pending state "
                f"after {total_wait} seconds. Exiting."
            )

        if total_wait + delay > max_wait:
            delay = max_wait - total_wait
        total_wait += delay
        time.sleep(delay)
        delay *= startup_failure_backoff


def get_pod_owner_references(
    core_api: k8s_client.CoreV1Api,
    pod_name: str,
    namespace: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> List[k8s_client.V1OwnerReference]:
    """Get owner references for a pod.

    Args:
        core_api: Kubernetes CoreV1Api client.
        pod_name: Name of the pod.
        namespace: Kubernetes namespace.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        List of owner references.
    """
    pod = get_pod(
        core_api=core_api,
        pod_name=pod_name,
        namespace=namespace,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )

    if not pod or not pod.metadata or not pod.metadata.owner_references:
        return []

    return cast(
        List[k8s_client.V1OwnerReference], pod.metadata.owner_references
    )


def retry_on_api_exception(
    func: Callable[..., R],
    max_retries: int = 3,
    delay: float = 1,
    backoff: float = 1,
    fail_on_status_codes: Tuple[int, ...] = (404,),
    api_request_timeout: Optional[int] = None,
) -> Callable[..., R]:
    """Retry a function on API exceptions.

    Args:
        func: The function to retry.
        max_retries: The maximum number of retries.
        delay: The delay between retries.
        backoff: The backoff factor.
        fail_on_status_codes: The status codes to fail on immediately.
        api_request_timeout: The request timeout in seconds.

    Returns:
        The wrapped function with retry logic.
    """

    @functools.wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> R:
        _delay = delay
        retries = 0
        while retries <= max_retries:
            try:
                if api_request_timeout and "_request_timeout" not in kwargs:
                    kwargs["_request_timeout"] = api_request_timeout
                return func(*args, **kwargs)
            except (ApiException, ReadTimeoutError) as e:
                if (
                    isinstance(e, ApiException)
                    and e.status in fail_on_status_codes
                ):
                    raise

                retries += 1
                if retries <= max_retries:
                    func_name = getattr(func, "__name__", repr(func))
                    logger.warning("Error calling %s: %s.", func_name, e)
                    time.sleep(_delay)
                    _delay *= backoff
                else:
                    raise

        func_name = getattr(func, "__name__", repr(func))
        raise RuntimeError(
            f"Failed to call {func_name} after {max_retries} retries."
        )

    return wrapper


def create_job(
    batch_api: k8s_client.BatchV1Api,
    namespace: str,
    job_manifest: k8s_client.V1Job,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1Job:
    """Create a Kubernetes job.

    Args:
        batch_api: Kubernetes batch api.
        namespace: Kubernetes namespace.
        job_manifest: The manifest of the job to create.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The created job.
    """
    return retry_on_api_exception(
        batch_api.create_namespaced_job,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        body=job_manifest,
    )


def delete_job(
    batch_api: k8s_client.BatchV1Api,
    namespace: str,
    job_name: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Delete a Kubernetes job and its pods.

    Args:
        batch_api: Kubernetes batch api.
        namespace: Kubernetes namespace.
        job_name: The name of the job to delete.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.
    """
    retry_on_api_exception(
        batch_api.delete_namespaced_job,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        name=job_name,
        namespace=namespace,
        propagation_policy="Foreground",
    )


def create_service(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    service_manifest: k8s_client.V1Service,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1Service:
    """Create a Kubernetes service.

    Args:
        core_api: Kubernetes core api.
        namespace: Kubernetes namespace.
        service_manifest: The manifest of the service to create.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The created service.
    """
    return retry_on_api_exception(
        core_api.create_namespaced_service,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        body=service_manifest,
    )


def get_job(
    batch_api: k8s_client.BatchV1Api,
    namespace: str,
    job_name: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1Job:
    """Get a job by name.

    Args:
        batch_api: Kubernetes batch api.
        namespace: Kubernetes namespace.
        job_name: The name of the job to get.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The job.
    """
    return retry_on_api_exception(
        batch_api.read_namespaced_job,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(name=job_name, namespace=namespace)


def list_jobs(
    batch_api: k8s_client.BatchV1Api,
    namespace: str,
    label_selector: Optional[str] = None,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1JobList:
    """List jobs in a namespace.

    Args:
        batch_api: Kubernetes batch api.
        namespace: Kubernetes namespace.
        label_selector: The label selector to use.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The job list.
    """
    return retry_on_api_exception(
        batch_api.list_namespaced_job,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        label_selector=label_selector,
    )


def update_job(
    batch_api: k8s_client.BatchV1Api,
    namespace: str,
    job_name: str,
    annotations: Dict[str, str],
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1Job:
    """Update a job.

    Args:
        batch_api: Kubernetes batch api.
        namespace: Kubernetes namespace.
        job_name: The name of the job to update.
        annotations: The annotations to update.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The updated job.
    """
    return retry_on_api_exception(
        batch_api.patch_namespaced_job,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        name=job_name,
        namespace=namespace,
        body={"metadata": {"annotations": annotations}},
    )


def is_step_job(job: k8s_client.V1Job) -> bool:
    """Check if a job is a step job.

    Args:
        job: The job to check.

    Returns:
        Whether the job is a step job.
    """
    if not job.metadata or not job.metadata.annotations:
        return False

    return STEP_NAME_ANNOTATION_KEY in job.metadata.annotations


def get_container_status(
    pod: k8s_client.V1Pod, container_name: str
) -> Optional[k8s_client.V1ContainerState]:
    """Get the status of a container.

    Args:
        pod: The pod to get the container status for.
        container_name: The container name.

    Returns:
        The container status.
    """
    if not pod.status or not pod.status.container_statuses:
        return None

    for container_status in pod.status.container_statuses:
        if container_status.name == container_name:
            return container_status.state

    return None


def get_container_termination_reason(
    pod: k8s_client.V1Pod, container_name: str
) -> Optional[Tuple[int, str]]:
    """Get the termination reason for a container.

    Args:
        pod: The pod to get the termination reason for.
        container_name: The container name.

    Returns:
        The exit code and termination reason for the container.
    """
    container_state = get_container_status(pod, container_name)
    if not container_state or not container_state.terminated:
        return None

    return (
        container_state.terminated.exit_code,
        container_state.terminated.reason or "Unknown",
    )


def get_pod_failure_details(
    pod: k8s_client.V1Pod, container_name: str
) -> Optional[str]:
    """Get best-effort pod failure details.

    Args:
        pod: The pod to get failure details for.
        container_name: The container name.

    Returns:
        Failure details for the pod, if available.
    """
    try:
        details: List[str] = []
        container_state = get_container_status(pod, container_name)
        if container_state and container_state.terminated:
            terminated = container_state.terminated
            container_details = [
                terminated.reason or "Unknown",
                f"exit_code={terminated.exit_code}",
            ]
            if terminated.message:
                container_details.append(f"message={terminated.message}")
            details.append(
                f"container failure reason: {', '.join(container_details)}"
            )
        elif container_state and container_state.waiting:
            waiting = container_state.waiting
            container_details = [waiting.reason or "Unknown"]
            if waiting.message:
                container_details.append(f"message={waiting.message}")
            details.append(
                f"container waiting reason: {', '.join(container_details)}"
            )

        if pod.status:
            pod_details = []
            if pod.status.reason:
                pod_details.append(pod.status.reason)
            if pod.status.message:
                pod_details.append(f"message={pod.status.message}")

            if pod_details:
                details.append(f"pod failure reason: {', '.join(pod_details)}")

        if details:
            return "; ".join(details)
    except Exception:
        logger.debug("Failed to extract pod failure details.", exc_info=True)

    return None


def get_pod_pending_details(
    pod: k8s_client.V1Pod, container_name: str
) -> Optional[str]:
    """Get best-effort pod pending details.

    Args:
        pod: The pod to get pending details for.
        container_name: The container name.

    Returns:
        Pending details for the pod, if available.
    """
    try:
        details: list[str] = []
        pod_name = pod.metadata.name if pod.metadata else None

        if pod.status:
            for condition in pod.status.conditions or []:
                if condition.status == "False" and (
                    condition.reason or condition.message
                ):
                    condition_details = [condition.type or "Unknown"]
                    if condition.reason:
                        condition_details.append(condition.reason)
                    if condition.message:
                        condition_details.append(
                            f"message={condition.message}"
                        )
                    details.append(
                        "pod condition: " + ", ".join(condition_details)
                    )

            if pod.status.reason:
                details.append(f"pod reason: {pod.status.reason}")
            if pod.status.message:
                details.append(f"pod message: {pod.status.message}")

        container_state = get_container_status(pod, container_name)
        if container_state and container_state.waiting:
            waiting = container_state.waiting
            container_details = [waiting.reason or "Unknown"]
            if waiting.message:
                container_details.append(f"message={waiting.message}")
            details.append(
                f"container waiting reason: {', '.join(container_details)}"
            )

        if details:
            prefix = f"pod `{pod_name}`" if pod_name else "pod"
            return f"{prefix}: " + "; ".join(details)
    except Exception:
        logger.debug("Failed to extract pod pending details.", exc_info=True)

    return None


def wait_for_job_to_finish(
    get_client: Callable[[], k8s_client.ApiClient],
    namespace: str,
    job_name: str,
    backoff_interval: float = 1,
    maximum_backoff: float = 32,
    exponential_backoff: bool = False,
    fail_on_container_waiting_reasons: Optional[List[str]] = None,
    stream_logs: bool = True,
    container_name: Optional[str] = None,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Wait for a job to finish.

    Args:
        get_client: A function that returns a Kubernetes API client.
        namespace: Kubernetes namespace.
        job_name: Name of the job for which to wait.
        backoff_interval: The interval to wait between polling the job status.
        maximum_backoff: The maximum interval to wait between polling the job
            status.
        exponential_backoff: Whether to use exponential backoff.
        fail_on_container_waiting_reasons: List of container waiting reasons
            that will cause the job to fail.
        stream_logs: Whether to stream the job logs.
        container_name: Name of the container to stream logs from.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Raises:
        RuntimeError: If the job failed or timed out.
    """
    logged_lines_per_pod: Dict[str, int] = defaultdict(int)
    finished_pods = set()

    while True:
        client = get_client()
        batch_api = k8s_client.BatchV1Api(client)
        core_api = k8s_client.CoreV1Api(client)

        job: k8s_client.V1Job = retry_on_api_exception(
            batch_api.read_namespaced_job,
            api_request_timeout=api_request_timeout,
            max_retries=max_retries,
        )(name=job_name, namespace=namespace)

        if job.status.conditions:
            for condition in job.status.conditions:
                if condition.type == "Complete" and condition.status == "True":
                    return
                if condition.type == "Failed" and condition.status == "True":
                    raise RuntimeError(
                        f"Job `{namespace}:{job_name}` failed: "
                        f"{condition.message}"
                    )

        if fail_on_container_waiting_reasons:
            pod_list: k8s_client.V1PodList = retry_on_api_exception(
                core_api.list_namespaced_pod,
                api_request_timeout=api_request_timeout,
                max_retries=max_retries,
            )(
                namespace=namespace,
                label_selector=f"job-name={job_name}",
                field_selector="status.phase=Pending",
            )
            for pod in pod_list.items:
                container_state = get_container_status(
                    pod, container_name or "main"
                )

                if (
                    container_state
                    and (waiting_state := container_state.waiting)
                    and waiting_state.reason
                    in fail_on_container_waiting_reasons
                ):
                    delete_job(
                        batch_api=batch_api,
                        namespace=namespace,
                        job_name=job_name,
                        api_request_timeout=api_request_timeout,
                        max_retries=max_retries,
                    )
                    raise RuntimeError(
                        f"Job `{namespace}:{job_name}` failed: "
                        f"Detected container in state "
                        f"{waiting_state.reason}"
                    )

        if stream_logs:
            try:
                pod_list = core_api.list_namespaced_pod(
                    namespace=namespace,
                    label_selector=f"job-name={job_name}",
                )
            except ApiException as e:
                logger.error("Error fetching pods: %s.", e)
                pod_list = []
            else:
                # Sort pods by creation timestamp, oldest first
                pod_list.items.sort(
                    key=lambda pod: pod.metadata.creation_timestamp,
                )

            for pod in pod_list.items:
                pod_name = pod.metadata.name
                pod_status = pod.status.phase

                if pod_name in finished_pods:
                    # We've already streamed all logs for this pod, so we can
                    # skip it.
                    continue

                if pod_status == PodPhase.PENDING.value:
                    # The pod is still pending, so we can't stream logs for it
                    # yet.
                    continue

                if pod_status in [
                    PodPhase.SUCCEEDED.value,
                    PodPhase.FAILED.value,
                ]:
                    finished_pods.add(pod_name)

                containers = pod.spec.containers
                if not container_name:
                    container_name = containers[0].name

                try:
                    response = core_api.read_namespaced_pod_log(
                        name=pod_name,
                        namespace=namespace,
                        container=container_name,
                        _preload_content=False,
                    )
                except ApiException as e:
                    logger.error("Error reading pod logs: %s.", e)
                else:
                    raw_data = response.data
                    decoded_log = raw_data.decode("utf-8", errors="replace")
                    logs = decoded_log.splitlines()
                    logged_lines = logged_lines_per_pod[pod_name]
                    if len(logs) > logged_lines:
                        for line in logs[logged_lines:]:
                            logger.info(line)
                        logged_lines_per_pod[pod_name] = len(logs)

        time.sleep(backoff_interval)
        if exponential_backoff and backoff_interval < maximum_backoff:
            backoff_interval *= 2


def check_job_status(
    batch_api: k8s_client.BatchV1Api,
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    job_name: str,
    fail_on_container_waiting_reasons: Optional[List[str]] = None,
    container_name: Optional[str] = None,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> Tuple[JobStatus, Optional[str]]:
    """Check the status of a job.

    Args:
        batch_api: Kubernetes BatchV1Api client.
        core_api: Kubernetes CoreV1Api client.
        namespace: Kubernetes namespace.
        job_name: Name of the job for which to wait.
        fail_on_container_waiting_reasons: List of container waiting reasons
            that will cause the job to fail.
        container_name: Name of the container to check for failure.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The status of the job and an optional status message. For failed jobs,
        this is the error message; for running jobs, this can contain pending
        pod diagnostics.
    """
    job: k8s_client.V1Job = retry_on_api_exception(
        batch_api.read_namespaced_job,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(name=job_name, namespace=namespace)

    if job.status.conditions:
        for condition in job.status.conditions:
            if condition.type == "Complete" and condition.status == "True":
                return JobStatus.SUCCEEDED, None
            if condition.type == "Failed" and condition.status == "True":
                error_message = condition.message or "Unknown"
                pod_failure_details = None
                try:
                    pods = core_api.list_namespaced_pod(
                        label_selector=f"job-name={job_name}",
                        namespace=namespace,
                    ).items
                    # Sort pods by creation timestamp, oldest first
                    pods.sort(
                        key=lambda pod: pod.metadata.creation_timestamp,
                    )
                    if pods:
                        pod_failure_details = get_pod_failure_details(
                            pods[-1], container_name or "main"
                        )
                except Exception:
                    pass

                if pod_failure_details:
                    error_message += f" ({pod_failure_details})"

                return JobStatus.FAILED, error_message

    pending_message = None
    if fail_on_container_waiting_reasons:
        pod_list: k8s_client.V1PodList = retry_on_api_exception(
            core_api.list_namespaced_pod,
            api_request_timeout=api_request_timeout,
            max_retries=max_retries,
        )(
            namespace=namespace,
            label_selector=f"job-name={job_name}",
            field_selector="status.phase=Pending",
        )
        pod_list.items.sort(
            key=lambda pod: (
                pod.metadata.creation_timestamp
                if pod.metadata and pod.metadata.creation_timestamp
                else datetime.min.replace(tzinfo=timezone.utc)
            ),
            reverse=True,
        )
        for pod in pod_list.items:
            container_state = get_container_status(
                pod, container_name or "main"
            )
            pending_message = pending_message or get_pod_pending_details(
                pod, container_name or "main"
            )

            if (
                container_state
                and (waiting_state := container_state.waiting)
                and waiting_state.reason in fail_on_container_waiting_reasons
            ):
                delete_job(
                    batch_api=batch_api,
                    namespace=namespace,
                    job_name=job_name,
                    api_request_timeout=api_request_timeout,
                    max_retries=max_retries,
                )
                error_message = (
                    f"Detected container in state `{waiting_state.reason}`"
                )
                if pending_message:
                    error_message += f" ({pending_message})"
                return JobStatus.FAILED, error_message

    return JobStatus.RUNNING, pending_message


def create_config_map(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    name: str,
    data: Dict[str, str],
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Create a Kubernetes config map.

    Args:
        core_api: Kubernetes CoreV1Api client.
        namespace: Kubernetes namespace.
        name: Name of the config map to create.
        data: Data to store in the config map.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.
    """
    retry_on_api_exception(
        core_api.create_namespaced_config_map,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        body=k8s_client.V1ConfigMap(metadata={"name": name}, data=data),
    )


def update_config_map(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    name: str,
    data: Dict[str, str],
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Update a Kubernetes config map.

    Args:
        core_api: Kubernetes CoreV1Api client.
        namespace: Kubernetes namespace.
        name: Name of the config map to update.
        data: Data to store in the config map.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.
    """
    retry_on_api_exception(
        core_api.patch_namespaced_config_map,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        name=name,
        body=k8s_client.V1ConfigMap(data=data),
    )


def get_config_map(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    name: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> k8s_client.V1ConfigMap:
    """Get a Kubernetes config map.

    Args:
        core_api: Kubernetes CoreV1Api client.
        namespace: Kubernetes namespace.
        name: Name of the config map to get.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The config map.
    """
    return retry_on_api_exception(
        core_api.read_namespaced_config_map,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        name=name,
    )


def delete_config_map(
    core_api: k8s_client.CoreV1Api,
    namespace: str,
    name: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> None:
    """Delete a Kubernetes config map.

    Args:
        core_api: Kubernetes CoreV1Api client.
        namespace: Kubernetes namespace.
        name: Name of the config map to delete.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.
    """
    retry_on_api_exception(
        core_api.delete_namespaced_config_map,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )(
        namespace=namespace,
        name=name,
    )


def get_parent_job_name(
    core_api: k8s_client.CoreV1Api,
    pod_name: str,
    namespace: str,
    api_request_timeout: Optional[int] = None,
    max_retries: int = 3,
) -> Optional[str]:
    """Get the name of the job that created a pod.

    Args:
        core_api: Kubernetes CoreV1Api client.
        pod_name: Name of the pod.
        namespace: Kubernetes namespace.
        api_request_timeout: The request timeout in seconds.
        max_retries: The maximum number of API request retries.

    Returns:
        The name of the job that created the pod, or None if the pod is not
        associated with a job.
    """
    pod = get_pod(
        core_api,
        pod_name=pod_name,
        namespace=namespace,
        api_request_timeout=api_request_timeout,
        max_retries=max_retries,
    )
    if (
        pod
        and pod.metadata
        and pod.metadata.labels
        and (job_name := pod.metadata.labels.get("job-name", None))
    ):
        return cast(str, job_name)

    return None


def apply_default_resource_requests(
    memory: str,
    cpu: Optional[str] = None,
    pod_settings: Optional[KubernetesPodSettings] = None,
) -> KubernetesPodSettings:
    """Applies default resource requests to a pod settings object.

    Args:
        memory: The memory resource request.
        cpu: The CPU resource request.
        pod_settings: The pod settings to update. A new one will be created
            if not provided.

    Returns:
        The new or updated pod settings.
    """
    resources = {
        "requests": {"memory": memory},
    }
    if cpu:
        resources["requests"]["cpu"] = cpu
    if not pod_settings:
        pod_settings = KubernetesPodSettings(resources=resources)
    elif not pod_settings.resources:
        pod_settings = pod_settings.model_copy(update={"resources": resources})
    else:
        set_requests = pod_settings.resources.get("requests", {})
        resources["requests"].update(set_requests)
        pod_settings.resources["requests"] = resources["requests"]

    return pod_settings


def apply_resource_request_component_settings(
    settings: SettingsT,
    allocated_resource_request: Optional["ResourceRequestResponse"],
    settings_class: Type[SettingsT],
) -> SettingsT:
    """Apply matching request target settings to stack settings.

    Args:
        settings: The stack component settings to update.
        allocated_resource_request: The allocated resource request, if any.
        settings_class: The settings class used to validate the result.

    Returns:
        The updated and validated stack component settings.

    Raises:
        ValueError: If the allocated resource request is invalid.
    """
    if not allocated_resource_request:
        return settings

    component_settings = (
        allocated_resource_request.get_resources().component_settings
    )

    settings_dict = settings.model_dump(exclude_unset=True)
    settings_dict.update(component_settings)

    try:
        return settings_class.model_validate(settings_dict)
    except (ValidationError, TypeError) as e:
        resource_pool_name = (
            allocated_resource_request.get_body().pool_name or "<unknown>"
        )
        component_settings_json = json.dumps(
            component_settings,
            default=str,
            indent=2,
            sort_keys=True,
        )
        raise ValueError(
            "Failed to apply the Resource Pool component setting overrides "
            "from the allocated resource request "
            f"{allocated_resource_request.id} "
            f"to `{settings_class.__name__}` stack component settings. "
            "The overrides were merged with the existing stack component "
            "settings, but the merged configuration is invalid. "
            "Component settings provided by the resource request:\n"
            f"{component_settings_json}\n"
            "Please check the target settings that you configured for the "
            f"`{resource_pool_name}` resource pool and its policies."
        ) from e


def apply_resource_request_allocations_to_pod_settings(
    allocated_resource_request: Optional["ResourceRequestResponse"],
    pod_settings: Optional[KubernetesPodSettings] = None,
) -> KubernetesPodSettings:
    """Apply allocated CPU, memory, and GPU resources to pod settings.

    Args:
        allocated_resource_request: The allocated resource request, if any.
        pod_settings: The pod settings to update. A new one will be created
            if not provided.

    Returns:
        The new or updated pod settings.
    """
    if not pod_settings:
        pod_settings = KubernetesPodSettings()
    else:
        pod_settings = pod_settings.model_copy(deep=True)

    if not allocated_resource_request:
        return pod_settings

    cpu_millicores = 0
    memory_bytes = 0
    gpu_count = 0

    for allocation in allocated_resource_request.get_resources().allocations:
        kind = allocation.resource_kind
        unit = allocation.unit

        if kind == "cpu":
            cpu_millicores += _cpu_allocation_to_millicores(
                quantity=allocation.quantity,
                unit=unit,
            )
        elif kind == "memory":
            memory_bytes += _memory_allocation_to_bytes(
                quantity=allocation.quantity,
                unit=unit,
            )
        elif kind == "gpu":
            gpu_count += allocation.quantity

    resources = {
        section: dict(values)
        for section, values in (pod_settings.resources or {}).items()
    }
    requests = resources.setdefault("requests", {})
    limits = resources.setdefault("limits", {})
    resource_request_resources: Dict[str, Dict[str, str]] = {
        "requests": {},
        "limits": {},
    }
    resource_request_requests = resource_request_resources["requests"]
    resource_request_limits = resource_request_resources["limits"]

    if cpu_millicores:
        if cpu_millicores % 1000 == 0:
            cpu = str(cpu_millicores // 1000)
        else:
            cpu = f"{cpu_millicores}m"
        requests["cpu"] = cpu
        limits["cpu"] = cpu
        resource_request_requests["cpu"] = cpu
        resource_request_limits["cpu"] = cpu

    if memory_bytes:
        memory = f"{math.ceil(memory_bytes / ByteUnit.MIB.byte_value)}Mi"
        requests["memory"] = memory
        limits["memory"] = memory
        resource_request_requests["memory"] = memory
        resource_request_limits["memory"] = memory

    if gpu_count:
        gpu = str(gpu_count)
        requests["nvidia.com/gpu"] = gpu
        limits["nvidia.com/gpu"] = gpu
        resource_request_requests["nvidia.com/gpu"] = gpu
        resource_request_limits["nvidia.com/gpu"] = gpu

    logger.debug(
        "Configured Kubernetes pod resources from allocated resource request "
        "`%s`: %s. Final Kubernetes pod resources: %s",
        allocated_resource_request.id,
        json.dumps(
            resource_request_resources,
            default=str,
            indent=2,
            sort_keys=True,
        ),
        json.dumps(
            resources,
            default=str,
            indent=2,
            sort_keys=True,
        ),
    )

    return pod_settings.model_copy(update={"resources": resources})


def _cpu_allocation_to_millicores(quantity: int, unit: Optional[str]) -> int:
    """Convert a CPU allocation to Kubernetes millicores.

    Args:
        quantity: CPU allocation quantity.
        unit: CPU allocation unit.

    Returns:
        CPU allocation expressed in Kubernetes millicores.
    """
    if unit is None:
        if quantity > 50:
            return quantity
        return quantity * 1000

    normalized_unit = unit.lower()
    if normalized_unit == "cpu":
        return quantity * 1000
    if normalized_unit in {"m", "mcpu", "millicpu", "millicore", "millicores"}:
        return quantity

    logger.warning(
        "Interpreting unsupported CPU allocation unit `%s` as full CPU cores.",
        unit,
    )
    return quantity * 1000


def _memory_allocation_to_bytes(quantity: int, unit: Optional[str]) -> int:
    """Convert a memory allocation to bytes.

    Args:
        quantity: Memory allocation quantity.
        unit: Memory allocation unit.

    Returns:
        Memory allocation expressed in bytes.
    """
    if unit is None:
        logger.warning("Interpreting memory allocation without a unit as MiB.")
        return quantity * ByteUnit.MIB.byte_value

    try:
        byte_unit = ByteUnit(unit)
    except ValueError:
        logger.warning(
            "Ignoring memory allocation with unsupported unit `%s`.",
            unit,
        )
        return 0

    return quantity * byte_unit.byte_value


# ============================================================================
# Resource Conversion Utilities
# ============================================================================


def convert_resource_settings_to_k8s_format(
    resource_settings: "ResourceSettings",
) -> Tuple[Dict[str, str], Dict[str, str], int]:
    """Convert ZenML ResourceSettings to Kubernetes resource format.

    Args:
        resource_settings: The resource settings from pipeline configuration.

    Returns:
        Tuple of (requests, limits, replicas) in Kubernetes format.
        - requests: Dict with 'cpu', 'memory', and optionally 'nvidia.com/gpu' keys
        - limits: Dict with same keys as requests (GPUs require limits=requests)
        - replicas: Number of replicas
    """
    requests: Dict[str, str] = {}
    limits: Dict[str, str] = {}

    if resource_settings.cpu_count is not None:
        cpu_value = resource_settings.cpu_count
        if cpu_value == int(cpu_value):
            cpu_str = str(int(cpu_value))
        else:
            cpu_str = f"{int(cpu_value * 1000)}m"

        requests["cpu"] = cpu_str

    if memory_mib := resource_settings.get_memory(unit=ByteUnit.MIB):
        memory_str = f"{int(memory_mib)}Mi"
        requests["memory"] = memory_str

    min_r = resource_settings.min_replicas
    max_r = resource_settings.max_replicas

    if min_r is not None and min_r > 0:
        replicas = min_r
    elif max_r is not None and max_r > 0:
        replicas = max_r
    else:
        replicas = 1

    if resource_settings.gpu_count:
        gpu_str = str(resource_settings.gpu_count)
        requests["nvidia.com/gpu"] = gpu_str
        limits["nvidia.com/gpu"] = gpu_str
        logger.info(
            f"Configured {resource_settings.gpu_count} GPU(s) per pod. "
            f"Ensure your cluster has GPU nodes with the nvidia.com/gpu resource. "
            f"You may need to install the NVIDIA device plugin: "
            f"https://github.com/NVIDIA/k8s-device-plugin"
        )

    return requests, limits, replicas


# ============================================================================
# URL Building Utilities
# ============================================================================


def build_service_url(
    core_api: k8s_client.CoreV1Api,
    service: Union[k8s_client.V1Service, Dict[str, Any]],
    namespace: str,
    ingress: Optional[Union[k8s_client.V1Ingress, Dict[str, Any]]] = None,
) -> Optional[str]:
    """Build URL for accessing a Kubernetes service.

    Supports multiple service types:
    - LoadBalancer: Returns http://<external-ip>:<port> if IP is assigned
    - NodePort: Returns http://<node-ip>:<node-port> if nodes have external IPs
    - ClusterIP: Returns internal cluster URL with warning about port-forwarding

    Args:
        core_api: Kubernetes Core V1 API client.
        service: Kubernetes Service resource (model or dict).
        namespace: Kubernetes namespace.
        ingress: Optional Kubernetes Ingress resource.

    Returns:
        Service URL
    """
    service_dict = normalize_resource_to_dict(service)

    if ingress:
        ingress_dict = normalize_resource_to_dict(ingress)

        ingress_spec = ingress_dict.get("spec")
        if ingress_spec:
            protocol = "https" if ingress_spec.get("tls") else "http"
            rules = ingress_spec.get("rules", [])
            if rules:
                rule = rules[0]
                host = rule.get("host")
                http_config = rule.get("http", {})
                paths = http_config.get("paths", [])
                if host and paths:
                    path = paths[0].get("path", "/")
                    return f"{protocol}://{host}{path}"

    metadata = service_dict.get("metadata", {})
    spec = service_dict.get("spec", {})

    service_name = metadata.get("name", "unknown")
    service_type = spec.get("type")
    ports = spec.get("ports", [])

    if not service_type or not ports:
        return None

    service_port = ports[0].get("port")

    if service_type == "LoadBalancer":
        status = service_dict.get("status", {})
        lb_status = status.get("loadBalancer", {})
        ingress_list = lb_status.get("ingress", [])

        if ingress_list:
            lb_ingress = ingress_list[0]
            host = lb_ingress.get("ip") or lb_ingress.get("hostname")
            if host:
                return f"http://{host}:{service_port}"

        return None

    if service_type == "NodePort":
        node_port = ports[0].get("nodePort")
        if not node_port:
            return None

        try:
            nodes = core_api.list_node()

            for node in nodes.items:
                if node.status and node.status.addresses:
                    for address in node.status.addresses:
                        if address.type == "ExternalIP":
                            return f"http://{address.address}:{node_port}"

            for node in nodes.items:
                if node.status and node.status.addresses:
                    for address in node.status.addresses:
                        if address.type == "InternalIP":
                            logger.warning(
                                f"NodePort service '{service_name}' has no ExternalIP. "
                                f"Use: kubectl port-forward -n {namespace} "
                                f"service/{service_name} 8080:{service_port}"
                            )
                            return f"http://{address.address}:{node_port}"
        except Exception as e:
            logger.error(f"Failed to get node IPs: {e}")

        return None

    if service_type == "ClusterIP":
        logger.warning(
            f"Service '{service_name}' uses ClusterIP (cluster-internal only). "
            f"Use: kubectl port-forward -n {namespace} "
            f"service/{service_name} 8080:{service_port}"
        )
        return f"http://{service_name}.{namespace}.svc.cluster.local:{service_port}"

    return None
