#  Copyright (c) ZenML GmbH 2023. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at:
#
#       https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
#  or implied. See the License for the specific language governing
#  permissions and limitations under the License.
"""Implementation of the Databricks orchestrator."""

import os
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple, Type, cast
from uuid import UUID

from databricks.sdk import WorkspaceClient as DatabricksClient
from databricks.sdk.service.jobs import CronSchedule, JobCluster
from databricks.sdk.service.jobs import Task as DatabricksTask

from zenml.constants import (
    ENV_ZENML_CUSTOM_SOURCE_ROOT,
    METADATA_ORCHESTRATOR_URL,
)
from zenml.integrations.databricks.flavors.databricks_orchestrator_flavor import (
    DatabricksOrchestratorConfig,
    DatabricksOrchestratorSettings,
)
from zenml.integrations.databricks.orchestrators.databricks_orchestrator_entrypoint_config import (
    ENV_ZENML_DATABRICKS_ORCHESTRATOR_RUN_ID,
    DatabricksEntrypointConfiguration,
)
from zenml.integrations.databricks.utils.databricks_utils import (
    DATABRICKS_WHEELS_DIRECTORY_PREFIX,
    DATABRICKS_ZENML_DEFAULT_CUSTOM_REPOSITORY_PATH,
    build_access_control_list,
    build_databricks_cluster_spec,
    collect_requirements,
    convert_step_to_task,
    delete_workspace_directory,
    upload_wheel_to_workspace,
)
from zenml.io import fileio
from zenml.logger import get_logger
from zenml.metadata.metadata_types import MetadataType, Uri
from zenml.models.v2.core.schedule import ScheduleResponse
from zenml.orchestrators.base_orchestrator import SubmissionResult
from zenml.orchestrators.utils import get_orchestrator_run_name
from zenml.orchestrators.wheeled_orchestrator import WheeledOrchestrator
from zenml.stack.stack_validator import StackValidator

if TYPE_CHECKING:
    from zenml.models import PipelineRunResponse, PipelineSnapshotResponse
    from zenml.stack.stack import Stack


logger = get_logger(__name__)

ZENML_STEP_DEFAULT_ENTRYPOINT_COMMAND = "entrypoint.main"
DATABRICKS_JOB_ID_PARAMETER_REFERENCE = "{{job.id}}"


class DatabricksOrchestrator(WheeledOrchestrator):
    """Databricks orchestrator."""

    @property
    def validator(self) -> Optional[StackValidator]:
        """Validates the stack.

        Returns:
            A validator that rejects local stack components.
        """

        def _validate_remote_components(
            stack: "Stack",
        ) -> Tuple[bool, str]:
            for component in stack.all_components:
                if not component.config.is_local:
                    continue

                return False, (
                    f"The Databricks orchestrator runs pipelines remotely, "
                    f"but the '{component.name}' {component.type.value} is "
                    "a local stack component and will not be available in "
                    "the Databricks step.\nPlease ensure that you always "
                    "use non-local stack components with the Databricks "
                    "orchestrator."
                )

            return True, ""

        return StackValidator(
            custom_validation_function=_validate_remote_components,
        )

    def _get_databricks_client(
        self,
    ) -> DatabricksClient:
        """Creates a Databricks client.

        Returns:
            The Databricks client.
        """
        if (
            self.config.client_id is not None
            and self.config.client_secret is not None
        ):
            return DatabricksClient(
                host=self.config.host,
                client_id=self.config.client_id,
                client_secret=self.config.client_secret,
            )
        return DatabricksClient(host=self.config.host)

    @property
    def config(self) -> DatabricksOrchestratorConfig:
        """Returns the `DatabricksOrchestratorConfig` config.

        Returns:
            The configuration.
        """
        return cast(DatabricksOrchestratorConfig, self._config)

    @property
    def settings_class(self) -> Type[DatabricksOrchestratorSettings]:
        """Settings class for the Databricks orchestrator.

        Returns:
            The settings class.
        """
        return DatabricksOrchestratorSettings

    def get_orchestrator_run_id(self) -> str:
        """Returns the active orchestrator run id.

        Raises:
            RuntimeError: If the run id cannot be read from the environment.

        Returns:
            The orchestrator run id.
        """
        orchestrator_run_id = os.environ.get(
            ENV_ZENML_DATABRICKS_ORCHESTRATOR_RUN_ID
        )
        if orchestrator_run_id is None:
            raise RuntimeError(
                "Unable to read run id from environment variable "
                f"{ENV_ZENML_DATABRICKS_ORCHESTRATOR_RUN_ID}."
            )

        return orchestrator_run_id

    def setup_credentials(self) -> None:
        """Set up credentials for the orchestrator."""
        connector = self.get_connector()
        assert connector is not None
        connector.configure_local_client()

    def submit_pipeline(
        self,
        snapshot: "PipelineSnapshotResponse",
        stack: "Stack",
        base_environment: Dict[str, str],
        step_environments: Dict[str, Dict[str, str]],
        placeholder_run: Optional["PipelineRunResponse"] = None,
    ) -> Optional[SubmissionResult]:
        """Submits a pipeline to the orchestrator.

        This method should only submit the pipeline and not wait for it to
        complete. If the orchestrator is configured to wait for the pipeline run
        to complete, a function that waits for the pipeline run to complete can
        be passed as part of the submission result.

        Args:
            snapshot: The pipeline snapshot to submit.
            stack: The stack the pipeline will run on.
            base_environment: Base environment shared by all Databricks tasks.
            step_environments: Environment variables to set when executing
                specific steps.
            placeholder_run: An optional placeholder run for the snapshot.

        Raises:
            ValueError: If the schedule is not set or if the cron expression
                is not set.
            Exception: If wheel upload or Databricks job submission fails
                after cleanup.

        Returns:
            Optional submission result.
        """
        settings = cast(
            DatabricksOrchestratorSettings, self.get_settings(snapshot)
        )
        if snapshot.schedule:
            if snapshot.schedule.catchup or snapshot.schedule.interval_second:
                logger.warning(
                    "Databricks orchestrator only uses schedules with the "
                    "`cron_expression` property, with optional `start_time` and/or `end_time`. "
                    "All other properties are ignored."
                )
            if snapshot.schedule.cron_expression is None:
                raise ValueError(
                    "Property `cron_expression` must be set when passing "
                    "schedule to a Databricks orchestrator."
                )
            if (
                snapshot.schedule.cron_expression
                and settings.schedule_timezone is None
            ):
                raise ValueError(
                    "Property `schedule_timezone` must be set when passing "
                    "`cron_expression` to a Databricks orchestrator. "
                    "Databricks orchestrator requires an IANA timezone ID "
                    "such as 'America/New_York' or 'UTC' to run the "
                    "pipeline on schedule."
                )

        def _construct_databricks_pipeline(
            zenml_project_wheel: str, job_cluster_key: str
        ) -> List[DatabricksTask]:
            """Create one Databricks task for each pipeline step.

            Args:
                zenml_project_wheel: The wheel package containing the ZenML
                    project.
                job_cluster_key: The ID of the Databricks job cluster.

            Returns:
                A list of Databricks tasks.
            """
            tasks = []
            for step_name, step in snapshot.step_configurations.items():
                arguments = DatabricksEntrypointConfiguration.get_entrypoint_arguments(
                    step_name=step_name,
                    snapshot_id=snapshot.id,
                    wheel_package=self.package_name,
                    databricks_job_id=DATABRICKS_JOB_ID_PARAMETER_REFERENCE,
                )

                # Dependency keys must match the snapshot-prefixed task keys.
                upstream_steps = [
                    f"{snapshot.id}_{upstream_step_name}"
                    for upstream_step_name in step.spec.upstream_steps
                ]

                task = convert_step_to_task(
                    f"{snapshot.id}_{step_name}",
                    ZENML_STEP_DEFAULT_ENTRYPOINT_COMMAND,
                    arguments,
                    collect_requirements(
                        docker_settings=step.config.docker_settings,
                        stack=stack,
                    ),
                    depends_on=upstream_steps,
                    zenml_project_wheel=zenml_project_wheel,
                    job_cluster_key=job_cluster_key,
                    timeout_seconds=settings.task_timeout_seconds,
                    max_retries=settings.max_retries,
                    min_retry_interval_millis=settings.min_retry_interval_millis,
                    retry_on_timeout=settings.retry_on_timeout,
                )
                tasks.append(task)
            return tasks

        orchestrator_run_name = get_orchestrator_run_name(
            pipeline_name=snapshot.pipeline_configuration.name
        )

        repository_temp_dir = (
            self.copy_repository_to_temp_dir_and_add_setup_py()
        )

        databricks_client = self._get_databricks_client()
        snapshot_name = self.sanitize_name(snapshot.pipeline.name)
        run_namespace = self.sanitize_name(
            str(placeholder_run.id)
            if placeholder_run
            else orchestrator_run_name
        )
        databricks_directory = (
            f"{DATABRICKS_WHEELS_DIRECTORY_PREFIX}/"
            f"{snapshot_name}/{run_namespace}/orchestrator"
        )
        try:
            wheel_path = self.create_wheel(temp_dir=repository_temp_dir)
            try:
                databricks_wheel_path = upload_wheel_to_workspace(
                    databricks_client=databricks_client,
                    wheel_path=wheel_path,
                    databricks_directory=databricks_directory,
                )
            except Exception:
                delete_workspace_directory(
                    databricks_client=databricks_client,
                    databricks_directory=databricks_directory,
                    context="failed wheel upload",
                )
                raise
        finally:
            fileio.rmtree(repository_temp_dir)

        env_vars = base_environment.copy()
        spark_env_vars = settings.spark_env_vars
        if spark_env_vars:
            for key, value in spark_env_vars.items():
                env_vars[key] = value
        env_vars[ENV_ZENML_CUSTOM_SOURCE_ROOT] = (
            DATABRICKS_ZENML_DEFAULT_CUSTOM_REPOSITORY_PATH
        )

        job_cluster_key = self.sanitize_name(str(snapshot.id))
        try:
            self._upload_and_run_pipeline(
                pipeline_name=orchestrator_run_name,
                settings=settings,
                tasks=_construct_databricks_pipeline(
                    databricks_wheel_path, job_cluster_key
                ),
                env_vars=env_vars,
                job_cluster_key=job_cluster_key,
                schedule=snapshot.schedule,
            )
        except Exception:
            delete_workspace_directory(
                databricks_client=databricks_client,
                databricks_directory=databricks_directory,
                context="failed job submission",
            )
            raise
        return None

    def _upload_and_run_pipeline(
        self,
        pipeline_name: str,
        settings: DatabricksOrchestratorSettings,
        tasks: List[DatabricksTask],
        env_vars: Dict[str, str],
        job_cluster_key: str,
        schedule: Optional["ScheduleResponse"] = None,
    ) -> None:
        """Upload and run the pipeline as a Databricks job.

        Args:
            pipeline_name: The name of the pipeline.
            tasks: The list of tasks to run.
            env_vars: The environment variables.
            job_cluster_key: The ID of the Databricks job cluster.
            schedule: Optional schedule for the pipeline.
            settings: The settings for the Databricks orchestrator.

        Raises:
            ValueError: If the `Job Compute` policy is not found or
                if the `schedule_timezone` is not set when passing a
                cron expression.
        """
        databricks_client = self._get_databricks_client()

        job_cluster = JobCluster(
            job_cluster_key=job_cluster_key,
            new_cluster=build_databricks_cluster_spec(
                databricks_client=databricks_client,
                settings=settings,
                env_vars=env_vars,
            ),
        )
        databricks_schedule = None
        if schedule and schedule.cron_expression:
            schedule_timezone = settings.schedule_timezone
            if schedule_timezone:
                databricks_schedule = CronSchedule(
                    quartz_cron_expression=schedule.cron_expression,
                    timezone_id=schedule_timezone,
                )
            else:
                raise ValueError(
                    "Property `schedule_timezone` must be set when passing "
                    "`cron_expression` to a Databricks orchestrator. "
                    "Databricks orchestrator requires an IANA timezone ID "
                    "such as 'America/New_York' or 'UTC' to run the "
                    "pipeline on schedule."
                )

        job = databricks_client.jobs.create(
            name=pipeline_name,
            tasks=tasks,
            job_clusters=[job_cluster],
            schedule=databricks_schedule,
            tags=settings.job_tags,
            access_control_list=build_access_control_list(settings),
            timeout_seconds=settings.timeout_seconds,
            max_concurrent_runs=settings.max_concurrent_runs,
        )
        if job.job_id:
            databricks_client.jobs.run_now(job_id=job.job_id)
        else:
            raise ValueError("An error occurred while getting the job id.")

    def get_pipeline_run_metadata(
        self, run_id: UUID
    ) -> Dict[str, "MetadataType"]:
        """Get general component-specific metadata for a pipeline run.

        Args:
            run_id: The ID of the pipeline run.

        Returns:
            A dictionary of metadata.
        """
        run_url = f"{self.config.host}/jobs/{self.get_orchestrator_run_id()}"
        return {
            METADATA_ORCHESTRATOR_URL: Uri(run_url),
        }
