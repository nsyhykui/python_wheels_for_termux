#  Copyright (c) ZenML GmbH 2021. All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at:
#
#       https://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
#  or implied. See the License for the specific language governing
#  permissions and limitations under the License.
"""ZenML enums."""

import logging
from enum import Enum

from zenml.utils.enum_utils import DescribedValuesEnum, StrEnum


class ArtifactType(StrEnum):
    """All possible types an artifact can have."""

    DATA_ANALYSIS = "DataAnalysisArtifact"
    DATA = "DataArtifact"
    MODEL = "ModelArtifact"
    SCHEMA = "SchemaArtifact"  # deprecated
    SERVICE = "ServiceArtifact"
    STATISTICS = "StatisticsArtifact"  # deprecated in favor of `DATA_ANALYSIS`
    BASE = "BaseArtifact"


class StepRunInputArtifactType(StrEnum):
    """All possible types of a step run input artifact."""

    STEP_OUTPUT = (
        "step_output"  # input argument that is the output of a previous step
    )
    MANUAL = "manual"  # manually loaded via `zenml.load_artifact()`
    EXTERNAL = "external"  # loaded via `ExternalArtifact(value=...)`
    LAZY_LOADED = "lazy"  # loaded via various lazy methods
    OVERRIDE = "override"  # used when overriding step inputs


class ArtifactSaveType(StrEnum):
    """All possible method types of how artifact versions can be saved."""

    STEP_OUTPUT = "step_output"  # output of the current step
    MANUAL = "manual"  # manually saved via `zenml.save_artifact()`
    PREEXISTING = "preexisting"  # register via `zenml.register_artifact()`
    EXTERNAL = (
        "external"  # saved via `zenml.ExternalArtifact.upload_by_value()`
    )


class DownloadType(StrEnum):
    """All possible types of downloadable content."""

    ARTIFACT_VERSION = "artifact_version"
    STEP_LOGS = "step_logs"
    RUN_LOGS = "run_logs"
    SNAPSHOT_CODE = "snapshot_code"


class VisualizationType(StrEnum):
    """All currently available visualization types."""

    CSV = "csv"
    HTML = "html"
    IMAGE = "image"
    MARKDOWN = "markdown"
    JSON = "json"


class ZenMLServiceType(StrEnum):
    """All possible types a service can have."""

    ZEN_SERVER = "zen_server"
    MODEL_SERVING = "model-serving"


class ExecutionStatus(StrEnum):
    """Enum that represents the execution status of a step or pipeline run."""

    INITIALIZING = "initializing"
    PROVISIONING = "provisioning"
    QUEUED = "queued"
    RUNNING = "running"
    FAILED = "failed"
    COMPLETED = "completed"
    CACHED = "cached"
    SKIPPED = "skipped"
    # When a step that can be retried failed, its status is set to retrying.
    # Once the next retry is attempted, the status is set to retried.
    RETRYING = "retrying"
    RETRIED = "retried"
    CANCELLING = "cancelling"
    CANCELLED = "cancelled"
    PAUSED = "paused"
    RESUMING = "resuming"
    STOPPED = "stopped"
    STOPPING = "stopping"

    @property
    def is_finished(self) -> bool:
        """Returns whether the execution status is in a finished state.

        Returns:
            Whether the execution status is finished.
        """
        return self in {
            ExecutionStatus.FAILED,
            ExecutionStatus.COMPLETED,
            ExecutionStatus.CACHED,
            ExecutionStatus.SKIPPED,
            ExecutionStatus.RETRIED,
            ExecutionStatus.STOPPED,
            ExecutionStatus.CANCELLED,
        }

    @property
    def is_successful(self) -> bool:
        """Whether the execution status refers to a successful execution.

        Returns:
            Whether the execution status refers to a successful execution.
        """
        return self in {
            ExecutionStatus.COMPLETED,
            ExecutionStatus.CACHED,
            ExecutionStatus.SKIPPED,
        }

    @property
    def is_failed(self) -> bool:
        """Whether the execution status refers to a failed execution.

        Returns:
            Whether the execution status refers to a failed execution.
        """
        return self in {ExecutionStatus.FAILED, ExecutionStatus.CANCELLED}


class HookType(StrEnum):
    """Hook types."""

    RUN_START = "run_start"
    RUN_SUCCESS = "run_success"
    RUN_FAILURE = "run_failure"
    RUN_END = "run_end"
    RUN_PAUSE = "run_pause"
    RUN_RESUME = "run_resume"
    STEP_START = "step_start"
    STEP_END = "step_end"
    STEP_SUCCESS = "step_success"
    STEP_FAILURE = "step_failure"
    CUSTOM = "custom"


class LoggingLevels(Enum):
    """Enum for logging levels."""

    NOTSET = logging.NOTSET
    ERROR = logging.ERROR
    WARN = logging.WARN
    WARNING = logging.WARNING
    INFO = logging.INFO
    DEBUG = logging.DEBUG
    CRITICAL = logging.CRITICAL


class ExecutionMode(StrEnum):
    """Enum that represents the execution mode of a pipeline run."""

    FAIL_FAST = "fail_fast"
    STOP_ON_FAILURE = "stop_on_failure"
    CONTINUE_ON_FAILURE = "continue_on_failure"


class RunWaitConditionType(StrEnum):
    """Supported wait condition types."""

    EXTERNAL_INPUT = "external_input"


class RunWaitConditionStatus(StrEnum):
    """Lifecycle states for a wait condition."""

    PENDING = "pending"
    RESOLVED = "resolved"


class RunWaitConditionResolution(StrEnum):
    """Resolution outcomes for resolved wait conditions."""

    CONTINUE = "continue"
    ABORT = "abort"


class RunWaitConditionLeaseMode(StrEnum):
    """Supported lease update modes for wait-condition polling."""

    REFRESH = "refresh"
    # Finalize the lease and release it. If the wait condition has been resolved
    # in the meantime, the poller is responsible for continuing the run.
    FINALIZE = "finalize"
    # The poller instance is no longer able to continue the run (due to an
    # error, etc.). If the wait condition has been resolved in the meantime,
    # the server should try resuming the run.
    ABANDON = "abandon"


class StackComponentType(StrEnum):
    """All possible types a `StackComponent` can have."""

    ALERTER = "alerter"
    ANNOTATOR = "annotator"
    ARTIFACT_STORE = "artifact_store"
    CONTAINER_REGISTRY = "container_registry"
    DATA_VALIDATOR = "data_validator"
    EXPERIMENT_TRACKER = "experiment_tracker"
    FEATURE_STORE = "feature_store"
    IMAGE_BUILDER = "image_builder"
    LOG_STORE = "log_store"
    MODEL_DEPLOYER = "model_deployer"
    ORCHESTRATOR = "orchestrator"
    STEP_OPERATOR = "step_operator"
    MODEL_REGISTRY = "model_registry"
    DEPLOYER = "deployer"
    SANDBOX = "sandbox"

    @property
    def plural(self) -> str:
        """Returns the plural of the enum value.

        Returns:
            The plural of the enum value.
        """
        if self == StackComponentType.CONTAINER_REGISTRY:
            return "container_registries"
        elif self == StackComponentType.MODEL_REGISTRY:
            return "model_registries"
        elif self == StackComponentType.SANDBOX:
            return "sandboxes"

        return f"{self.value}s"

    @property
    def supports_multiple_per_stack(self) -> bool:
        """Whether multiple components of this type can exist in one stack.

        Returns:
            True if this component type is repeatable within a stack.
        """
        return self in {
            StackComponentType.ALERTER,
            StackComponentType.EXPERIMENT_TRACKER,
            StackComponentType.STEP_OPERATOR,
            StackComponentType.SANDBOX,
        }


class StoreType(StrEnum):
    """Zen Store Backend Types."""

    SQL = "sql"
    REST = "rest"


class SecretsStoreType(StrEnum):
    """Secrets Store Backend Types."""

    NONE = "none"  # indicates that no secrets store is used
    SQL = "sql"
    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"
    HASHICORP = "hashicorp"
    CUSTOM = "custom"  # indicates that the secrets store uses a custom backend


class ContainerRegistryFlavor(StrEnum):
    """Flavors of container registries."""

    DEFAULT = "default"
    GITHUB = "github"
    DOCKERHUB = "dockerhub"
    GCP = "gcp"
    AZURE = "azure"


class CliCategories(StrEnum):
    """All possible categories for CLI commands.

    Note: The order of the categories is important. The same
    order is used to sort the commands in the CLI help output.
    """

    STACK_COMPONENTS = "Stack Components"
    MODEL_DEPLOYMENT = "Model Deployment"
    INTEGRATIONS = "Integrations"
    MANAGEMENT_TOOLS = "Management Tools"
    MODEL_CONTROL_PLANE = "Model Control Plane"
    IDENTITY_AND_SECURITY = "Identity and Security"
    OTHER_COMMANDS = "Other Commands"


class AnnotationTasks(StrEnum):
    """Supported annotation tasks."""

    IMAGE_CLASSIFICATION = "image_classification"
    OBJECT_DETECTION_BOUNDING_BOXES = "object_detection_bounding_boxes"
    OCR = "optical_character_recognition"
    TEXT_CLASSIFICATION = "text_classification"


class SecretValidationLevel(StrEnum):
    """Secret validation levels."""

    SECRET_AND_KEY_EXISTS = "SECRET_AND_KEY_EXISTS"
    SECRET_EXISTS = "SECRET_EXISTS"
    NONE = "NONE"


class ServerProviderType(StrEnum):
    """ZenML server providers."""

    DAEMON = "daemon"
    DOCKER = "docker"


class AnalyticsEventSource(StrEnum):
    """Enum to identify analytics events source."""

    ZENML_GO = "zenml go"
    ZENML_INIT = "zenml init"
    ZENML_SERVER = "zenml server"


class AuthScheme(StrEnum):
    """The authentication scheme."""

    NO_AUTH = "NO_AUTH"
    HTTP_BASIC = "HTTP_BASIC"
    OAUTH2_PASSWORD_BEARER = "OAUTH2_PASSWORD_BEARER"
    EXTERNAL = "EXTERNAL"


class OAuthGrantTypes(StrEnum):
    """The OAuth grant types."""

    OAUTH_PASSWORD = "password"
    OAUTH_DEVICE_CODE = "urn:ietf:params:oauth:grant-type:device_code"
    ZENML_EXTERNAL = "zenml-external"
    ZENML_API_KEY = "zenml-api-key"


class OAuthDeviceStatus(StrEnum):
    """The OAuth device status."""

    PENDING = "pending"
    VERIFIED = "verified"
    ACTIVE = "active"
    LOCKED = "locked"


class APITokenType(StrEnum):
    """The API token type."""

    GENERIC = "generic"
    WORKLOAD = "workload"


class GenericFilterOps(StrEnum):
    """Ops for all filters for string values on list methods."""

    EQUALS = "equals"
    NOT_EQUALS = "notequals"
    CONTAINS = "contains"
    STARTSWITH = "startswith"
    ENDSWITH = "endswith"
    ONEOF = "oneof"
    NOT_ONEOF = "notoneof"
    NOT_CONTAINS = "notcontains"
    IS_NULL = "isnull"
    IS_NOT_NULL = "isnotnull"
    GTE = "gte"
    GT = "gt"
    LTE = "lte"
    LT = "lt"
    IN = "in"


class SorterOps(StrEnum):
    """Ops for all filters for string values on list methods."""

    ASCENDING = "asc"
    DESCENDING = "desc"


class LogicalOperators(StrEnum):
    """Logical Ops to use to combine filters on list methods."""

    OR = "or"
    AND = "and"


class OperatingSystemType(StrEnum):
    """Enum for OS types."""

    LINUX = "Linux"
    WINDOWS = "Windows"
    MACOS = "Darwin"


class SourceContextTypes(StrEnum):
    """Enum for event source types."""

    CLI = "cli"
    PYTHON = "python"
    DASHBOARD = "dashboard"
    DASHBOARD_V2 = "dashboard-v2"
    API = "api"
    KITARU_PYTHON = "kitaru-python"
    KITARU_CLI = "kitaru-cli"
    KITARU_MCP = "kitaru-mcp"
    KITARU_API = "kitaru-api"
    KITARU_UI = "kitaru-ui"
    UNKNOWN = "unknown"


class EnvironmentType(StrEnum):
    """Enum for environment types."""

    BITBUCKET_CI = "bitbucket_ci"
    CIRCLE_CI = "circle_ci"
    COLAB = "colab"
    CONTAINER = "container"
    DOCKER = "docker"
    GENERIC_CI = "generic_ci"
    GITHUB_ACTION = "github_action"
    GITLAB_CI = "gitlab_ci"
    KUBERNETES = "kubernetes"
    NATIVE = "native"
    NOTEBOOK = "notebook"
    PAPERSPACE = "paperspace"
    WSL = "wsl"
    LIGHTNING_AI_STUDIO = "lightning_ai_studio"
    GITHUB_CODESPACES = "github_codespaces"
    VSCODE_REMOTE_CONTAINER = "vscode_remote_container"
    ZENML_CODESPACE = "zenml_codespace"


class ModelStages(StrEnum):
    """All possible stages of a Model Version."""

    NONE = "none"
    STAGING = "staging"
    PRODUCTION = "production"
    ARCHIVED = "archived"
    LATEST = "latest"


class ColorVariants(StrEnum):
    """All possible color variants for frontend."""

    GREY = "grey"
    PURPLE = "purple"
    RED = "red"
    GREEN = "green"
    YELLOW = "yellow"
    ORANGE = "orange"
    LIME = "lime"
    TEAL = "teal"
    TURQUOISE = "turquoise"
    MAGENTA = "magenta"
    BLUE = "blue"


class TaggableResourceTypes(StrEnum):
    """All possible resource types for tagging."""

    ARTIFACT = "artifact"
    ARTIFACT_VERSION = "artifact_version"
    MODEL = "model"
    MODEL_VERSION = "model_version"
    PIPELINE = "pipeline"
    PIPELINE_RUN = "pipeline_run"
    RUN_TEMPLATE = "run_template"
    PIPELINE_SNAPSHOT = "pipeline_snapshot"
    DEPLOYMENT = "deployment"


class ResponseUpdateStrategy(StrEnum):
    """All available strategies to handle updated properties in the response."""

    ALLOW = "allow"
    IGNORE = "ignore"
    DENY = "deny"


class MetadataResourceTypes(StrEnum):
    """All possible resource types for adding metadata."""

    PIPELINE_RUN = "pipeline_run"
    STEP_RUN = "step_run"
    ARTIFACT_VERSION = "artifact_version"
    MODEL_VERSION = "model_version"
    SCHEDULE = "schedule"
    WAIT_CONDITION = "wait_condition"


class VisualizationResourceTypes(StrEnum):
    """Resource types that support curated visualizations.

    Curated visualizations can be attached to these ZenML resources to provide
    contextual dashboards and visual insights throughout the ML lifecycle:

    - **DEPLOYMENT**: Server-side pipeline deployments - surface visualizations
      on deployment monitoring dashboards and status pages
    - **MODEL**: ZenML model entities - surface model evaluation dashboards and
      performance summaries directly on the model detail pages
    - **PIPELINE**: Pipeline definitions - associate visualizations with pipeline
      configurations for reusable visual documentation
    - **PIPELINE_RUN**: Pipeline execution runs - attach visualizations to specific
      run results for detailed analysis and debugging
    - **PIPELINE_SNAPSHOT**: Pipeline snapshots - link visualizations to captured
      pipeline configurations for version comparison and historical analysis
    - **PROJECT**: Project-level overviews - provide high-level project dashboards
      and KPI visualizations for cross-pipeline insights
    """

    DEPLOYMENT = "deployment"  # Server-side pipeline deployments
    MODEL = "model"  # ZenML models
    PIPELINE = "pipeline"  # Pipeline definitions
    PIPELINE_RUN = "pipeline_run"  # Execution runs
    PIPELINE_SNAPSHOT = "pipeline_snapshot"  # Snapshot configurations
    PROJECT = "project"  # Project-level dashboards


class CuratedVisualizationSize(StrEnum):
    """Layout size options for curated visualizations."""

    FULL_WIDTH = "full_width"
    HALF_WIDTH = "half_width"


class SecretResourceTypes(StrEnum):
    """All possible resource types for adding secrets."""

    STACK = "stack"
    STACK_COMPONENT = "stack_component"


class DatabaseBackupStrategy(StrEnum):
    """All available database backup strategies."""

    # Backup disabled
    DISABLED = "disabled"
    # In-memory backup
    IN_MEMORY = "in-memory"
    # Dump the database to a file
    DUMP_FILE = "dump-file"
    # Create a backup of the database in the remote database service
    DATABASE = "database"
    # Use mydumper/myloader for parallel backup/restore (MySQL only)
    MYDUMPER = "mydumper"
    # Use a custom backup engine
    CUSTOM = "custom"


class SQLDatabaseAuthMode(StrEnum):
    """Authentication modes supported by SQL ZenML stores."""

    PASSWORD = "password"
    AWS_RDS_IAM = "aws_rds_iam"


class OnboardingStep(StrEnum):
    """All onboarding steps."""

    DEVICE_VERIFIED = "device_verified"
    PROJECT_CREATED = "project_created"
    PIPELINE_RUN = "pipeline_run"
    STACK_WITH_REMOTE_ORCHESTRATOR_CREATED = (
        "stack_with_remote_orchestrator_created"
    )
    STACK_WITH_REMOTE_ARTIFACT_STORE_CREATED = (
        "stack_with_remote_artifact_store_created"
    )
    PIPELINE_RUN_WITH_REMOTE_ORCHESTRATOR = (
        "pipeline_run_with_remote_orchestrator"
    )
    PIPELINE_RUN_WITH_REMOTE_ARTIFACT_STORE = (
        "pipeline_run_with_remote_artifact_store"
    )
    PIPELINE_DEPLOYED = "pipeline_deployed"
    OSS_ONBOARDING_COMPLETED = "oss_onboarding_completed"
    PRO_ONBOARDING_COMPLETED = "pro_onboarding_completed"


class StackDeploymentProvider(StrEnum):
    """All possible stack deployment providers."""

    AWS = "aws"
    GCP = "gcp"
    AZURE = "azure"


class ServiceState(StrEnum):
    """Possible states for the service and service endpoint."""

    INACTIVE = "inactive"
    ACTIVE = "active"
    PENDING_STARTUP = "pending_startup"
    PENDING_SHUTDOWN = "pending_shutdown"
    ERROR = "error"
    SCALED_TO_ZERO = "scaled_to_zero"


class DeploymentStatus(StrEnum):
    """Status of a deployment."""

    UNKNOWN = "unknown"
    PENDING = "pending"
    RUNNING = "running"
    ABSENT = "absent"
    ERROR = "error"


class PipelineRunTriggeredByType(StrEnum):
    """All possible types that can trigger a pipeline run."""

    STEP_RUN = "step_run"
    DEPLOYMENT = "deployment"


class KubernetesServiceType(StrEnum):
    """Kubernetes Service types for the Kubernetes deployer."""

    LOAD_BALANCER = "LoadBalancer"
    NODE_PORT = "NodePort"
    CLUSTER_IP = "ClusterIP"


class StepRuntime(StrEnum):
    """All possible runtime modes for a step."""

    INLINE = "inline"
    ISOLATED = "isolated"


class StepType(StrEnum):
    """All supported step types."""

    TOOL_CALL = "tool_call"
    LLM_CALL = "llm_call"
    MEMORY_CALL = "memory_call"


class GroupType(StrEnum):
    """Enum representing different types of group."""

    MANUAL = "manual"
    MAP = "map"


class ResourceRequestStatus(StrEnum):
    """Resource request statuses."""

    PENDING = "pending"
    ALLOCATED = "allocated"
    PREEMPTING = "preempting"
    PREEMPTED = "preempted"
    CANCELLED = "cancelled"
    REJECTED = "rejected"
    RELEASED = "released"
    EXPIRED = "expired"
    NO_MATCHING_POOL = "no_matching_pool"


class ResourcePoolScope(StrEnum):
    """Ownership scopes for resource pools."""

    GLOBAL = "global"
    ORGANIZATION = "organization"
    WORKSPACE = "workspace"


class ResourceRequestRuntimeState(StrEnum):
    """Owner-reported runtime states for resource requests."""

    UNKNOWN = "unknown"
    PENDING = "pending"
    SUBMITTED = "submitted"
    RUNNING = "running"
    IDLE = "idle"


class ResourceRequestReclaimTolerance(StrEnum):
    """Caller tolerance for reclaiming lower-priority work on a request."""

    NONE = "none"
    COORDINATED = "coordinated"
    ANY = "any"


class TriggerType(StrEnum):
    """Enum representing fundamental trigger types."""

    SCHEDULE = "schedule"
    PLATFORM_EVENT = "platform_event"
    WEBHOOK = "webhook"


class TriggerFlavor(StrEnum):
    """Enum representing trigger flavors."""

    NATIVE_SCHEDULE = "native schedule"
    PLATFORM_EVENT = "platform event"
    WEBHOOK = "webhook"


class TriggerRunConcurrency(StrEnum):
    """Enum representing trigger run concurrency."""

    SKIP = "skip"
    SUBMIT = "submit"


class ContainerEngineType(StrEnum):
    """Container engine types."""

    DOCKER = "docker"
    PODMAN = "podman"


class SourceType(StrEnum):
    """Enum representing the source type."""

    PIPELINE = "pipeline"
    PIPELINE_RUN = "pipeline_run"
    PIPELINE_SNAPSHOT = "pipeline_snapshot"


class PipelineEvent(DescribedValuesEnum):
    """Enum representing platform target events for pipelines."""

    RUN_COMPLETED = "run_completed"
    RUN_FAILED = "run_failed"

    @classmethod
    def value_description_index(cls) -> dict[str, str]:
        """Helper utility to describe enum values.

        Returns:
            An dictionary with descriptions for each enum value.
        """
        return {
            cls.RUN_COMPLETED: "A pipeline run of the source pipeline has completed successfully.",
            cls.RUN_FAILED: "A pipeline run of the source pipeline has failed.",
        }


class PipelineRunEvent(DescribedValuesEnum):
    """Enum representing platform target events for pipeline runs."""

    COMPLETED = "completed"
    FAILED = "failed"

    @classmethod
    def value_description_index(cls) -> dict[str, str]:
        """Helper utility to describe enum values.

        Returns:
            An dictionary with descriptions for each enum value.
        """
        return {
            cls.COMPLETED: "Source pipeline run completed successfully.",
            cls.FAILED: "Source pipeline run failed.",
        }


class PipelineSnapshotEvent(DescribedValuesEnum):
    """Enum representing platform target events for pipeline snapshots."""

    RUN_COMPLETED = "run_completed"
    RUN_FAILED = "run_failed"

    @classmethod
    def value_description_index(cls) -> dict[str, str]:
        """Helper utility to describe enum values.

        Returns:
            A dictionary with descriptions for each value.
        """
        return {
            cls.RUN_COMPLETED: "A pipeline run of the source snapshot has completed successfully.",
            cls.RUN_FAILED: "A pipeline run of the source snapshot has failed.",
        }


PLATFORM_EVENT_REGISTRY: dict[SourceType, type[DescribedValuesEnum]] = {
    SourceType.PIPELINE: PipelineEvent,
    SourceType.PIPELINE_RUN: PipelineRunEvent,
    SourceType.PIPELINE_SNAPSHOT: PipelineSnapshotEvent,
}
