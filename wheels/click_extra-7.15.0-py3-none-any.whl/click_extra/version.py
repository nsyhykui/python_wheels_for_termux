# Copyright Kevin Deldycke <kevin@deldycke.com> and contributors.
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
"""Gather CLI metadata and print them.

Pre-baking is inspired by `shadow-rs
<https://github.com/baoyachi/shadow-rs>`_, which injects build-time
constants (``BRANCH``, ``SHORT_COMMIT``, ``COMMIT_HASH``,
``COMMIT_DATE``, ``TAG``, ...) into Rust binaries at compile time.

.. todo::
    shadow-rs also provides constants not yet covered here:
    ``BUILD_TIME``, ``BUILD_TIME_2822``, ``BUILD_TIME_3339``,
    ``BUILD_OS``, ``BUILD_TARGET``, ``BUILD_TARGET_ARCH``. Some overlap
    with data already in ``{env_info}`` (Python version, OS,
    architecture). Others like ``BUILD_TIME`` could be added as new
    template fields.
"""

from __future__ import annotations

import ast
import importlib
import inspect
import logging
import os
import subprocess
import sys
from functools import cached_property
from gettext import gettext as _
from importlib import metadata
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # type: ignore[import-not-found]

import click
from boltons.ecoutils import get_profile
from boltons.formatutils import BaseFormatField, tokenize_format_str

from . import Style, echo, get_current_context
from .context import _LazyMetaDict
from .parameters import ExtraOption
from .theme import default_theme

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Sequence
    from types import FrameType, ModuleType
    from typing import Any

    from cloup.styling import IStyle


GIT_FIELDS: dict[str, tuple[str, ...]] = {
    "git_branch": ("rev-parse", "--abbrev-ref", "HEAD"),
    "git_long_hash": ("rev-parse", "HEAD"),
    "git_short_hash": ("rev-parse", "--short", "HEAD"),
    "git_date": ("show", "-s", "--format=%ci", "HEAD"),
    "git_tag": ("describe", "--tags", "--exact-match", "HEAD"),
}
"""Git fields that can be pre-baked, mapped to their ``git`` subcommand args.

``git_tag_sha`` is excluded because its resolution depends on
``git_tag`` (it runs ``git rev-list -1 <tag>``), so it cannot be
expressed as a static argument tuple.
"""


def run_git(*args: str, cwd: Path | None = None) -> str | None:
    """Run a ``git`` command and return its stripped output, or ``None``.

    *cwd* defaults to the current working directory when not provided.
    """
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True,
            timeout=5,
        )
        return result.stdout.strip() or None
    except (
        subprocess.CalledProcessError,
        FileNotFoundError,
        subprocess.TimeoutExpired,
    ):
        return None


def _find_dunder_str(source: str, name: str) -> ast.Constant | None:
    """Find a top-level dunder string constant in parsed source.

    Locates the first top-level ``name = "..."`` assignment and returns
    the :class:`ast.Constant` node for the string value. Returns
    ``None`` if no matching assignment is found.
    """
    tree = ast.parse(source)
    for node in ast.iter_child_nodes(tree):
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == name
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        ):
            return node.value
    return None


def _rewrite_str_literal(
    file_path: Path,
    source: str,
    node: ast.Constant,
    new_value: str,
) -> None:
    """Replace a string literal's content in a source file.

    Uses the AST node's line/column positions to swap the text between
    the opening and closing quotes, preserving quoting style and all
    surrounding content.
    """
    col_offset = node.col_offset
    end_lineno = node.end_lineno
    col_end = node.end_col_offset
    assert col_offset is not None
    assert end_lineno is not None and col_end is not None
    lines = source.splitlines(keepends=True)
    line = lines[end_lineno - 1]
    # Replace everything between the opening and closing quotes.
    new_line = line[: col_offset + 1] + new_value + line[col_end - 1 :]
    lines[end_lineno - 1] = new_line
    file_path.write_text("".join(lines), encoding="utf-8")


def prebake_version(
    file_path: Path,
    local_version: str,
) -> str | None:
    """Pre-bake a ``__version__`` string with a `PEP 440 local version
    identifier
    <https://peps.python.org/pep-0440/#local-version-identifiers>`_.

    Reads *file_path*, finds the ``__version__`` assignment via
    :mod:`ast`, and — if the version contains ``.dev`` and does not
    already contain ``+`` — appends ``+<local_version>``.

    This is the compile-time complement to the runtime
    :attr:`ExtraVersionOption.version` property: Nuitka/PyInstaller
    binaries cannot run ``git`` at runtime, so the hash must be baked
    into ``__version__`` in the source file **before** compilation.

    Returns the new version string on success, or ``None`` if no change
    was made (release version, already pre-baked, or no ``__version__``
    found).
    """
    source = file_path.read_text(encoding="utf-8")
    node = _find_dunder_str(source, "__version__")
    if node is None:
        logging.warning("No __version__ found in %s", file_path)
        return None

    version = node.value
    assert isinstance(version, str)

    if ".dev" not in version:
        logging.info(
            "Release version %r in %s — skipping.",
            version,
            file_path,
        )
        return None

    if "+" in version:
        logging.info(
            "Version %r in %s already has a local identifier — skipping.",
            version,
            file_path,
        )
        return None

    new_version = f"{version}+{local_version}"
    _rewrite_str_literal(file_path, source, node, new_version)

    logging.info(
        "Pre-baked %s: %r → %r",
        file_path,
        version,
        new_version,
    )
    return new_version


def prebake_dunder(
    file_path: Path,
    name: str,
    value: str,
) -> str | None:
    """Replace an empty dunder variable's value in a Python source file.

    Reads *file_path*, finds a top-level ``name = ""`` assignment via
    :mod:`ast`, and — if the current value is an empty string — replaces
    it with *value*.

    Placeholders must use empty strings (``__field__ = ""``, not
    ``None``). The AST matcher only recognizes string literals, and
    the empty string serves as a falsy sentinel that stays
    type-consistent with baked values (always ``str``).

    This is the generic counterpart to :func:`prebake_version`: where
    ``prebake_version`` appends a PEP 440 local identifier to
    ``__version__``, this function does a full replacement of any dunder
    variable that starts empty. Typical use case: injecting a release
    commit SHA into ``__git_tag_sha__ = ""`` at build time.

    Returns the new value on success, or ``None`` if no change was made
    (variable not found, or already has a non-empty value).
    """
    source = file_path.read_text(encoding="utf-8")
    node = _find_dunder_str(source, name)
    if node is None:
        logging.warning("No %s found in %s", name, file_path)
        return None

    current = node.value

    if current:
        logging.info(
            "%s in %s already has value %r — skipping.",
            name,
            file_path,
            current,
        )
        return None

    _rewrite_str_literal(file_path, source, node, value)

    logging.info(
        "Pre-baked %s in %s: %r → %r",
        name,
        file_path,
        current,
        value,
    )
    return value


def discover_package_init_files() -> list[Path]:
    """Discover ``__init__.py`` files from ``[project.scripts]``.

    Reads the ``pyproject.toml`` in the current working directory,
    extracts ``[project.scripts]`` entry points, and returns the
    unique ``__init__.py`` paths for each top-level package.

    Only returns paths that exist on disk. Returns an empty list if
    ``pyproject.toml`` is missing or has no ``[project.scripts]``.
    """
    pyproject_path = Path("pyproject.toml")
    if not pyproject_path.exists():
        logging.warning("No pyproject.toml found in current directory.")
        return []

    data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    scripts = data.get("project", {}).get("scripts", {})
    if not scripts:
        logging.warning("No [project.scripts] entries found in pyproject.toml.")
        return []

    seen: set[Path] = set()
    paths: list[Path] = []
    for script in scripts.values():
        # "repomatic.__main__:main" → "repomatic".
        module_id = script.split(":")[0]
        package_dir = module_id.split(".")[0]
        init_path = Path(package_dir) / "__init__.py"
        if init_path in seen:
            continue
        seen.add(init_path)
        if init_path.exists():
            paths.append(init_path)
        else:
            logging.warning("Package init not found: %s", init_path)
    return paths


class ExtraVersionOption(ExtraOption):
    """Gather CLI metadata and prints a colored version string.

    .. note::
        This started as a `copy of the standard @click.version_option() decorator
        <https://github.com/pallets/click/blob/cdab890/src/click/decorators.py#L421-L524>`_,
        but is **no longer a drop-in replacement**. Hence the ``Extra`` prefix.

        This address the following Click issues:

        - `click#2324 <https://github.com/pallets/click/issues/2324>`_,
          to allow its use with the declarative ``params=`` argument.

        - `click#2331 <https://github.com/pallets/click/issues/2331>`_,
          by distinguishing the module from the package.

        - `click#1756 <https://github.com/pallets/click/issues/1756>`_,
          by allowing path and Python version.
    """

    message: str = _("{prog_name}, version {version}")
    """Default message template used to render the version string."""

    template_fields: tuple[str, ...] = (
        "module",
        "module_name",
        "module_file",
        "module_version",
        "package_name",
        "package_version",
        "exec_name",
        "version",
        "git_repo_path",
        "git_branch",
        "git_long_hash",
        "git_short_hash",
        "git_date",
        "git_tag",
        "git_tag_sha",
        "prog_name",
        "env_info",
    )
    """List of field IDs recognized by the message template."""

    def __init__(
        self,
        param_decls: Sequence[str] | None = None,
        message: str | None = None,
        # Field value overrides.
        module: str | None = None,
        module_name: str | None = None,
        module_file: str | None = None,
        module_version: str | None = None,
        package_name: str | None = None,
        package_version: str | None = None,
        exec_name: str | None = None,
        version: str | None = None,
        git_repo_path: str | None = None,
        git_branch: str | None = None,
        git_long_hash: str | None = None,
        git_short_hash: str | None = None,
        git_date: str | None = None,
        git_tag: str | None = None,
        git_tag_sha: str | None = None,
        prog_name: str | None = None,
        env_info: dict[str, str] | None = None,
        # Field style overrides.
        message_style: IStyle | None = None,
        module_style: IStyle | None = None,
        module_name_style: IStyle | None = default_theme.invoked_command,
        module_file_style: IStyle | None = None,
        module_version_style: IStyle | None = Style(fg="green"),
        package_name_style: IStyle | None = default_theme.invoked_command,
        package_version_style: IStyle | None = Style(fg="green"),
        exec_name_style: IStyle | None = default_theme.invoked_command,
        version_style: IStyle | None = Style(fg="green"),
        git_repo_path_style: IStyle | None = Style(fg="bright_black"),
        git_branch_style: IStyle | None = Style(fg="cyan"),
        git_long_hash_style: IStyle | None = Style(fg="yellow"),
        git_short_hash_style: IStyle | None = Style(fg="yellow"),
        git_date_style: IStyle | None = Style(fg="bright_black"),
        git_tag_style: IStyle | None = Style(fg="cyan"),
        git_tag_sha_style: IStyle | None = Style(fg="yellow"),
        prog_name_style: IStyle | None = default_theme.invoked_command,
        env_info_style: IStyle | None = Style(fg="bright_black"),
        is_flag=True,
        expose_value=False,
        is_eager=True,
        help=_("Show the version and exit."),
        **kwargs,
    ) -> None:
        """Preconfigured as a ``--version`` option flag.

        :param message: the message template to print, in `format string syntax
            <https://docs.python.org/3/library/string.html#format-string-syntax>`_.
            Defaults to ``{prog_name}, version {version}``.

        :param module: forces the value of ``{module}``.
        :param module_name: forces the value of ``{module_name}``.
        :param module_file: forces the value of ``{module_file}``.
        :param module_version: forces the value of ``{module_version}``.
        :param package_name: forces the value of ``{package_name}``.
        :param package_version: forces the value of ``{package_version}``.
        :param exec_name: forces the value of ``{exec_name}``.
        :param version: forces the value of ``{version}``.
        :param git_repo_path: forces the value of ``{git_repo_path}``.
        :param git_branch: forces the value of ``{git_branch}``.
        :param git_long_hash: forces the value of ``{git_long_hash}``.
        :param git_short_hash: forces the value of ``{git_short_hash}``.
        :param git_date: forces the value of ``{git_date}``.
        :param git_tag: forces the value of ``{git_tag}``.
        :param git_tag_sha: forces the value of ``{git_tag_sha}``.
        :param prog_name: forces the value of ``{prog_name}``.
        :param env_info: forces the value of ``{env_info}``.

        :param message_style: default style of the message.

        :param module_style: style of ``{module}``.
        :param module_name_style: style of ``{module_name}``.
        :param module_file_style: style of ``{module_file}``.
        :param module_version_style: style of ``{module_version}``.
        :param package_name_style: style of ``{package_name}``.
        :param package_version_style: style of ``{package_version}``.
        :param exec_name_style: style of ``{exec_name}``.
        :param version_style: style of ``{version}``.
        :param git_repo_path_style: style of ``{git_repo_path}``.
        :param git_branch_style: style of ``{git_branch}``.
        :param git_long_hash_style: style of ``{git_long_hash}``.
        :param git_short_hash_style: style of ``{git_short_hash}``.
        :param git_date_style: style of ``{git_date}``.
        :param git_tag_style: style of ``{git_tag}``.
        :param git_tag_sha_style: style of ``{git_tag_sha}``.
        :param prog_name_style: style of ``{prog_name}``.
        :param env_info_style: style of ``{env_info}``.
        """
        if not param_decls:
            param_decls = ("--version",)

        if message is not None:
            self.message = message

        self.message_style = message_style

        # Overrides default field's value and style with user-provided parameters.
        for field_id in self.template_fields:
            # Override field value.
            user_value = locals().get(field_id)
            if user_value is not None:
                setattr(self, field_id, user_value)

            # Set field style.
            style_id = f"{field_id}_style"
            setattr(self, style_id, locals()[style_id])

        kwargs.setdefault("callback", self.print_and_exit)

        super().__init__(
            param_decls=param_decls,
            is_flag=is_flag,
            expose_value=expose_value,
            is_eager=is_eager,
            help=help,
            **kwargs,
        )

    @staticmethod
    def cli_frame() -> FrameType:
        """Returns the frame in which the CLI is implemented.

        Inspects the execution stack frames to find the package in which the user's CLI
        is implemented.

        Returns the frame itself.
        """
        # Keep a list of all frames inspected for debugging.
        frame_chain: list[tuple[str | None, str]] = []

        candidate: FrameType | None = None

        # Walk the execution stack from bottom to top.
        for frame_info in inspect.stack():
            frame = frame_info.frame

            # Get the current package name from the frame's globals.
            frame_name = frame.f_globals.get("__name__")

            # Get the current function name.
            func_name = frame_info.function

            # Keep track of the inspected frames.
            frame_chain.append((frame_name, func_name))

            # Stop at the invoke() function of any CliRunner class, which is used for
            # testing.
            if func_name == "invoke" and isinstance(
                frame.f_locals.get("self"),
                click.testing.CliRunner,
            ):
                # Because click_extra.testing.ExtraCliRunner inherits from
                # click.testing.CliRunner, we'd like to keep looking for candidate as
                # long as the frame is an invoke() function of a CliRunner class.
                candidate = frame
                continue

            # We found the top-most frame that is an invoke() function.
            if candidate:
                return candidate

            # Skip the intermediate frames added by the `@cached_property` decorator
            # and the Click ecosystem.
            if frame_name and frame_name.split(".", 1)[0] in (
                "functools",
                "click_extra",
                "cloup",
                "click",
            ):
                continue

            # We found a frame that is not part of the Click ecosystem, and is not an
            # intermediate frame added by a decorator. We assume this is the frame in
            # which the user's CLI is implemented.
            return frame

        # Our heuristics to locate the CLI implementation failed. Fall back to
        # the outermost frame in the stack. This happens in Nuitka-compiled
        # binaries where the entry point module's ``__name__`` may be a
        # submodule of the Click ecosystem package (e.g.
        # ``click_extra.__main__``) and all frames get skipped.
        logger = logging.getLogger("click_extra")
        count_size = len(str(len(frame_chain)))
        for counter, (p_name, f_name) in enumerate(frame_chain):
            logger.debug(f"Frame {counter:<{count_size}} # {p_name}:{f_name}")

        # The outermost frame is the last one returned by inspect.stack().
        outermost = inspect.stack()[-1].frame
        logger.debug(
            "cli_frame heuristics exhausted, falling back to outermost frame: "
            f"{outermost.f_globals.get('__name__')}:{outermost.f_code.co_name}"
        )
        return outermost

    @cached_property
    def module(self) -> ModuleType:
        """Returns the module in which the CLI resides."""
        frame = self.cli_frame()

        module = inspect.getmodule(frame)
        if not module:
            raise RuntimeError(f"Cannot find module of {frame!r}")

        # If the module is a generated entry point script (e.g., .venv/bin/cli-name),
        # try to find the actual CLI module.
        if module.__name__ == "__main__" and not module.__package__:
            module_file = getattr(module, "__file__", None)
            if module_file:
                module_path = Path(module_file)
                # Entry points are typically in bin/ or Scripts/ directories
                if module_path.parent.name in ("bin", "Scripts"):
                    script_name = module_path.name

                    # Try to find the package via entry_points API
                    actual_module = self._resolve_entry_point_module(script_name)
                    if actual_module:
                        return actual_module

                    # Fallback: inspect frame globals for imported callables
                    actual_module = self._resolve_module_from_frame(frame)
                    if actual_module:
                        return actual_module

        return module

    @staticmethod
    def _resolve_entry_point_module(script_name: str) -> ModuleType | None:
        """Resolve the module from a console_scripts entry point name."""
        # Search through all entry points in the 'console_scripts' group.
        eps = metadata.entry_points()

        console_scripts = eps.select(group="console_scripts")

        for ep in console_scripts:
            if ep.name == script_name:
                # ep.value is like "click_extra.__main__:main".
                module_name = ep.value.split(":")[0]
                if module_name in sys.modules:
                    return sys.modules[module_name]
                return importlib.import_module(module_name)

        return None

    @staticmethod
    def _resolve_module_from_frame(frame: FrameType) -> ModuleType | None:
        """Fallback: find module from callables in frame's globals."""
        for obj in frame.f_globals.values():
            if callable(obj) and hasattr(obj, "__module__"):
                actual_module_name = obj.__module__
                if actual_module_name in sys.modules:
                    actual_module = sys.modules[actual_module_name]
                    if getattr(actual_module, "__package__", None):
                        return actual_module
        return None

    @cached_property
    def module_name(self) -> str:
        """Returns the full module name or ``__main__`."""
        return self.module.__name__

    @cached_property
    def module_file(self) -> str | None:
        """Returns the module's file full path."""
        return self.module.__file__

    @cached_property
    def module_version(self) -> str | None:
        """Returns the string found in the local ``__version__`` variable.

        .. hint::
            ``__version__`` is an old pattern from early Python packaging. It is not a
            standard variable and is not defined in the packaging PEPs.

            You should prefer using the ``package_version`` property below instead,
            which uses the standard library `importlib.metadata` API.

            We're still supporting it for backward compatibility with existing
            codebases, as `Click removed it in version 8.2.0
            <https://github.com/pallets/click/issues/2598>`_.
        """
        # First, try to get __version__ from the detected module.
        version = getattr(self.module, "__version__", None)

        # If not found, try to get it from the command's callback globals.
        # This handles cases where the command is defined in a different context
        # (e.g., Sphinx documentation blocks, or standalone scripts).
        if version is None:
            ctx = get_current_context(silent=True)
            if ctx and ctx.command and hasattr(ctx.command, "callback"):
                callback = ctx.command.callback
                if callback is not None:
                    # Get the callback's globals (where __version__ might be defined).
                    callback_globals = getattr(callback, "__globals__", {})
                    version = callback_globals.get("__version__")

        # If still not found, check the parent package. This handles
        # ``__main__`` entry points where ``__version__`` is defined in
        # the package's ``__init__.py`` (e.g. Nuitka-compiled binaries).
        # Skip modules belonging to the Click ecosystem because
        # ``cli_frame()`` may resolve to a CliRunner frame instead of
        # the user's module, producing false-positive lookups. ``__main__``
        # modules are always entry points (never CliRunner artifacts), so
        # they are exempt from the exclusion.
        is_main_entry = self.module_name == "__main__" or self.module_name.endswith(
            ".__main__"
        )
        if (
            version is None
            and self.package_name
            and (
                is_main_entry
                or self.module_name.split(".")[0]
                not in ("click", "click_extra", "cloup")
            )
        ):
            parent = sys.modules.get(self.package_name)
            if parent:
                version = getattr(parent, "__version__", None)

        if version is not None and not isinstance(version, str):
            raise ValueError(
                f"Module version {version!r} expected to be a string or None."
            )
        return version

    @cached_property
    def package_name(self) -> str | None:
        """Returns the package name."""
        return self.module.__package__

    @cached_property
    def package_version(self) -> str | None:
        """Returns the package version if installed."""
        logger = logging.getLogger("click_extra")

        if not self.package_name:
            logger.debug("Cannot guess version from package: no package name provided.")
            return None

        try:
            version = metadata.version(self.package_name)
        except metadata.PackageNotFoundError:
            logger.debug(
                f"Cannot get version: {self.package_name!r} package not found or not "
                "installed."
            )
            return None

        return version

    @cached_property
    def exec_name(self) -> str:
        """User-friendly name of the executed CLI.

        Returns the module name. But if the later is ``__main__``, returns the package
        name.

        If not packaged, the CLI is assumed to be a simple standalone script, and the
        returned name is the script's file name (including its extension).
        """
        # The CLI has its own module.
        if self.module_name != "__main__":
            return self.module_name

        # The CLI module is a `__main__` entry-point, so returns its package name.
        if self.package_name:
            return self.package_name

        # The CLI is not packaged: it is a standalone script. Fallback to its
        # filename.
        if self.module_file:
            return os.path.basename(self.module_file)

        raise RuntimeError(
            "Could not determine the user-friendly name of the CLI from the frame "
            "stack."
        )

    @cached_property
    def version(self) -> str | None:
        """Return the version of the CLI.

        Returns the module version if a ``__version__`` variable is set alongside the
        CLI in its module.

        Else returns the package version if the CLI is implemented in a package, using
        `importlib.metadata.version()
        <https://docs.python.org/3/library/importlib.metadata.html?highlight=metadata#distribution-versions>`_.

        For development versions (containing ``.dev``), automatically appends the Git
        short hash as a `PEP 440 local version identifier
        <https://peps.python.org/pep-0440/#local-version-identifiers>`_, producing
        versions like ``1.2.3.dev0+abc1234``. This helps identify the exact commit a
        dev build was produced from. If Git is unavailable, the plain dev version is
        returned.

        Versions that already contain a ``+`` (i.e., a pre-baked local version
        identifier, typically set at build time by CI pipelines) are returned as-is
        to avoid producing invalid double-suffixed versions like
        ``1.2.3.dev0+abc1234+xyz5678``.
        """
        ver = self.module_version or self.package_version
        if ver and ".dev" in ver and "+" not in ver:
            git_hash = self.git_short_hash
            if git_hash:
                return f"{ver}+{git_hash}"
        return ver or None

    @cached_property
    def git_repo_path(self) -> Path | None:
        """Find the Git repository root directory."""
        if self.module_file:
            # Start from the module's directory.
            current_path = Path(self.module_file).parent
        else:
            # Fallback to current working directory.
            current_path = Path.cwd()

        # Walk up the directory tree to find .git.
        for path in [current_path] + list(current_path.parents):
            if (path / ".git").exists():
                return path

        return None

    def _run_git_command(self, *args: str) -> str | None:
        """Run a ``git`` command and return its output, or ``None``."""
        if not self.git_repo_path:
            return None
        return run_git(*args, cwd=self.git_repo_path)

    def _get_prebaked(self, field_id: str) -> str | None:
        """Check the CLI module for a pre-baked ``__<field_id>__`` dunder.

        Returns the dunder's value if it is a non-empty string, otherwise
        ``None``.
        """
        dunder_name = f"__{field_id}__"
        value = getattr(self.module, dunder_name, None)
        if value and isinstance(value, str):
            return value  # type: ignore[no-any-return]
        return None

    @cached_property
    def git_branch(self) -> str | None:
        """Returns the current Git branch name.

        Checks for a pre-baked ``__git_branch__`` dunder first, then
        falls back to ``git rev-parse --abbrev-ref HEAD``.
        """
        return self._get_prebaked("git_branch") or self._run_git_command(
            *GIT_FIELDS["git_branch"]
        )

    @cached_property
    def git_long_hash(self) -> str | None:
        """Returns the full Git commit hash.

        Checks for a pre-baked ``__git_long_hash__`` dunder first, then
        falls back to ``git rev-parse HEAD``.
        """
        return self._get_prebaked("git_long_hash") or self._run_git_command(
            *GIT_FIELDS["git_long_hash"]
        )

    @cached_property
    def git_short_hash(self) -> str | None:
        """Returns the short Git commit hash.

        Checks for a pre-baked ``__git_short_hash__`` dunder first, then
        falls back to ``git rev-parse --short HEAD``.

        .. hint::
            The short hash is usually the first 7 characters of the full hash, but this
            is not guaranteed to be the case.

            But it is at least guaranteed to be unique within the repository, and
            a `minimum of 4 characters
            <https://git-scm.com/docs/git-config#Documentation/git-config.txt-coreabbrev>`_.
        """
        return self._get_prebaked("git_short_hash") or self._run_git_command(
            *GIT_FIELDS["git_short_hash"]
        )

    @cached_property
    def git_date(self) -> str | None:
        """Returns the commit date in ISO format: ``YYYY-MM-DD HH:MM:SS +ZZZZ``.

        Checks for a pre-baked ``__git_date__`` dunder first, then
        falls back to ``git show -s --format=%ci HEAD``.
        """
        return self._get_prebaked("git_date") or self._run_git_command(
            *GIT_FIELDS["git_date"]
        )

    @cached_property
    def git_tag(self) -> str | None:
        """Returns the Git tag pointing at HEAD, if any.

        Checks for a pre-baked ``__git_tag__`` dunder first, then
        falls back to ``git describe --tags --exact-match HEAD``.

        Returns ``None`` if HEAD is not at a tagged commit.
        """
        return self._get_prebaked("git_tag") or self._run_git_command(
            *GIT_FIELDS["git_tag"]
        )

    @cached_property
    def git_tag_sha(self) -> str | None:
        """Returns the commit SHA that the current tag points at.

        Checks for a pre-baked ``__git_tag_sha__`` dunder first, then
        falls back to ``git rev-list -1`` on the tag returned by
        :attr:`git_tag`. Returns ``None`` if HEAD is not at a tag.
        """
        prebaked = self._get_prebaked("git_tag_sha")
        if prebaked:
            return prebaked
        tag = self.git_tag
        if tag:
            return self._run_git_command("rev-list", "-1", tag)
        return None

    @cached_property
    def prog_name(self) -> str | None:
        """Return the name of the CLI, from Click's point of view.

        Get the `info_name
        <https://click.palletsprojects.com/en/stable/api/#click.Context.info_name>`_ of
        the `root
        <https://click.palletsprojects.com/en/stable/api/#click.Context.find_root>`_
        command.
        """
        return get_current_context().find_root().info_name

    @cached_property
    def env_info(self) -> dict[str, Any]:
        """Various environment info.

        Returns the data produced by `boltons.ecoutils.get_profile()
        <https://boltons.readthedocs.io/en/latest/ecoutils.html#boltons.ecoutils.get_profile>`_.
        """
        return get_profile(scrub=True)

    def colored_template(self, template: str | None = None) -> str:
        """Insert ANSI styles to a message template.

        Accepts a custom ``template`` as parameter, otherwise uses the default message
        defined on the Option instance.

        This step is necessary because we need to linearize the template to apply the
        ANSI codes on the string segments. This is a consequence of the nature of ANSI,
        directives which cannot be encapsulated within another (unlike markup tags
        like HTML).
        """
        if template is None:
            template = self.message

        # Normalize the default to a no-op Style() callable to simplify the code
        # of the colorization step.
        def noop(s: str) -> str:
            return s

        default_style = self.message_style if self.message_style else noop

        # Associate each field with its own style.
        field_styles = {}
        for field_id in self.template_fields:
            field_style = getattr(self, f"{field_id}_style")
            # If no style is defined for this field, use the default style of the
            # message.
            if not field_style:
                field_style = default_style
            field_styles[field_id] = field_style

        # Split the template semantically between fields and literals.
        segments = tokenize_format_str(template, resolve_pos=False)

        # A copy of the template, where literals and fields segments are colored.
        colored_template = ""

        # Apply styles to field and literal segments.
        literal_accu = ""
        for i, segment in enumerate(segments):
            # Is the segment a format field?
            is_field = isinstance(segment, BaseFormatField)
            # If not, keep accumulating literal strings until the next field.
            if not is_field:
                # Re-escape literal curly braces to avoid messing up the format.
                literal_accu += segment.replace(  # type: ignore[union-attr]
                    "{", "{{"
                ).replace("}", "}}")

            # Dump the accumulated literals before processing the field, or at the end
            # of the template.
            is_last_segment = i + 1 == len(segments)
            if (is_field or is_last_segment) and literal_accu:
                # Colorize literals with the default style.
                colored_template += default_style(literal_accu)
                # Reset the accumulator.
                literal_accu = ""

            # Add the field to the template copy, colored with its own style.
            if is_field:
                colored_template += field_styles[
                    segment.base_name  # type: ignore[union-attr]
                ](str(segment))

        return colored_template

    def render_message(self, template: str | None = None) -> str:
        """Render the version string from the provided template.

        Accepts a custom ``template`` as parameter, otherwise uses the default
        ``self.colored_template()`` produced by the instance.
        """
        if template is None:
            template = self.colored_template()

        # Only resolve fields that actually appear in the template, so unused
        # properties (git calls, env_info, etc.) are never evaluated.
        used_fields = {
            seg.base_name
            for seg in tokenize_format_str(template, resolve_pos=False)
            if isinstance(seg, BaseFormatField)
        }
        return template.format(**{v: getattr(self, v) for v in used_fields})

    def print_debug_message(self) -> None:
        """Render in debug logs all template fields in color.

        .. todo::
            Pretty print JSON output (easier to read in bug reports)?
        """
        logger = logging.getLogger("click_extra")
        if logger.getEffectiveLevel() == logging.DEBUG:
            all_fields = {
                f"{{{{{field_id}}}}}": f"{{{field_id}}}"
                for field_id in self.template_fields
            }
            max_len = max(map(len, all_fields))
            raw_format = "\n".join(
                f"{k:<{max_len}}: {v}" for k, v in all_fields.items()
            )
            msg = self.render_message(self.colored_template(raw_format))
            logger.debug("Version string template variables:")
            for line in msg.splitlines():
                logger.debug(line)

    def print_and_exit(
        self,
        ctx: click.Context,
        param: click.Parameter,
        value: bool,
    ) -> None:
        """Print the version string and exits.

        Also stores all version string elements in the Context's ``meta`` `dict`.
        """
        # Install a lazy dict so that version fields in ctx.meta are only
        # evaluated when actually accessed, avoiding unnecessary git calls,
        # environment profiling, and stack inspection on every invocation.
        ctx._meta = _LazyMetaDict(ctx._meta, self, self.template_fields)

        # Eagerly resolve ``module`` now: cli_frame() relies on stack
        # inspection that only produces the correct result during the eager
        # callback. Once cached, all dependent properties (module_name,
        # package_name, etc.) will use this cached value regardless of when
        # they are accessed.
        self.module  # noqa: B018

        # Always log all template fields at DEBUG level, even if --version is
        # not called. This provides valuable execution context in bug reports.
        # The debug check inside the method ensures fields are only resolved
        # (and thus the lazy dict entries materialized) when DEBUG is active.
        self.print_debug_message()

        if not value or ctx.resilient_parsing:
            # Do not print the version and continue normal CLI execution.
            return

        echo(self.render_message(), color=ctx.color)
        ctx.exit()
