from __future__ import annotations

import dis
import inspect
import itertools
import opcode as _opcode
import sys
import types
from typing import (
    Any,
    Dict,
    Iterable,
    Iterator,
    List,
    MutableSequence,
    Optional,
    Sequence,
    Set,
    Tuple,
    Type,
    TypeVar,
    Union,
    cast,
)

# alias to keep the 'bytecode' variable free
import bytecode as _bytecode
from bytecode.flags import CompilerFlags
from bytecode.instr import (
    _UNSET,
    BINARY_OPS,
    BITFLAG2_OPCODES,
    BITFLAG_OPCODES,
    CACHE_OPCODE,
    COMMON_CONSTANT_OPS,
    DUAL_ARG_OPCODES,
    DUAL_ARG_OPCODES_SINGLE_OPS,
    EXTENDEDARG_OPCODE,
    FORMAT_VALUE_OPS,
    HAS_JUMP,
    INTRINSIC,
    INTRINSIC_1OP,
    INTRINSIC_2OP,
    NOP_OPCODE,
    PLACEHOLDER_LABEL,
    SPECIAL_OPS,
    UNSET,
    BaseInstr,
    BinaryOp,
    CellVar,
    CommonConstant,
    Compare,
    FormatValue,
    FreeVar,
    Instr,
    InstrArg,
    InstrLocation,
    Intrinsic1Op,
    Intrinsic2Op,
    Label,
    SetLineno,
    SpecialMethod,
    TryBegin,
    TryEnd,
    _check_arg_int,
    const_key,
    opcode_has_argument,
)
from bytecode.utils import PY312, PY313

HAS_CONST = set(_opcode.hasconst)
HAS_LOCAL = set(_opcode.haslocal)
HAS_NAME = set(_opcode.hasname)
HAS_FREE = set(_opcode.hasfree)
HAS_COMPARE = set(_opcode.hascompare)


def _set_docstring(code: _bytecode.BaseBytecode, consts: Sequence) -> None:
    if not consts:
        return
    first_const = consts[0]
    if isinstance(first_const, str) or first_const is None:
        code.docstring = first_const


T = TypeVar("T", bound="ConcreteInstr")


class ConcreteInstr(BaseInstr[int]):
    """Concrete instruction.

    arg must be an integer in the range 0..2147483647.

    It has a read-only size attribute.

    """

    # For ConcreteInstr the argument is always an integer
    _arg: int

    __slots__ = ("_extended_args", "_size")

    def __init__(
        self,
        name: str,
        arg: int = UNSET,
        *,
        lineno: Union[int, _UNSET, None] = UNSET,
        location: Optional[InstrLocation] = None,
        extended_args: Optional[int] = None,
    ):
        # Allow to remember a potentially meaningless EXTENDED_ARG emitted by
        # Python to properly compute the size and avoid messing up the jump
        # targets
        self._extended_args = extended_args
        super().__init__(name, arg, lineno=lineno, location=location)

    def _check_arg(self, name: str, opcode: int, arg: int) -> None:
        if opcode_has_argument(opcode):
            if arg is UNSET:
                raise ValueError("operation %s requires an argument" % name)

            _check_arg_int(arg, name)
        # opcode == 0 corresponds to CACHE instruction in 3.11+ and was unused before
        elif opcode == 0:
            arg = arg if arg is not UNSET else 0
            _check_arg_int(arg, name)
        else:
            if arg is not UNSET:
                raise ValueError("operation %s has no argument" % name)

    def _set(
        self,
        name: str,
        arg: int,
    ) -> None:
        super()._set(name, arg)
        size = 2
        if arg is not UNSET:
            while arg > 0xFF:
                size += 2
                arg >>= 8
        if self._extended_args is not None:
            size = 2 + 2 * self._extended_args
        self._size = size

    @property
    def size(self) -> int:
        return self._size

    def _cmp_key(self) -> Tuple[Optional[InstrLocation], str, int]:
        return (self._location, self._name, self._arg)

    def get_jump_target(self, instr_offset: int) -> Optional[int]:
        # When a jump arg is zero the jump always points to the first non-CACHE
        # opcode following the jump. The passed in offset is the offset at
        # which the jump opcode starts. So to compute the target, we add to it
        # the instruction size (accounting for extended args) and the
        # number of caches expected to follow the jump instruction.
        s = (self._size // 2) + self.use_cache_opcodes()
        if self.is_forward_rel_jump():
            return instr_offset + s + self._arg
        if self.is_backward_rel_jump():
            return instr_offset + s - self._arg
        if self.is_abs_jump():
            return self._arg
        return None

    def assemble(self) -> bytes:
        if self._arg is UNSET:
            return bytes((self._opcode, 0))

        arg = self._arg
        b = [self._opcode, arg & 0xFF]
        while arg > 0xFF:
            arg >>= 8
            b[:0] = [_opcode.EXTENDED_ARG, arg & 0xFF]

        if self._extended_args:
            while len(b) < self._size:
                b[:0] = [_opcode.EXTENDED_ARG, 0x00]

        return bytes(b)

    @classmethod
    def _from_opcode(
        cls: Type[T],
        name: str,
        opcode: int,
        arg: int,
        location: Optional[InstrLocation],
    ) -> T:
        """Fast path for from_code: arg is a raw byte (0-255), size is always 2."""
        new = object.__new__(cls)
        new._name = name
        new._opcode = opcode
        new._is_jump = opcode in HAS_JUMP
        new._arg = arg
        new._location = location
        new._extended_args = None
        new._size = 2
        return new

    @classmethod
    def _from_trusted(
        cls: Type[T],
        name: str,
        opcode: int,
        arg: int,
        location: Optional[InstrLocation],
    ) -> T:
        """Fast path for concrete_instructions: skip validation, compute size from arg."""
        new = object.__new__(cls)
        new._name = name
        new._opcode = opcode
        new._is_jump = opcode in HAS_JUMP
        new._arg = arg
        new._location = location
        new._extended_args = None
        size = 2
        if arg is not UNSET:
            _arg = arg
            while _arg > 0xFF:
                size += 2
                _arg >>= 8
        new._size = size
        return new

    @classmethod
    def disassemble(cls: Type[T], lineno: Optional[int], code: bytes, offset: int) -> T:
        index = 2 * offset
        op = code[index]
        if opcode_has_argument(op):
            arg = code[index + 1]
        else:
            arg = UNSET
        name = _opcode.opname[op]
        return cls(name, arg, lineno=lineno)

    def use_cache_opcodes(self) -> int:
        if PY313:
            return (
                dis._inline_cache_entries[self._name]  # type: ignore[attr-defined]
                if self._name in dis._inline_cache_entries  # type: ignore[attr-defined]
                else 0
            )
        else:
            return dis._inline_cache_entries[self._opcode]  # type: ignore


class ExceptionTableEntry:
    """Entry for a given line in the exception table.

    All offset are expressed in instructions not in bytes.

    """

    #: Offset in instruction between the beginning of the bytecode and the beginning
    #: of this entry.
    start_offset: int

    #: Offset in instruction between the beginning of the bytecode and the end
    #: of this entry. This offset is inclusive meaning that the instruction it points
    #: to is included in the try/except handling.
    stop_offset: int

    #: Offset in instruction to the first instruction of the exception handling block.
    target: int

    #: Minimal stack depth in the block delineated by start and stop
    #: offset of the exception table entry. Used to restore the stack (by
    #: popping items) when entering the exception handling block.
    stack_depth: int

    #: Should the offset, at which an exception was raised, be pushed on the stack
    #: before the exception itself (which is pushed as a single value)).
    push_lasti: bool

    __slots__ = ("push_lasti", "stack_depth", "start_offset", "stop_offset", "target")

    def __init__(
        self,
        start_offset: int,
        stop_offset: int,
        target: int,
        stack_depth: int,
        push_lasti: bool,
    ) -> None:
        self.start_offset = start_offset
        self.stop_offset = stop_offset
        self.target = target
        self.stack_depth = stack_depth
        self.push_lasti = push_lasti

    def __repr__(self) -> str:
        return (
            "ExceptionTableEntry("
            f"start_offset={self.start_offset}, "
            f"stop_offset={self.stop_offset}, "
            f"target={self.target}, "
            f"stack_depth={self.stack_depth}, "
            f"push_lasti={self.push_lasti}"
        )


class ConcreteBytecode(_bytecode._BaseBytecodeList[Union[ConcreteInstr, SetLineno]]):
    #: List of "constant" objects for the bytecode
    consts: List

    #: List of names used by local variables.
    names: List[str]

    #: List of names used by input variables.
    varnames: List[str]

    #: Table describing portion of the bytecode in which exceptions are caught and
    #: where there are handled.
    #: Used only in Python 3.11+
    exception_table: List[ExceptionTableEntry]

    def __init__(
        self,
        instructions=(),
        *,
        consts: tuple = (),
        names: Tuple[str, ...] = (),
        varnames: Iterable[str] = (),
        exception_table: Optional[List[ExceptionTableEntry]] = None,
    ):
        super().__init__()
        self.consts = list(consts)
        self.names = list(names)
        self.varnames = list(varnames)
        self.exception_table = exception_table or []
        self.extend(instructions)

    def _check_instr(self, instr: Any) -> None:
        if not isinstance(instr, (ConcreteInstr, SetLineno)):
            raise ValueError(
                "ConcreteBytecode must only contain "
                "ConcreteInstr and SetLineno objects, "
                "but %s was found" % type(instr).__name__
            )

    def _copy_attr_from(self, bytecode):
        super()._copy_attr_from(bytecode)
        if isinstance(bytecode, ConcreteBytecode):
            self.consts = bytecode.consts
            self.names = bytecode.names
            self.varnames = bytecode.varnames

    def __repr__(self) -> str:
        return "<ConcreteBytecode instr#=%s>" % len(self)

    def __eq__(self, other: Any) -> bool:
        if type(self) is not type(other):
            return False

        const_keys1 = list(map(const_key, self.consts))
        const_keys2 = list(map(const_key, other.consts))
        if const_keys1 != const_keys2:
            return False

        if self.names != other.names:
            return False
        if self.varnames != other.varnames:
            return False

        return super().__eq__(other)

    @staticmethod
    def from_code(
        code: types.CodeType, *, extended_arg: bool = False
    ) -> ConcreteBytecode:
        instructions: MutableSequence[Union[SetLineno, ConcreteInstr]] = []
        bc = code.co_code
        opname = _opcode.opname
        # co_positions() yields one (lineno, end_lineno, col_offset,
        # end_col_offset) per instruction word (including CACHE entries),
        # available from Python 3.11+. CACHE entries are already inline in
        # co_code on all supported versions, so iterating co_code directly
        # handles all versions without dis overhead.
        pos_iter: Iterator[
            Tuple[Optional[int], Optional[int], Optional[int], Optional[int]]
        ] = iter(code.co_positions())
        _last_pos: Optional[
            Tuple[Optional[int], Optional[int], Optional[int], Optional[int]]
        ] = None
        _last_loc: Optional[InstrLocation] = None
        for offset in range(0, len(bc), 2):
            op = bc[offset]
            arg = bc[offset + 1] if opcode_has_argument(op) else UNSET
            pos = next(pos_iter, None)
            if pos == _last_pos:
                loc: Optional[InstrLocation] = _last_loc
            else:
                loc = InstrLocation._from_tuple(*pos) if pos is not None else None
                _last_pos = pos
                _last_loc = loc
            instructions.append(ConcreteInstr._from_opcode(opname[op], op, arg, loc))

        bytecode = ConcreteBytecode()

        # HINT : in some cases Python generate useless EXTENDED_ARG opcode
        # with a value of zero. Such opcodes do not increases the size of the
        # following opcode the way a normal EXTENDED_ARG does. As a
        # consequence, they need to be tracked manually as otherwise the
        # offsets in jump targets can end up being wrong.
        if not extended_arg:
            # The list is modified in place
            bytecode._remove_extended_args(instructions)

        bytecode.name = code.co_name
        bytecode.filename = code.co_filename
        bytecode.flags = CompilerFlags(code.co_flags)
        bytecode.argcount = code.co_argcount
        bytecode.posonlyargcount = code.co_posonlyargcount
        bytecode.kwonlyargcount = code.co_kwonlyargcount
        bytecode.first_lineno = code.co_firstlineno
        bytecode.names = list(code.co_names)
        bytecode.consts = list(code.co_consts)
        bytecode.varnames = list(code.co_varnames)
        bytecode.freevars = list(code.co_freevars)
        bytecode.cellvars = list(code.co_cellvars)
        _set_docstring(bytecode, code.co_consts)
        bytecode.exception_table = bytecode._parse_exception_table(
            code.co_exceptiontable
        )
        bytecode.qualname = code.co_qualname

        bytecode[:] = instructions
        return bytecode

    @staticmethod
    def _normalize_lineno(
        instructions: Sequence[Union[ConcreteInstr, SetLineno]], first_lineno: int
    ) -> Iterator[Tuple[int, ConcreteInstr]]:
        lineno = first_lineno
        # For each instruction compute an "inherited" lineno used:
        # - to infer a lineno if no lineno was provided
        for instr in instructions:
            i_lineno = instr.lineno
            # if instr.lineno is not set, it's inherited from the previous
            # instruction, or from self.first_lineno
            if i_lineno is not None and i_lineno is not UNSET:
                lineno = i_lineno

            if isinstance(instr, ConcreteInstr):
                yield (lineno, instr)

    def _assemble_code(
        self,
    ) -> Tuple[bytes, List[Tuple[int, int, int, Optional[InstrLocation]]]]:
        offset = 0
        code_str = []
        linenos = []
        for lineno, instr in self._normalize_lineno(self, self.first_lineno):
            code_str.append(instr.assemble())
            i_size = instr.size
            linenos.append(
                (
                    (offset * 2),
                    i_size,
                    lineno,
                    instr.location,
                )
            )
            offset += i_size // 2

        return (b"".join(code_str), linenos)

    # The formats are describes in CPython/Objects/locations.md
    @staticmethod
    def _encode_location_varint(varint: int) -> bytearray:
        encoded = bytearray()
        # We encode on 6 bits
        while True:
            encoded.append(varint & 0x3F)
            varint >>= 6
            if varint:
                encoded[-1] |= 0x40  # bit 6 is set except on the last entry
            else:
                break
        return encoded

    def _encode_location_svarint(self, svarint: int) -> bytearray:
        if svarint < 0:
            return self._encode_location_varint(((-svarint) << 1) | 1)
        else:
            return self._encode_location_varint(svarint << 1)

    @staticmethod
    def _pack_location_header(code: int, size: int) -> int:
        return (1 << 7) + (code << 3) + (size - 1 if size <= 8 else 7)

    def _pack_location(
        self, buf: bytearray, size: int, lineno: int, location: Optional[InstrLocation]
    ) -> None:
        l_lineno: Optional[int]
        # The location was not set so we infer a line.
        if location is None:
            l_lineno, end_lineno, col_offset, end_col_offset = (
                lineno,
                None,
                None,
                None,
            )
        else:
            l_lineno, end_lineno, col_offset, end_col_offset = (
                location.lineno,
                location.end_lineno,
                location.col_offset,
                location.end_col_offset,
            )

        # We have no location information so the code is 15
        if l_lineno is None:
            buf.append(self._pack_location_header(15, size))

        # No column info, code 13
        elif col_offset is None:
            if end_lineno is not None and end_lineno != l_lineno:
                raise ValueError(
                    "An instruction cannot have no column offset and span "
                    f"multiple lines (lineno: {l_lineno}, end lineno: {end_lineno}"
                )
            buf.extend(
                (
                    self._pack_location_header(13, size),
                    *self._encode_location_svarint(l_lineno - lineno),
                )
            )

        # We enforce the end_lineno to be defined
        else:
            assert end_col_offset is not None

            # Short forms
            if (
                end_lineno == l_lineno
                and l_lineno - lineno == 0
                and col_offset < 72
                and (end_col_offset - col_offset) <= 15
            ):
                buf.extend(
                    (
                        self._pack_location_header(col_offset // 8, size),
                        ((col_offset % 8) << 4) + (end_col_offset - col_offset),
                    )
                )

            # One line form
            elif (
                end_lineno == l_lineno
                and l_lineno - lineno in (1, 2)
                and col_offset < 256
                and end_col_offset < 256
            ):
                buf.extend(
                    (
                        self._pack_location_header(10 + l_lineno - lineno, size),
                        col_offset,
                        end_col_offset,
                    )
                )

            # Long form
            else:
                assert end_lineno is not None

                buf.extend(
                    (
                        self._pack_location_header(14, size),
                        *self._encode_location_svarint(l_lineno - lineno),
                        *self._encode_location_varint(end_lineno - l_lineno),
                        # When decoding in codeobject.c::advance_with_locations
                        # we remove 1 from the offset ...
                        *self._encode_location_varint(col_offset + 1),
                        *self._encode_location_varint(end_col_offset + 1),
                    )
                )

    def _push_locations(
        self,
        buf: bytearray,
        size: int,
        lineno: int,
        location: InstrLocation,
    ) -> int:
        # We need the size in instruction not in bytes
        size //= 2

        # Repeatedly add element since we cannot cover more than 8 code
        # elements. We recompute each time since in practice we will
        # rarely loop.
        while True:
            self._pack_location(buf, size, lineno, location)
            # Update the lineno since if we need more than one entry the
            # reference for the delta of the lineno change
            lineno = location.lineno if location.lineno is not None else lineno
            size -= 8
            if size < 1:
                break

        return lineno

    def _assemble_locations(
        self,
        first_lineno: int,
        linenos: Iterable[Tuple[int, int, int, Optional[InstrLocation]]],
    ) -> bytes:
        if not linenos:
            return b""

        buf = bytearray()

        iter_in = iter(linenos)

        _, size, lineno, old_location = next(iter_in)
        # Infer the line if location is None
        old_location = old_location or InstrLocation._from_tuple(
            lineno, None, None, None
        )
        lineno = first_lineno

        # We track the last set lineno to be able to compute deltas
        for _, i_size, _, location in iter_in:
            # Infer the location if location is None
            location = location or old_location

            # Group together instruction with equivalent locations
            if old_location.lineno is not None and old_location == location:
                size += i_size
                continue

            lineno = self._push_locations(buf, size, lineno, old_location)

            size = i_size
            old_location = location

        # Pack the line of the last instruction.
        self._push_locations(buf, size, lineno, old_location)

        return bytes(buf)

    @staticmethod
    def _remove_extended_args(
        instructions: MutableSequence[Union[SetLineno, ConcreteInstr]],
    ) -> None:
        # replace jump targets with blocks
        # HINT : in some cases Python generate useless EXTENDED_ARG opcode
        # with a value of zero. Such opcodes do not increases the size of the
        # following opcode the way a normal EXTENDED_ARG does. As a
        # consequence, they need to be tracked manually as otherwise the
        # offsets in jump targets can end up being wrong.
        nb_extended_args = 0
        extended_arg = None
        index = 0
        while index < len(instructions):
            instr = instructions[index]

            # Skip SetLineno meta instruction
            if isinstance(instr, SetLineno):
                index += 1
                continue

            if instr._opcode == EXTENDEDARG_OPCODE:
                nb_extended_args += 1
                if extended_arg is not None:
                    extended_arg = (extended_arg << 8) + instr.arg
                else:
                    extended_arg = instr.arg

                del instructions[index]
                continue

            if extended_arg is not None:
                arg = (
                    UNSET
                    if instr._opcode == NOP_OPCODE
                    else (extended_arg << 8) + instr.arg
                )
                extended_arg = None

                instr = ConcreteInstr(
                    instr._name,
                    arg,
                    location=instr.location,
                    extended_args=nb_extended_args,
                )
                instructions[index] = instr
                nb_extended_args = 0

            index += 1

        if extended_arg is not None:
            raise ValueError("EXTENDED_ARG at the end of the code")

    # Taken and adapted from exception_handling_notes.txt in cpython/Objects
    @staticmethod
    def _parse_varint(except_table_iterator: Iterator[int]) -> int:
        b = next(except_table_iterator)
        val = b & 63
        while b & 64:
            val <<= 6
            b = next(except_table_iterator)
            val |= b & 63
        return val

    def _parse_exception_table(
        self, exception_table: bytes
    ) -> List[ExceptionTableEntry]:
        table = []
        iterator = iter(exception_table)
        try:
            while True:
                start = self._parse_varint(iterator)
                length = self._parse_varint(iterator)
                end = start + length - 1  # Present as inclusive
                target = self._parse_varint(iterator)
                dl = self._parse_varint(iterator)
                depth = dl >> 1
                lasti = bool(dl & 1)
                table.append(ExceptionTableEntry(start, end, target, depth, lasti))
        except StopIteration:
            return table

    @staticmethod
    def _encode_varint(value: int, set_begin_marker: bool = False) -> Iterator[int]:
        # Encode value as a varint on 7 bits (MSB should come first) and set
        # the begin marker if requested.
        temp: List[int] = []
        while value:
            temp.append(value & 63 | (64 if temp else 0))
            value >>= 6
        temp = temp or [0]
        if set_begin_marker:
            temp[-1] |= 128
        return reversed(temp)

    def _assemble_exception_table(self) -> bytes:
        table = bytearray()
        for entry in self.exception_table or []:
            size = entry.stop_offset - entry.start_offset + 1
            depth = (entry.stack_depth << 1) + entry.push_lasti
            table.extend(self._encode_varint(entry.start_offset, True))
            table.extend(self._encode_varint(size))
            table.extend(self._encode_varint(entry.target))
            table.extend(self._encode_varint(depth))

        return bytes(table)

    def compute_stacksize(self, *, check_pre_and_post: bool = True) -> int:
        bytecode = self.to_bytecode()
        cfg = _bytecode.ControlFlowGraph.from_bytecode(bytecode)
        return cfg.compute_stacksize(check_pre_and_post=check_pre_and_post)

    def to_code(
        self,
        stacksize: Optional[int] = None,
        *,
        check_pre_and_post: bool = True,
        compute_exception_stack_depths: bool = True,
    ) -> types.CodeType:
        # Prevent reconverting the concrete bytecode to bytecode and cfg to do the
        # calculation if we need to do it.
        if stacksize is None or compute_exception_stack_depths:
            cfg = _bytecode.ControlFlowGraph.from_bytecode(self.to_bytecode())
            stacksize = cfg.compute_stacksize(
                check_pre_and_post=check_pre_and_post,
                compute_exception_stack_depths=compute_exception_stack_depths,
            )
            self = cfg.to_bytecode().to_concrete_bytecode(
                compute_exception_stack_depths=False
            )

        # Assemble the code string after round tripping to CFG if necessary.
        code_str, linenos = self._assemble_code()

        lnotab = self._assemble_locations(self.first_lineno, linenos)
        nlocals = len(self.varnames)

        return types.CodeType(
            self.argcount,
            self.posonlyargcount,
            self.kwonlyargcount,
            nlocals,
            stacksize,
            int(self.flags),
            code_str,
            tuple(self.consts),
            tuple(self.names),
            tuple(self.varnames),
            self.filename,
            self.name,
            self.qualname,
            self.first_lineno,
            lnotab,
            self._assemble_exception_table(),
            tuple(self.freevars),
            tuple(self.cellvars),
        )

    def to_bytecode(
        self,
        prune_caches: bool = True,
        conserve_exception_block_stackdepth: bool = False,
    ) -> _bytecode.Bytecode:
        # On 3.11 we generate pseudo-instruction from the exception table

        # Copy instruction and remove extended args if any (in-place)
        c_instructions = self[:]
        self._remove_extended_args(c_instructions)

        # Find jump targets; stash (size, jump_target) to avoid recomputing in the main loop
        jump_targets: Set[int] = set()
        _instr_props: List[Tuple[int, Optional[int]]] = []
        offset = 0
        for c_instr in c_instructions:
            if isinstance(c_instr, SetLineno):
                continue
            size = c_instr.size
            target = c_instr.get_jump_target(offset)
            _instr_props.append((size, target))
            if target is not None:
                jump_targets.add(target)
            offset += size // 2

        # On 3.11+ we need to also look at the exception table for jump targets
        for ex_entry in self.exception_table:
            jump_targets.add(ex_entry.target)

        # Create look up dict to find entries based on either exception handling
        # block exit or entry offsets. Several blocks can end on the same instruction
        # so we store a list of entry per offset.
        ex_start: Dict[int, ExceptionTableEntry] = {}
        ex_end: Dict[int, List[ExceptionTableEntry]] = {}
        for entry in self.exception_table:
            # Ensure we do not have more than one entry with identical starting
            # offsets
            ex_start[entry.start_offset] = entry
            ex_end.setdefault(entry.stop_offset, []).append(entry)

        # Create labels and instructions
        jumps: List[Tuple[int, int]] = []
        instructions: List[Union[Instr, Label, TryBegin, TryEnd, SetLineno]] = []
        labels = {}
        tb_instrs: Dict[ExceptionTableEntry, TryBegin] = {}
        offset = 0

        # In Python 3.11+ cell and varnames can be shared and are indexed in a single
        # array.
        # As a consequence, the instruction argument can be either:
        # - < len(varnames): the name is shared an we can directly use
        #   the index to access the name in cellvars
        # - > len(varnames): the name is not shared and is offset by the
        #   number unshared varname.
        # Free vars are never shared and correspond to index larger than the
        # largest cell var.
        # See PyCode_NewWithPosOnlyArgs
        cells_lookup = self.varnames + [
            CellVar(n) for n in self.cellvars if n not in self.varnames
        ]
        ncells = len(cells_lookup)

        # In Python 3.13+ LOAD_FAST can be used to retrieve cell values
        locals_lookup: Sequence[Union[str, CellVar, FreeVar]]
        if PY313:
            locals_lookup = cells_lookup + [
                FreeVar(n) for n in self.freevars if n not in self.varnames
            ]
        else:
            locals_lookup = self.varnames

        _props_iter = iter(_instr_props)
        for lineno, c_instr in self._normalize_lineno(
            c_instructions, self.first_lineno
        ):
            if offset in jump_targets:
                label = Label()
                labels[offset] = label
                instructions.append(label)

            # Handle TryBegin pseudo instructions
            if offset in ex_start:
                entry = ex_start[offset]
                # Check if the try begin was already created by an entry
                # with a end offset less or equal to the start offset.
                if entry not in tb_instrs:
                    tb_instr = TryBegin(
                        Label(),
                        entry.push_lasti,
                        entry.stack_depth
                        if conserve_exception_block_stackdepth
                        else UNSET,
                    )
                    # Per entry store the pseudo instruction associated
                    tb_instrs[entry] = tb_instr
                    instructions.append(tb_instr)

            size, jump_target = next(_props_iter)
            # If an instruction uses extended args, those appear before the instruction
            # causing the instruction to appear at offset that accounts for extended
            # args. So we first update the offset to account for extended args, then
            # record the instruction offset and then add the instruction itself to the
            # offset.
            offset += size // 2 - 1
            current_instr_offset = offset
            offset += 1

            # on Python 3.11+ remove CACHE opcodes if we are requested to do so.
            # We are careful to first advance the offset and check that the CACHE
            # is not a jump target. It should never be the case but we double check.
            if prune_caches and c_instr._opcode == CACHE_OPCODE:
                if jump_target is not None:
                    msg = "cache instruction cannot have jump target"
                    raise ValueError(msg)

            # We may need to insert a TryEnd after a CACHE so we need to run the
            # through the last block.
            else:
                opcode = c_instr._opcode
                arg: InstrArg
                c_arg = c_instr.arg
                # FIXME: better error reporting
                if opcode in HAS_CONST:
                    arg = self.consts[c_arg]
                elif opcode in _opcode.haslocal:
                    if opcode in DUAL_ARG_OPCODES:
                        arg = (locals_lookup[c_arg >> 4], locals_lookup[c_arg & 15])
                    else:
                        arg = locals_lookup[c_arg]
                elif opcode in HAS_NAME:
                    if opcode in BITFLAG_OPCODES:
                        arg = (
                            bool(c_arg & 1),
                            self.names[c_arg >> 1],
                        )
                    elif opcode in BITFLAG2_OPCODES:
                        arg = (bool(c_arg & 1), bool(c_arg & 2), self.names[c_arg >> 2])
                    else:
                        arg = self.names[c_arg]
                elif opcode in HAS_FREE:
                    if c_arg < ncells:
                        n_or_cell = cells_lookup[c_arg]
                        arg = (
                            n_or_cell
                            if isinstance(n_or_cell, CellVar)
                            else CellVar(n_or_cell)
                        )
                    else:
                        name = self.freevars[c_arg - ncells]
                        arg = FreeVar(name)
                elif opcode in HAS_COMPARE:
                    arg = Compare(
                        (c_arg >> 5) + ((1 << 4) if (c_arg & 16) else 0)
                        if PY313
                        else ((c_arg >> 4) if PY312 else c_arg)
                    )
                elif opcode in INTRINSIC_1OP:
                    arg = Intrinsic1Op(c_arg)
                elif opcode in INTRINSIC_2OP:
                    arg = Intrinsic2Op(c_arg)
                elif opcode in BINARY_OPS:
                    arg = BinaryOp(c_arg)
                elif opcode in COMMON_CONSTANT_OPS:
                    arg = CommonConstant(c_arg)
                elif opcode in SPECIAL_OPS:
                    arg = SpecialMethod(c_arg)
                elif opcode in FORMAT_VALUE_OPS:
                    if opcode in BITFLAG_OPCODES:
                        arg = (
                            bool(c_arg & 1),
                            FormatValue(c_arg >> 1),
                        )
                    else:
                        arg = FormatValue(c_arg)
                else:
                    arg = c_arg

                location = c_instr.location or InstrLocation._from_tuple(
                    lineno, None, None, None
                )

                if jump_target is not None:
                    arg = PLACEHOLDER_LABEL
                    instr_index = len(instructions)
                    jumps.append((instr_index, jump_target))

                instructions.append(
                    Instr._from_trusted(c_instr._name, c_instr._opcode, arg, location)
                )

            # We now insert the TryEnd entries
            if current_instr_offset in ex_end:
                entries = ex_end[current_instr_offset]
                for entry in reversed(entries):
                    try:
                        instructions.append(TryEnd(tb_instrs[entry]))
                    except KeyError:
                        # The end offset is behind the start offset, so we
                        # need to create
                        tb_instr = TryBegin(
                            Label(),
                            entry.push_lasti,
                            entry.stack_depth
                            if conserve_exception_block_stackdepth
                            else UNSET,
                        )
                        # Per entry store the pseudo instruction associated
                        tb_instrs[entry] = tb_instr
                        instructions.append(tb_instr)
                        instructions.append(TryEnd(tb_instr))

        # Replace jump targets with labels
        for index, jump_target in jumps:
            instr = instructions[index]
            assert isinstance(instr, Instr) and instr.arg is PLACEHOLDER_LABEL
            # FIXME: better error reporting on missing label
            instr.arg = labels[jump_target]

        # Set the label for TryBegin
        for entry, tb in tb_instrs.items():
            tb.target = labels[entry.target]

        bytecode = _bytecode.Bytecode()
        bytecode._copy_attr_from(self)

        nargs = bytecode.argcount + bytecode.kwonlyargcount
        nargs += bytecode.posonlyargcount
        if bytecode.flags & inspect.CO_VARARGS:
            nargs += 1
        if bytecode.flags & inspect.CO_VARKEYWORDS:
            nargs += 1
        bytecode.argnames = self.varnames[:nargs]
        _set_docstring(bytecode, self.consts)

        bytecode.extend(instructions)
        return bytecode


class _ConvertBytecodeToConcrete:
    # FIXME document attributes

    #: Default number of passes of compute_jumps() before giving up.  Refer to
    #: assemble_jump_offsets() in compile.c for background.
    _compute_jumps_passes = 10

    def __init__(self, code: _bytecode.Bytecode) -> None:
        self.bytecode = code

        # temporary variables
        self.instructions: list[ConcreteInstr] = []
        self.jumps: list[tuple[int, Label, ConcreteInstr]] = []
        self.labels: dict[Label, int] = {}
        self.exception_handling_blocks: dict[TryBegin, ExceptionTableEntry] = {}
        self.required_caches = 0
        self.seen_manual_cache = False

        # used to build ConcreteBytecode() object
        self.consts_indices: dict[bytes | Tuple[type, int], int] = {}
        self.consts_list: list[Any] = []
        self.names: list[str] = []
        self.names_map: dict[str, int] = {}
        self.varnames: list[str] = []
        self.varnames_map: dict[str, int] = {}

    def add_const(self, value: Any) -> int:
        key = const_key(value)
        if key in self.consts_indices:
            return self.consts_indices[key]
        index = len(self.consts_indices)
        self.consts_indices[key] = index
        self.consts_list.append(value)
        return index

    def add_name(self, name: str) -> int:
        index = self.names_map.get(name)
        if index is None:
            index = len(self.names)
            self.names_map[name] = index
            self.names.append(name)
        return index

    def add_varname(self, name: str) -> int:
        index = self.varnames_map.get(name)
        if index is None:
            index = len(self.varnames)
            self.varnames_map[name] = index
            self.varnames.append(name)
        return index

    def concrete_instructions(self) -> None:
        location = InstrLocation._from_tuple(
            self.bytecode.first_lineno, None, None, None
        )
        # Track instruction (index) using cell vars and free vars to be able to update
        # the index used once all the names are known.
        cell_instrs: list[int] = []
        free_instrs: list[int] = []

        # On 3.13+, try to use small indexes for names used in dual arg opcode
        # to improve the chances to be able to use them (since we cannot use
        # only the 15 first names.
        if PY313:
            for binstr in self.bytecode:
                if isinstance(binstr, Instr) and binstr._opcode in DUAL_ARG_OPCODES:
                    assert isinstance(binstr.arg, tuple)
                    for parg in binstr.arg:
                        assert isinstance(parg, str)
                        self.add_varname(parg)

        # We use None as a sentinel to ensure caches for the last instruction are
        # properly generated.
        for instr in itertools.chain(self.bytecode, [None]):
            # Enforce proper use of CACHE opcode on Python 3.11+ by checking we get the
            # number we expect or directly generate the needed ones.
            if isinstance(instr, Instr) and instr._opcode == CACHE_OPCODE:
                if not self.required_caches:
                    raise RuntimeError("Found a CACHE opcode when none was expected.")
                self.seen_manual_cache = True
                self.required_caches -= 1

            elif self.required_caches:
                if not self.seen_manual_cache:
                    # We preserve the location of the instruction requiring the
                    # presence of cache instructions
                    self.instructions.extend(
                        [
                            ConcreteInstr(
                                "CACHE", 0, location=self.instructions[-1].location
                            )
                        ]
                        * self.required_caches
                    )
                    self.required_caches = 0
                    self.seen_manual_cache = False
                else:
                    raise RuntimeError(
                        "Found some manual CACHE opcode but less than expected. "
                        f"Missing {self.required_caches} CACHE opcodes."
                    )

            if instr is None:
                continue

            if isinstance(instr, Label):
                self.labels[instr] = len(self.instructions)
                continue

            if isinstance(instr, SetLineno):
                location = InstrLocation._from_tuple(instr.lineno, None, None, None)
                continue

            if isinstance(instr, TryBegin):
                # We expect the stack depth to have be provided or computed earlier
                # NOTE here we store the index of the instruction at which the
                # exception table entry starts. This is not the final value we want,
                # we want the offset in the bytecode but that requires to compute
                # the jumps first to resolve any possible extended arg needed in a
                # jump.
                self.exception_handling_blocks[instr] = ExceptionTableEntry(
                    len(self.instructions), 0, 0, instr.stack_depth, instr.push_lasti
                )
                continue

            # Do not handle TryEnd before we insert possible CACHE opcode
            if isinstance(instr, TryEnd):
                entry = self.exception_handling_blocks[instr.entry]
                # The TryEnd is located after the last opcode in the exception entry
                # so we move the offset by one. We choose one so that the end does
                # encompass a possible EXTENDED_ARG
                entry.stop_offset = len(self.instructions) - 1
                continue

            assert isinstance(instr, Instr)

            # Access private slots directly — avoids property descriptor overhead on
            # every iteration; safe because instr is a validated Instr at this point.
            if instr._location is not UNSET and instr._location is not None:
                location = instr._location

            instr_name = instr._name
            opcode = instr._opcode
            arg = instr._arg
            is_jump = False
            if isinstance(arg, Label):
                label = arg
                # fake value, real value is set in compute_jumps()
                c_arg = 0
                is_jump = True
            elif opcode in HAS_CONST:
                c_arg = self.add_const(arg)
            elif opcode in HAS_LOCAL:
                if opcode in DUAL_ARG_OPCODES:
                    _arg2 = cast(Tuple[str, str], arg)
                    arg1_index = self.add_varname(_arg2[0])
                    arg2_index = self.add_varname(_arg2[1])
                    if arg1_index > 16 or arg2_index > 16:
                        n1, n2 = DUAL_ARG_OPCODES_SINGLE_OPS[opcode]
                        c_instr = ConcreteInstr(n1, arg1_index, location=location)
                        self.instructions.append(c_instr)
                        instr_name = n2
                        c_arg = arg2_index
                    else:
                        c_arg = (arg1_index << 4) + arg2_index
                elif PY313 and isinstance(arg, CellVar):
                    cell_instrs.append(len(self.instructions))
                    c_arg = self.bytecode.cellvars.index(arg.name)
                elif PY313 and isinstance(arg, FreeVar):
                    free_instrs.append(len(self.instructions))
                    c_arg = self.bytecode.freevars.index(arg.name)
                else:
                    assert isinstance(arg, str)
                    c_arg = self.add_varname(arg)
            elif opcode in HAS_NAME:
                if opcode in BITFLAG_OPCODES:
                    assert (
                        isinstance(arg, tuple)
                        and len(arg) == 2
                        and isinstance(arg[0], bool)
                    ), arg
                    if isinstance(arg[1], str):
                        index = self.add_name(arg[1])
                    elif isinstance(arg, FormatValue):
                        index = int(arg)
                    else:
                        assert False, arg  # noqa
                    c_arg = int(arg[0]) + (index << 1)
                elif opcode in BITFLAG2_OPCODES:
                    _arg3 = cast(tuple[bool, bool, str], arg)
                    index = self.add_name(_arg3[2])
                    c_arg = int(_arg3[0]) + 2 * int(_arg3[1]) + (index << 2)
                else:
                    assert isinstance(arg, str), f"Got {arg}, expected a str"
                    c_arg = self.add_name(arg)
            elif opcode in HAS_FREE:
                if isinstance(arg, CellVar):
                    cell_instrs.append(len(self.instructions))
                    c_arg = self.bytecode.cellvars.index(arg.name)
                else:
                    assert isinstance(arg, FreeVar)
                    free_instrs.append(len(self.instructions))
                    c_arg = self.bytecode.freevars.index(arg.name)
            elif opcode in HAS_COMPARE:
                if isinstance(arg, Compare):
                    # In Python 3.13 the 4 lowest bits are used for caching
                    # and the 5th one indicate a cast to bool
                    if PY313:
                        c_arg = (
                            arg._get_mask()
                            + ((arg.value & 0b1111) << 5)
                            + (arg.value & 16)
                        )
                    # In Python 3.12 the 4 lowest bits are used for caching
                    # See compare_masks in compile.c
                    elif PY312:
                        c_arg = arg._get_mask() + (arg.value << 4)
                    else:
                        c_arg = arg.value
            elif opcode in INTRINSIC:
                if isinstance(arg, (Intrinsic1Op, Intrinsic2Op)):
                    c_arg = arg.value
            else:
                assert isinstance(arg, int)
                c_arg = arg

            # The above should have performed all the necessary conversion
            c_instr = ConcreteInstr._from_trusted(instr_name, opcode, c_arg, location)
            if is_jump:
                self.jumps.append((len(self.instructions), label, c_instr))

            # If the instruction expect some cache
            self.required_caches = c_instr.use_cache_opcodes()
            self.seen_manual_cache = False

            self.instructions.append(c_instr)

        # On Python 3.11 varnames and cells can share some names. Wind the shared
        # names and update the arg argument of instructions using cell vars.
        # We also track by how much to offset free vars which are stored in a
        # contiguous array after the cell vars
        # Map naive cell index to shared index
        shared_name_indexes: Dict[int, int] = {}
        n_shared = 0
        n_unshared = 0
        for i, name in enumerate(self.bytecode.cellvars):
            if name in self.varnames:
                shared_name_indexes[i] = self.varnames.index(name)
                n_shared += 1
            else:
                shared_name_indexes[i] = len(self.varnames) + n_unshared
                n_unshared += 1

        for index in cell_instrs:
            c_instr = self.instructions[index]
            c_instr.arg = shared_name_indexes[c_instr.arg]

        free_offset = len(self.varnames) + len(self.bytecode.cellvars) - n_shared

        for index in free_instrs:
            c_instr = self.instructions[index]
            c_instr.arg += free_offset

    def compute_jumps(self) -> bool:
        # For labels we need the offset before the instruction at a given index but for
        # exception table entries we need the offset of the instruction which can differ
        # in the presence of extended args...
        label_offsets = []
        instruction_offsets = []
        offset = 0
        for instr in self.instructions:
            label_offsets.append(offset)
            # If an instruction uses extended args, those appear before the instruction
            # causing the instruction to appear at offset that accounts for extended
            # args.
            offset += instr.size // 2 - 1
            instruction_offsets.append(offset)
            offset += 1
        # needed if a label is at the end
        label_offsets.append(offset)

        # Fix argument of jump instructions: resolve labels
        modified = False
        for index, label, instr in self.jumps:
            target_index = self.labels[label]
            target_offset = label_offsets[target_index]

            # For jump using cache opcodes, an argument of 0 jumps to the
            # first non cache instructions right after the jump instruction
            instr_offset = label_offsets[index] + instr.use_cache_opcodes()
            if instr.is_forward_rel_jump():
                target_offset -= instr_offset + (instr.size // 2)
            elif instr.is_backward_rel_jump():
                target_offset = instr_offset + (instr.size // 2) - target_offset

            old_size = instr.size
            # FIXME: better error report if target_offset is negative
            instr.arg = target_offset
            if instr.size != old_size:
                modified = True

        # If a jump required an extended arg hence invalidating the calculation
        # we return early before filling the exception table entries
        if modified:
            return modified

        # Resolve labels for exception handling entries
        for tb, entry in self.exception_handling_blocks.items():
            # Set the offset for the start and end offset from the instruction
            # index stored when assembling the concrete instructions.
            entry.start_offset = instruction_offsets[entry.start_offset]
            entry.stop_offset = instruction_offsets[entry.stop_offset]

            # Set the offset to the target instruction
            lb = tb.target
            assert isinstance(lb, Label)
            target_index = self.labels[lb]
            target_offset = label_offsets[target_index]
            entry.target = target_offset

        return False

    def to_concrete_bytecode(
        self,
        compute_jumps_passes: Optional[int] = None,
        compute_exception_stack_depths: bool = True,
    ) -> ConcreteBytecode:
        if compute_exception_stack_depths:
            cfg = _bytecode.ControlFlowGraph.from_bytecode(self.bytecode)
            cfg.compute_stacksize(compute_exception_stack_depths=True)
            self.bytecode = cfg.to_bytecode()

        if compute_jumps_passes is None:
            compute_jumps_passes = self._compute_jumps_passes

        first_const = self.bytecode.docstring
        if first_const is not UNSET:
            self.add_const(first_const)

        for name in self.bytecode.argnames:
            self.add_varname(name)

        self.concrete_instructions()
        for _ in range(0, compute_jumps_passes):
            modified = self.compute_jumps()
            if not modified:
                break
        else:
            raise RuntimeError(
                "compute_jumps() failed to converge after"
                " %d passes" % (compute_jumps_passes)
            )

        concrete = ConcreteBytecode(
            self.instructions,
            consts=tuple(self.consts_list),
            names=tuple(self.names),
            varnames=self.varnames,
            exception_table=list(self.exception_handling_blocks.values()),
        )
        concrete._copy_attr_from(self.bytecode)
        return concrete
