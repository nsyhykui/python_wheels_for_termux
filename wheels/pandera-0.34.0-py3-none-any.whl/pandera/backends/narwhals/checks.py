"""Check backend for Narwhals."""

import inspect
from functools import lru_cache, partial
from typing import Any, Optional

import narwhals.stable.v1 as nw

from pandera.api.base.checks import CheckResult
from pandera.api.checks import Check
from pandera.api.narwhals.types import NarwhalsData
from pandera.api.narwhals.utils import _EAGER_PANDAS_LIKE_IMPLEMENTATIONS
from pandera.backends.base import BaseCheckBackend
from pandera.constants import CHECK_OUTPUT_KEY

# Temporary column carrying the input column's nullness for pandas-like
# ignore_na handling (see _use_input_nullness).
_INPUT_NULL_KEY = f"{CHECK_OUTPUT_KEY}_input_null"


def _use_input_nullness(ignore_na: bool, frame: Any, key: Any) -> bool:
    """Whether ``ignore_na`` must also consult the input column's nullness.

    On polars/ibis, null inputs propagate to null check outputs, so ORing the
    output with its own nullness suffices. On pandas-like backends, NaN
    inputs produce ``False`` comparison outputs (never null), so the input
    column's nullness must be ORed in as well. Only column-level checks
    (``key`` not None/"*") can attribute nullness to an input column.
    """
    if not ignore_na or not key or key == "*":
        return False
    return (
        getattr(frame, "implementation", None)
        in _EAGER_PANDAS_LIKE_IMPLEMENTATIONS
    )


try:
    import ibis  # noqa: F401
    import ibis.expr.types as ir

    _HAS_IBIS = True
except ImportError:  # pragma: no cover — ibis is optional
    _HAS_IBIS = False
    ir = None  # type: ignore[assignment]


def _unwrap_callable(fn: Any) -> Any:
    """Unwrap ``functools.partial`` chains to reach the underlying callable.

    Used when the caller needs the *identity* of the underlying function (e.g.
    for type-checking or ``isinstance`` dispatch), not for arity detection.
    Arity detection should be performed on the partial itself so that
    post-binding required-positional counts are respected — see
    ``_required_positional_count`` and its usage in ``apply()``.
    """
    while isinstance(fn, partial):
        fn = fn.func
    return fn


@lru_cache(maxsize=1024)
def _required_positional_count(fn: Any) -> int | None:
    """Return the number of required positional parameters for ``fn``.

    Returns ``None`` when introspection is not possible (e.g. C-extension
    callables or objects whose ``__call__`` cannot be inspected). Callers
    should treat ``None`` as "use the legacy 2-arg narwhals convention".

    A parameter counts as "required positional" only when it has no default
    *and* its kind is ``POSITIONAL_ONLY`` or ``POSITIONAL_OR_KEYWORD``.
    ``*args`` and ``**kwargs`` are excluded so functions like the
    ``BaseCheckInfo._adapter`` (``def _adapter(arg, **kwargs)``) report
    exactly one required positional.

    """
    try:
        sig = inspect.signature(fn)
    except (TypeError, ValueError):
        return None
    required = 0
    for param in sig.parameters.values():
        if param.kind not in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            continue
        if param.default is inspect.Parameter.empty:
            required += 1
    return required


def _is_polars_native(frame: Any) -> bool:
    """Cheap polars detection without importing polars at module load.

    Avoids a hard polars import: the narwhals backend is also reachable on
    ibis-only installs where polars is not present.
    """
    mod = getattr(type(frame), "__module__", "") or ""
    return mod.startswith("polars")


def _is_ibis_native(frame: Any) -> bool:
    """Cheap ibis detection that mirrors ``_is_polars_native``."""
    if not _HAS_IBIS:
        return False
    return isinstance(frame, ibis.Table)


def _is_pyarrow_native(frame: Any) -> bool:
    """Cheap ``pyarrow.Table`` detection that mirrors ``_is_polars_native``.

    Duck-types via the module name so the narwhals backend keeps working on
    installs where pyarrow is not present.
    """
    mod = getattr(type(frame), "__module__", "") or ""
    return mod.startswith("pyarrow") and type(frame).__name__ == "Table"


# Root modules of pandas-like libraries. Compared against the first dotted
# segment of ``type(obj).__module__``: pandas < 3 reports e.g.
# "pandas.core.frame" while pandas >= 3 reports just "pandas" for its public
# classes, so a bare root comparison covers both.
_PANDAS_LIKE_MODULE_ROOTS = frozenset({"pandas", "modin", "cudf"})


def _is_pandas_like_module(mod: str) -> bool:
    """True if a ``__module__`` string belongs to a pandas-like library."""
    return mod.split(".", 1)[0] in _PANDAS_LIKE_MODULE_ROOTS


def _is_pandas_like_native(frame: Any) -> bool:
    """Cheap pandas-like (pandas, modin, cuDF) detection.

    Mirrors ``_is_polars_native``: module duck-typing so that pandas
    (and modin/cudf) never need to be imported on installs without them.
    """
    mod = getattr(type(frame), "__module__", "") or ""
    return _is_pandas_like_module(mod)


def _wrap_native_frame_with_key(native_frame: Any, key: str | None) -> Any:
    """Wrap ``(native_frame, key)`` into a polars/ibis-style data container.

    Returns a ``PolarsData`` / ``IbisData`` matching the native frame type so
    that polars-style or ibis-style user check functions (``def fn(data:
    PolarsData)`` / ``def fn(data: IbisData)``) receive the same object they
    would under the native polars/ibis backends.

    When the frame type is unrecognised, returns ``None`` so the caller can
    fall back to the legacy two-positional narwhals dispatch.

    Polars is *not* imported at the module level here — narwhals must
    continue to work on ibis-only installs, so we duck-type via
    ``type(native_frame).__name__``.
    """
    if _is_polars_native(native_frame):
        from pandera.api.polars.types import PolarsData

        if type(native_frame).__name__ == "LazyFrame":
            lf = native_frame
        else:
            lf = native_frame.lazy()
        return PolarsData(lazyframe=lf, key=key or "*")

    if _is_ibis_native(native_frame):
        from pandera.api.ibis.types import IbisData

        return IbisData(table=native_frame, key=key)

    if _is_pyarrow_native(native_frame):
        from pandera.api.pyarrow.types import PyArrowData

        return PyArrowData(table=native_frame, key=key or "*")

    if _is_pandas_like_native(native_frame):
        # pandas-style user check functions receive exactly what the native
        # pandas backend passes them: the Series for a column-level check and
        # the DataFrame for a dataframe-level check. This keeps existing
        # pandas checks (``pa.Check(lambda s: s > 0)``) working unchanged
        # under the narwhals backend.
        if key is None or key == "*":
            return native_frame
        return native_frame[key]

    return None


class NarwhalsCheckBackend(BaseCheckBackend):
    """Check backend for Narwhals."""

    def __init__(self, check: Check):
        """Initializes a check backend object."""
        super().__init__(check)
        assert check._check_fn is not None, "Check._check_fn must be set."
        self.check = check
        self.check_fn = partial(check._check_fn, **check._check_kwargs)

    def groupby(self, check_obj):
        """Implements groupby behavior for check object.

        Column-check-groups (`groupby=`) are a pandas-semantic feature: the
        user check function receives a ``dict`` mapping group key to the native
        pandas ``Series``/``DataFrame`` for that group. Narwhals has no
        equivalent, so for pandas-like eager frames we group the *native* frame
        with pandas and build the same dict the native pandas backend produces.

        :param check_obj: a native pandas-like frame (already unwrapped).
        """
        assert self.check.groupby is not None, "Check.groupby must be set."
        if isinstance(self.check.groupby, (str, list)):
            return check_obj.groupby(self.check.groupby)
        return self.check.groupby(check_obj)

    @staticmethod
    def _format_groupby_input(groupby_obj, groups):
        """Format a pandas groupby object into a dict of group -> Series/df.

        Ported from :class:`~pandera.backends.pandas.checks.PandasCheckBackend`
        so the narwhals backend runs column-check-groups without dispatching to
        the pandas check backend.
        """
        if groups is None:
            return {
                (k if isinstance(k, bool) else k[0] if len(k) == 1 else k): v
                for k, v in groupby_obj
            }
        group_keys = {k[0] if len(k) == 1 else k for k, _ in groupby_obj}
        invalid_groups = [g for g in groups if g not in group_keys]
        if invalid_groups:
            raise KeyError(
                f"groups {invalid_groups} provided in `groups` argument not a "
                f"valid group key. Valid group keys: {group_keys}"
            )
        output = {}
        for group_key, group in groupby_obj:
            if isinstance(group_key, tuple) and len(group_key) == 1:
                group_key = group_key[0]
            if group_key in groups:
                output[group_key] = group
        return output

    def apply_groupby(self, check_obj: NarwhalsData):
        """Run a `groupby=` check by building the pandas group dict.

        Only supported for pandas-like eager frames. The user check function
        receives the same ``dict`` it would under the native pandas backend and
        typically returns a scalar boolean (or a per-group Series/dict of
        booleans, which is reduced to a single pass/fail).
        """
        native = nw.to_native(check_obj.frame)
        if hasattr(native, "collect"):  # pragma: no cover — lazy safety net
            native = native.collect()
        if not _is_pandas_like_native(native):
            raise NotImplementedError(
                "groupby checks (column check groups) are only supported for "
                "pandas-like frames under the narwhals backend."
            )
        key = check_obj.key
        grouped = self.groupby(native)
        if key and key != "*":
            grouped = grouped[key]
        group_dict = self._format_groupby_input(grouped, self.check.groups)
        return self._reduce_groupby_output(self.check_fn(group_dict))

    @staticmethod
    def _reduce_groupby_output(out):
        """Reduce a groupby-check output to a scalar boolean.

        Accepts a Python/numpy scalar bool, a numpy boolean array, a pandas
        ``Series`` of booleans, or a ``dict`` of group -> bool, and returns a
        single pass/fail bool (a group check passes only if every group passes).
        """
        if isinstance(out, dict):
            return all(bool(v) for v in out.values())
        mod = getattr(type(out), "__module__", "") or ""
        if mod.startswith("numpy"):
            if getattr(out, "ndim", 0) == 0:
                return bool(out)
            return bool(out.all())
        if _is_pandas_like_module(mod) and type(out).__name__ == "Series":
            return bool(out.all())
        return out

    def query(self, check_obj: nw.LazyFrame):
        """Implements querying behavior to produce subset of check object."""
        raise NotImplementedError

    def aggregate(self, check_obj: nw.LazyFrame):
        """Implements aggregation behavior for check object."""
        raise NotImplementedError

    def preprocess(self, check_obj: nw.LazyFrame, key: str | None):
        """Preprocesses a check object before applying the check function."""
        return check_obj

    def apply(self, check_obj: NarwhalsData):
        """Apply check function — dispatch on self.check.native flag."""
        frame = check_obj.frame
        key = check_obj.key

        # Column-check-groups: build the pandas group dict and run the check
        # on it (narwhals-native handling for pandas-like frames).
        if self.check.groupby is not None:
            return self.apply_groupby(check_obj)

        if self.check.element_wise:
            selector = nw.col(key or "*")
            try:
                expr = selector.map_batches(
                    self.check_fn, return_dtype=nw.Boolean
                )
                # Force evaluation on a minimal probe to catch SQL-lazy
                # backends that reject map_batches at query-plan build time
                # (Narwhals raises NotImplementedError during .select()).
                frame.select(expr)
                return expr
            except NotImplementedError:
                raise NotImplementedError(
                    "element_wise checks are not supported on SQL-lazy backends "
                    "(Ibis, DuckDB, PySpark) because row-level Python functions "
                    "cannot be applied to lazy query plans. "
                    "Use a vectorized check instead."
                )

        elif self.check.native:
            # native=True: unwrap to backend-native type and dispatch.
            #
            # Two calling conventions are supported, discriminated by the
            # user check function's required-positional-arg count:
            #
            #   * 2+ positional → narwhals-native style:
            #       check_fn(native_frame, key)
            #     This is the documented narwhals backend convention used
            #     throughout tests/narwhals/test_checks.py.
            #
            #   * 0-1 positional → polars/ibis style:
            #       check_fn(PolarsData(lazyframe=…, key=…)) for polars
            #       check_fn(IbisData(table=…, key=…))      for ibis
            #     This matches what PolarsCheckBackend / IbisCheckBackend do
            #     natively, so polars/ibis-style user functions and
            #     ``@pa.check``-decorated model methods (whose ``_adapter``
            #     accepts a single positional arg) work identically under
            #     the narwhals backend.
            native_frame = nw.to_native(frame)
            # Use check._check_fn directly — do not unwrap user-supplied partials;
            # the post-binding arity is what selects the correct calling convention.
            arity = _required_positional_count(self.check._check_fn)
            if arity is not None and arity <= 1:
                data = _wrap_native_frame_with_key(native_frame, key)
                if data is not None:
                    out = self.check_fn(data)
                else:
                    # Unknown frame type — preserve legacy 2-arg behaviour
                    # so error messages remain informative.
                    out = self.check_fn(native_frame, key)
            else:
                out = self.check_fn(native_frame, key)
            return self._normalize_native_output(out, check_obj)

        else:
            # native=False: expression protocol.
            # Column check: pass nw.col(key). Frame check (key=="*"): pass frame.
            if key and key != "*":
                expr = self.check_fn(nw.col(key))
            else:
                expr = self.check_fn(frame)
            return expr

    @staticmethod
    def _normalize_native_output(out, check_obj: NarwhalsData):
        """Normalize native outputs from ``native=True`` checks.

        Native check functions may return any of:

        - **ibis**: ``ir.BooleanScalar`` (aggregate bool), ``ir.BooleanColumn``
          (row-level bool), or ``ibis.Table``.
        - **polars**: ``pl.Series`` of booleans, ``pl.DataFrame``, or
          ``pl.LazyFrame``. Single-column boolean frames are renamed to
          ``CHECK_OUTPUT_KEY``; multi-column boolean frames are AND-reduced
          to a single ``CHECK_OUTPUT_KEY`` column (matching
          :class:`PolarsCheckBackend` behaviour). If the frame already
          contains a ``CHECK_OUTPUT_KEY`` column, that column is used
          directly.
        - Any Python ``bool`` / scalar — passed through unchanged so
          ``postprocess_bool_output`` can handle it.

        The output shape mirrors ``postprocess_lazyframe_output``: a wide
        Narwhals frame with the original columns plus ``CHECK_OUTPUT_KEY``.
        """
        if _HAS_IBIS:
            if isinstance(out, ir.BooleanScalar):
                return bool(out.execute())
            if isinstance(out, ir.BooleanColumn):
                # Attach the boolean column expression to the original table,
                # producing a wide table (original columns + CHECK_OUTPUT_KEY).
                native = nw.to_native(check_obj.frame)
                tbl = native.mutate(**{CHECK_OUTPUT_KEY: out})
                return nw.from_native(tbl, eager_or_interchange_only=False)
            if isinstance(out, ir.Table):
                return nw.from_native(out, eager_or_interchange_only=False)

        # Handle polars native return types from native=True checks.
        # Detection uses ``type(out).__module__`` and ``type(out).__name__``
        # so polars (an optional dependency) does not need to be imported
        # here — that would break ibis-only installs (see
        # ``test_checks_has_no_polars_import``). All reductions / renames go
        # through narwhals so polars-specific expression APIs stay out of
        # this file.
        out_mod = getattr(type(out), "__module__", "") or ""
        if out_mod.startswith("polars"):
            out_type_name = type(out).__name__

            # Collect ``pl.LazyFrame`` to ``pl.DataFrame`` so we can attach
            # an eager boolean column to the original frame. Polars-style
            # user checks routinely return a ``pl.LazyFrame``.
            if out_type_name == "LazyFrame":
                out = out.collect()
                out_type_name = type(out).__name__

            native = nw.to_native(check_obj.frame)
            # native may be a LazyFrame; collect to attach an eager column.
            if hasattr(native, "collect"):
                native = native.collect()

            if out_type_name == "Series":
                bool_col = out.alias(CHECK_OUTPUT_KEY)
            elif out_type_name == "DataFrame":
                out_cols = list(out.columns)
                if CHECK_OUTPUT_KEY in out_cols:
                    bool_col = out[CHECK_OUTPUT_KEY].alias(CHECK_OUTPUT_KEY)
                elif len(out_cols) == 1:
                    # Single-column boolean output — rename to the canonical
                    # check-output key (matches ``PolarsCheckBackend.apply``).
                    bool_col = out.to_series(0).alias(CHECK_OUTPUT_KEY)
                else:
                    # Multi-column boolean output — AND-reduce to a single
                    # check-output column (matches ``PolarsCheckBackend.apply``)
                    # using narwhals operators so this file stays
                    # polars-agnostic.
                    nw_out = nw.from_native(out, eager_only=True)
                    reduced_native = nw.to_native(
                        nw_out.select(
                            nw.all_horizontal(
                                [nw.col(c) for c in out_cols]
                            ).alias(CHECK_OUTPUT_KEY)
                        )
                    )
                    bool_col = reduced_native.to_series(0)
            else:  # pragma: no cover — unexpected polars type
                return out

            # A one-row result from a multi-row input is an aggregate boolean,
            # not a row-level mask.  Treat it like a scalar check so that the
            # output is not attached to the input frame as a length-mismatched
            # column.  This mirrors the native Polars backend, where a
            # one-row result is reduced by ``check_passed.all()``.
            if native.height > 1 and len(bool_col) == 1:
                return bool(bool_col.item())

            return nw.from_native(
                native.with_columns(bool_col), eager_only=True
            )

        # Handle pyarrow native return types from native=True checks. As with
        # polars above, pyarrow is not imported at module level so ibis-only /
        # polars-only installs keep working — detection is by module name.
        if out_mod.startswith("pyarrow"):
            out_type_name = type(out).__name__

            if out_type_name == "Table":
                return nw.from_native(out, eager_only=True)

            if out_type_name.endswith("Scalar"):
                # Aggregate boolean result — hand back a plain Python bool.
                return bool(out.as_py())

            if out_type_name.endswith(("Array", "ChunkedArray")):
                # Row-level boolean output — attach it to the original table as
                # ``CHECK_OUTPUT_KEY`` to build a wide frame, mirroring the
                # polars branch above.
                from pandera.api.narwhals.utils import _materialize

                native = nw.to_native(_materialize(check_obj.frame))
                tbl = native.append_column(CHECK_OUTPUT_KEY, out)
                return nw.from_native(tbl, eager_only=True)

            return out  # pragma: no cover — unexpected pyarrow type

        # Handle pandas-like native return types (pandas, modin, cuDF) from
        # native=True checks: boolean Series / DataFrame outputs are attached
        # to the original frame as CHECK_OUTPUT_KEY, mirroring the polars
        # handling above. Detection is module based so pandas is not
        # imported on pandas-free installs.
        if _is_pandas_like_module(out_mod):
            out_type_name = type(out).__name__
            native = nw.to_native(check_obj.frame)

            if out_type_name == "Series":
                bool_series = out
            elif out_type_name == "DataFrame":
                if CHECK_OUTPUT_KEY in out.columns:
                    bool_series = out[CHECK_OUTPUT_KEY]
                else:
                    # Multi-column boolean output — AND-reduce to a single
                    # check-output column (matches the native pandas backend
                    # and the polars handling above).
                    bool_series = out.all(axis=1)
            else:  # pragma: no cover — unexpected pandas-like type
                return out

            native = native.assign(**{CHECK_OUTPUT_KEY: bool_series})
            return nw.from_native(native, eager_only=True)

        # Handle numpy return types from pandas-style checks:
        # - 0-d bool scalars (e.g. ``(series > 0).all()`` returns np.bool_)
        #   → plain Python bool, handled by postprocess_bool_output.
        # - 1-d boolean arrays → attached positionally as CHECK_OUTPUT_KEY.
        if out_mod.startswith("numpy"):
            out_type_name = type(out).__name__
            # numpy 1.x names the scalar bool type "bool_"; numpy 2.x "bool".
            if out_type_name in ("bool_", "bool"):
                return bool(out)
            if (
                out_type_name == "ndarray"
                and getattr(out, "dtype", None) is not None
                and out.dtype.kind == "b"
            ):
                native = nw.to_native(check_obj.frame)
                if hasattr(native, "assign"):
                    native = native.assign(**{CHECK_OUTPUT_KEY: out})
                    return nw.from_native(native, eager_only=True)

        return out  # bool or other scalar — handled by postprocess_bool_output

    def postprocess(self, check_obj: NarwhalsData, check_output):
        """Postprocesses the result of applying the check function."""
        if isinstance(check_output, nw.Expr):
            return self.postprocess_expr_output(check_obj, check_output)
        elif isinstance(check_output, (nw.LazyFrame, nw.DataFrame)):
            return self.postprocess_lazyframe_output(check_obj, check_output)
        elif isinstance(check_output, bool):
            return self.postprocess_bool_output(check_obj, check_output)
        raise TypeError(
            f"output type of check_fn not recognized: {type(check_output)}"
        )

    def postprocess_expr_output(
        self,
        check_obj: NarwhalsData,
        expr: nw.Expr,
    ) -> CheckResult:
        """Postprocesses nw.Expr check output into a CheckResult.

        Stores the original expr as check_output and defers failure_cases
        computation entirely — no wide table is built during the check loop.

        When drop_invalid_rows=True: failure_cases are never needed, so
        this avoids all per-check materialization.
        When SchemaErrors is raised: failure_cases_metadata() in base.py
        reconstructs them from the stored expr exactly once.

        check_passed is computed via a single-column select+aggregate
        (frame.select(expr) → apply ignore_na on column → .select(.all()))
        rather than frame.with_columns(expr) which keeps all original columns.

        ignore_na is applied at the column level AFTER evaluation rather than
        as expr | expr.is_null() — the latter causes ibis to produce incorrect
        SQL (isnull() on an expression before binding returns True for all rows
        on some SQL backends, because the expression is treated as nullable).

        For pandas-like frames, ignore_na additionally ORs in the *input*
        column's nullness: pandas comparisons on NaN yield False instead of
        propagating null (unlike polars/ibis), so output-nullness alone would
        treat missing values as check failures.
        """
        frame = check_obj.frame
        key = check_obj.key
        # Evaluate expr to a single-column frame, then apply ignore_na on
        # the concrete column values where is_null() works correctly.
        select_exprs = [expr.alias(CHECK_OUTPUT_KEY)]
        include_input_null = _use_input_nullness(
            self.check.ignore_na, frame, key
        )
        if include_input_null:
            select_exprs.append(nw.col(key).is_null().alias(_INPUT_NULL_KEY))
        check_col = frame.select(*select_exprs)
        if self.check.ignore_na:
            na_pass = (
                nw.col(CHECK_OUTPUT_KEY) | nw.col(CHECK_OUTPUT_KEY).is_null()
            )
            if include_input_null:
                na_pass = na_pass | nw.col(_INPUT_NULL_KEY)
            check_col = check_col.with_columns(na_pass.alias(CHECK_OUTPUT_KEY))
        passed = check_col.select(nw.col(CHECK_OUTPUT_KEY).all())
        return CheckResult(
            check_output=expr,  # Store ONLY the expr — failure_cases deferred
            check_passed=passed,
            checked_object=check_obj,
            failure_cases=None,  # Computed later in failure_cases_metadata()
        )

    def postprocess_lazyframe_output(
        self,
        check_obj: NarwhalsData,
        check_output,
    ) -> CheckResult:
        """Postprocesses LazyFrame check output into a CheckResult."""
        # check_output is the wide table (frame + CHECK_OUTPUT_KEY column). Stay lazy.
        if self.check.ignore_na:
            na_pass = (
                nw.col(CHECK_OUTPUT_KEY) | nw.col(CHECK_OUTPUT_KEY).is_null()
            )
            if _use_input_nullness(
                self.check.ignore_na, check_output, check_obj.key
            ):
                # pandas-like: NaN comparisons yield False, not null — OR in
                # the input column's nullness (the wide table still carries
                # the original columns).
                na_pass = na_pass | nw.col(check_obj.key).is_null()
            check_output = check_output.with_columns(
                na_pass.alias(CHECK_OUTPUT_KEY)
            )
        passed = check_output.select(nw.col(CHECK_OUTPUT_KEY).all())
        failure_cases = check_output.filter(~nw.col(CHECK_OUTPUT_KEY))

        if check_obj.key != "*":
            failure_cases = failure_cases.select(check_obj.key)
        if self.check.n_failure_cases is not None:
            failure_cases = failure_cases.head(self.check.n_failure_cases)

        return CheckResult(
            check_output=check_output,
            check_passed=passed,
            checked_object=check_obj,
            failure_cases=failure_cases,
        )

    def postprocess_bool_output(
        self,
        check_obj: NarwhalsData,
        check_output: bool,
    ) -> CheckResult:
        """Postprocesses bool check output into a CheckResult."""
        # SQL-lazy backends (ibis) do not support nw.from_dict with their
        # native namespace — fall back to pyarrow as the eager intermediate.
        try:
            ns = nw.get_native_namespace(check_obj.frame)
            lf = nw.from_dict(
                {CHECK_OUTPUT_KEY: [check_output]}, native_namespace=ns
            ).lazy()
        except (ValueError, AttributeError):
            lf = nw.from_dict(
                {CHECK_OUTPUT_KEY: [check_output]}, backend="pyarrow"
            ).lazy()
        return CheckResult(
            check_output=lf,
            check_passed=lf,
            checked_object=check_obj,
            failure_cases=None,
        )

    def __call__(
        self,
        check_obj,
        key: str | None = None,
    ) -> CheckResult:
        # Accept either a Narwhals frame (the usual path from
        # ``schema.validate``) or a native frame (e.g. ``pl.LazyFrame`` /
        # ``ibis.Table``) so that direct check invocations
        # — ``pa.Check(fn)(native_frame, column=…)`` — work identically to
        # the native polars/ibis backends.
        if not isinstance(check_obj, (nw.LazyFrame, nw.DataFrame)):
            check_obj = nw.from_native(
                check_obj, eager_or_interchange_only=False
            )
        check_obj = self.preprocess(check_obj, key)
        narwhals_data = NarwhalsData(check_obj, key or "*")
        check_output = self.apply(narwhals_data)
        return self.postprocess(narwhals_data, check_output)
