from __future__ import annotations

import asyncio
import contextvars
import datetime
import logging
import multiprocessing
import multiprocessing.context
import os
import signal
import sys
import threading
import time
from collections.abc import Mapping
from contextlib import (
    AsyncExitStack,
    ExitStack,
    asynccontextmanager,
    contextmanager,
    nullcontext,
)
from dataclasses import dataclass, field
from functools import wraps
from typing import (
    Any,
    AsyncGenerator,
    Coroutine,
    Dict,
    Generator,
    Generic,
    Iterable,
    Literal,
    Optional,
    Type,
    TypeVar,
    Union,
    cast,
)
from uuid import UUID

import anyio
from anyio import CancelScope
from opentelemetry import propagate, trace
from typing_extensions import ParamSpec

from prefect import Task, __version__
from prefect._flow_run_suspension import (
    FlowRunSuspensionRequest,
    is_suspended_flow_run_state,
    observe_flow_run_suspension,
    raise_if_flow_run_suspension_requested,
    register_flow_run_suspension_request,
)
from prefect._internal.attempt_control import EngineOutcomeReceipt
from prefect._internal.compatibility.deprecated import deprecated_callable
from prefect._internal.control_listener import (
    Intent,
    configure_from_env,
    get_intent,
    report_engine_outcome,
)
from prefect._internal.engine import get_hook_name, resolve_custom_flow_run_name
from prefect._internal.metrics import RunMetrics
from prefect.client.orchestration import PrefectClient, SyncPrefectClient, get_client
from prefect.client.schemas import FlowRun, TaskRun
from prefect.client.schemas.filters import FlowRunFilter
from prefect.client.schemas.sorting import FlowRunSort
from prefect.concurrency._leases import (
    amaintain_concurrency_lease,
    maintain_concurrency_lease,
)
from prefect.concurrency.context import ConcurrencyContext
from prefect.concurrency.v1.context import ConcurrencyContext as ConcurrencyContextV1
from prefect.context import (
    AsyncClientContext,
    FlowRunContext,
    SettingsContext,
    SyncClientContext,
    TagsContext,
    _deployment_id,
    _deployment_parameters,
    get_settings_context,
    hydrated_context,
    serialize_context,
)
from prefect.engine import _drive_run_flow_result, handle_engine_signals
from prefect.events.related import RelatedResource, tags_as_related_resources
from prefect.events.utilities import emit_event
from prefect.exceptions import (
    Abort,
    MissingFlowError,
    Pause,
    PrefectException,
    TerminationSignal,
    UpstreamTaskError,
)
from prefect.flows import (
    Flow,
    load_flow_from_entrypoint,
    load_flow_from_flow_run,
    load_function_and_convert_to_flow,
)
from prefect.futures import PrefectFuture, resolve_futures_to_states
from prefect.logging.loggers import (
    flow_run_logger,
    get_logger,
    get_run_logger,
    patch_print,
)
from prefect.results import (
    ResultStore,
    _aget_default_persist_result,
    _get_default_persist_result,
    get_result_store,
    should_persist_result,
)
from prefect.settings import PREFECT_DEBUG_MODE
from prefect.settings.context import get_current_settings
from prefect.settings.models.root import Settings
from prefect.states import (
    Cancelled,
    Cancelling,
    Failed,
    Pending,
    Running,
    State,
    exception_to_crashed_state,
    exception_to_failed_state,
    return_value_to_state,
)
from prefect.telemetry.run_telemetry import (
    LABELS_TRACEPARENT_KEY,
    TRACEPARENT_KEY,
    OTELSetter,
    RunTelemetry,
)
from prefect.types import KeyValueLabels
from prefect.utilities.annotations import NotSet
from prefect.utilities.asyncutils import run_coro_as_sync
from prefect.utilities.callables import (
    _run_serialized_call,
    call_with_parameters,
    cloudpickle_wrapped_call,
    get_call_parameters,
    parameters_to_args_kwargs,
)
from prefect.utilities.collections import visit_collection
from prefect.utilities.engine import (
    capture_sigterm,
    link_state_to_flow_run_result,
    propose_state,
    propose_state_sync,
    resolve_to_final_result,
)
from prefect.utilities.processutils import sanitize_subprocess_env
from prefect.utilities.timeout import timeout, timeout_async
from prefect.utilities.urls import url_for

P = ParamSpec("P")
R = TypeVar("R")

MINIMUM_HEARTBEAT_INTERVAL = 30
_engine_logger = get_logger("engine")
_CONTROL_CHANNEL_ENV_KEYS = frozenset(
    {"PREFECT__CONTROL_PORT", "PREFECT__CONTROL_TOKEN"}
)


def _run_serialized_call_with_control_bootstrap(
    payload: bytes,
    startup_env: dict[str, str] | None = None,
) -> bytes:
    """Consume control-channel bootstrap env before deserializing payload."""
    if startup_env:
        os.environ.update(startup_env)

    configure_from_env()
    return _run_serialized_call(payload)


def _runtime_subprocess_env(
    env: Mapping[str, str | None] | None,
) -> dict[str, str]:
    """Remove one-shot control-channel bootstrap vars from runtime child env."""
    sanitized_env = sanitize_subprocess_env(env)
    return {
        key: value
        for key, value in sanitized_env.items()
        if key not in _CONTROL_CHANNEL_ENV_KEYS
    }


def _termination_intent() -> Intent | None:
    """Return the runner-delivered control intent for an in-flight
    `TerminationSignal`, if any.

    The single source of truth is the control listener's intent flag,
    which the runner sets via the loopback channel before sending the kill.
    Reading at exception-handling time (rather than via a ContextVar set
    during the signal handler) avoids token-reset races and works uniformly
    for the outermost flow run as well as nested subflows running in the
    same process.

    Adding an intent means extending `Intent` in
    `prefect._internal.control_listener` and the `except TerminationSignal`
    dispatch below with a matching branch.
    """
    return get_intent()


# Intents where the `prefect flow-run execute` supervisor owns the run's next state
# (`reschedule` proposes it; `relinquish` leaves it to retrying infrastructure), so
# the engine must exit without proposing one.
_SUPERVISOR_OWNED_INTENTS: frozenset[Intent] = frozenset({"reschedule", "relinquish"})


def _is_async_runtime_cancellation(exc: BaseException) -> bool:
    """Return whether an async exception represents runtime task cancellation."""
    try:
        return isinstance(exc, anyio.get_cancelled_exc_class())
    except RuntimeError:
        return False


class FlowRunTimeoutError(TimeoutError):
    """Raised when a flow run exceeds its defined timeout."""


def load_flow_run(flow_run_id: UUID) -> FlowRun:
    client = get_client(sync_client=True)
    flow_run = client.read_flow_run(flow_run_id)
    return flow_run


def _load_flow_from_runtime_entrypoint(entrypoint: str) -> Flow[..., Any]:
    try:
        return load_flow_from_entrypoint(entrypoint, use_placeholder_flow=False)
    except MissingFlowError:
        return load_function_and_convert_to_flow(entrypoint)


def load_flow(flow_run: FlowRun) -> Flow[..., Any]:
    entrypoint = os.environ.get("PREFECT__FLOW_ENTRYPOINT")

    if entrypoint:
        flow = _load_flow_from_runtime_entrypoint(entrypoint)
    else:
        flow = run_coro_as_sync(
            load_flow_from_flow_run(flow_run, use_placeholder_flow=False)
        )
    return flow


def load_flow_and_flow_run(flow_run_id: UUID) -> tuple[FlowRun, Flow[..., Any]]:
    flow_run = load_flow_run(flow_run_id)
    flow = load_flow(flow_run)
    return flow_run, flow


def _run_flow_from_runtime_entrypoint(flow_run_id: UUID, entrypoint: str) -> None:
    configure_from_env()

    with handle_engine_signals(flow_run_id):
        flow_run = load_flow_run(flow_run_id=flow_run_id)
        run_logger = flow_run_logger(flow_run=flow_run)

        try:
            flow = _load_flow_from_runtime_entrypoint(entrypoint)
        except Exception:
            run_logger.error(
                "Unexpected exception encountered when trying to load flow",
                exc_info=True,
            )
            raise

        with RunMetrics(flow_run, flow):
            run_result = run_flow(flow, flow_run=flow_run, error_logger=run_logger)
            _drive_run_flow_result(flow, run_result)


def _main(argv: list[str] | None = None) -> int:
    args = sys.argv[1:] if argv is None else argv
    if len(args) != 1:
        _engine_logger.error(
            "Invalid flow entrypoint. Expected one argument; received: %s", args
        )
        return 1

    flow_run_id_value = os.environ.get("PREFECT__FLOW_RUN_ID")
    try:
        flow_run_id = UUID(flow_run_id_value) if flow_run_id_value else None
    except ValueError:
        flow_run_id = None

    if flow_run_id is None:
        _engine_logger.error(
            "Invalid flow run id. Expected PREFECT__FLOW_RUN_ID to contain a UUID."
        )
        return 1

    _run_flow_from_runtime_entrypoint(flow_run_id, args[0])
    return 0


@contextmanager
def _send_heartbeats(
    engine: "BaseFlowRunEngine[Any, Any]",
    join_on_exit: bool = True,
) -> Generator[None, None, None]:
    """Context manager that maintains heartbeats for a flow run using a daemon thread.

    Uses a background OS thread instead of an asyncio task so that heartbeats
    fire even when the event loop is blocked by CPU-bound work.

    Args:
        engine: The flow run engine instance to emit heartbeats for.
        join_on_exit: Whether to join the heartbeat thread on exit. Set to
            `False` in async engines to avoid blocking the event loop.

    Yields:
        None
    """
    heartbeat_seconds = engine.heartbeat_seconds
    if heartbeat_seconds is None:
        yield
        return
    heartbeat_seconds = max(heartbeat_seconds, MINIMUM_HEARTBEAT_INTERVAL)

    # Pre-compute the event template once to minimize per-heartbeat GIL hold time
    resource, related = engine._build_heartbeat_event_template()

    stop_event = threading.Event()

    def heartbeat_loop() -> None:
        while not stop_event.is_set():
            # Check state before emitting - don't emit if final
            if (
                engine.flow_run
                and engine.flow_run.state
                and engine.flow_run.state.is_final()
            ):
                engine.logger.debug("Flow run in terminal state, stopping heartbeat")
                return

            try:
                engine._emit_flow_run_heartbeat(resource, related)
            except Exception:
                engine.logger.debug("Failed to emit heartbeat", exc_info=True)

            # Sleep in increments to allow quick shutdown
            for _ in range(heartbeat_seconds):
                if stop_event.is_set():
                    return
                time.sleep(1)

    # Copy the current context so the heartbeat thread sees the same
    # `SettingsContext` (and therefore the same `PREFECT_API_URL`) as the
    # calling thread. Without this, `threading.Thread` starts with an empty
    # context and `SettingsContext.get()` falls back to the process-wide
    # `GLOBAL_SETTINGS_CONTEXT`, which is initialized at import time and can
    # have a stale `api.url=None`. That caused `EventsWorker.instance()` from
    # the heartbeat path to spawn an ephemeral `SubprocessASGIServer` during
    # flow teardown, racing with interpreter shutdown and aborting the
    # process.
    heartbeat_ctx = contextvars.copy_context()
    thread = threading.Thread(
        target=heartbeat_ctx.run, args=(heartbeat_loop,), daemon=True
    )
    thread.start()
    engine.logger.debug("Started flow run heartbeat context")

    try:
        yield
    finally:
        stop_event.set()
        if join_on_exit:
            thread.join(timeout=2)
        engine.logger.debug("Stopped flow run heartbeat context")


@deprecated_callable(
    start_date=datetime.datetime(2026, 3, 1),
    help="Use `_send_heartbeats` instead.",
)
@contextmanager
def send_heartbeats_sync(
    engine: "FlowRunEngine[Any, Any]",
) -> Generator[None, None, None]:
    with _send_heartbeats(engine, join_on_exit=True):
        yield


@deprecated_callable(
    start_date=datetime.datetime(2026, 3, 1),
    help="Use `_send_heartbeats` instead.",
)
@asynccontextmanager
async def send_heartbeats_async(
    engine: "AsyncFlowRunEngine[Any, Any]",
) -> AsyncGenerator[None, None]:
    with _send_heartbeats(engine, join_on_exit=False):
        yield


@dataclass
class BaseFlowRunEngine(Generic[P, R]):
    flow: Union[Flow[P, R], Flow[P, Coroutine[Any, Any, R]]]
    parameters: Optional[Dict[str, Any]] = None
    flow_run: Optional[FlowRun] = None
    flow_run_id: Optional[UUID] = None
    logger: logging.Logger = field(default_factory=lambda: get_logger("engine"))
    wait_for: Optional[Iterable[PrefectFuture[Any]]] = None
    context: Optional[dict[str, Any]] = None
    # holds the return value from the user code
    _return_value: Union[R, Type[NotSet]] = NotSet
    # holds the exception raised by the user code, if any
    _raised: Union[Exception, Type[NotSet]] = NotSet
    _is_started: bool = False
    short_circuit: bool = False
    _flow_run_name_set: bool = False
    _started_with_in_process_parent_flow_run_context: bool = False
    _telemetry: RunTelemetry = field(default_factory=RunTelemetry)
    _flow_run_suspension_request: FlowRunSuspensionRequest = field(
        default_factory=FlowRunSuspensionRequest
    )
    _attempt_conclusion: EngineOutcomeReceipt | None = field(default=None, init=False)

    def __post_init__(self) -> None:
        if self.flow is None and self.flow_run_id is None:
            raise ValueError("Either a flow or a flow_run_id must be provided.")

        if self.parameters is None:
            self.parameters = {}

    @property
    def state(self) -> State:
        return self.flow_run.state  # type: ignore

    def is_running(self) -> bool:
        if getattr(self, "flow_run", None) is None:
            return False
        return getattr(self, "flow_run").state.is_running()

    def is_pending(self) -> bool:
        if getattr(self, "flow_run", None) is None:
            return False  # TODO: handle this differently?
        return getattr(self, "flow_run").state.is_pending()

    @property
    def heartbeat_seconds(self) -> Optional[int]:
        """Get the heartbeat interval from settings."""
        value = get_current_settings().flows.heartbeat_frequency
        if value is not None:
            return max(value, MINIMUM_HEARTBEAT_INTERVAL)
        return value

    def cancel_all_tasks(self) -> None:
        if hasattr(self.flow.task_runner, "cancel_all"):
            self.flow.task_runner.cancel_all()  # type: ignore

    def _capture_state_report(self, state: State) -> None:
        if (
            (state.is_final() or state.is_paused())
            and state.id is not None
            and state.name is not None
        ):
            self._attempt_conclusion = EngineOutcomeReceipt.state_reported(
                state_id=state.id,
                state_type=state.type.value,
                state_name=state.name,
            )
        else:
            self._attempt_conclusion = None

    def _report_attempt_conclusion(self) -> None:
        if (
            not self._started_with_in_process_parent_flow_run_context
            and self._attempt_conclusion is not None
        ):
            report_engine_outcome(self._attempt_conclusion)

    def _build_heartbeat_event_template(
        self,
    ) -> tuple[dict[str, str], list[RelatedResource]]:
        """Pre-compute the heartbeat event resource and related list.

        Called once before starting the heartbeat thread to avoid repeated
        Pydantic validation (RelatedResource.model_validate) on every tick.
        """
        resource: dict[str, str] = {}
        related: list[RelatedResource] = []

        if not self.flow_run:
            return resource, related

        resource = {
            "prefect.resource.id": f"prefect.flow-run.{self.flow_run.id}",
            "prefect.resource.name": self.flow_run.name or "",
            "prefect.version": __version__,
        }

        tags: list[str] = list(self.flow_run.tags or [])

        if self.flow_run.flow_id:
            related.append(
                RelatedResource.model_validate(
                    {
                        "prefect.resource.id": f"prefect.flow.{self.flow_run.flow_id}",
                        "prefect.resource.role": "flow",
                        "prefect.resource.name": self.flow.name if self.flow else "",
                    }
                )
            )

        if self.flow_run.deployment_id:
            related.append(
                RelatedResource.model_validate(
                    {
                        "prefect.resource.id": f"prefect.deployment.{self.flow_run.deployment_id}",
                        "prefect.resource.role": "deployment",
                    }
                )
            )

        related += tags_as_related_resources(set(tags))

        return resource, related

    def _emit_flow_run_heartbeat(
        self,
        resource: dict[str, str] | None = None,
        related: list[RelatedResource] | None = None,
    ) -> None:
        """Emit a heartbeat event for the current flow run.

        Args:
            resource: Pre-computed resource dict from _build_heartbeat_event_template.
            related: Pre-computed related list from _build_heartbeat_event_template.
                If not provided, builds the template on the fly (backward compat).
        """
        if not self.flow_run:
            return

        if resource is None or related is None:
            resource, related = self._build_heartbeat_event_template()

        emit_event(
            event="prefect.flow-run.heartbeat",
            resource=resource,
            related=related,
        )

    def _update_otel_labels(
        self, span: trace.Span, client: Union[SyncPrefectClient, PrefectClient]
    ):
        parent_flow_run_ctx = FlowRunContext.get()

        if parent_flow_run_ctx and parent_flow_run_ctx.flow_run:
            if traceparent := parent_flow_run_ctx.flow_run.labels.get(
                LABELS_TRACEPARENT_KEY
            ):
                carrier: KeyValueLabels = {TRACEPARENT_KEY: traceparent}
                propagate.get_global_textmap().inject(
                    carrier={TRACEPARENT_KEY: traceparent},
                    setter=OTELSetter(),
                )

            else:
                carrier: KeyValueLabels = {}
                propagate.get_global_textmap().inject(
                    carrier,
                    context=trace.set_span_in_context(span),
                    setter=OTELSetter(),
                )
            if carrier.get(TRACEPARENT_KEY):
                if self.flow_run:
                    client.update_flow_run_labels(
                        flow_run_id=self.flow_run.id,
                        labels={LABELS_TRACEPARENT_KEY: carrier[TRACEPARENT_KEY]},
                    )
                else:
                    self.logger.info(
                        f"Tried to set traceparent {carrier[TRACEPARENT_KEY]} for flow run, but None was found"
                    )

    def _engine_owns_cancellation_handling(self) -> bool:
        """Return whether this engine owns cancellation state and hooks.

        Runner-managed subprocesses set `PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS=false`
        and retain ownership of acknowledged cancellation state and hooks.
        Engine-reported Crashed states are different: their hooks remain
        engine-owned and are not governed by this switch. Same-process nested
        subflows have no external supervisor, so the engine ignores suppression
        when it started inside a non-detached parent `FlowRunContext`. Top-level
        non-runner flows also fall through to engine ownership because the env
        defaults to enabled.
        """

        return self._started_with_in_process_parent_flow_run_context or (
            os.environ.get(
                "PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS", "true"
            ).lower()
            == "true"
        )

    def _get_flow_run_suspension_request(self) -> FlowRunSuspensionRequest:
        parent_flow_run_context = FlowRunContext.get()
        if parent_flow_run_context:
            return parent_flow_run_context.flow_run_suspension_request
        return self._flow_run_suspension_request

    @contextmanager
    def setup_flow_run_suspension_request(
        self,
    ) -> Generator[FlowRunSuspensionRequest, None, None]:
        if not self.flow_run:
            raise ValueError("Flow run not set")

        flow_run_suspension_request = self._get_flow_run_suspension_request()
        with ExitStack() as stack:
            stack.enter_context(
                register_flow_run_suspension_request(
                    self.flow_run.id, flow_run_suspension_request
                )
            )
            if self.flow_run.deployment_id:
                stack.enter_context(
                    observe_flow_run_suspension(
                        self.flow_run.id, flow_run_suspension_request
                    )
                )

            flow_run_suspension_request.raise_if_requested()
            yield flow_run_suspension_request


@dataclass
class FlowRunEngine(BaseFlowRunEngine[P, R]):
    _client: Optional[SyncPrefectClient] = None
    flow_run: FlowRun | None = None
    parameters: dict[str, Any] | None = None

    @property
    def client(self) -> SyncPrefectClient:
        if not self._is_started or self._client is None:
            raise RuntimeError("Engine has not started.")
        return self._client

    def _resolve_parameters(self):
        if not self.parameters:
            return

        resolved_parameters = {}
        for parameter, value in self.parameters.items():
            try:
                resolved_parameters[parameter] = visit_collection(
                    value,
                    visit_fn=resolve_to_final_result,
                    return_data=True,
                    max_depth=-1,
                    remove_annotations=True,
                    context={"parameter_name": parameter},
                )
            except UpstreamTaskError:
                raise
            except Exception as exc:
                raise PrefectException(
                    f"Failed to resolve inputs in parameter {parameter!r}. If your"
                    " parameter type is not supported, consider using the `quote`"
                    " annotation to skip resolution of inputs."
                ) from exc

        self.parameters = resolved_parameters

    def _wait_for_dependencies(self):
        if not self.wait_for:
            return

        visit_collection(
            self.wait_for,
            visit_fn=resolve_to_final_result,
            return_data=False,
            max_depth=-1,
            remove_annotations=True,
            context={},
        )

    def begin_run(self) -> State:
        try:
            self._resolve_parameters()
            self._wait_for_dependencies()
        except UpstreamTaskError as upstream_exc:
            state = self.set_state(
                Pending(
                    name="NotReady",
                    message=str(upstream_exc),
                ),
                # if orchestrating a run already in a pending state, force orchestration to
                # update the state name
                force=self.state.is_pending(),
            )
            return state

        # validate prior to context so that context receives validated params
        if self.flow.should_validate_parameters:
            try:
                self.parameters = self.flow.validate_parameters(self.parameters or {})
            except Exception as exc:
                message = "Validation of flow parameters failed with error:"
                self.logger.error("%s %s", message, exc)
                self.handle_exception(
                    exc,
                    msg=message,
                    result_store=get_result_store().update_for_flow(
                        self.flow, _sync=True
                    ),
                )
                self.short_circuit = True

        if (
            not self.short_circuit
            and not self._flow_run_name_set
            and self.flow.flow_run_name
        ):
            if self.flow_run is None:
                raise ValueError("Flow run not set")

            with FlowRunContext(
                flow=self.flow,
                flow_run=self.flow_run,
                parameters=self.parameters,
                client=self.client,
                task_runner=self.flow.task_runner,
                result_store=get_result_store().update_for_flow(self.flow, _sync=True),
            ):
                flow_run_name = resolve_custom_flow_run_name(
                    flow=self.flow, parameters=self.parameters or {}
                )
            self.client.set_flow_run_name(
                flow_run_id=self.flow_run.id, name=flow_run_name
            )
            self.flow_run.name = flow_run_name
            self._flow_run_name_set = True
            self._telemetry.update_run_name(name=flow_run_name)

        self._get_flow_run_suspension_request().raise_if_requested()
        new_state = Running()
        state = self.set_state(new_state)
        while state.is_pending():
            time.sleep(0.2)
            state = self.set_state(new_state)
        return state

    def set_state(self, state: State, force: bool = False) -> State:
        """ """
        # prevents any state-setting activity
        if self.short_circuit:
            return self.state

        state = propose_state_sync(
            self.client, state, flow_run_id=self.flow_run.id, force=force
        )  # type: ignore
        self.flow_run.state = state  # type: ignore
        self.flow_run.state_name = state.name  # type: ignore
        self.flow_run.state_type = state.type  # type: ignore

        self._capture_state_report(state)
        self._telemetry.update_state(state)
        self.call_hooks(state)

        return state

    def result(self, raise_on_failure: bool = True) -> "Union[R, State, None]":
        if self._return_value is not NotSet and not isinstance(
            self._return_value, State
        ):
            _result = self._return_value
            link_state_to_flow_run_result(self.state, _result)

            if asyncio.iscoroutine(_result):
                # getting the value for a BaseResult may return an awaitable
                # depending on whether the parent frame is sync or not
                _result = run_coro_as_sync(_result)
            return _result

        if self._raised is not NotSet:
            if raise_on_failure:
                raise self._raised
            return self._raised

        # This is a fall through case which leans on the existing state result mechanics to get the
        # return value. This is necessary because we currently will return a State object if the
        # the State was Prefect-created.
        # TODO: Remove the need to get the result from a State except in cases where the return value
        # is a State object.
        _result = self.state.result(raise_on_failure=raise_on_failure, _sync=True)  # type: ignore
        return _result

    def handle_success(self, result: R) -> R:
        raise_if_flow_run_suspension_requested()
        result_store = getattr(FlowRunContext.get(), "result_store", None)
        if result_store is None:
            raise ValueError("Result store is not set")
        resolved_result = resolve_futures_to_states(result)
        terminal_state = run_coro_as_sync(
            return_value_to_state(
                resolved_result,
                result_store=result_store,
                write_result=should_persist_result(),
            )
        )
        raise_if_flow_run_suspension_requested()
        self.set_state(terminal_state)
        self._return_value = resolved_result

        link_state_to_flow_run_result(terminal_state, resolved_result)
        self._telemetry.end_span_on_success()

        # Track first flow run milestone for analytics
        try:
            from prefect._internal.analytics import try_mark_milestone

            try_mark_milestone("first_flow_run")
        except Exception:
            pass

        return result

    def handle_exception(
        self,
        exc: Exception,
        msg: Optional[str] = None,
        result_store: Optional[ResultStore] = None,
    ) -> State:
        self._get_flow_run_suspension_request().raise_if_requested()
        context = FlowRunContext.get()
        terminal_state = cast(
            State,
            run_coro_as_sync(
                exception_to_failed_state(
                    exc,
                    message=msg or "Flow run encountered an exception:",
                    result_store=result_store or getattr(context, "result_store", None),
                    write_result=True,
                )
            ),
        )
        self._get_flow_run_suspension_request().raise_if_requested()
        state = self.set_state(terminal_state)
        if self.state.is_scheduled():
            self.logger.info(
                (
                    f"Received non-final state {state.name!r} when proposing final"
                    f" state {terminal_state.name!r} and will attempt to run again..."
                ),
            )
            self._get_flow_run_suspension_request().raise_if_requested()
            state = self.set_state(Running())
        self._raised = exc
        self._telemetry.record_exception(exc)
        self._telemetry.end_span_on_failure(state.message)

        return state

    def handle_timeout(self, exc: TimeoutError) -> None:
        if isinstance(exc, FlowRunTimeoutError):
            message = (
                f"Flow run exceeded timeout of {self.flow.timeout_seconds} second(s)"
            )
        else:
            message = f"Flow run failed due to timeout: {exc!r}"
        self.logger.error(message)
        self._get_flow_run_suspension_request().raise_if_requested()
        state = Failed(
            data=exc,
            message=message,
            name="TimedOut",
        )
        self.set_state(state)
        if self.state.is_scheduled():
            self.logger.info(
                f"Received non-final state {self.state.name!r} when proposing final"
                f" state {state.name!r} and will attempt to run again..."
            )
            self._get_flow_run_suspension_request().raise_if_requested()
            self.set_state(Running())
            return
        self._raised = exc
        self._telemetry.record_exception(exc)
        self._telemetry.end_span_on_failure(message)

    def handle_crash(self, exc: BaseException) -> None:
        state = run_coro_as_sync(exception_to_crashed_state(exc))
        self.logger.error(f"Crash detected! {state.message}")
        self.logger.debug("Crash details:", exc_info=exc)
        self.set_state(state, force=True)
        self._raised = exc
        self._telemetry.record_exception(exc)
        self._telemetry.end_span_on_failure(state.message if state else None)

    def handle_cancellation(self, exc: BaseException) -> None:
        """Force this run through Cancelling -> Cancelled.

        Used when `capture_sigterm` has determined (via the cancellation
        listener) that the SIGTERM was the runner asking for cancellation,
        not an unrelated termination. The same ownership rule governs the
        `on_cancellation` hook: if the engine owns cancellation handling, it
        must drive `Cancelling -> Cancelled` and run the hook locally; if an
        external runner owns cancellation, the child avoids duplicating state
        history and hooks. Engine-reported Crashed states and `on_crashed`
        hooks always remain engine-owned.
        """
        msg = "Flow run was cancelled."
        self.logger.info(msg)
        if self._engine_owns_cancellation_handling():
            self.set_state(Cancelling(message=msg), force=True)
            self.set_state(Cancelled(message=msg), force=True)
        self._raised = exc
        self._telemetry.record_exception(exc)
        self._telemetry.end_span_on_failure(msg)

    def load_subflow_run(
        self,
        parent_task_run: TaskRun,
        client: SyncPrefectClient,
        context: FlowRunContext,
    ) -> Union[FlowRun, None]:
        """
        This method attempts to load an existing flow run for a subflow task
        run, if appropriate.

        If the parent task run is in a final state, we return the existing
        subflow run unless the parent is being rerun and the subflow either
        did not complete or has no persisted result. In those cases a fresh
        run gives the subflow its full retry budget while preserving the
        previous run's history.

        If the parent task run is in a non-final state (e.g. still Running
        after a process restart), we also look for an existing subflow run
        to reattach to, preventing duplicate subflow runs from being created
        under the same parent task run.

        If no existing flow run is found, or if the subflow should be rerun,
        then no flow run is returned.
        """

        # check if the parent flow run is rerunning
        rerunning = (
            context.flow_run.run_count > 1
            if getattr(context, "flow_run", None)
            and isinstance(context.flow_run, FlowRun)
            else False
        )

        assert isinstance(parent_task_run.state, State)

        # If the user explicitly triggered a re-run and the subflow did not
        # complete, allow a fresh subflow to be created.
        if (
            parent_task_run.state.is_final()
            and rerunning
            and not parent_task_run.state.is_completed()
        ):
            return None

        # Look for an existing subflow run attached to this parent task run.
        flow_runs = client.read_flow_runs(
            flow_run_filter=FlowRunFilter(
                parent_task_run_id={"any_": [parent_task_run.id]}
            ),
            sort=FlowRunSort.EXPECTED_START_TIME_DESC,
            limit=1,
        )
        if flow_runs:
            loaded_flow_run = flow_runs[0]
            if (
                rerunning
                and parent_task_run.state.is_completed()
                and loaded_flow_run.state is not None
                and loaded_flow_run.state.is_completed()
                and loaded_flow_run.state.data is None
            ):
                # Without a persisted result the child must execute again. A
                # fresh run preserves its history and restores its retry budget.
                return None

            # Keep the previous state available when reusing a finished run.
            if parent_task_run.state.is_final():
                self._return_value = loaded_flow_run.state
            return loaded_flow_run

    def create_flow_run(self, client: SyncPrefectClient) -> FlowRun:
        flow_run_ctx = FlowRunContext.get()
        parameters = self.parameters or {}

        parent_task_run = None

        # this is a subflow run
        if flow_run_ctx:
            raise_if_flow_run_suspension_requested()

            # add a task to a parent flow run that represents the execution of a subflow run
            parent_task = Task(
                name=self.flow.name, fn=self.flow.fn, version=self.flow.version
            )
            setattr(parent_task, "_is_subflow_tracking_task", True)

            parent_task_run = run_coro_as_sync(
                parent_task.create_run(
                    flow_run_context=flow_run_ctx,
                    parameters=self.parameters,
                    wait_for=self.wait_for,
                )
            )

            # check if there is already a flow run for this subflow
            if subflow_run := self.load_subflow_run(
                parent_task_run=parent_task_run, client=client, context=flow_run_ctx
            ):
                return subflow_run

        return client.create_flow_run(
            flow=self.flow,
            parameters=self.flow.serialize_parameters(parameters),
            state=Pending(),
            parent_task_run_id=getattr(parent_task_run, "id", None),
            tags=TagsContext.get().current_tags,
        )

    def call_hooks(self, state: Optional[State] = None) -> None:
        if state is None:
            state = self.state
        flow = self.flow
        flow_run = self.flow_run

        if not flow_run:
            raise ValueError("Flow run is not set")

        engine_owns_cancellation_handling = self._engine_owns_cancellation_handling()

        if state.is_failed() and flow.on_failure_hooks:
            hooks = flow.on_failure_hooks
        elif state.is_completed() and flow.on_completion_hooks:
            hooks = flow.on_completion_hooks
        elif (
            engine_owns_cancellation_handling
            and state.is_cancelling()
            and flow.on_cancellation_hooks
        ):
            hooks = flow.on_cancellation_hooks
        elif state.is_crashed() and flow.on_crashed_hooks:
            hooks = flow.on_crashed_hooks
        elif state.is_running() and flow.on_running_hooks:
            hooks = flow.on_running_hooks
        else:
            hooks = None

        for hook in hooks or []:
            hook_name = get_hook_name(hook)

            try:
                self.logger.info(
                    f"Running hook {hook_name!r} in response to entering state"
                    f" {state.name!r}"
                )
                result = hook(flow, flow_run, state)
                if asyncio.iscoroutine(result):
                    run_coro_as_sync(result)
            except Exception:
                self.logger.error(
                    f"An error was encountered while running hook {hook_name!r}",
                    exc_info=True,
                )
            else:
                self.logger.info(f"Hook {hook_name!r} finished running successfully")

    @contextmanager
    def setup_run_context(self, client: Optional[SyncPrefectClient] = None):
        from prefect.utilities.engine import (
            should_log_prints,
        )

        if client is None:
            client = self.client
        if not self.flow_run:
            raise ValueError("Flow run not set")

        self.flow_run = client.read_flow_run(self.flow_run.id)
        log_prints = should_log_prints(self.flow)
        flow_run_suspension_request = self._get_flow_run_suspension_request()
        if (state := self.flow_run.state) and is_suspended_flow_run_state(state):
            flow_run_suspension_request.mark_requested(state)

        with ExitStack() as stack:
            # TODO: Explore closing task runner before completing the flow to
            # wait for futures to complete
            if log_prints:
                stack.enter_context(patch_print())
            task_runner = stack.enter_context(self.flow.task_runner.duplicate())
            result_store = get_result_store().update_for_flow(self.flow, _sync=True)
            persist_result = (
                self.flow.persist_result
                if self.flow.persist_result is not None
                else _get_default_persist_result()
            )
            stack.enter_context(
                FlowRunContext(
                    flow=self.flow,
                    log_prints=log_prints,
                    flow_run=self.flow_run,
                    parameters=self.parameters,
                    client=client,
                    result_store=result_store,
                    task_runner=task_runner,
                    persist_result=persist_result,
                    flow_run_suspension_request=flow_run_suspension_request,
                )
            )
            # Set deployment context vars only if this is the top-level deployment run
            # (nested flows will inherit via ContextVar propagation)
            if self.flow_run.deployment_id and not _deployment_id.get():
                id_token = _deployment_id.set(self.flow_run.deployment_id)
                params_token = _deployment_parameters.set(self.flow_run.parameters)
                stack.callback(_deployment_id.reset, id_token)
                stack.callback(_deployment_parameters.reset, params_token)
            stack.enter_context(ConcurrencyContextV1())
            stack.enter_context(ConcurrencyContext())
            if lease_id := self.state.state_details.deployment_concurrency_lease_id:
                stack.enter_context(
                    maintain_concurrency_lease(
                        lease_id, 300, raise_on_lease_renewal_failure=True
                    )
                )

            # set the logger to the flow run logger

            self.logger: "logging.Logger" = flow_run_logger(
                flow_run=self.flow_run, flow=self.flow
            )  # type: ignore

            # update the flow run name if necessary
            if not self._flow_run_name_set and self.flow.flow_run_name:
                flow_run_name = resolve_custom_flow_run_name(
                    flow=self.flow, parameters=self.parameters
                )
                self.client.set_flow_run_name(
                    flow_run_id=self.flow_run.id, name=flow_run_name
                )

                self.logger.extra["flow_run_name"] = flow_run_name
                self.logger.debug(
                    f"Renamed flow run {self.flow_run.name!r} to {flow_run_name!r}"
                )
                self.flow_run.name = flow_run_name
                self._flow_run_name_set = True

                self._telemetry.update_run_name(name=flow_run_name)

            if self.flow_run.parent_task_run_id:
                _logger = get_run_logger(FlowRunContext.get())
                run_type = "subflow"
            else:
                _logger = self.logger
                run_type = "flow"

            _logger.info(
                f"Beginning {run_type} run {self.flow_run.name!r} for flow {self.flow.name!r}"
            )

            if flow_run_url := url_for(self.flow_run):
                self.logger.info(
                    f"View at {flow_run_url}", extra={"send_to_api": False}
                )

            yield

    @contextmanager
    def initialize_run(self):
        """
        Enters a client context and creates a flow run if needed.
        """
        with hydrated_context(self.context):
            parent_flow_run_context = FlowRunContext.get()
            self._started_with_in_process_parent_flow_run_context = (
                parent_flow_run_context is not None
                and not parent_flow_run_context.detached
            )
            with SyncClientContext.get_or_create() as client_ctx:
                self._client = client_ctx.client
                self._is_started = True

                if not self.flow_run:
                    self.flow_run = self.create_flow_run(self.client)
                else:
                    # Update the empirical policy to match the flow if it is not set
                    if self.flow_run.empirical_policy.retry_delay is None:
                        self.flow_run.empirical_policy.retry_delay = (
                            self.flow.retry_delay_seconds
                        )

                    if self.flow_run.empirical_policy.retries is None:
                        self.flow_run.empirical_policy.retries = self.flow.retries

                    self.client.update_flow_run(
                        flow_run_id=self.flow_run.id,
                        flow_version=self.flow.version,
                        empirical_policy=self.flow_run.empirical_policy,
                    )

                self._telemetry.start_span(
                    run=self.flow_run,
                    client=self.client,
                    parameters=self.parameters,
                )

                # Keep the control session open until the terminal outcome receipt
                # has been acknowledged by the supervising process.
                with capture_sigterm():
                    try:
                        yield self

                    except TerminationSignal as exc:
                        self.cancel_all_tasks()
                        intent = _termination_intent()
                        if intent == "cancel":
                            self.handle_cancellation(exc)
                            raise
                        if intent in _SUPERVISOR_OWNED_INTENTS:
                            raise
                        if intent is not None:
                            # Defensive: an unknown intent means the control
                            # listener was extended (e.g. "suspend" in a
                            # follow-up PR) without extending this dispatch.
                            # Treat as crash so the flow run still reaches a
                            # terminal state rather than silently hanging.
                            self.logger.error(
                                "Unhandled termination intent %r; treating as"
                                " crash. A follow-up PR needs to add a matching"
                                " dispatch branch.",
                                intent,
                            )
                        if self.flow_run.state and self.flow_run.state.is_final():
                            # A termination signal that lands during teardown
                            # must not overwrite an already-reported final state
                            self.logger.debug(
                                "Termination signal was received after the flow"
                                " run reached a final state",
                                exc_info=exc,
                            )
                        else:
                            self.handle_crash(exc)
                        raise
                    except Exception:
                        # regular exceptions are caught and re-raised to the user
                        raise
                    except (Abort, Pause) as exc:
                        if state := getattr(exc, "state", None):
                            # we set attribute explicitly because
                            # internals will have already called the state change API
                            self.flow_run.state = state
                            self._capture_state_report(state)
                        elif isinstance(exc, Abort):
                            self._attempt_conclusion = (
                                EngineOutcomeReceipt.orchestration_aborted()
                            )
                        raise
                    except GeneratorExit:
                        # Do not capture generator exits as crashes
                        raise
                    except BaseException as exc:
                        # We don't want to crash a flow run if the user code finished executing
                        if self.flow_run.state and not self.flow_run.state.is_final():
                            # BaseExceptions are caught and handled as crashes
                            self.handle_crash(exc)
                            raise
                        else:
                            self.logger.debug(
                                "BaseException was raised after user code finished executing",
                                exc_info=exc,
                            )
                    finally:
                        self._report_attempt_conclusion()

                        # If debugging, use the more complete `repr` than the usual `str` description
                        display_state = (
                            repr(self.state) if PREFECT_DEBUG_MODE else str(self.state)
                        )
                        self.logger.log(
                            level=logging.INFO,
                            msg=f"Finished in state {display_state}",
                        )

                        self._is_started = False
                        self._client = None

    # --------------------------
    #
    # The following methods compose the main task run loop
    #
    # --------------------------

    @contextmanager
    def start(self) -> Generator[None, None, None]:
        with self.initialize_run():
            with (
                trace.use_span(self._telemetry.span)
                if self._telemetry.span
                else nullcontext()
            ):
                with self.setup_flow_run_suspension_request():
                    self.begin_run()

                    yield

    @contextmanager
    def run_context(self):
        timeout_context = timeout_async if self.flow.isasync else timeout
        # reenter the run context to ensure it is up to date for every run
        with self.setup_run_context():
            raise_if_flow_run_suspension_requested()
            try:
                with timeout_context(
                    seconds=self.flow.timeout_seconds,
                    timeout_exc_type=FlowRunTimeoutError,
                ):
                    with _send_heartbeats(self):
                        self.logger.debug(
                            f"Executing flow {self.flow.name!r} for flow run {self.flow_run.name!r}..."
                        )
                        yield self
            except TimeoutError as exc:
                self.handle_timeout(exc)
            except Exception as exc:
                self.logger.exception("Encountered exception during execution: %r", exc)
                self.handle_exception(exc)

    def call_flow_fn(self) -> Union[R, Coroutine[Any, Any, R]]:
        """
        Convenience method to call the flow function. Returns a coroutine if the
        flow is async.
        """
        if self.flow.isasync:

            async def _call_flow_fn():
                result = await call_with_parameters(self.flow.fn, self.parameters)
                self.handle_success(result)

            return _call_flow_fn()
        else:
            result = call_with_parameters(self.flow.fn, self.parameters)
            self.handle_success(result)


@dataclass
class AsyncFlowRunEngine(BaseFlowRunEngine[P, R]):
    """
    Async version of the flow run engine.

    NOTE: This has not been fully asyncified yet which may lead to async flows
    not being fully asyncified.
    """

    _client: Optional[PrefectClient] = None
    parameters: dict[str, Any] | None = None
    flow_run: FlowRun | None = None

    @property
    def client(self) -> PrefectClient:
        if not self._is_started or self._client is None:
            raise RuntimeError("Engine has not started.")
        return self._client

    def _resolve_parameters(self):
        if not self.parameters:
            return

        resolved_parameters = {}
        for parameter, value in self.parameters.items():
            try:
                resolved_parameters[parameter] = visit_collection(
                    value,
                    visit_fn=resolve_to_final_result,
                    return_data=True,
                    max_depth=-1,
                    remove_annotations=True,
                    context={"parameter_name": parameter},
                )
            except UpstreamTaskError:
                raise
            except Exception as exc:
                raise PrefectException(
                    f"Failed to resolve inputs in parameter {parameter!r}. If your"
                    " parameter type is not supported, consider using the `quote`"
                    " annotation to skip resolution of inputs."
                ) from exc

        self.parameters = resolved_parameters

    def _wait_for_dependencies(self):
        if not self.wait_for:
            return

        visit_collection(
            self.wait_for,
            visit_fn=resolve_to_final_result,
            return_data=False,
            max_depth=-1,
            remove_annotations=True,
            context={},
        )

    async def begin_run(self) -> State:
        try:
            self._resolve_parameters()
            self._wait_for_dependencies()
        except UpstreamTaskError as upstream_exc:
            state = await self.set_state(
                Pending(
                    name="NotReady",
                    message=str(upstream_exc),
                ),
                # if orchestrating a run already in a pending state, force orchestration to
                # update the state name
                force=self.state.is_pending(),
            )
            return state

        # validate prior to context so that context receives validated params
        if self.flow.should_validate_parameters:
            try:
                self.parameters = self.flow.validate_parameters(self.parameters or {})
            except Exception as exc:
                message = "Validation of flow parameters failed with error:"
                self.logger.error("%s %s", message, exc)
                await self.handle_exception(
                    exc,
                    msg=message,
                    result_store=get_result_store().update_for_flow(
                        self.flow, _sync=True
                    ),
                )
                self.short_circuit = True

        if (
            not self.short_circuit
            and not self._flow_run_name_set
            and self.flow.flow_run_name
        ):
            if self.flow_run is None:
                raise ValueError("Flow run not set")

            with FlowRunContext(
                flow=self.flow,
                flow_run=self.flow_run,
                parameters=self.parameters,
                client=self.client,
                task_runner=self.flow.task_runner,
                result_store=get_result_store().update_for_flow(self.flow, _sync=True),
            ):
                flow_run_name = resolve_custom_flow_run_name(
                    flow=self.flow, parameters=self.parameters or {}
                )
            await self.client.set_flow_run_name(
                flow_run_id=self.flow_run.id, name=flow_run_name
            )
            self.flow_run.name = flow_run_name
            self._flow_run_name_set = True
            self._telemetry.update_run_name(name=flow_run_name)

        self._get_flow_run_suspension_request().raise_if_requested()
        new_state = Running()
        state = await self.set_state(new_state)
        while state.is_pending():
            await asyncio.sleep(0.2)
            state = await self.set_state(new_state)
        return state

    async def set_state(self, state: State, force: bool = False) -> State:
        """ """
        # prevents any state-setting activity
        if self.short_circuit:
            return self.state

        state = await propose_state(
            self.client, state, flow_run_id=self.flow_run.id, force=force
        )  # type: ignore
        self.flow_run.state = state  # type: ignore
        self.flow_run.state_name = state.name  # type: ignore
        self.flow_run.state_type = state.type  # type: ignore

        self._capture_state_report(state)
        self._telemetry.update_state(state)
        await self.call_hooks(state)

        return state

    async def result(self, raise_on_failure: bool = True) -> "Union[R, State, None]":
        if self._return_value is not NotSet and not isinstance(
            self._return_value, State
        ):
            _result = self._return_value
            link_state_to_flow_run_result(self.state, _result)

            if asyncio.iscoroutine(_result):
                # getting the value for a BaseResult may return an awaitable
                # depending on whether the parent frame is sync or not
                _result = await _result
            return _result

        if self._raised is not NotSet:
            if raise_on_failure:
                raise self._raised
            return self._raised

        # This is a fall through case which leans on the existing state result mechanics to get the
        # return value. This is necessary because we currently will return a State object if the
        # the State was Prefect-created.
        # TODO: Remove the need to get the result from a State except in cases where the return value
        # is a State object.
        return await self.state.aresult(raise_on_failure=raise_on_failure)  # type: ignore

    async def handle_success(self, result: R) -> R:
        raise_if_flow_run_suspension_requested()
        result_store = getattr(FlowRunContext.get(), "result_store", None)
        if result_store is None:
            raise ValueError("Result store is not set")
        resolved_result = resolve_futures_to_states(result)
        terminal_state = await return_value_to_state(
            resolved_result,
            result_store=result_store,
            write_result=should_persist_result(),
        )
        raise_if_flow_run_suspension_requested()
        await self.set_state(terminal_state)
        self._return_value = resolved_result

        self._telemetry.end_span_on_success()

        # Track first flow run milestone for analytics
        try:
            from prefect._internal.analytics import try_mark_milestone

            try_mark_milestone("first_flow_run")
        except Exception:
            pass

        return result

    async def handle_exception(
        self,
        exc: Exception,
        msg: Optional[str] = None,
        result_store: Optional[ResultStore] = None,
    ) -> State:
        self._get_flow_run_suspension_request().raise_if_requested()
        context = FlowRunContext.get()
        terminal_state = cast(
            State,
            await exception_to_failed_state(
                exc,
                message=msg or "Flow run encountered an exception:",
                result_store=result_store or getattr(context, "result_store", None),
                write_result=True,
            ),
        )
        self._get_flow_run_suspension_request().raise_if_requested()
        state = await self.set_state(terminal_state)
        if self.state.is_scheduled():
            self.logger.info(
                (
                    f"Received non-final state {state.name!r} when proposing final"
                    f" state {terminal_state.name!r} and will attempt to run again..."
                ),
            )
            self._get_flow_run_suspension_request().raise_if_requested()
            state = await self.set_state(Running())
        self._raised = exc
        self._telemetry.record_exception(exc)
        self._telemetry.end_span_on_failure(state.message)

        return state

    async def handle_timeout(self, exc: TimeoutError) -> None:
        if isinstance(exc, FlowRunTimeoutError):
            message = (
                f"Flow run exceeded timeout of {self.flow.timeout_seconds} second(s)"
            )
        else:
            message = f"Flow run failed due to timeout: {exc!r}"
        self.logger.error(message)
        self._get_flow_run_suspension_request().raise_if_requested()
        state = Failed(
            data=exc,
            message=message,
            name="TimedOut",
        )
        await self.set_state(state)
        if self.state.is_scheduled():
            self.logger.info(
                f"Received non-final state {self.state.name!r} when proposing final"
                f" state {state.name!r} and will attempt to run again..."
            )
            self._get_flow_run_suspension_request().raise_if_requested()
            await self.set_state(Running())
            return
        self._raised = exc

        self._telemetry.record_exception(exc)
        self._telemetry.end_span_on_failure(message)

    async def handle_crash(self, exc: BaseException) -> None:
        # need to shield from asyncio cancellation to ensure we update the state
        # on the server before exiting
        with CancelScope(shield=True):
            state = await exception_to_crashed_state(exc)
            self.logger.error(f"Crash detected! {state.message}")
            self.logger.debug("Crash details:", exc_info=exc)
            await self.set_state(state, force=True)
            self._raised = exc

            self._telemetry.record_exception(exc)
            self._telemetry.end_span_on_failure(state.message)

    async def handle_cancellation(self, exc: BaseException) -> None:
        """Force this run through Cancelling -> Cancelled.

        Async counterpart to `FlowRunEngine.handle_cancellation`. Shielded
        from asyncio cancellation so engine-owned transitions always reach
        the server.
        """
        with CancelScope(shield=True):
            msg = "Flow run was cancelled."
            self.logger.info(msg)
            if self._engine_owns_cancellation_handling():
                await self.set_state(Cancelling(message=msg), force=True)
                await self.set_state(Cancelled(message=msg), force=True)
            self._raised = exc
            self._telemetry.record_exception(exc)
            self._telemetry.end_span_on_failure(msg)

    async def load_subflow_run(
        self,
        parent_task_run: TaskRun,
        client: PrefectClient,
        context: FlowRunContext,
    ) -> Union[FlowRun, None]:
        """
        This method attempts to load an existing flow run for a subflow task
        run, if appropriate.

        If the parent task run is in a final state, we return the existing
        subflow run unless the parent is being rerun and the subflow either
        did not complete or has no persisted result. In those cases a fresh
        run gives the subflow its full retry budget while preserving the
        previous run's history.

        If the parent task run is in a non-final state (e.g. still Running
        after a process restart), we also look for an existing subflow run
        to reattach to, preventing duplicate subflow runs from being created
        under the same parent task run.

        If no existing flow run is found, or if the subflow should be rerun,
        then no flow run is returned.
        """

        # check if the parent flow run is rerunning
        rerunning = (
            context.flow_run.run_count > 1
            if getattr(context, "flow_run", None)
            and isinstance(context.flow_run, FlowRun)
            else False
        )

        assert isinstance(parent_task_run.state, State)

        # If the user explicitly triggered a re-run and the subflow did not
        # complete, allow a fresh subflow to be created.
        if (
            parent_task_run.state.is_final()
            and rerunning
            and not parent_task_run.state.is_completed()
        ):
            return None

        # Look for an existing subflow run attached to this parent task run.
        flow_runs = await client.read_flow_runs(
            flow_run_filter=FlowRunFilter(
                parent_task_run_id={"any_": [parent_task_run.id]}
            ),
            sort=FlowRunSort.EXPECTED_START_TIME_DESC,
            limit=1,
        )
        if flow_runs:
            loaded_flow_run = flow_runs[0]
            if (
                rerunning
                and parent_task_run.state.is_completed()
                and loaded_flow_run.state is not None
                and loaded_flow_run.state.is_completed()
                and loaded_flow_run.state.data is None
            ):
                # Without a persisted result the child must execute again. A
                # fresh run preserves its history and restores its retry budget.
                return None

            # Keep the previous state available when reusing a finished run.
            if parent_task_run.state.is_final():
                self._return_value = loaded_flow_run.state
            return loaded_flow_run

    async def create_flow_run(self, client: PrefectClient) -> FlowRun:
        flow_run_ctx = FlowRunContext.get()
        parameters = self.parameters or {}

        parent_task_run = None

        # this is a subflow run
        if flow_run_ctx:
            raise_if_flow_run_suspension_requested()

            # add a task to a parent flow run that represents the execution of a subflow run
            parent_task = Task(
                name=self.flow.name, fn=self.flow.fn, version=self.flow.version
            )
            setattr(parent_task, "_is_subflow_tracking_task", True)

            parent_task_run = await parent_task.create_run(
                flow_run_context=flow_run_ctx,
                parameters=self.parameters,
                wait_for=self.wait_for,
            )

            # check if there is already a flow run for this subflow
            if subflow_run := await self.load_subflow_run(
                parent_task_run=parent_task_run, client=client, context=flow_run_ctx
            ):
                return subflow_run

        return await client.create_flow_run(
            flow=self.flow,
            parameters=self.flow.serialize_parameters(parameters),
            state=Pending(),
            parent_task_run_id=getattr(parent_task_run, "id", None),
            tags=TagsContext.get().current_tags,
        )

    async def call_hooks(self, state: Optional[State] = None) -> None:
        if state is None:
            state = self.state
        flow = self.flow
        flow_run = self.flow_run

        if not flow_run:
            raise ValueError("Flow run is not set")

        engine_owns_cancellation_handling = self._engine_owns_cancellation_handling()

        if state.is_failed() and flow.on_failure_hooks:
            hooks = flow.on_failure_hooks
        elif state.is_completed() and flow.on_completion_hooks:
            hooks = flow.on_completion_hooks
        elif (
            engine_owns_cancellation_handling
            and state.is_cancelling()
            and flow.on_cancellation_hooks
        ):
            hooks = flow.on_cancellation_hooks
        elif state.is_crashed() and flow.on_crashed_hooks:
            hooks = flow.on_crashed_hooks
        elif state.is_running() and flow.on_running_hooks:
            hooks = flow.on_running_hooks
        else:
            hooks = None

        for hook in hooks or []:
            hook_name = get_hook_name(hook)

            try:
                self.logger.info(
                    f"Running hook {hook_name!r} in response to entering state"
                    f" {state.name!r}"
                )
                result = hook(flow, flow_run, state)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                self.logger.error(
                    f"An error was encountered while running hook {hook_name!r}",
                    exc_info=True,
                )
            else:
                self.logger.info(f"Hook {hook_name!r} finished running successfully")

    @asynccontextmanager
    async def setup_run_context(self, client: Optional[PrefectClient] = None):
        from prefect.utilities.engine import (
            should_log_prints,
        )

        if client is None:
            client = self.client
        if not self.flow_run:
            raise ValueError("Flow run not set")

        self.flow_run = await client.read_flow_run(self.flow_run.id)
        log_prints = should_log_prints(self.flow)
        flow_run_suspension_request = self._get_flow_run_suspension_request()
        if (state := self.flow_run.state) and is_suspended_flow_run_state(state):
            flow_run_suspension_request.mark_requested(state)

        async with AsyncExitStack() as stack:
            # TODO: Explore closing task runner before completing the flow to
            # wait for futures to complete
            if log_prints:
                stack.enter_context(patch_print())
            task_runner = stack.enter_context(self.flow.task_runner.duplicate())
            result_store = get_result_store().update_for_flow(self.flow, _sync=True)
            persist_result = (
                self.flow.persist_result
                if self.flow.persist_result is not None
                else await _aget_default_persist_result()
            )
            stack.enter_context(
                FlowRunContext(
                    flow=self.flow,
                    log_prints=log_prints,
                    flow_run=self.flow_run,
                    parameters=self.parameters,
                    client=client,
                    result_store=result_store,
                    task_runner=task_runner,
                    persist_result=persist_result,
                    flow_run_suspension_request=flow_run_suspension_request,
                )
            )
            # Set deployment context vars only if this is the top-level deployment run
            # (nested flows will inherit via ContextVar propagation)
            if self.flow_run.deployment_id and not _deployment_id.get():
                id_token = _deployment_id.set(self.flow_run.deployment_id)
                params_token = _deployment_parameters.set(self.flow_run.parameters)
                stack.callback(_deployment_id.reset, id_token)
                stack.callback(_deployment_parameters.reset, params_token)
            stack.enter_context(ConcurrencyContextV1())
            stack.enter_context(ConcurrencyContext())
            if lease_id := self.state.state_details.deployment_concurrency_lease_id:
                await stack.enter_async_context(
                    amaintain_concurrency_lease(
                        lease_id, 300, raise_on_lease_renewal_failure=True
                    )
                )

            # set the logger to the flow run logger
            self.logger: "logging.Logger" = flow_run_logger(
                flow_run=self.flow_run, flow=self.flow
            )

            # update the flow run name if necessary

            if not self._flow_run_name_set and self.flow.flow_run_name:
                flow_run_name = resolve_custom_flow_run_name(
                    flow=self.flow, parameters=self.parameters
                )
                await self.client.set_flow_run_name(
                    flow_run_id=self.flow_run.id, name=flow_run_name
                )
                self.logger.extra["flow_run_name"] = flow_run_name
                self.logger.debug(
                    f"Renamed flow run {self.flow_run.name!r} to {flow_run_name!r}"
                )
                self.flow_run.name = flow_run_name
                self._flow_run_name_set = True

                self._telemetry.update_run_name(name=flow_run_name)
            if self.flow_run.parent_task_run_id:
                _logger = get_run_logger(FlowRunContext.get())
                run_type = "subflow"
            else:
                _logger = self.logger
                run_type = "flow"

            _logger.info(
                f"Beginning {run_type} run {self.flow_run.name!r} for flow {self.flow.name!r}"
            )

            if flow_run_url := url_for(self.flow_run):
                self.logger.info(
                    f"View at {flow_run_url}", extra={"send_to_api": False}
                )

            yield

    @asynccontextmanager
    async def initialize_run(self):
        """
        Enters a client context and creates a flow run if needed.
        """
        with hydrated_context(self.context):
            parent_flow_run_context = FlowRunContext.get()
            self._started_with_in_process_parent_flow_run_context = (
                parent_flow_run_context is not None
                and not parent_flow_run_context.detached
            )
            async with AsyncClientContext.get_or_create() as client_ctx:
                self._client = client_ctx.client
                self._is_started = True

                if not self.flow_run:
                    self.flow_run = await self.create_flow_run(self.client)
                    flow_run_url = url_for(self.flow_run)

                    if flow_run_url:
                        self.logger.info(
                            f"View at {flow_run_url}", extra={"send_to_api": False}
                        )
                else:
                    # Update the empirical policy to match the flow if it is not set
                    if self.flow_run.empirical_policy.retry_delay is None:
                        self.flow_run.empirical_policy.retry_delay = (
                            self.flow.retry_delay_seconds
                        )

                    if self.flow_run.empirical_policy.retries is None:
                        self.flow_run.empirical_policy.retries = self.flow.retries

                    await self.client.update_flow_run(
                        flow_run_id=self.flow_run.id,
                        flow_version=self.flow.version,
                        empirical_policy=self.flow_run.empirical_policy,
                    )

                await self._telemetry.async_start_span(
                    run=self.flow_run,
                    client=self.client,
                    parameters=self.parameters,
                )

                # Keep the control session open until the terminal outcome receipt
                # has been acknowledged by the supervising process.
                with capture_sigterm():
                    try:
                        yield self

                    except TerminationSignal as exc:
                        self.cancel_all_tasks()
                        intent = _termination_intent()
                        if intent == "cancel":
                            await self.handle_cancellation(exc)
                            raise
                        if intent in _SUPERVISOR_OWNED_INTENTS:
                            raise
                        if intent is not None:
                            # Defensive: see sync engine's dispatch for why.
                            self.logger.error(
                                "Unhandled termination intent %r; treating as"
                                " crash. A follow-up PR needs to add a matching"
                                " dispatch branch.",
                                intent,
                            )
                        if self.flow_run.state and self.flow_run.state.is_final():
                            # A termination signal that lands during teardown
                            # must not overwrite an already-reported final state
                            self.logger.debug(
                                "Termination signal was received after the flow"
                                " run reached a final state",
                                exc_info=exc,
                            )
                        else:
                            await self.handle_crash(exc)
                        raise
                    except Exception:
                        # regular exceptions are caught and re-raised to the user
                        raise
                    except (Abort, Pause) as exc:
                        if state := getattr(exc, "state", None):
                            # we set attribute explicitly because
                            # internals will have already called the state change API
                            self.flow_run.state = state
                            self._capture_state_report(state)
                        elif isinstance(exc, Abort):
                            self._attempt_conclusion = (
                                EngineOutcomeReceipt.orchestration_aborted()
                            )
                        raise
                    except GeneratorExit:
                        # Do not capture generator exits as crashes
                        raise
                    except BaseException as exc:
                        if (
                            _is_async_runtime_cancellation(exc)
                            and _termination_intent() == "cancel"
                        ):
                            if (
                                self.flow_run.state
                                and not self.flow_run.state.is_final()
                            ):
                                await self.handle_cancellation(exc)
                                raise TerminationSignal(signal.SIGTERM) from exc
                            else:
                                self.logger.debug(
                                    "Async cancellation was raised after user code"
                                    " finished executing",
                                    exc_info=exc,
                                )
                                raise
                        if (
                            _is_async_runtime_cancellation(exc)
                            and _termination_intent() in _SUPERVISOR_OWNED_INTENTS
                        ):
                            # A supervisor-driven SIGTERM can surface here as a cancellation
                            # rather than a TerminationSignal.
                            raise TerminationSignal(signal.SIGTERM) from exc
                        # We don't want to crash a flow run if the user code finished executing
                        if self.flow_run.state and not self.flow_run.state.is_final():
                            # BaseExceptions are caught and handled as crashes
                            await self.handle_crash(exc)
                            raise
                        else:
                            self.logger.debug(
                                "BaseException was raised after user code finished executing",
                                exc_info=exc,
                            )
                    finally:
                        self._report_attempt_conclusion()

                        # If debugging, use the more complete `repr` than the usual `str` description
                        display_state = (
                            repr(self.state) if PREFECT_DEBUG_MODE else str(self.state)
                        )
                        self.logger.log(
                            level=logging.INFO
                            if self.state.is_completed()
                            else logging.ERROR,
                            msg=f"Finished in state {display_state}",
                        )

                        self._is_started = False
                        self._client = None

    # --------------------------
    #
    # The following methods compose the main task run loop
    #
    # --------------------------

    @asynccontextmanager
    async def start(self) -> AsyncGenerator[None, None]:
        async with self.initialize_run():
            with (
                trace.use_span(self._telemetry.span)
                if self._telemetry.span
                else nullcontext()
            ):
                with self.setup_flow_run_suspension_request():
                    await self.begin_run()

                    yield

    @asynccontextmanager
    async def run_context(self):
        timeout_context = timeout_async if self.flow.isasync else timeout
        # reenter the run context to ensure it is up to date for every run
        async with self.setup_run_context():
            raise_if_flow_run_suspension_requested()
            try:
                with timeout_context(
                    seconds=self.flow.timeout_seconds,
                    timeout_exc_type=FlowRunTimeoutError,
                ):
                    with _send_heartbeats(self, join_on_exit=False):
                        self.logger.debug(
                            f"Executing flow {self.flow.name!r} for flow run {self.flow_run.name!r}..."
                        )
                        yield self
            except TimeoutError as exc:
                await self.handle_timeout(exc)
            except Exception as exc:
                self.logger.exception("Encountered exception during execution: %r", exc)
                await self.handle_exception(exc)

    async def call_flow_fn(self) -> Coroutine[Any, Any, R]:
        """
        Convenience method to call the flow function. Returns a coroutine if the
        flow is async.
        """
        assert self.flow.isasync, "Flow must be async to be run with AsyncFlowRunEngine"

        result = await call_with_parameters(self.flow.fn, self.parameters)
        await self.handle_success(result)
        return result


def run_flow_sync(
    flow: Flow[P, R],
    flow_run: Optional[FlowRun] = None,
    parameters: Optional[Dict[str, Any]] = None,
    wait_for: Optional[Iterable[PrefectFuture[Any]]] = None,
    return_type: Literal["state", "result"] = "result",
    context: Optional[dict[str, Any]] = None,
) -> Union[R, State, None]:
    engine = FlowRunEngine[P, R](
        flow=flow,
        parameters=parameters,
        flow_run=flow_run,
        wait_for=wait_for,
        context=context,
    )

    with engine.start():
        while engine.is_running():
            with engine.run_context():
                engine.call_flow_fn()

    return engine.state if return_type == "state" else engine.result()


async def run_flow_async(
    flow: Flow[P, R],
    flow_run: Optional[FlowRun] = None,
    parameters: Optional[Dict[str, Any]] = None,
    wait_for: Optional[Iterable[PrefectFuture[Any]]] = None,
    return_type: Literal["state", "result"] = "result",
    context: Optional[dict[str, Any]] = None,
) -> Union[R, State, None]:
    engine = AsyncFlowRunEngine[P, R](
        flow=flow,
        parameters=parameters,
        flow_run=flow_run,
        wait_for=wait_for,
        context=context,
    )

    async with engine.start():
        while engine.is_running():
            async with engine.run_context():
                await engine.call_flow_fn()

    return engine.state if return_type == "state" else await engine.result()


def run_generator_flow_sync(
    flow: Flow[P, R],
    flow_run: Optional[FlowRun] = None,
    parameters: Optional[Dict[str, Any]] = None,
    wait_for: Optional[Iterable[PrefectFuture[Any]]] = None,
    return_type: Literal["state", "result"] = "result",
    context: Optional[dict[str, Any]] = None,
) -> Generator[R, None, None]:
    if return_type != "result":
        raise ValueError("The return_type for a generator flow must be 'result'")

    engine = FlowRunEngine[P, R](
        flow=flow,
        parameters=parameters,
        flow_run=flow_run,
        wait_for=wait_for,
        context=context,
    )

    with engine.start():
        while engine.is_running():
            with engine.run_context():
                call_args, call_kwargs = parameters_to_args_kwargs(
                    flow.fn, engine.parameters or {}
                )
                gen = flow.fn(*call_args, **call_kwargs)
                try:
                    while True:
                        gen_result = next(gen)
                        # link the current state to the result for dependency tracking
                        link_state_to_flow_run_result(engine.state, gen_result)
                        yield gen_result
                except StopIteration as exc:
                    engine.handle_success(exc.value)
                except GeneratorExit as exc:
                    engine.handle_success(None)
                    gen.throw(exc)

    return engine.result()


async def run_generator_flow_async(
    flow: Flow[P, R],
    flow_run: Optional[FlowRun] = None,
    parameters: Optional[Dict[str, Any]] = None,
    wait_for: Optional[Iterable[PrefectFuture[R]]] = None,
    return_type: Literal["state", "result"] = "result",
    context: Optional[dict[str, Any]] = None,
) -> AsyncGenerator[R, None]:
    if return_type != "result":
        raise ValueError("The return_type for a generator flow must be 'result'")

    engine = AsyncFlowRunEngine[P, R](
        flow=flow,
        parameters=parameters,
        flow_run=flow_run,
        wait_for=wait_for,
        context=context,
    )

    async with engine.start():
        while engine.is_running():
            async with engine.run_context():
                call_args, call_kwargs = parameters_to_args_kwargs(
                    flow.fn, engine.parameters or {}
                )
                gen = flow.fn(*call_args, **call_kwargs)
                try:
                    while True:
                        # can't use anext in Python < 3.10
                        gen_result = await gen.__anext__()
                        # link the current state to the result for dependency tracking
                        link_state_to_flow_run_result(engine.state, gen_result)
                        yield gen_result
                except (StopAsyncIteration, GeneratorExit) as exc:
                    await engine.handle_success(None)
                    if isinstance(exc, GeneratorExit):
                        gen.throw(exc)

    # async generators can't return, but we can raise failures here
    if engine.state.is_failed():
        await engine.result()


def run_flow(
    flow: Flow[P, R],
    flow_run: Optional[FlowRun] = None,
    parameters: Optional[Dict[str, Any]] = None,
    wait_for: Optional[Iterable[PrefectFuture[R]]] = None,
    return_type: Literal["state", "result"] = "result",
    error_logger: Optional[logging.Logger] = None,
    context: Optional[dict[str, Any]] = None,
) -> (
    R
    | State
    | None
    | Coroutine[Any, Any, R | State | None]
    | Generator[R, None, None]
    | AsyncGenerator[R, None]
):
    ret_val: Union[
        R,
        State,
        None,
        Coroutine[Any, Any, R | State | None],
        Generator[R, None, None],
        AsyncGenerator[R, None],
    ] = None

    try:
        kwargs: dict[str, Any] = dict(
            flow=flow,
            flow_run=flow_run,
            parameters=_flow_parameters(
                flow=flow, flow_run=flow_run, parameters=parameters
            ),
            wait_for=wait_for,
            return_type=return_type,
            context=context,
        )

        if flow.isasync and flow.isgenerator:
            ret_val = run_generator_flow_async(**kwargs)
        elif flow.isgenerator:
            ret_val = run_generator_flow_sync(**kwargs)
        elif flow.isasync:
            ret_val = run_flow_async(**kwargs)
        else:
            ret_val = run_flow_sync(**kwargs)
    except (Abort, Pause):
        raise
    except Exception:
        if error_logger:
            error_logger.error(
                "Engine execution exited with unexpected exception", exc_info=True
            )
        raise
    except BaseException as exc:
        # This top-level wrapper can fail before setup_run_context() installs
        # the flow-run-scoped logger onto the engine.  This branch
        # intentionally preserves per-run error logging for interrupts such
        # as KeyboardInterrupt and SystemExit that would otherwise bypass
        # the Exception handler above. Runner-delivered control intents
        # (cancel today; suspend in a follow-up) already have dedicated
        # engine handling, so logging them again here is just noisy.
        is_control_termination = isinstance(exc, TerminationSignal) and (
            _termination_intent() is not None
        )
        if error_logger and not is_control_termination:
            error_logger.error(
                "Engine execution interrupted by base exception", exc_info=True
            )
        raise
    return ret_val


def _flow_parameters(
    flow: Flow[P, R], flow_run: Optional[FlowRun], parameters: Optional[Dict[str, Any]]
) -> Dict[str, Any]:
    if parameters:
        # This path is taken when a flow is being called directly with
        # parameters, in that case just return the parameters as-is.
        return parameters

    # Otherwise the flow is being executed indirectly and we may need to grab
    # the parameters from the flow run. We also need to resolve any default
    # parameters that are defined on the flow function itself.

    parameters = flow_run.parameters if flow_run else {}
    call_args, call_kwargs = parameters_to_args_kwargs(flow.fn, parameters)
    return get_call_parameters(flow.fn, call_args, call_kwargs)


def run_flow_in_subprocess(
    flow: "Flow[..., Any]",
    flow_run: "FlowRun | None" = None,
    parameters: dict[str, Any] | None = None,
    wait_for: Iterable[PrefectFuture[Any]] | None = None,
    context: dict[str, Any] | None = None,
    env: dict[str, str | None] | None = None,
) -> multiprocessing.context.SpawnProcess:
    """
    Run a flow in a subprocess.

    Note the result of the flow will only be accessible if the flow is configured to
    persist its result.

    Args:
        flow: The flow to run.
        flow_run: The flow run object containing run metadata.
        parameters: The parameters to use when invoking the flow.
        wait_for: The futures to wait for before starting the flow.
        context: A serialized context to hydrate before running the flow. If not provided,
            the current context will be used. A serialized context should be provided if
            this function is called in a separate memory space from the parent run (e.g.
            in a subprocess or on another machine).
        env: Additional environment variables to set in the subprocess.

    Returns:
        A multiprocessing.context.SpawnProcess representing the process that is running the flow.
    """
    from prefect.flow_engine import run_flow

    @wraps(run_flow)
    def run_flow_with_env(
        *args: Any,
        env: dict[str, str | None] | None = None,
        remove_env: set[str] | None = None,
        **kwargs: Any,
    ):
        """
        Wrapper function to update environment variables and settings before running the flow.
        """
        for key in remove_env or ():
            os.environ.pop(key, None)
        os.environ.update(_runtime_subprocess_env(env))
        settings_context = get_settings_context()
        # Create a new settings context with a new settings object to pick up the updated
        # environment variables
        with SettingsContext(
            profile=settings_context.profile,
            settings=Settings(),
        ):
            with handle_engine_signals(getattr(flow_run, "id", None)):
                maybe_coro = run_flow(*args, **kwargs)
                if asyncio.iscoroutine(maybe_coro):
                    # This is running in a brand new process, so there won't be an existing
                    # event loop.
                    asyncio.run(maybe_coro)

    ctx = multiprocessing.get_context("spawn")

    context = context or serialize_context()
    merged_env: dict[str, str | None] = (
        get_current_settings().to_environment_variables(exclude_unset=True)
        | os.environ
        | {
            # TODO: make this a thing we can pass into the engine
            "PREFECT__ENABLE_CANCELLATION_AND_CRASHED_HOOKS": "false",
        }
        | (env or {})
    )
    sanitized_merged_env = sanitize_subprocess_env(merged_env)
    runtime_env = _runtime_subprocess_env(sanitized_merged_env)
    startup_env = {
        key: value
        for key, value in sanitized_merged_env.items()
        if key in _CONTROL_CHANNEL_ENV_KEYS
    }
    wrapped_call = cloudpickle_wrapped_call(
        run_flow_with_env,
        env=runtime_env,
        remove_env={key for key, value in merged_env.items() if value is None},
        flow=flow,
        flow_run=flow_run,
        parameters=parameters,
        wait_for=wait_for,
        context=context,
    )

    process = ctx.Process(
        target=_run_serialized_call_with_control_bootstrap,
        args=(cast(bytes, wrapped_call.args[0]), startup_env),
    )
    process.start()

    return process


if __name__ == "__main__":
    raise SystemExit(_main())
