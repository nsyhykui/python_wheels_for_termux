"""FastAPI HTTP server factory and route definitions for Kedro."""

from __future__ import annotations

import logging
import os
import threading
import time
import traceback
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any

from fastapi import FastAPI, Query

from kedro import __version__ as kedro_version
from kedro.framework.cli.utils import _split_params
from kedro.framework.project import settings
from kedro.framework.session.service_session import KedroServiceSession
from kedro.framework.startup import bootstrap_project
from kedro.inspection import get_project_snapshot
from kedro.io.core import _redact_url_credentials, generate_timestamp
from kedro.runner import AbstractRunner
from kedro.server.models import (
    ErrorDetail,
    HealthResponse,
    RunFailure,
    RunRequest,
    RunResponse,
    RunSuccess,
    SnapshotFailure,
    SnapshotResponse,
    SnapshotSuccess,
)
from kedro.server.utils import (
    KEDRO_SERVER_CONF_SOURCE,
    KEDRO_SERVER_ENV,
    _resolve_project_path,
)
from kedro.utils import _is_module_allowed, load_obj

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator
    from pathlib import Path

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Lifespan context manager for FastAPI application.

    Bootstraps the Kedro project on startup.
    """
    project_path = app.state.project_path
    logger.info("Bootstrapping Kedro project at: %s", project_path)
    app.state.metadata = bootstrap_project(project_path)

    if settings.SESSION_CLASS is not KedroServiceSession:
        logger.warning(
            "The Kedro HTTP server is designed to work with KedroServiceSession. Not using the `SESSION_CLASS` specified in the settings.",
        )

    logger.info("Kedro server started successfully")

    yield
    logger.info("Kedro server shutting down")
    with app.state.session_lock:
        if hasattr(app.state, "session"):
            app.state.session.close()


def create_http_server(
    project_path: str | Path | None = None,
    env: str | None = None,
    conf_source: str | None = None,
) -> FastAPI:
    """Create and configure the FastAPI HTTP server.

    Programmatic values passed to this factory take precedence over
    environment-variable defaults set by the CLI.

    Args:
        project_path: Optional path to the Kedro project to serve. If not provided,
            it will be resolved from KEDRO_PROJECT_PATH environment variable.
        env: Optional Kedro environment to use. Overrides the KEDRO_SERVER_ENV environment variable if provided.
        conf_source: Optional configuration source to use. Overrides the KEDRO_SERVER_CONF_SOURCE environment variable if provided.
    Returns:
        Configured FastAPI application instance.
    """
    resolved_env = env if env is not None else os.environ.get(KEDRO_SERVER_ENV)
    resolved_conf_source = (
        conf_source
        if conf_source is not None
        else os.environ.get(KEDRO_SERVER_CONF_SOURCE)
    )

    app = FastAPI(
        title="Kedro Server",
        description="HTTP API for triggering pipeline runs, inspecting project metadata, and more",
        version=kedro_version,
        lifespan=lifespan,
    )
    app.state.default_env = resolved_env
    app.state.default_conf_source = resolved_conf_source
    app.state.project_path = _resolve_project_path(project_path)
    app.state.session_lock = threading.Lock()

    @app.get("/health", response_model=HealthResponse, tags=["health"])
    async def health() -> HealthResponse:
        """Health check endpoint.

        Returns server status and Kedro version information.
        """
        return HealthResponse(
            status="healthy",
            kedro_version=kedro_version,
        )

    @app.get("/snapshot", response_model=SnapshotResponse, tags=["inspection"])
    def get_snapshot(
        params: str | None = Query(
            default=None,
            description=(
                "Runtime parameters for this snapshot, in `kedro run --params` "
                "format (e.g. `version=02,model.lr=0.01`). Values must not "
                "contain commas."
            ),
        ),
    ) -> SnapshotResponse:
        """Return a read-only snapshot of the Kedro project.

        Uses the server-level environment configured at startup (equivalent to
        the ``env`` passed to ``create_http_server`` or the ``KEDRO_SERVER_ENV``
        environment variable).

        Args:
            params: Optional comma-separated ``key=value`` pairs (CLI ``--params``
                format) used to resolve ``${runtime_params:...}`` interpolation for
                this request only. Values containing a literal comma are not
                supported.

        Returns:
            `SnapshotResponse` with project metadata, pipelines, datasets,
            and parameter keys, or error details on failure.
        """
        try:
            runtime_params = _parse_snapshot_params(params) if params else None
        except ValueError as exc:
            logger.error("Snapshot request failed to parse 'params': %s", exc)
            return SnapshotFailure(
                status="failure",
                error=ErrorDetail(type=type(exc).__qualname__, message=str(exc)),
            )

        try:
            snapshot = get_project_snapshot(
                env=app.state.default_env,
                conf_source=app.state.default_conf_source,
                metadata=app.state.metadata,
                runtime_params=runtime_params,
            )
            return SnapshotSuccess(
                status="success",
                metadata=snapshot.metadata,
                pipelines=snapshot.pipelines,
                datasets=snapshot.datasets,
                parameters=snapshot.parameters,
            )
        except Exception as exc:
            # Third-party exceptions (e.g. from a filesystem or storage client)
            # may embed a dataset's own unsanitised URL, so both the message
            # and the traceback are redacted before being logged or returned.
            redacted_message = _redact_url_credentials(str(exc))
            redacted_traceback = _redact_url_credentials(
                "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            )
            logger.error(
                "Snapshot request failed: %s\n%s", redacted_message, redacted_traceback
            )
            return SnapshotFailure(
                status="failure",
                error=ErrorDetail(
                    type=type(exc).__qualname__,
                    message=redacted_message,
                ),
            )

    @app.post("/run", response_model=RunResponse, tags=["pipeline"])
    def run_pipeline(request: RunRequest) -> RunResponse:
        """Execute a Kedro pipeline.

        This endpoint accepts a `RunRequest` with parameters for pipeline execution,
        runs the pipeline using the session, and returns a `RunResponse` with the result.
        First run request creates a new `KedroServiceSession`, and subsequent requests reuse it.

        Args:
            request: Pipeline execution parameters.

        Returns:
            `RunResponse` with run_id, status, duration, and optional error details.
        """
        with app.state.session_lock:
            if not hasattr(app.state, "session"):
                app.state.session = KedroServiceSession.create(
                    project_path=app.state.project_path,
                    env=app.state.default_env,
                    conf_source=app.state.default_conf_source,
                    serving_mode=True,
                )

        return _execute_pipeline(session=app.state.session, request=request)

    return app


def _parse_snapshot_params(value: str) -> dict[str, Any]:
    """Parse a `kedro run --params`-style query string into a dict, e.g.:
    "version=02,model.lr=0.01" -> {"version": 2, "model": {"lr": 0.01}}

    Values must not contain commas.
    """
    try:
        return _split_params(None, None, value)  # type: ignore[arg-type,no-any-return]
    except AttributeError as exc:
        # _split_params reports invalid input via ctx.fail(), which needs a
        # real click.Context; with ctx=None that raises AttributeError instead.
        raise ValueError(
            f"Invalid 'params' value: '{value}'. Expected comma-separated "
            "key=value pairs, e.g. 'version=02,model.lr=0.01'. Values must "
            "not contain commas."
        ) from exc


def _validate_runner_module(runner_name: str | None, package_name: str | None) -> bool:
    """Return True when the runner's module prefix is in the allowlist.

    A runner name without a module prefix (e.g. ``SequentialRunner``) always
    passes because ``load_obj`` will resolve it against ``kedro.runner``.
    Allowed prefixes are ``kedro.runner``, the project <package_name>, and any
    additional entries in ``settings.RUNNER_MODULE_ALLOWLIST``.
    """
    if runner_name is None or "." not in runner_name:
        return True
    module = runner_name.rsplit(".", 1)[0]
    return _is_module_allowed(
        module,
        ["kedro.runner", package_name, *settings.RUNNER_MODULE_ALLOWLIST],
    )


def _execute_pipeline(
    session: KedroServiceSession,
    *,
    request: RunRequest,
) -> RunResponse:
    """Execute a Kedro pipeline and return a structured result.

    It receives a `KedroServiceSession` and a `RunRequest` as input, resolves
    the runner, calls ``session.run()``, and returns a
    `RunResponse`.

    Args:
        session: Kedro service session to use for pipeline execution.
        request: Pipeline execution parameters.

    Returns:
        A `RunResponse` with run id, status, duration,
        and optional error details.
    """
    run_id: str = generate_timestamp()
    start_time = time.perf_counter()

    try:
        runner_name = request.runner or "SequentialRunner"
        if not _validate_runner_module(runner_name, session._package_name):
            module = runner_name.rsplit(".", 1)[0]
            raise ValueError(
                f"Runner module '{module}' is not allowed. "
                "Only 'kedro.runner', the project package, or modules listed in "
                "'RUNNER_MODULE_ALLOWLIST' via settings.py are permitted."
            )
        runner_class = load_obj(runner_name, "kedro.runner")
        if not (
            isinstance(runner_class, type) and issubclass(runner_class, AbstractRunner)
        ):
            raise ValueError(
                f"Runner '{runner_name}' is not a subclass of AbstractRunner. "
                "Only AbstractRunner subclasses are permitted."
            )
        runner_obj = runner_class(is_async=request.is_async)

        session.run(
            run_id=run_id,
            pipeline_names=request.pipeline_names,
            tags=tuple(request.tags) if request.tags else None,
            runner=runner_obj,
            node_names=tuple(request.node_names) if request.node_names else None,
            from_nodes=request.from_nodes,
            to_nodes=request.to_nodes,
            from_inputs=request.from_inputs,
            to_outputs=request.to_outputs,
            load_versions=request.load_versions,
            namespaces=request.namespaces,
            only_missing_outputs=request.only_missing_outputs,
            runtime_params=request.params,
        )

        duration_ms = (time.perf_counter() - start_time) * 1000
        logger.info("Pipeline run %s completed in %.2fms", run_id, duration_ms)
        return RunSuccess(
            run_id=run_id,
            status="success",
            duration_ms=round(duration_ms, 2),
        )

    except Exception as exc:
        duration_ms = (time.perf_counter() - start_time) * 1000
        # Dataset load/save failures can surface a raw dataset URL via the
        # underlying third-party exception, so both the message and the
        # traceback are redacted before being logged or returned.
        redacted_message = _redact_url_credentials(str(exc))
        redacted_traceback = _redact_url_credentials(
            "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        )
        logger.error(
            "Pipeline run %s failed: %s\n%s",
            run_id,
            redacted_message,
            redacted_traceback,
        )

        return RunFailure(
            run_id=run_id,
            status="failure",
            duration_ms=round(duration_ms, 2),
            error=ErrorDetail(
                type=type(exc).__qualname__,
                message=redacted_message,
            ),
        )
