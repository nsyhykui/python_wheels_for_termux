from __future__ import annotations

import logging
import logging.config
import os
import textwrap
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

from kedro import __version__ as kedro_version
from kedro.framework import project as kedro_project
from kedro.framework.hooks import _create_hook_manager
from kedro.framework.hooks.manager import _register_hooks, _register_hooks_entry_points
from kedro.framework.project import (
    pipelines,
    settings,
    validate_settings,
)
from kedro.io.core import generate_timestamp
from kedro.io.data_catalog import SharedMemoryDataCatalog
from kedro.pipeline.pipeline import Pipeline
from kedro.runner import AbstractRunner, ParallelRunner, SequentialRunner
from kedro.utils import find_kedro_project, get_close_matches

from .abstract_session import AbstractSession, KedroSessionError

if TYPE_CHECKING:
    from collections.abc import Iterable

    from kedro.config import AbstractConfigLoader
    from kedro.framework.context import KedroContext


class KedroServiceSession(AbstractSession):
    """``KedroServiceSession`` is the object that is responsible for managing the lifecycle
    of multiple Kedro runs. Use `KedroServiceSession.create()` as
    a context manager to construct a new KedroServiceSession with session data
    provided (see the example below).



    Example:
    ``` python
    from kedro.framework.session import KedroServiceSession
    from kedro.framework.startup import bootstrap_project
    from pathlib import Path

    # If you are creating a session outside of a Kedro project (i.e. not using
    # `kedro run` or `kedro jupyter`), you need to run `bootstrap_project` to
    # let Kedro find your configuration.
    bootstrap_project(Path("<project_root>"))
    with KedroServiceSession.create() as session:
        run_1 = session.run(runtime_params={"param1": "value1"})
        run_2 = session.run(runtime_params={"param1": "value2"})
    ```
    NOTE: This session implementation is under active development and may occasionally contain breaking changes.
    """

    def __init__(
        self,
        session_id: str,
        package_name: str | None = None,
        project_path: Path | str | None = None,
        conf_source: Path | str | None = None,
        env: str | None = None,
    ):
        self._project_path = Path(
            project_path or find_kedro_project(Path.cwd()) or Path.cwd()
        ).resolve()
        self.session_id = session_id
        self._package_name = package_name or kedro_project.PACKAGE_NAME
        hook_manager = _create_hook_manager()
        _register_hooks(hook_manager, settings.HOOKS)
        _register_hooks_entry_points(hook_manager, settings.DISABLE_HOOKS_FOR_PLUGINS)
        self._hook_manager = hook_manager
        self.env = env
        self._conf_source = conf_source or str(
            self._project_path / settings.CONF_SOURCE
        )
        self._serving_mode = False

    @classmethod
    def create(
        cls,
        session_id: str | None = None,
        project_path: Path | str | None = None,
        env: str | None = None,
        conf_source: Path | str | None = None,
        serving_mode: bool = False,
    ) -> KedroServiceSession:
        """Create a new instance of the session.

        Args:
            session_id: Optional ID for this session; defaults to a UUID.
            project_path: Optional path to the Kedro project root.
            env: Optional Kedro environment name.
            conf_source: Optional path to the configuration source directory.
            serving_mode: When ``True``, all pipelines are preloaded eagerly at
                session creation time. This ensures that the shared
                ``pipelines`` singleton is fully populated before any concurrent
                ``run()`` calls begin, making pipeline lookups safe across
                threads. Leave ``False`` (the default) for CLI use, where
                selective pipeline loading is preferred for startup performance.

        Returns:
            A new ``KedroServiceSession`` instance ready for use.
        """
        validate_settings()
        env = env or os.getenv("KEDRO_ENV")
        session = cls(
            project_path=project_path,
            session_id=session_id or str(uuid.uuid4()),
            conf_source=conf_source,
            env=env,
        )
        if serving_mode:
            session._enable_serving_mode()
        return session

    def _enable_serving_mode(self) -> None:
        """Preload all pipelines, then switch the session into serving mode.

        The flag is set *after* a successful preload so that a failure during
        loading leaves the session in normal CLI mode rather than in an
        inconsistent state where ``run()`` would skip ``set_requested()``
        against an empty pipeline registry.
        """
        self._preload_pipelines()
        self._serving_mode = True

    def _preload_pipelines(self) -> None:
        """Eagerly load all registered pipelines into the shared singleton.

        Called once during session creation in serving mode, before any request
        threads are started. After this returns, ``pipelines._content`` is
        fully populated and ``pipelines._is_data_loaded`` is ``True``, so
        subsequent concurrent ``run()`` calls read the dict without mutating
        shared state.
        """
        self._logger.info(
            "Serving mode: preloading all pipelines for session %s", self.session_id
        )
        pipelines.set_requested(None)
        list(pipelines)

    @property
    def _logger(self) -> logging.Logger:
        return logging.getLogger(__name__)

    def close(self) -> None:
        self._logger.info("Closing session %s", self.session_id)

    def _get_config_loader(
        self,
        runtime_params: dict[str, Any] | None = None,
    ) -> AbstractConfigLoader:
        """An instance of the config loader.

        Args:
            runtime_params: Extra parameters passed to a Kedro run.

        In serving mode, ``runtime_params`` originates from an untrusted caller
        (an HTTP request body), so the config loader is forced to reject a
        catalog dataset `type` driven by `runtime_params`, regardless of what a
        project's own `CONFIG_LOADER_ARGS` says -- that restriction must not be
        weakenable by project config for an untrusted caller. See
        https://github.com/kedro-org/kedro/issues/5706.
        """
        config_loader_class = settings.CONFIG_LOADER_CLASS
        config_loader_args = dict(settings.CONFIG_LOADER_ARGS)
        if self._serving_mode:
            config_loader_args["restrict_runtime_params_type_selection"] = True
        return config_loader_class(  # type: ignore[no-any-return]
            conf_source=self._conf_source,
            env=self.env,
            runtime_params=runtime_params,
            **config_loader_args,
        )

    def load_context(
        self,
        runtime_params: dict[str, Any] | None = None,
    ) -> KedroContext:
        """An instance of the project context with runtime parameters injected."""
        config_loader = self._get_config_loader(runtime_params)
        context_class = settings.CONTEXT_CLASS
        context = context_class(
            package_name=self._package_name,
            project_path=self._project_path,
            config_loader=config_loader,
            env=self.env,
            runtime_params=runtime_params,
            hook_manager=self._hook_manager,
        )
        self._hook_manager.hook.after_context_created(context=context)

        return context  # type: ignore[no-any-return]

    def run(  # noqa: PLR0913
        self,
        run_id: str | None = None,
        pipeline_names: list[str] | None = None,
        tags: Iterable[str] | None = None,
        runner: AbstractRunner | None = None,
        node_names: Iterable[str] | None = None,
        from_nodes: Iterable[str] | None = None,
        to_nodes: Iterable[str] | None = None,
        from_inputs: Iterable[str] | None = None,
        to_outputs: Iterable[str] | None = None,
        load_versions: dict[str, str] | None = None,
        namespaces: Iterable[str] | None = None,
        only_missing_outputs: bool = False,
        runtime_params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Run the pipeline."""
        run_id = run_id or generate_timestamp()
        project_name = self._package_name or self._project_path.name
        self._logger.info("Kedro project %s", project_name)
        self._logger.info("Session ID: %s", self.session_id)
        self._logger.info("Run ID: %s", run_id)
        save_version = run_id

        # In CLI mode, set_requested() tells the lazy loader which pipelines to
        # import, keeping startup fast when only one pipeline is needed.
        # In serving mode all pipelines are already loaded, so skip the write
        # to avoid mutating shared singleton state across concurrent requests.
        if not self._serving_mode:
            pipelines.set_requested(pipeline_names or None)
        context = self.load_context(runtime_params)
        pipeline_names = pipeline_names or ["__default__"]
        combined_pipeline = Pipeline([])
        for name in pipeline_names:
            try:
                combined_pipeline += pipelines[name]
            except KeyError as exc:
                if not self._serving_mode:
                    # Reset to None so keys() loads all pipelines for suggestions.
                    pipelines.set_requested(None)
                matches = get_close_matches(name, pipelines.keys())
                if matches:
                    suggestion = (
                        "Did you mean one of these instead?\n"
                        + textwrap.indent("\n".join(matches), " " * 4)
                    )
                else:
                    suggestion = ""
                raise ValueError(
                    f"Failed to find the pipeline named '{name}'. "
                    f"It needs to be generated and returned "
                    f"by the 'register_pipelines' function. "
                    f"{suggestion}"
                ) from exc

        filtered_pipeline = combined_pipeline.filter(
            tags=tags,
            from_nodes=from_nodes,
            to_nodes=to_nodes,
            node_names=node_names,
            from_inputs=from_inputs,
            to_outputs=to_outputs,
            node_namespaces=namespaces,
        )
        runner = runner or SequentialRunner()
        if not isinstance(runner, AbstractRunner):
            raise KedroSessionError(
                "KedroServiceSession expect an instance of Runner instead of a class."
                "Have you forgotten the `()` at the end of the statement?"
            )

        catalog_class = (
            SharedMemoryDataCatalog
            if isinstance(runner, ParallelRunner)
            else settings.DATA_CATALOG_CLASS
        )

        # Scope validation to the requested pipelines; `__default__` falls
        # back to validating every registered pipeline.
        if "__default__" not in pipeline_names:
            context._pipelines_to_validate = list(pipeline_names)

        catalog = context._get_catalog(
            catalog_class=catalog_class,
            save_version=save_version,
            load_versions=load_versions,
        )

        record_data = {
            "session_id": self.session_id,
            "run_id": run_id,
            "project_path": self._project_path.as_posix(),
            "env": context.env,
            "kedro_version": kedro_version,
            "tags": tags,
            "from_nodes": from_nodes,
            "to_nodes": to_nodes,
            "node_names": node_names,
            "from_inputs": from_inputs,
            "to_outputs": to_outputs,
            "load_versions": load_versions,
            "runtime_params": runtime_params or {},
            "pipeline_names": pipeline_names,
            "namespaces": namespaces,
            "runner": getattr(runner, "__name__", str(runner)),
            "only_missing_outputs": only_missing_outputs,
        }

        # Run the runner
        hook_manager = self._hook_manager
        hook_manager.hook.before_pipeline_run(
            run_params=record_data, pipeline=filtered_pipeline, catalog=catalog
        )
        try:
            run_result = runner.run(
                filtered_pipeline,
                catalog,
                hook_manager,
                run_id=run_id,
                only_missing_outputs=only_missing_outputs,
            )
        except Exception as error:
            hook_manager.hook.on_pipeline_error(
                error=error,
                run_params=record_data,
                pipeline=filtered_pipeline,
                catalog=catalog,
            )
            raise

        hook_manager.hook.after_pipeline_run(
            run_params=record_data,
            run_result=run_result,
            pipeline=filtered_pipeline,
            catalog=catalog,
        )
        return run_result
