#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

"""
Change ``signed_url_template`` from VARCHAR(200) to TEXT.

Revision ID: 509b94a1042d
Revises: 82dbd68e6171
Create Date: 2026-02-14 23:27:15.069945

"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

from airflow.migrations.utils import disable_sqlite_fkeys

# revision identifiers, used by Alembic.
revision = "509b94a1042d"
down_revision = "82dbd68e6171"
branch_labels = None
depends_on = None
airflow_version = "3.1.8"


def upgrade():
    """Apply Change signed_url_template from VARCHAR(200) to TEXT."""
    with disable_sqlite_fkeys(op):
        with op.batch_alter_table("dag_bundle", schema=None) as batch_op:
            batch_op.alter_column(
                "signed_url_template",
                existing_type=sa.VARCHAR(length=200),
                type_=sa.Text(),
                existing_nullable=True,
            )


def downgrade():
    """Unapply Change signed_url_template from VARCHAR(200) to TEXT."""
    with disable_sqlite_fkeys(op):
        with op.batch_alter_table("dag_bundle", schema=None) as batch_op:
            batch_op.alter_column(
                "signed_url_template",
                existing_type=sa.Text(),
                type_=sa.VARCHAR(length=200),
                existing_nullable=True,
            )
