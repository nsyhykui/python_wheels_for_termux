# Portions of this package are derived from MCPCat/mcpcat-typescript-sdk
# Copyright (c) 2025 MCPcat
# Licensed under the MIT License: https://github.com/MCPCat/mcpcat-typescript-sdk/blob/main/LICENSE

"""Public event names and property wire-keys for PostHog MCP analytics.

These are plain classes with string class attributes (not ``enum.StrEnum``,
which is 3.11+) so they work on the repo's minimum Python 3.10 and read the same
way as the TypeScript const objects: ``PostHogMCPAnalyticsEvent.TOOL_CALL``.
"""

__all__ = [
    "POSTHOG_MCP_ANALYTICS_SOURCE",
    "PostHogMCPAnalyticsEvent",
    "PostHogMCPAnalyticsProperty",
]

INACTIVITY_TIMEOUT_IN_MINUTES = 30

DEFAULT_CONTEXT_PARAMETER_DESCRIPTION = (
    "Explain in 15-25 words, in third person, why this tool is called and how it supports "
    "the user's goal. For analytics only. You MUST describe only the abstract purpose of the "
    "tool call. NEVER include, repeat, paraphrase, or infer personal, sensitive, or identifying "
    "information from the user request or tool results, including names, emails, phone numbers, "
    'IPs, IDs, or credentials. You MUST generalize specific entities into roles such as "a user", '
    '"the customer", or "an account". Example: "Retrieving a customer\'s recent orders to '
    'investigate a billing issue and help support determine the appropriate resolution."'
)

DEFAULT_CONVERSATION_ID_DESCRIPTION = (
    "Echo the conversation_id from the server's previous response. The server provides it on "
    "the first call — never invent one, and do not issue parallel tool calls until you have it."
)

DEFAULT_MODEL_PARAMETER_DESCRIPTION = (
    "The exact model identifier you (the assistant) are running as, taken from your "
    'system prompt or environment (e.g. "claude-opus-4-8", "gpt-5.2"). Used for '
    'analytics only. If you do not know your model identifier with certainty, pass "unknown" '
    "— never guess."
)

POSTHOG_MCP_ANALYTICS_SOURCE = "posthog_mcp_analytics"
POSTHOG_MCP_LIB_NAME = "posthog-python-mcp"


class PostHogMCPAnalyticsEvent:
    """PostHog-owned event names. All ``$``-prefixed per the PostHog convention;
    non-``$`` names would be treated as customer-defined events."""

    CUSTOM = "$mcp_custom"
    EXCEPTION = "$exception"
    IDENTIFY = "$identify"
    INITIALIZE = "$mcp_initialize"
    MISSING_CAPABILITY = "$mcp_missing_capability"
    PROMPT_GET = "$mcp_prompt_get"
    PROMPTS_LIST = "$mcp_prompts_list"
    RESOURCE_READ = "$mcp_resource_read"
    RESOURCES_LIST = "$mcp_resources_list"
    TOOL_CALL = "$mcp_tool_call"
    TOOLS_LIST = "$mcp_tools_list"


class PostHogMCPAnalyticsProperty:
    """PostHog property wire-keys emitted on MCP events."""

    CLIENT_NAME = "$mcp_client_name"
    CLIENT_USER_AGENT = "$mcp_client_user_agent"
    CLIENT_VERSION = "$mcp_client_version"
    VENDOR_CLIENT = "$mcp_vendor_client"
    PROTOCOL_VERSION = "$mcp_protocol_version"
    CONVERSATION_ID = "$mcp_conversation_id"
    DURATION_MS = "$mcp_duration_ms"
    ERROR_MESSAGE = "$mcp_error_message"
    ERROR_TYPE = "$mcp_error_type"
    IS_ERROR = "$mcp_is_error"
    INTENT = "$mcp_intent"
    INTENT_SOURCE = "$mcp_intent_source"
    LLM_MODEL = "$mcp_llm_model"
    LLM_MODEL_SOURCE = "$mcp_llm_model_source"
    LISTED_TOOL_NAMES = "$mcp_listed_tool_names"
    PARAMETERS = "$mcp_parameters"
    RESOURCE_NAME = "$mcp_resource_name"
    RESPONSE = "$mcp_response"
    SERVER_NAME = "$mcp_server_name"
    SERVER_VERSION = "$mcp_server_version"
    SESSION_ID = "$session_id"
    SOURCE = "$mcp_source"
    TOOL_CATEGORY = "$mcp_tool_category"
    TOOL_DESCRIPTION = "$mcp_tool_description"
    TOOL_NAME = "$mcp_tool_name"
