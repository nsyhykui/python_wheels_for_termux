"""Frictionless session-token minting for stateless / multi-pod MCP servers.

A stateless MCP server issues no session id, so ``$session_id`` fragments across
pods and the client identity (the "harness") sent only at ``initialize`` is lost.
The fix is a self-encoded token (see :mod:`.session_token`) minted onto the
``Mcp-Session-Id`` response header at ``initialize``; clients replay it on every
request, so any pod recovers session + harness from the header alone.

The MCP Python SDK owns ``initialize`` in its runner/session layer and forbids
overriding it via ``request_handlers``, so -- unlike the TS SDK, which wraps the
initialize handler -- there is no in-SDK seam to mint from. We mint at the HTTP
layer instead, with a pure-ASGI middleware that works for both a mounted FastMCP
app and a custom ``PostHogMCP`` dispatcher, across every SDK routing path.

On the ``instrument()`` path this is **wired up automatically**:
``instrument(server, ...)`` wraps the FastMCP server's app factories
(``streamable_http_app()`` / ``sse_app()``, which ``mcp.run()`` also calls), so the
app it builds already carries the middleware -- nothing extra to add.

For a custom ``PostHogMCP`` dispatcher (you own the ASGI app), add it once::

    app.add_middleware(PostHogMcpStatelessSessionMiddleware)

then read the recovered session on any request::

    sess = get_mcp_session(request)
    posthog.capture_tool_call(
        tool_name=name,
        session_id=sess.session_id if sess else None,
        client_name=sess.client_name if sess else None,
        client_version=sess.client_version if sess else None,
    )

This module has no hard dependency on Starlette/FastAPI -- it speaks raw ASGI.
"""

from __future__ import annotations

import functools
import json
from typing import Any, Optional

from .logger import log, warn
from .session import new_session_id
from .session_token import (
    MCP_SESSION_HEADER,
    SessionTokenPayload,
    decode_session_id,
    encode_session_id,
    read_mcp_session_header,
)

# Scope key the middleware stashes the decoded token payload under.
_SCOPE_KEY = "posthog_mcp_session"

# JSON-RPC request bodies are tiny; cap what we buffer so a stray large POST on
# the same app can't be read into memory in full before minting.
_MAX_SNIFF_BODY = 256 * 1024


def get_mcp_session(request_or_scope: Any) -> Optional[SessionTokenPayload]:
    """Return the ``SessionTokenPayload`` the middleware recovered for this request,
    or ``None``. Accepts a Starlette ``Request`` or a raw ASGI ``scope`` dict."""
    scope = getattr(request_or_scope, "scope", request_or_scope)
    if not isinstance(scope, dict):
        return None
    value = scope.get(_SCOPE_KEY)
    return value if isinstance(value, SessionTokenPayload) else None


class PostHogMcpStatelessSessionMiddleware:
    """ASGI middleware that mints a session token onto the ``Mcp-Session-Id``
    response header at ``initialize`` (when the client sent none) and decodes the
    replayed token on every request, exposing it via :func:`get_mcp_session`.

    Fail-safe: any error while sniffing/minting is logged and the request passes
    through untouched -- analytics must never break the host."""

    def __init__(self, app: Any) -> None:
        self.app = app

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        try:
            incoming_header = read_mcp_session_header(_headers_dict(scope))
        except Exception as error:  # noqa: BLE001
            log(f"PostHog MCP session middleware: header read failed - {error}")
            await self.app(scope, receive, send)
            return

        # Decode a replayed token (if any) so the app can read it via get_mcp_session.
        decoded = decode_session_id(incoming_header)
        if decoded is not None:
            scope[_SCOPE_KEY] = decoded

        # Only POSTs carry JSON-RPC. Mint only when the client replayed no session
        # id at all -- if one is present (ours or a stateful transport's), leave it.
        if scope.get("method") != "POST" or incoming_header is not None:
            await self.app(scope, receive, send)
            return

        # Guard the whole sniff+mint path: on any failure (a raising receive() or
        # adversarial body) the request passes through untouched, per the contract.
        token = None
        try:
            body, receive = await _buffer_body(receive)
            token = _mint_token_if_initialize(body)
        except Exception as error:  # noqa: BLE001
            log(f"PostHog MCP session middleware: mint failed - {error}")

        if token is None:
            await self.app(scope, receive, send)
            return

        scope[_SCOPE_KEY] = decode_session_id(token)
        await self.app(scope, receive, _sending_session_header(send, token))


def _headers_dict(scope: Any) -> dict[str, str]:
    """ASGI raw headers (list of (bytes, bytes)) -> a lowercased str dict."""
    result: dict[str, str] = {}
    for key, value in scope.get("headers") or []:
        try:
            result[key.decode("latin-1").lower()] = value.decode("latin-1")
        except Exception:  # noqa: BLE001
            continue
    return result


async def _buffer_body(receive: Any) -> tuple[bytes, Any]:
    """Read up to ``_MAX_SNIFF_BODY`` of the request body for sniffing, then return
    that prefix plus a ``receive`` that replays it and streams the rest.

    Memory is bounded to the cap: an `initialize` handshake is tiny, so once we
    exceed the cap the request cannot be one and we stop buffering — the prefix is
    replayed with ``more_body: True`` and any remaining chunks are forwarded
    straight from the original ``receive`` (never accumulated). This keeps an
    unauthenticated large / streamed POST from exhausting memory."""
    chunks: list[bytes] = []
    total = 0
    complete = False
    overflow = False
    while True:
        message = await receive()
        if message.get("type") != "http.request":
            # A non-body message (e.g. http.disconnect); stop with what we have.
            break
        chunks.append(message.get("body", b"") or b"")
        total += len(chunks[-1])
        if not message.get("more_body", False):
            complete = True
            break
        if total > _MAX_SNIFF_BODY:
            overflow = True  # too big to be initialize — stop buffering
            break

    buffered = b"".join(chunks)
    replayed = False

    async def replay() -> dict[str, Any]:
        # Replay the buffered prefix once; if we stopped early, flag more_body so
        # the app keeps pulling the rest straight from the original transport.
        nonlocal replayed
        if not replayed:
            replayed = True
            return {"type": "http.request", "body": buffered, "more_body": overflow}
        return await receive()

    # Only sniff (parse for `initialize`) when we captured the whole small body.
    sniff = buffered if (complete and not overflow) else b""
    return sniff, replay


def _mint_token_if_initialize(body: bytes) -> Optional[str]:
    """If ``body`` is an ``initialize`` JSON-RPC request, mint and return a token
    string carrying a fresh session id + the client's self-reported identity.
    Returns ``None`` for anything else (never raises)."""
    if not body:
        return None
    try:
        # RecursionError (deeply-nested JSON) is a RuntimeError, not a
        # ValueError/TypeError -- catch broadly so a hostile body can't escape.
        message = json.loads(body)
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(message, dict) or message.get("method") != "initialize":
        return None
    params = message.get("params")
    params = params if isinstance(params, dict) else {}
    client_info = params.get("clientInfo")
    client_info = client_info if isinstance(client_info, dict) else {}
    try:
        return encode_session_id(
            SessionTokenPayload(
                session_id=new_session_id(),
                client_name=_str_or_none(client_info.get("name")),
                client_version=_str_or_none(client_info.get("version")),
                protocol_version=_str_or_none(params.get("protocolVersion")),
            )
        )
    except Exception as error:  # noqa: BLE001
        log(f"PostHog MCP session middleware: mint failed - {error}")
        return None


def _sending_session_header(send: Any, token: str) -> Any:
    """Wrap ``send`` so the outgoing response start carries ``Mcp-Session-Id: token``
    -- but only if the app/transport didn't already set one (never clobber a
    stateful transport's own session id)."""
    header = MCP_SESSION_HEADER.encode("latin-1")
    token_bytes = token.encode("latin-1")

    async def wrapped(message: dict[str, Any]) -> None:
        if message.get("type") == "http.response.start":
            headers = list(message.get("headers") or [])
            if not any(k.lower() == header for k, _ in headers):
                headers.append((header, token_bytes))
                message = {**message, "headers": headers}
        await send(message)

    return wrapped


def _str_or_none(value: Any) -> Optional[str]:
    return value if isinstance(value, str) and value else None


# Marker so we never double-wrap a factory (idempotent across repeat instrument()).
_AUTOWIRED = "__posthog_mcp_autowired__"


def autowire_stateless_mint(server: Any) -> None:
    """Make stateless minting zero-config on the ``instrument()`` path.

    Wraps a FastMCP server's ASGI-app factories so the app they build already has
    :class:`PostHogMcpStatelessSessionMiddleware` applied. Covers both
    ``server.streamable_http_app()`` / ``sse_app()`` and ``mcp.run(transport=...)``
    (which calls those factories internally), so the user adds nothing.

    No-op for servers without app factories (stdio / low-level ``Server``), and safe
    if the middleware is also added manually (it only mints when none is present).
    On fastmcp 2.x, ``streamable_http_app`` / ``sse_app`` can be thin wrappers over
    ``http_app``; wrapping all three could add the middleware twice to one app, so
    the factory guards against a double-add (see ``_app_already_wrapped``)."""
    _warn_if_app_built_before_instrument(server)
    for attr in ("streamable_http_app", "sse_app", "http_app"):
        original = getattr(server, attr, None)
        if not callable(original) or getattr(original, _AUTOWIRED, False):
            continue
        try:
            setattr(server, attr, _wrap_app_factory(original))
        except Exception as error:  # noqa: BLE001 - never let wiring break instrument()
            log(f"PostHog MCP: could not auto-wire stateless mint on {attr} - {error}")


def _app_was_already_built(server: Any) -> bool:
    """Whether the streamable-HTTP app already exists, so wrapping the factories
    now cannot retrofit it.

    The tell is ``_session_manager``, created lazily on the first
    ``streamable_http_app()`` call and non-``None`` forever after. It sits on the
    server itself on the official SDK's ``FastMCP`` (1.x) and on the low-level
    server it delegates to (2.x's ``MCPServer`` renamed that attribute
    ``_lowlevel_server``; older/other wrappers may still use ``_mcp_server``), so
    check both names.

    Deliberately partial: jlowin's ``fastmcp`` 2.x/3.x keeps its session manager as
    a local inside ``http_app()`` and never stores it, so there is nothing to probe
    and those servers get no instrument-time warning. The runtime warning in
    ``_instrumentation`` still covers them."""
    low_level = getattr(server, "_mcp_server", None) or getattr(
        server, "_lowlevel_server", None
    )
    for candidate in (server, low_level):
        try:
            if getattr(candidate, "_session_manager", None) is not None:
                return True
        except Exception:  # noqa: BLE001 - never let a probe break instrument()
            continue
    return False


def _warn_if_app_built_before_instrument(server: Any) -> None:
    """Catch the ordering trap that silently disables stateless capture: the
    streamable-HTTP app was built (and likely already mounted) *before* ``instrument()``
    ran, so wrapping the factories now can't retrofit that already-built app."""
    if not _app_was_already_built(server):
        return
    warn(
        "Warning: streamable_http_app() was called before instrument(), so the ASGI app "
        "already in use has no PostHog MCP middleware and stateless sessions will not be "
        "captured (autowiring only affects apps built after instrument() runs). Call "
        "instrument(server) before building or mounting the app, or add the middleware "
        "manually: app.add_middleware(PostHogMcpStatelessSessionMiddleware). "
        "You can ignore this if you already added the middleware yourself — the app is "
        "built by then, so there is no way for us to tell from here. "
        "See posthog/mcp/README.md (stateless / multi-pod servers)."
    )


def _app_already_wrapped(app: Any) -> bool:
    """True if ``app`` already carries our middleware -- so wrapping a factory that
    delegates to another wrapped factory (fastmcp 2.x aliases) doesn't add it twice."""
    if isinstance(app, PostHogMcpStatelessSessionMiddleware):
        return True
    for middleware in getattr(app, "user_middleware", None) or []:
        if getattr(middleware, "cls", None) is PostHogMcpStatelessSessionMiddleware:
            return True
    return False


def _wrap_app_factory(original: Any) -> Any:
    @functools.wraps(original)
    def factory(*args: Any, **kwargs: Any) -> Any:
        app = original(*args, **kwargs)
        if _app_already_wrapped(app):
            return app
        add_middleware = getattr(app, "add_middleware", None)
        if callable(add_middleware):
            add_middleware(PostHogMcpStatelessSessionMiddleware)
            return app
        # Not a Starlette app -- wrap as raw ASGI so minting still happens.
        return PostHogMcpStatelessSessionMiddleware(app)

    setattr(factory, _AUTOWIRED, True)
    return factory
