# Portions of this package are derived from MCPCat/mcpcat-typescript-sdk
# Copyright (c) 2025 MCPcat
# Licensed under the MIT License: https://github.com/MCPCat/mcpcat-typescript-sdk/blob/main/LICENSE

# Version of the PostHog MCP analytics SDK surface. Stamped as ``sdk_version``
# on every captured event. The package itself ships inside posthog.
__version__ = "0.3.0"
