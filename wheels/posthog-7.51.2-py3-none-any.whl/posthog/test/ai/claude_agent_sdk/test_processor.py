from __future__ import annotations

import base64
import logging
from types import SimpleNamespace
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock, patch

import pytest

from posthog.version import VERSION

try:
    from claude_agent_sdk.types import (
        AssistantMessage,
        ClaudeAgentOptions,
        ResultMessage,
        StreamEvent,
        TextBlock,
        ToolUseBlock,
    )

    from posthog.ai.claude_agent_sdk import (
        PostHogClaudeAgentProcessor,
        instrument,
        query as posthog_query,
    )

    CLAUDE_AGENT_SDK_AVAILABLE = True
except ImportError:
    CLAUDE_AGENT_SDK_AVAILABLE = False

pytestmark = pytest.mark.skipif(
    not CLAUDE_AGENT_SDK_AVAILABLE, reason="Claude Agent SDK is not available"
)


# ── Helpers ──────────────────────────────────────────────────────


def _make_stream_event(
    event_type: str, data: Optional[Dict[str, Any]] = None, session_id: str = "sess_123"
) -> StreamEvent:
    event = {"type": event_type, **(data or {})}
    return StreamEvent(uuid="evt_1", session_id=session_id, event=event)


def _make_message_start(
    model: str = "claude-sonnet-4-6",
    input_tokens: int = 100,
    output_tokens: int = 0,
    cache_read: int = 0,
    cache_creation: int = 0,
) -> StreamEvent:
    return _make_stream_event(
        "message_start",
        {
            "message": {
                "model": model,
                "usage": {
                    "input_tokens": input_tokens,
                    "output_tokens": output_tokens,
                    "cache_read_input_tokens": cache_read,
                    "cache_creation_input_tokens": cache_creation,
                },
            },
        },
    )


def _make_message_delta(output_tokens: int = 50) -> StreamEvent:
    return _make_stream_event(
        "message_delta",
        {
            "usage": {"output_tokens": output_tokens},
        },
    )


def _make_message_stop() -> StreamEvent:
    return _make_stream_event("message_stop")


def _make_assistant_message(
    model: str = "claude-sonnet-4-6",
    text: str = "Hello!",
    tool_uses: Optional[List[Dict[str, Any]]] = None,
) -> AssistantMessage:
    content = [TextBlock(text=text)]
    if tool_uses:
        for tu in tool_uses:
            content.append(
                ToolUseBlock(id=tu["id"], name=tu["name"], input=tu.get("input", {}))
            )
    return AssistantMessage(content=content, model=model)


def _make_result_message(
    total_cost_usd: float = 0.01,
    input_tokens: int = 100,
    output_tokens: int = 50,
    duration_ms: int = 2000,
    duration_api_ms: int = 1500,
    num_turns: int = 3,
    is_error: bool = False,
    cache_read: int = 0,
    cache_creation: int = 0,
    cache_creation_ttl: Optional[Dict[str, int]] = None,
) -> ResultMessage:
    usage: Dict[str, Any] = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_input_tokens": cache_read,
        "cache_creation_input_tokens": cache_creation,
    }
    if cache_creation_ttl is not None:
        usage["cache_creation"] = cache_creation_ttl

    return ResultMessage(
        subtype="success" if not is_error else "error",
        duration_ms=duration_ms,
        duration_api_ms=duration_api_ms,
        is_error=is_error,
        num_turns=num_turns,
        session_id="sess_123",
        total_cost_usd=total_cost_usd,
        usage=usage,
    )


async def _fake_query(messages):
    """Create a fake query function that yields pre-defined messages."""
    for msg in messages:
        yield msg


# ── Fixtures ─────────────────────────────────────────────────────


@pytest.fixture
def mock_client():
    client = MagicMock()
    client.privacy_mode = False
    logging.getLogger("posthog").setLevel(logging.DEBUG)
    return client


@pytest.fixture
def processor(mock_client):
    return PostHogClaudeAgentProcessor(
        client=mock_client,
        distinct_id="test-user",
        privacy_mode=False,
    )


# ── Tests ────────────────────────────────────────────────────────


class TestPostHogClaudeAgentProcessor:
    def test_initialization(self, mock_client):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            distinct_id="user@example.com",
            privacy_mode=True,
            groups={"company": "acme"},
            properties={"env": "test"},
        )
        assert proc._client == mock_client
        assert proc._distinct_id == "user@example.com"
        assert proc._privacy_mode is True
        assert proc._groups == {"company": "acme"}
        assert proc._properties == {"env": "test"}

    def test_initialization_defaults(self):
        with patch("posthog.ai.claude_agent_sdk.processor.setup") as mock_setup:
            mock_setup.return_value = MagicMock()
            proc = PostHogClaudeAgentProcessor()
            assert proc._distinct_id is None
            assert proc._privacy_mode is False
            assert proc._groups == {}
            assert proc._properties == {}


class TestGenerationEmission:
    @pytest.mark.asyncio
    async def test_emits_generation_from_stream_events(self, processor, mock_client):
        messages = [
            _make_message_start(input_tokens=100, cache_read=20),
            _make_message_delta(output_tokens=50),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            collected = []
            async for msg in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                collected.append(msg)

        # Should have captured $ai_generation + $ai_trace
        calls = mock_client.capture.call_args_list
        events = [c.kwargs.get("event") or c[1].get("event") for c in calls]
        assert "$ai_generation" in events
        assert "$ai_trace" in events

        # Check generation properties
        gen_call = next(
            c
            for c in calls
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_generation"
        )
        props = gen_call.kwargs.get("properties") or gen_call[1].get("properties")
        assert props["$ai_provider"] == "anthropic"
        assert props["$ai_framework"] == "claude-agent-sdk"
        assert props["$ai_model"] == "claude-sonnet-4-6"
        assert props["$ai_input_tokens"] == 100
        assert props["$ai_output_tokens"] == 50
        assert props["$ai_cache_read_input_tokens"] == 20

    @pytest.mark.asyncio
    async def test_emits_cache_creation_ttl_breakdown_from_stream_events(
        self, processor, mock_client
    ):
        message_start = _make_message_start(input_tokens=100, cache_creation=800)
        message_start.event["message"]["usage"]["cache_creation"] = {
            "ephemeral_5m_input_tokens": 300,
            "ephemeral_1h_input_tokens": 500,
        }
        messages = [
            message_start,
            _make_message_delta(output_tokens=50),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        generation_call = next(
            call
            for call in mock_client.capture.call_args_list
            if (call.kwargs.get("event") or call[1].get("event")) == "$ai_generation"
        )
        props = generation_call.kwargs.get("properties") or generation_call[1].get(
            "properties"
        )
        assert props["$ai_cache_creation_input_tokens"] == 800
        assert props["$ai_usage"]["cache_creation"] == {
            "ephemeral_5m_input_tokens": 300,
            "ephemeral_1h_input_tokens": 500,
        }

    @pytest.mark.asyncio
    async def test_emits_multiple_generations_for_multi_turn(
        self, processor, mock_client
    ):
        messages = [
            # Turn 1
            _make_message_start(input_tokens=50),
            _make_message_delta(output_tokens=30),
            _make_message_stop(),
            _make_assistant_message(),
            # Turn 2
            _make_message_start(input_tokens=80),
            _make_message_delta(output_tokens=40),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(num_turns=2),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        gen_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_generation"
        ]
        assert len(gen_calls) == 2

    @pytest.mark.asyncio
    async def test_fallback_generation_from_result_when_no_stream_events(
        self, processor, mock_client
    ):
        """When StreamEvents are not available, fall back to ResultMessage data."""
        messages = [
            _make_assistant_message(),
            _make_result_message(
                input_tokens=200,
                output_tokens=100,
                cache_creation=800,
                cache_creation_ttl={
                    "ephemeral_5m_input_tokens": 300,
                    "ephemeral_1h_input_tokens": 500,
                },
            ),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        gen_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_generation"
        ]
        assert len(gen_calls) == 1
        props = gen_calls[0].kwargs.get("properties") or gen_calls[0][1].get(
            "properties"
        )
        assert props["$ai_input_tokens"] == 200
        assert props["$ai_output_tokens"] == 100
        assert props["$ai_cache_creation_input_tokens"] == 800
        assert props["$ai_usage"]["cache_creation"] == {
            "ephemeral_5m_input_tokens": 300,
            "ephemeral_1h_input_tokens": 500,
        }

    @pytest.mark.asyncio
    async def test_fallback_copies_result_usage_before_capture(
        self, processor, mock_client
    ):
        result = _make_result_message(input_tokens=200)
        messages = [_make_assistant_message(), result]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        generation_call = next(
            call
            for call in mock_client.capture.call_args_list
            if (call.kwargs.get("event") or call[1].get("event")) == "$ai_generation"
        )
        props = generation_call.kwargs.get("properties") or generation_call[1].get(
            "properties"
        )

        assert result.usage is not None
        result.usage["input_tokens"] = 999

        assert props["$ai_usage"]["input_tokens"] == 200


class TestToolSpanEmission:
    @pytest.mark.asyncio
    async def test_emits_span_for_tool_use(self, processor, mock_client):
        messages = [
            _make_message_start(),
            _make_message_stop(),
            _make_assistant_message(
                tool_uses=[
                    {
                        "id": "tu_1",
                        "name": "Read",
                        "input": {"file_path": "/tmp/test.py"},
                    },
                ]
            ),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(
                prompt="Read a file", options=ClaudeAgentOptions()
            ):
                pass

        span_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_span"
        ]
        assert len(span_calls) == 1
        props = span_calls[0].kwargs.get("properties") or span_calls[0][1].get(
            "properties"
        )
        assert props["$ai_span_name"] == "Read"
        assert props["$ai_span_type"] == "tool"
        assert props["$ai_input_state"] == {"file_path": "/tmp/test.py"}


class TestTraceEmission:
    @pytest.mark.asyncio
    async def test_emits_trace_on_result(self, processor, mock_client):
        messages = [
            _make_message_start(),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(total_cost_usd=0.05, duration_ms=3000, is_error=False),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        trace_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_trace"
        ]
        assert len(trace_calls) == 1
        props = trace_calls[0].kwargs.get("properties") or trace_calls[0][1].get(
            "properties"
        )
        assert props["$ai_trace_name"] == "claude_agent_sdk_query"
        assert props["$ai_total_cost_usd"] == 0.05
        assert props["$ai_latency"] == 3.0
        assert props["$ai_is_error"] is False

    @pytest.mark.asyncio
    async def test_trace_emits_error_status(self, processor, mock_client):
        messages = [
            _make_result_message(is_error=True, total_cost_usd=0.0),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        trace_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_trace"
        ]
        assert len(trace_calls) == 1
        props = trace_calls[0].kwargs.get("properties") or trace_calls[0][1].get(
            "properties"
        )
        assert props["$ai_is_error"] is True


class TestPrivacyMode:
    @pytest.mark.asyncio
    async def test_client_privacy_mode_redacts_generation_input(self, mock_client):
        mock_client.privacy_mode = True
        proc = PostHogClaudeAgentProcessor(client=mock_client, distinct_id="user")
        messages = [_make_message_start(), _make_message_stop()]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(prompt="secret", options=ClaudeAgentOptions()):
                pass

        properties = mock_client.capture.call_args.kwargs["properties"]
        assert properties["$ai_input"] is None

    @pytest.mark.asyncio
    @pytest.mark.parametrize(
        ("processor_privacy", "call_privacy"),
        [(False, True), (True, False)],
    )
    async def test_per_call_privacy_mode_cannot_disable_processor_mode(
        self, mock_client, processor_privacy, call_privacy
    ):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            distinct_id="user",
            privacy_mode=processor_privacy,
        )
        messages = [_make_message_start(), _make_message_stop()]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(
                prompt="secret",
                options=ClaudeAgentOptions(),
                posthog_privacy_mode=call_privacy,
            ):
                pass

        properties = mock_client.capture.call_args.kwargs["properties"]
        assert properties["$ai_input"] is None

    @pytest.mark.asyncio
    async def test_client_without_privacy_mode_captures_content(self):
        client = SimpleNamespace(capture=MagicMock())
        proc = PostHogClaudeAgentProcessor(client=client, distinct_id="user")
        messages = [_make_message_start(), _make_message_stop()]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(prompt="visible", options=ClaudeAgentOptions()):
                pass

        properties = client.capture.call_args.kwargs["properties"]
        assert properties["$ai_input"] == [{"role": "user", "content": "visible"}]

    @pytest.mark.asyncio
    async def test_privacy_mode_redacts_tool_input(self, mock_client):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            distinct_id="user",
            privacy_mode=True,
        )
        message_start = _make_message_start(cache_creation=800)
        message_start.event["message"]["usage"]["cache_creation"] = {
            "ephemeral_5m_input_tokens": 300,
            "ephemeral_1h_input_tokens": 500,
        }
        messages = [
            message_start,
            _make_message_stop(),
            _make_assistant_message(
                tool_uses=[
                    {
                        "id": "tu_1",
                        "name": "Read",
                        "input": {"file_path": "/secret/file"},
                    },
                ]
            ),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(
                prompt="Read secret", options=ClaudeAgentOptions()
            ):
                pass

        span_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_span"
        ]
        assert len(span_calls) == 1
        props = span_calls[0].kwargs.get("properties") or span_calls[0][1].get(
            "properties"
        )
        assert "$ai_input_state" not in props

        generation_call = next(
            call
            for call in mock_client.capture.call_args_list
            if (call.kwargs.get("event") or call[1].get("event")) == "$ai_generation"
        )
        generation_props = generation_call.kwargs.get("properties") or generation_call[
            1
        ].get("properties")
        assert generation_props["$ai_input"] is None
        assert generation_props.get("$ai_output_choices") is None
        assert generation_props["$ai_usage"]["cache_creation"] == {
            "ephemeral_5m_input_tokens": 300,
            "ephemeral_1h_input_tokens": 500,
        }


class TestMediaRedactionEndToEnd:
    @pytest.mark.asyncio
    async def test_data_url_prompt_and_tool_use_base64_are_redacted(
        self, processor, mock_client
    ):
        """A data-URL image in the prompt ($ai_input) and base64 in a
        tool_use block's input (relayed into $ai_output_choices via
        format_assistant_blocks) must both be redacted end-to-end."""
        png_b64 = base64.b64encode(b"\x89PNG\r\n\x1a\n" + b"\x00" * 400).decode()
        data_url = f"data:image/png;base64,{png_b64}"

        messages = [
            _make_message_start(),
            _make_message_stop(),
            _make_assistant_message(
                tool_uses=[
                    {"id": "tu_1", "name": "Read", "input": {"image": data_url}},
                ]
            ),
            _make_message_start(),
            _make_message_stop(),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(
                prompt=data_url, options=ClaudeAgentOptions()
            ):
                pass

        gen_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_generation"
        ]
        assert len(gen_calls) == 2

        gen1_props = gen_calls[0].kwargs.get("properties") or gen_calls[0][1].get(
            "properties"
        )
        assert gen1_props["$ai_input"][0]["content"] == "[base64 image redacted]"

        gen2_props = gen_calls[1].kwargs.get("properties") or gen_calls[1][1].get(
            "properties"
        )
        output_content = gen2_props["$ai_output_choices"][0]["content"]
        function_block = next(
            item for item in output_content if item.get("type") == "function"
        )
        assert (
            function_block["function"]["arguments"]["image"]
            == "[base64 image redacted]"
        )


class TestPersonlessMode:
    @pytest.mark.asyncio
    async def test_no_distinct_id_sets_process_person_profile_false(self, mock_client):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            distinct_id=None,
        )
        messages = [
            _make_message_start(),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(
                prompt="Hi",
                options=ClaudeAgentOptions(),
                posthog_trace_id="trace-fallback",
            ):
                pass

        for call in mock_client.capture.call_args_list:
            props = call.kwargs.get("properties") or call[1].get("properties")
            assert props.get("$process_person_profile") is False
            assert call.kwargs["distinct_id"] == "trace-fallback"


class TestCapturePolicy:
    def test_explicit_groups_override_preserves_empty_groups(self, mock_client):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            groups={"company": "default"},
        )

        proc._capture_event("$ai_trace", {}, groups={})

        assert mock_client.capture.call_args.kwargs["groups"] == {}

    def test_default_properties_keep_existing_precedence(self, mock_client):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            properties={"environment": "processor"},
        )

        proc._capture_event(
            "$ai_trace",
            {"environment": "event", "$ai_trace_id": "trace-id"},
        )

        assert mock_client.capture.call_args.kwargs["properties"] == {
            "$ai_lib": "posthog-ai",
            "$ai_lib_version": VERSION,
            "environment": "processor",
            "$ai_trace_id": "trace-id",
        }

    def test_client_without_capture_capability_is_ignored(self):
        proc = PostHogClaudeAgentProcessor(client=object())

        proc._capture_event("$ai_trace", {})

    def test_capture_errors_are_logged_and_suppressed(self, mock_client, caplog):
        mock_client.capture.side_effect = RuntimeError("capture failed")
        proc = PostHogClaudeAgentProcessor(client=mock_client)

        with caplog.at_level(logging.DEBUG, logger="posthog"):
            proc._capture_event("$ai_trace", {})

        assert "Failed to capture PostHog event: capture failed" in caplog.text


class TestCustomProperties:
    @pytest.mark.asyncio
    async def test_instance_properties_merged(self, mock_client):
        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            distinct_id="user",
            properties={"app": "stamphog", "version": "1.0"},
        )
        messages = [
            _make_message_start(),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        for call in mock_client.capture.call_args_list:
            props = call.kwargs.get("properties") or call[1].get("properties")
            assert props.get("app") == "stamphog"
            assert props.get("version") == "1.0"

    @pytest.mark.asyncio
    async def test_per_call_properties_merged(self, processor, mock_client):
        messages = [
            _make_message_start(),
            _make_message_stop(),
            _make_assistant_message(),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in processor.query(
                prompt="Hi",
                options=ClaudeAgentOptions(),
                posthog_properties={"pr_number": 42},
            ):
                pass

        for call in mock_client.capture.call_args_list:
            props = call.kwargs.get("properties") or call[1].get("properties")
            assert props.get("pr_number") == 42


class TestCallableDistinctId:
    @pytest.mark.asyncio
    async def test_callable_distinct_id_resolved_on_trace(self, mock_client):
        def resolver(result):
            return f"user-{result.session_id}"

        proc = PostHogClaudeAgentProcessor(
            client=mock_client,
            distinct_id=resolver,
        )
        messages = [
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(messages),
        ):
            async for _ in proc.query(prompt="Hi", options=ClaudeAgentOptions()):
                pass

        trace_calls = [
            c
            for c in mock_client.capture.call_args_list
            if (c.kwargs.get("event") or c[1].get("event")) == "$ai_trace"
        ]
        assert len(trace_calls) == 1
        did = trace_calls[0].kwargs.get("distinct_id") or trace_calls[0][1].get(
            "distinct_id"
        )
        assert did == "user-sess_123"


class TestMessagePassthrough:
    @pytest.mark.asyncio
    async def test_all_messages_yielded_unchanged(self, processor, mock_client):
        original_messages = [
            _make_message_start(),
            _make_message_delta(),
            _make_message_stop(),
            _make_assistant_message(text="Hello world"),
            _make_result_message(),
        ]

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=lambda **kw: _fake_query(original_messages),
        ):
            collected = []
            async for msg in processor.query(prompt="Hi", options=ClaudeAgentOptions()):
                collected.append(msg)

        assert len(collected) == len(original_messages)
        # Verify types match
        for orig, got in zip(original_messages, collected):
            assert type(orig) is type(got)


class TestInstrumentFunction:
    def test_instrument_returns_processor(self, mock_client):
        proc = instrument(client=mock_client, distinct_id="test")
        assert isinstance(proc, PostHogClaudeAgentProcessor)
        assert proc._distinct_id == "test"
        assert proc._client == mock_client


class TestEnsurePartialMessages:
    @pytest.mark.asyncio
    async def test_enables_partial_messages_on_options(self, processor, mock_client):
        """Verify that the processor enables include_partial_messages."""
        captured_options = {}

        async def fake_query_capture(**kwargs):
            captured_options.update(kwargs)
            return
            yield  # make it an async generator

        with patch(
            "posthog.ai.claude_agent_sdk.processor.original_query",
            side_effect=fake_query_capture,
        ):
            async for _ in processor.query(
                prompt="Hi",
                options=ClaudeAgentOptions(include_partial_messages=False),
            ):
                pass

        assert captured_options.get("options").include_partial_messages is True


class TestQueryGracefulFallback:
    @pytest.mark.asyncio
    async def test_falls_back_to_original_query_when_posthog_not_configured(self):
        result_msg = _make_result_message()
        messages_from_sdk = [result_msg]

        with (
            patch(
                "posthog.ai.claude_agent_sdk.PostHogClaudeAgentProcessor",
                side_effect=ValueError("API key is required"),
            ),
            patch(
                "claude_agent_sdk.query",
                side_effect=lambda **kwargs: _fake_query(messages_from_sdk),
            ),
        ):
            collected = []
            async for msg in posthog_query(
                prompt="Hello", options=ClaudeAgentOptions()
            ):
                collected.append(msg)

        assert len(collected) == 1
        assert collected[0] is result_msg

    @pytest.mark.asyncio
    async def test_non_config_errors_propagate(self):
        with patch(
            "posthog.ai.claude_agent_sdk.PostHogClaudeAgentProcessor",
            side_effect=RuntimeError("unexpected init bug"),
        ):
            with pytest.raises(RuntimeError, match="unexpected init bug"):
                async for _ in posthog_query(
                    prompt="Hello", options=ClaudeAgentOptions()
                ):
                    pass


def test_ai_lane_client_routes_through_capture_ai(mock_client):
    mock_client.enable_full_ai_capture = True
    processor = PostHogClaudeAgentProcessor(client=mock_client, distinct_id="test-user")
    processor._capture_event(event="$ai_trace", properties={}, distinct_id="d")

    mock_client.capture.assert_not_called()
    mock_client.capture_ai.assert_called_once()
    assert mock_client.capture_ai.call_args[1]["event"] == "$ai_trace"
