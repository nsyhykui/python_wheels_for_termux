import datetime
import threading
import unittest

from unittest import mock
from zoneinfo import ZoneInfo
from dateutil import parser
from dateutil.relativedelta import relativedelta
from freezegun import freeze_time
from parameterized import parameterized
import pytest

from posthog.client import Client
import posthog.feature_flags
from posthog.feature_flags import (
    PROPERTY_OPERATORS,
    _UNHANDLED_OPERATOR_MESSAGE,
    InconclusiveMatchError,
    RequiresServerEvaluation,
    match_cohort,
    match_property,
    match_property_group,
    parse_datetime,
    relative_date_parse_for_feature_flag_matching,
)
from posthog.request import APIError, GetResponse
from posthog.test.test_utils import FAKE_TEST_API_KEY
from posthog.utils import FlagCache


# This module preserves the legacy single-flag API's compatibility behavior;
# warning emission itself is asserted in test_evaluate_flags.py.
pytestmark = [
    pytest.mark.filterwarnings(
        r"ignore:`(feature_enabled|get_feature_flag|get_feature_flag_payload)` is deprecated:DeprecationWarning"
    ),
    pytest.mark.filterwarnings(
        r"ignore:send_feature_flag_events is deprecated in get_feature_flag_payload:DeprecationWarning"
    ),
]


class TestCohortMatching(unittest.TestCase):
    def setUp(self):
        self.cohorts = {
            "1": {
                "type": "AND",
                "values": [
                    {
                        "key": "country",
                        "value": "US",
                        "operator": "exact",
                        "type": "person",
                    }
                ],
            }
        }

    def test_cohort_membership_operators(self):
        for operator in (None, "exact", "in"):
            with self.subTest(operator=operator):
                prop = {"value": 1, "operator": operator, "type": "cohort"}
                self.assertTrue(match_cohort(prop, {"country": "US"}, self.cohorts))
                self.assertFalse(match_cohort(prop, {"country": "UK"}, self.cohorts))

        not_in = {"value": 1, "operator": "not_in", "type": "cohort"}
        self.assertFalse(match_cohort(not_in, {"country": "US"}, self.cohorts))
        self.assertTrue(match_cohort(not_in, {"country": "UK"}, self.cohorts))

    def test_only_canonical_empty_groups_match(self):
        self.assertTrue(match_property_group({}, {}, {}))
        self.assertTrue(match_property_group({"type": "AND", "values": []}, {}, {}))
        self.assertTrue(
            match_property_group(
                {"type": "AND", "values": [{"type": "AND", "values": []}, {}]},
                {},
                {},
            )
        )

        malformed_groups = [
            None,
            "invalid",
            {"type": "AND"},
            {"type": "AND", "values": {}},
            {"values": []},
            {"type": "INVALID", "values": []},
        ]
        for group in malformed_groups:
            with self.subTest(group=group):
                with self.assertRaises(RequiresServerEvaluation):
                    match_property_group(group, {}, {})

    def test_missing_nested_cohort_always_requires_server_evaluation(self):
        matching_leaf = {
            "key": "country",
            "value": "US",
            "operator": "exact",
            "type": "person",
        }
        missing_cohort = {"key": "id", "value": 999, "type": "cohort"}

        cases = [
            ("OR", "US", [matching_leaf, missing_cohort]),
            ("OR", "US", [missing_cohort, matching_leaf]),
            ("AND", "UK", [matching_leaf, missing_cohort]),
            ("AND", "UK", [missing_cohort, matching_leaf]),
        ]
        for group_type, country, values in cases:
            with self.subTest(group_type=group_type, values=values):
                with self.assertRaises(RequiresServerEvaluation):
                    match_property_group(
                        {"type": group_type, "values": values},
                        {"country": country},
                        {},
                    )


class TestLocalEvaluation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # This ensures no real HTTP POST requests are made
        cls.capture_patch = mock.patch.object(Client, "capture")
        cls.capture_patch.start()

    @classmethod
    def tearDownClass(cls):
        cls.capture_patch.stop()

    def set_fail(self, e, batch):
        """Mark the failure handler"""
        print("FAIL", e, batch)  # noqa: T201
        self.failed = True

    def setUp(self):
        self.failed = False
        self.client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail)
        # Reset the process-wide malformed-dependency warning dedup set so tests
        # asserting on the warning stay order-independent.
        posthog.feature_flags._warned_malformed_flag_dependencies.clear()

    @mock.patch("posthog.client.get")
    def test_flag_person_properties(self, patch_get):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "person-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        feature_flag_match = self.client.get_feature_flag(
            "person-flag", "some-distinct-id", person_properties={"region": "USA"}
        )

        not_feature_flag_match = self.client.get_feature_flag(
            "person-flag", "some-distinct-2", person_properties={"region": "Canada"}
        )

        self.assertTrue(feature_flag_match)
        self.assertFalse(not_feature_flag_match)

    @mock.patch("posthog.client.flags")
    def test_distinct_id_property_is_available_for_local_evaluation_only(
        self, patch_flags
    ):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Distinct ID Feature",
                "key": "distinct-id-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "distinct_id",
                                    "operator": "exact",
                                    "value": "some-distinct-id",
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        person_properties = {"region": "USA"}
        feature_flag_match = self.client.get_feature_flag(
            "distinct-id-flag",
            "some-distinct-id",
            person_properties=person_properties,
            only_evaluate_locally=True,
            send_feature_flag_events=False,
        )

        self.assertTrue(feature_flag_match)
        self.assertEqual(person_properties, {"region": "USA"})
        self.assertEqual(patch_flags.call_count, 0)

    def test_exact_matching_uses_unicode_lowercase(self):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "person-flag",
                "is_simple_flag": True,
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "location",
                                    "operator": "exact",
                                    "value": ["Straße"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        },
                        {
                            "properties": [
                                {
                                    "key": "star",
                                    "operator": "exact",
                                    "value": ["ſun"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        },
                    ],
                },
            }
        ]

        self.assertTrue(
            self.client.get_feature_flag(
                "person-flag",
                "some-distinct-id",
                person_properties={"location": "straße"},
                only_evaluate_locally=True,
            )
        )

        self.assertFalse(
            self.client.get_feature_flag(
                "person-flag",
                "some-distinct-id",
                person_properties={"location": "strasse"},
                only_evaluate_locally=True,
            )
        )

        self.assertTrue(
            self.client.get_feature_flag(
                "person-flag",
                "some-distinct-id",
                person_properties={"star": "ſun"},
                only_evaluate_locally=True,
            )
        )

        self.assertFalse(
            self.client.get_feature_flag(
                "person-flag",
                "some-distinct-id",
                person_properties={"star": "sun"},
                only_evaluate_locally=True,
            )
        )

    @parameterized.expand(
        [
            # (description, early_exit value, expected result)
            ("enabled", True, False),
            ("not set", None, True),
            ("explicitly disabled", False, True),
        ]
    )
    def test_early_exit(self, _name, early_exit, expected):
        # First group's properties match but its rollout (0%) excludes everyone; the second
        # group would otherwise match. Mirrors the server-side OutOfRolloutBound short-circuit.
        filters = {
            "groups": [
                {
                    "properties": [
                        {
                            "key": "region",
                            "operator": "exact",
                            "value": ["USA"],
                            "type": "person",
                        }
                    ],
                    "rollout_percentage": 0,
                },
                {
                    "properties": [
                        {
                            "key": "region",
                            "operator": "exact",
                            "value": ["USA"],
                            "type": "person",
                        }
                    ],
                    "rollout_percentage": 100,
                },
            ],
        }
        if early_exit is not None:
            filters["early_exit"] = early_exit

        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Early Exit Feature",
                "key": "early-exit-flag",
                "active": True,
                "filters": filters,
            }
        ]

        self.assertEqual(
            self.client.get_feature_flag(
                "early-exit-flag",
                "some-distinct-id",
                person_properties={"region": "USA"},
            ),
            expected,
        )

    def test_early_exit_on_rollout_only_group_with_no_property_filters(self):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Early Exit Feature",
                "key": "early-exit-flag",
                "active": True,
                "filters": {
                    "early_exit": True,
                    "groups": [
                        {"rollout_percentage": 0},
                        {"rollout_percentage": 100},
                    ],
                },
            }
        ]

        self.assertFalse(
            self.client.get_feature_flag("early-exit-flag", "some-distinct-id")
        )

    @mock.patch("posthog.client.flags")
    def test_early_exit_preserves_fallback_after_inconclusive_presence_condition(
        self, patch_flags
    ):
        patch_flags.return_value = {
            "featureFlags": {"early-exit-presence-flag": "server-fallback"}
        }

        for operator in ("is_set", "is_not_set"):
            with self.subTest(operator=operator):
                self.client.feature_flags = [
                    {
                        "id": 1,
                        "name": "Early Exit Presence Feature",
                        "key": "early-exit-presence-flag",
                        "active": True,
                        "filters": {
                            "early_exit": True,
                            "groups": [
                                {
                                    "properties": [
                                        {
                                            "key": "plan",
                                            "operator": operator,
                                            "value": "",
                                            "type": "person",
                                        }
                                    ],
                                    "rollout_percentage": 100,
                                },
                                {"properties": [], "rollout_percentage": 0},
                            ],
                        },
                    }
                ]

                self.assertEqual(
                    "server-fallback",
                    self.client.get_feature_flag(
                        "early-exit-presence-flag", "some-distinct-id"
                    ),
                )

        self.assertEqual(patch_flags.call_count, 2)

    def test_early_exit_does_not_trigger_on_property_mismatch(self):
        # First group fails on its property (region mismatch), not rollout — so even with
        # early_exit enabled, evaluation must continue to the second group, which matches.
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Early Exit Feature",
                "key": "early-exit-flag",
                "active": True,
                "filters": {
                    "early_exit": True,
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["Canada"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 0,
                        },
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        },
                    ],
                },
            }
        ]

        self.assertTrue(
            self.client.get_feature_flag(
                "early-exit-flag",
                "some-distinct-id",
                person_properties={"region": "USA"},
            )
        )

    def test_early_exit_on_multivariate_flag(self):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Early Exit Multivariate",
                "key": "early-exit-multivariate",
                "active": True,
                "filters": {
                    "early_exit": True,
                    "multivariate": {
                        "variants": [
                            {"key": "control", "rollout_percentage": 50},
                            {"key": "test", "rollout_percentage": 50},
                        ]
                    },
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 0,
                        },
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        },
                    ],
                },
            }
        ]

        self.assertFalse(
            self.client.get_feature_flag(
                "early-exit-multivariate",
                "some-distinct-id",
                person_properties={"region": "USA"},
            )
        )

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_group_properties(self, patch_get, patch_flags):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "group-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "groups": [
                        {
                            "properties": [
                                {
                                    "group_type_index": 0,
                                    "key": "name",
                                    "operator": "exact",
                                    "value": ["Project Name 1"],
                                    "type": "group",
                                }
                            ],
                            "rollout_percentage": 35,
                        }
                    ],
                },
            }
        ]

        self.client.group_type_mapping = {"0": "company", "1": "project"}

        # Group names not passed in
        self.assertFalse(
            self.client.get_feature_flag(
                "group-flag",
                "some-distinct-id",
                group_properties={"company": {"name": "Project Name 1"}},
            )
        )

        self.assertFalse(
            self.client.get_feature_flag(
                "group-flag",
                "some-distinct-2",
                group_properties={"company": {"name": "Project Name 2"}},
            )
        )

        # this is good
        self.assertTrue(
            self.client.get_feature_flag(
                "group-flag",
                "some-distinct-id",
                groups={"company": "amazon_without_rollout"},
                group_properties={"company": {"name": "Project Name 1"}},
            )
        )
        # rollout %
        self.assertFalse(
            self.client.get_feature_flag(
                "group-flag",
                "some-distinct-id",
                groups={"company": "amazon"},
                group_properties={"company": {"name": "Project Name 1"}},
            )
        )

        # property mismatch
        self.assertFalse(
            self.client.get_feature_flag(
                "group-flag",
                "some-distinct-2",
                groups={"company": "amazon_without_rollout"},
                group_properties={"company": {"name": "Project Name 2"}},
            )
        )
        self.assertEqual(patch_flags.call_count, 0)

        # Now group type mappings are gone, so fall back to /flags/
        patch_flags.return_value = {
            "featureFlags": {"group-flag": "flags-fallback-value"}
        }

        self.client.group_type_mapping = {}
        self.assertEqual(
            self.client.get_feature_flag(
                "group-flag",
                "some-distinct-id",
                groups={"company": "amazon"},
                group_properties={"company": {"name": "Project Name 1"}},
            ),
            "flags-fallback-value",
        )

        self.assertEqual(patch_flags.call_count, 1)

    def test_group_flag_is_inconclusive_when_group_properties_missing(self):
        feature_flag = {
            "id": 1,
            "name": "Group Flag Without Property Filters",
            "key": "group-flag-no-props",
            "active": True,
            "filters": {
                "aggregation_group_type_index": 0,
                "groups": [{"properties": [], "rollout_percentage": 100}],
            },
        }
        self.client.group_type_mapping = {"0": "company"}

        with self.assertRaises(InconclusiveMatchError):
            self.client._compute_flag_locally(
                feature_flag,
                "some-distinct-id",
                groups={"company": "acme"},
                group_properties={},
            )

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_with_complex_definition(self, patch_get, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {"complex-flag": "flags-fallback-value"}
        }
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "complex-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                },
                                {
                                    "key": "name",
                                    "operator": "exact",
                                    "value": ["Aloha"],
                                    "type": "person",
                                },
                            ],
                            "rollout_percentage": 100,
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "operator": "exact",
                                    "value": ["a@b.com", "b@c.com"],
                                    "type": "person",
                                },
                            ],
                            "rollout_percentage": 30,
                        },
                        {
                            "properties": [
                                {
                                    "key": "doesnt_matter",
                                    "operator": "exact",
                                    "value": ["1", "2"],
                                    "type": "person",
                                },
                            ],
                            "rollout_percentage": 0,
                        },
                    ],
                },
            }
        ]

        self.assertTrue(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id",
                person_properties={"region": "USA", "name": "Aloha"},
            )
        )
        self.assertEqual(patch_flags.call_count, 0)

        # this distinctIDs hash is < rollout %
        self.assertTrue(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id_within_rollout?",
                person_properties={"region": "USA", "email": "a@b.com"},
            )
        )
        self.assertEqual(patch_flags.call_count, 0)

        # will fall back on `/flags`, as all properties present for second group, but that group resolves to false
        self.assertEqual(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id_outside_rollout?",
                person_properties={"region": "USA", "email": "a@b.com"},
            ),
            "flags-fallback-value",
        )
        self.assertEqual(patch_flags.call_count, 1)

        patch_flags.reset_mock()

        # same as above
        self.assertEqual(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id",
                person_properties={"doesnt_matter": "1"},
            ),
            "flags-fallback-value",
        )
        self.assertEqual(patch_flags.call_count, 1)

        patch_flags.reset_mock()

        # this one will need to fall back
        self.assertEqual(
            client.get_feature_flag(
                "complex-flag", "some-distinct-id", person_properties={"region": "USA"}
            ),
            "flags-fallback-value",
        )
        self.assertEqual(patch_flags.call_count, 1)

        patch_flags.reset_mock()

        # won't need to fall back when all values are present
        self.assertFalse(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id_outside_rollout?",
                person_properties={
                    "region": "USA",
                    "email": "a@b.com",
                    "name": "X",
                    "doesnt_matter": "1",
                },
            )
        )
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_flags_fallback_to_flags(self, patch_get, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "alakazam", "beta-feature2": "alakazam2"}
        }
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "id",
                                    "value": 98,
                                    "operator": None,
                                    "type": "cohort",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "beta-feature2",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # beta-feature falls back to /flags because property type is unknown
        feature_flag_match = client.get_feature_flag("beta-feature", "some-distinct-id")

        self.assertEqual(feature_flag_match, "alakazam")
        self.assertEqual(patch_flags.call_count, 1)

        # beta-feature2 falls back to /flags because region property was not given with the call
        feature_flag_match = client.get_feature_flag(
            "beta-feature2", "some-distinct-id"
        )

        self.assertEqual(feature_flag_match, "alakazam2")
        self.assertEqual(patch_flags.call_count, 2)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_flags_dont_fallback_to_flags_when_only_local_evaluation_is_true(
        self, patch_get, patch_flags
    ):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "alakazam", "beta-feature2": "alakazam2"}
        }
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "id",
                                    "value": 98,
                                    "operator": None,
                                    "type": "cohort",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "beta-feature2",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # beta-feature would fall back to /flags because the property type is unknown,
        # but doesn't because only_evaluate_locally is true
        feature_flag_match = client.get_feature_flag(
            "beta-feature", "some-distinct-id", only_evaluate_locally=True
        )

        self.assertEqual(feature_flag_match, None)
        self.assertEqual(patch_flags.call_count, 0)

        feature_flag_match = client.feature_enabled(
            "beta-feature", "some-distinct-id", only_evaluate_locally=True
        )

        self.assertEqual(feature_flag_match, None)
        self.assertEqual(patch_flags.call_count, 0)

        # beta-feature2 would fall back to /flags because the region property was not given with the call,
        # but doesn't because only_evaluate_locally is true
        feature_flag_match = client.get_feature_flag(
            "beta-feature2", "some-distinct-id", only_evaluate_locally=True
        )
        self.assertEqual(feature_flag_match, None)

        feature_flag_match = client.feature_enabled(
            "beta-feature2", "some-distinct-id", only_evaluate_locally=True
        )
        self.assertEqual(feature_flag_match, None)

        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_flag_never_returns_undefined_during_regular_evaluation(
        self, patch_get, patch_flags
    ):
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ],
                },
            },
        ]

        # beta-feature resolves to False, so no matter the default, stays False
        self.assertFalse(client.get_feature_flag("beta-feature", "some-distinct-id"))
        self.assertFalse(client.feature_enabled("beta-feature", "some-distinct-id"))

        # beta-feature2 falls back to /flags, and whatever /flags returns is the value
        self.assertFalse(client.get_feature_flag("beta-feature2", "some-distinct-id"))
        self.assertEqual(patch_flags.call_count, 1)

        self.assertFalse(client.feature_enabled("beta-feature2", "some-distinct-id"))
        self.assertEqual(patch_flags.call_count, 2)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_flag_return_none_when_flags_errors_out(
        self, patch_get, patch_flags
    ):
        patch_flags.side_effect = APIError(400, "Flags error")
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = []

        # beta-feature2 falls back to /flags, which on error returns None
        self.assertIsNone(client.get_feature_flag("beta-feature2", "some-distinct-id"))
        self.assertEqual(patch_flags.call_count, 1)

        self.assertIsNone(client.feature_enabled("beta-feature2", "some-distinct-id"))
        self.assertEqual(patch_flags.call_count, 2)

    @mock.patch("posthog.client.flags")
    def test_experience_continuity_flag_not_evaluated_locally(self, patch_flags):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "flags-fallback-value"}
        }
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
                "ensure_experience_continuity": True,
            }
        ]
        # /flags is always called when experience_continuity is set
        self.assertEqual(
            client.get_feature_flag("beta-feature", "distinct_id"),
            "flags-fallback-value",
        )
        self.assertEqual(patch_flags.call_count, 1)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_with_fallback(self, patch_flags, patch_capture):
        patch_flags.return_value = {
            "featureFlags": {
                "beta-feature": "variant-1",
                "beta-feature2": "variant-2",
                "disabled-feature": False,
            }
        }  # /flags should return the same flags
        client = self.client
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "disabled-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            },
            {
                "id": 3,
                "name": "Beta Feature",
                "key": "beta-feature2",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "country", "value": "US"}],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            },
        ]
        # beta-feature value overridden by /flags
        self.assertEqual(
            client.get_all_flags("distinct_id"),
            {
                "beta-feature": "variant-1",
                "beta-feature2": "variant-2",
                "disabled-feature": False,
            },
        )
        self.assertEqual(patch_flags.call_count, 1)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_and_payloads_with_fallback(self, patch_flags, patch_capture):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "variant-1", "beta-feature2": "variant-2"},
            "featureFlagPayloads": {"beta-feature": 100, "beta-feature2": 300},
        }
        client = self.client
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                    "payloads": {
                        "true": "some-payload",
                    },
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "disabled-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ],
                    "payloads": {
                        "true": "another-payload",
                    },
                },
            },
            {
                "id": 3,
                "name": "Beta Feature",
                "key": "beta-feature2",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "country", "value": "US"}],
                            "rollout_percentage": 0,
                        }
                    ],
                    "payloads": {
                        "true": "payload-3",
                    },
                },
            },
        ]
        # beta-feature value overridden by /flags
        self.assertEqual(
            client.get_all_flags_and_payloads("distinct_id")["featureFlagPayloads"],
            {
                "beta-feature": 100,
                "beta-feature2": 300,
            },
        )
        self.assertEqual(patch_flags.call_count, 1)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_with_fallback_empty_local_flags(
        self, patch_flags, patch_capture
    ):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "variant-1", "beta-feature2": "variant-2"}
        }
        client = self.client
        client.feature_flags = []
        # beta-feature value overridden by /flags
        self.assertEqual(
            client.get_all_flags("distinct_id"),
            {"beta-feature": "variant-1", "beta-feature2": "variant-2"},
        )
        self.assertEqual(patch_flags.call_count, 1)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_and_payloads_with_fallback_empty_local_flags(
        self, patch_flags, patch_capture
    ):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "variant-1", "beta-feature2": "variant-2"},
            "featureFlagPayloads": {"beta-feature": 100, "beta-feature2": 300},
        }
        client = self.client
        client.feature_flags = []
        # beta-feature value overridden by /flags
        self.assertEqual(
            client.get_all_flags_and_payloads("distinct_id")["featureFlagPayloads"],
            {"beta-feature": 100, "beta-feature2": 300},
        )
        self.assertEqual(patch_flags.call_count, 1)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_with_no_fallback(self, patch_flags, patch_capture):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "variant-1", "beta-feature2": "variant-2"}
        }
        client = self.client
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "disabled-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            },
        ]
        self.assertEqual(
            client.get_all_flags("distinct_id"),
            {"beta-feature": True, "disabled-feature": False},
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_and_payloads_with_no_fallback(
        self, patch_flags, patch_capture
    ):
        client = self.client
        basic_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "properties": [],
                        "rollout_percentage": 100,
                    }
                ],
                "payloads": {
                    "true": "new",
                },
            },
        }
        disabled_flag = {
            "id": 2,
            "name": "Beta Feature",
            "key": "disabled-feature",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [],
                        "rollout_percentage": 0,
                    }
                ],
                "payloads": {
                    "true": "some-payload",
                },
            },
        }
        client.feature_flags = [
            basic_flag,
            disabled_flag,
        ]
        self.assertEqual(
            client.get_all_flags_and_payloads("distinct_id")["featureFlagPayloads"],
            {"beta-feature": "new"},
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_with_fallback_but_only_local_evaluation_set(
        self, patch_flags, patch_capture
    ):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "variant-1", "beta-feature2": "variant-2"}
        }
        client = self.client
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "disabled-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            },
            {
                "id": 3,
                "name": "Beta Feature",
                "key": "beta-feature2",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "country", "value": "US"}],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            },
        ]
        # beta-feature2 has no value
        self.assertEqual(
            client.get_all_flags("distinct_id", only_evaluate_locally=True),
            {"beta-feature": True, "disabled-feature": False},
        )
        self.assertEqual(patch_flags.call_count, 0)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_all_flags_and_payloads_with_fallback_but_only_local_evaluation_set(
        self, patch_flags, patch_capture
    ):
        patch_flags.return_value = {
            "featureFlags": {"beta-feature": "variant-1", "beta-feature2": "variant-2"},
            "featureFlagPayloads": {"beta-feature": 100, "beta-feature2": 300},
        }
        client = self.client
        flag_1 = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "properties": [],
                        "rollout_percentage": 100,
                    }
                ],
                "payloads": {
                    "true": "some-payload",
                },
            },
        }
        flag_2 = {
            "id": 2,
            "name": "Beta Feature",
            "key": "disabled-feature",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [],
                        "rollout_percentage": 0,
                    }
                ],
                "payloads": {
                    "true": "another-payload",
                },
            },
        }
        flag_3 = {
            "id": 3,
            "name": "Beta Feature",
            "key": "beta-feature2",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [{"key": "country", "value": "US"}],
                        "rollout_percentage": 0,
                    }
                ],
                "payloads": {
                    "true": "payload-3",
                },
            },
        }
        client.feature_flags = [
            flag_1,
            flag_2,
            flag_3,
        ]
        # beta-feature2 has no value
        self.assertEqual(
            client.get_all_flags_and_payloads(
                "distinct_id", only_evaluate_locally=True
            )["featureFlagPayloads"],
            {"beta-feature": "some-payload"},
        )
        self.assertEqual(patch_flags.call_count, 0)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_compute_inactive_flags_locally(self, patch_flags, patch_capture):
        client = self.client
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "disabled-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            },
        ]
        self.assertEqual(
            client.get_all_flags("distinct_id"),
            {"beta-feature": True, "disabled-feature": False},
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)
        self.assertEqual(patch_capture.call_count, 0)

        # Now, after a poll interval, flag 1 is inactive, and flag 2 rollout is set to 100%.
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": False,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            },
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "disabled-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            },
        ]
        self.assertEqual(
            client.get_all_flags("distinct_id"),
            {"beta-feature": False, "disabled-feature": True},
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_feature_flags_local_evaluation_None_values(self, patch_flags):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        load_patch = mock.patch.object(client, "_load_feature_flags")
        patch_load = load_patch.start()
        self.addCleanup(load_patch.stop)
        client.feature_flags = [
            {
                id: 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "variant": None,
                            "properties": [
                                {
                                    "key": "latestBuildVersion",
                                    "type": "person",
                                    "value": ".+",
                                    "operator": "regex",
                                },
                                {
                                    "key": "latestBuildVersionMajor",
                                    "type": "person",
                                    "value": "23",
                                    "operator": "gt",
                                },
                                {
                                    "key": "latestBuildVersionMinor",
                                    "type": "person",
                                    "value": "31",
                                    "operator": "gt",
                                },
                                {
                                    "key": "latestBuildVersionPatch",
                                    "type": "person",
                                    "value": "0",
                                    "operator": "gt",
                                },
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={
                "latestBuildVersion": None,
                "latestBuildVersionMajor": None,
                "latestBuildVersionMinor": None,
                "latestBuildVersionPatch": None,
            },
        )

        self.assertEqual(feature_flag_match, False)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={
                "latestBuildVersion": "24.32.1",
                "latestBuildVersionMajor": "24",
                "latestBuildVersionMinor": "32",
                "latestBuildVersionPatch": "1",
            },
        )

        self.assertEqual(feature_flag_match, True)

    @mock.patch("posthog.client.flags")
    def test_feature_flags_local_evaluation_for_cohorts(self, patch_flags):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        load_patch = mock.patch.object(client, "_load_feature_flags")
        patch_load = load_patch.start()
        self.addCleanup(load_patch.stop)
        client.feature_flags = [
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                },
                                {
                                    "key": "id",
                                    "value": 98,
                                    "operator": None,
                                    "type": "cohort",
                                },
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]
        client.cohorts = {
            "98": {
                "type": "OR",
                "values": [
                    {"key": "id", "value": 1, "type": "cohort"},
                    {
                        "key": "nation",
                        "operator": "exact",
                        "value": ["UK"],
                        "type": "person",
                    },
                ],
            },
            "1": {
                "type": "AND",
                "values": [
                    {
                        "key": "other",
                        "operator": "exact",
                        "value": ["thing"],
                        "type": "person",
                    }
                ],
            },
        }

        feature_flag_match = client.get_feature_flag(
            "beta-feature", "some-distinct-id", person_properties={"region": "UK"}
        )

        self.assertEqual(feature_flag_match, False)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={"region": "USA", "nation": "UK"},
        )
        # even though 'other' property is not present, the cohort should still match since it's an OR condition
        self.assertEqual(feature_flag_match, True)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={"region": "USA", "other": "thing"},
        )
        self.assertEqual(feature_flag_match, True)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

    @mock.patch("posthog.client.flags")
    def test_feature_flags_local_evaluation_for_negated_cohorts(self, patch_flags):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        load_patch = mock.patch.object(client, "_load_feature_flags")
        patch_load = load_patch.start()
        self.addCleanup(load_patch.stop)
        client.feature_flags = [
            {
                "id": 2,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "region",
                                    "operator": "exact",
                                    "value": ["USA"],
                                    "type": "person",
                                },
                                {
                                    "key": "id",
                                    "value": 98,
                                    "operator": None,
                                    "type": "cohort",
                                },
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]
        client.cohorts = {
            "98": {
                "type": "OR",
                "values": [
                    {"key": "id", "value": 1, "type": "cohort"},
                    {
                        "key": "nation",
                        "operator": "exact",
                        "value": ["UK"],
                        "type": "person",
                    },
                ],
            },
            "1": {
                "type": "AND",
                "values": [
                    {
                        "key": "other",
                        "operator": "exact",
                        "value": ["thing"],
                        "type": "person",
                        "negation": True,
                    }
                ],
            },
        }

        feature_flag_match = client.get_feature_flag(
            "beta-feature", "some-distinct-id", person_properties={"region": "UK"}
        )

        self.assertEqual(feature_flag_match, False)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={"region": "USA", "nation": "UK"},
        )
        # even though 'other' property is not present, the cohort should still match since it's an OR condition
        self.assertEqual(feature_flag_match, True)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={"region": "USA", "other": "thing"},
        )
        # since 'other' is negated, we return False. Since 'nation' is not present, we can't tell whether the flag should be true or false, so fall back to /flags
        self.assertEqual(patch_flags.call_count, 1)
        patch_load.assert_not_called()

        patch_flags.reset_mock()

        feature_flag_match = client.get_feature_flag(
            "beta-feature",
            "some-distinct-id",
            person_properties={"region": "USA", "other": "thing2"},
        )
        self.assertEqual(feature_flag_match, True)
        self.assertEqual(patch_flags.call_count, 0)
        patch_load.assert_not_called()

    @mock.patch("posthog.feature_flags.log")
    @mock.patch("posthog.client.flags")
    def test_feature_flags_with_flag_dependencies(self, patch_flags, mock_log):
        # Mock remote flags call to return empty for this flag (fallback returns None)
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        load_patch = mock.patch.object(client, "_load_feature_flags")
        patch_load = load_patch.start()
        self.addCleanup(load_patch.stop)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag with Dependencies",
                "key": "flag-with-dependencies",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "beta-feature",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["beta-feature"],
                                },
                                {
                                    "key": "email",
                                    "operator": "icontains",
                                    "value": "@example.com",
                                    "type": "person",
                                },
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        # Test that flag evaluation handles flag dependencies properly
        # The flag has a dependency on "beta-feature" which doesn't exist locally
        # Since the dependency doesn't exist, local evaluation should fail and fall back to remote
        # Remote returns empty result, so final result is None
        feature_flag_match = client.get_feature_flag(
            "flag-with-dependencies",
            "test-user",
            person_properties={"email": "test@example.com"},
        )
        self.assertIsNone(feature_flag_match)
        self.assertEqual(patch_flags.call_count, 1)
        patch_load.assert_not_called()

        # Test with email that doesn't match (should also fall back to remote due to missing dependency)
        feature_flag_match = client.get_feature_flag(
            "flag-with-dependencies",
            "test-user-2",
            person_properties={"email": "test@other.com"},
        )
        self.assertIsNone(feature_flag_match)
        self.assertEqual(patch_flags.call_count, 2)  # Called twice now
        patch_load.assert_not_called()

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_simple_chain(self, patch_get, patch_flags):
        """Test basic flag dependency: flag-b depends on flag-a"""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag A",
                "key": "flag-a",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "operator": "icontains",
                                    "value": "@example.com",
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Flag B",
                "key": "flag-b",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-a",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["flag-a"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # Test when dependency is satisfied
        result = client.get_feature_flag(
            "flag-b",
            "test-user",
            person_properties={"email": "test@example.com"},
        )
        self.assertEqual(result, True)

        # Test when dependency is not satisfied
        result = client.get_feature_flag(
            "flag-b",
            "test-user-2",
            person_properties={"email": "test@other.com"},
        )
        self.assertEqual(result, False)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_circular_dependency(self, patch_get, patch_flags):
        """Test circular dependency handling: flag-a depends on flag-b, flag-b depends on flag-a"""
        # Mock remote flags call to return empty for these flags (fallback returns None)
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag A",
                "key": "flag-a",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-b",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": [],  # Empty chain indicates circular dependency
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Flag B",
                "key": "flag-b",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-a",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": [],  # Empty chain indicates circular dependency
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # Both flags should fall back to remote evaluation due to circular dependency
        # Since we're not mocking the remote call, both should return None
        result_a = client.get_feature_flag("flag-a", "test-user")
        self.assertIsNone(result_a)

        result_b = client.get_feature_flag("flag-b", "test-user")
        self.assertIsNone(result_b)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_missing_flag(self, patch_get, patch_flags):
        """Test handling of missing flag dependency"""
        # Mock remote flags call to return empty for this flag (fallback returns None)
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag A",
                "key": "flag-a",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "non-existent-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["non-existent-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        # Should fall back to remote evaluation because dependency doesn't exist
        # Since we're not mocking the remote call, should return None
        result = client.get_feature_flag("flag-a", "test-user")
        self.assertIsNone(result)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_complex_chain(self, patch_get, patch_flags):
        """Test complex dependency chain: flag-d -> flag-c -> [flag-a, flag-b]"""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag A",
                "key": "flag-a",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Flag B",
                "key": "flag-b",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 3,
                "name": "Flag C",
                "key": "flag-c",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-a",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["flag-a"],
                                },
                                {
                                    "key": "flag-b",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["flag-b"],
                                },
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 4,
                "name": "Flag D",
                "key": "flag-d",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-c",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["flag-a", "flag-b", "flag-c"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # All dependencies satisfied - should return True
        result = client.get_feature_flag("flag-d", "test-user")
        self.assertEqual(result, True)

        # Make flag-a inactive - should break the chain
        client.feature_flags[0]["active"] = False
        result = client.get_feature_flag("flag-d", "test-user")
        self.assertEqual(result, False)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_mixed_conditions(self, patch_get, patch_flags):
        """Test flag dependency mixed with other property conditions"""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Mixed Flag",
                "key": "mixed-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                },
                                {
                                    "key": "email",
                                    "operator": "icontains",
                                    "value": "@example.com",
                                    "type": "person",
                                },
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # Both flag dependency and email condition satisfied
        result = client.get_feature_flag(
            "mixed-flag",
            "test-user",
            person_properties={"email": "test@example.com"},
        )
        self.assertEqual(result, True)

        # Flag dependency satisfied but email condition not satisfied
        result = client.get_feature_flag(
            "mixed-flag",
            "test-user-2",
            person_properties={"email": "test@other.com"},
        )
        self.assertEqual(result, False)

        # Email condition satisfied but flag dependency not satisfied
        client.feature_flags[0]["active"] = False
        result = client.get_feature_flag(
            "mixed-flag",
            "test-user-3",
            person_properties={"email": "test@example.com"},
        )
        self.assertEqual(result, False)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_malformed_chain(self, patch_get, patch_flags):
        """Test handling of malformed dependency chains"""
        # Mock remote flags call to return empty for this flag (fallback returns None)
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Missing Chain Flag",
                "key": "missing-chain-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    # No dependency_chain property - should evaluate as inconclusive
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # Should fall back to remote evaluation when dependency_chain is missing
        # Since we're not mocking the remote call, should return None
        result = client.get_feature_flag("missing-chain-flag", "test-user")
        self.assertIsNone(result)

    def test_flag_dependencies_without_context_raises_inconclusive(self):
        """Test that missing flags_by_key raises InconclusiveMatchError"""
        from posthog.feature_flags import (
            evaluate_flag_dependency,
            InconclusiveMatchError,
        )

        property_with_flag_dep = {
            "key": "some-flag",
            "operator": "flag_evaluates_to",
            "value": True,
            "type": "flag",
            "dependency_chain": ["some-flag"],
        }

        # Should raise InconclusiveMatchError when flags_by_key is None
        with self.assertRaises(InconclusiveMatchError) as cm:
            evaluate_flag_dependency(
                property_with_flag_dep,
                flags_by_key=None,  # This should trigger the error
                evaluation_cache={},
                distinct_id="test-user",
                properties={},
                cohort_properties={},
            )

        self.assertIn("Cannot evaluate flag dependency", str(cm.exception))
        self.assertIn("some-flag", str(cm.exception))

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_evaluates_to_false(self, patch_get, patch_flags):
        """A `flag_evaluates_to: false` condition matches when the referenced flag is conclusively False, without falling back to /flags."""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                # 0% rollout: conclusively False for everyone
                "filters": {"groups": [{"properties": [], "rollout_percentage": 0}]},
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": False,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        for distinct_id in ["user-1", "user-2", "another-user-xyz"]:
            self.assertEqual(
                client.get_feature_flag("dependent-flag", distinct_id), True
            )

        # Control: base flag returning a variant does not match `value: false`
        client.feature_flags[0]["filters"] = {
            "groups": [
                {"properties": [], "rollout_percentage": 100, "variant": "test"}
            ],
            "multivariate": {"variants": [{"key": "test", "rollout_percentage": 100}]},
        }
        self.assertEqual(client.get_feature_flag("dependent-flag", "user-1"), False)

        # Control: base flag at 100% (True) does not match `value: false`
        client.feature_flags[0]["filters"] = {
            "groups": [{"properties": [], "rollout_percentage": 100}]
        }
        self.assertEqual(client.get_feature_flag("dependent-flag", "user-1"), False)

        # Everything above resolves locally - no /flags fallback
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_multi_level_evaluates_to_false(
        self, patch_get, patch_flags
    ):
        """Multi-level chain with a legitimately-False ancestor: A(false) -> B(true) -> D(true)."""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Flag A",
                "key": "flag-a",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 0}]},
            },
            {
                "id": 2,
                "name": "Flag B",
                "key": "flag-b",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-a",
                                    "operator": "flag_evaluates_to",
                                    "value": False,
                                    "type": "flag",
                                    "dependency_chain": ["flag-a"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 3,
                "name": "Flag D",
                "key": "flag-d",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "flag-b",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    # Ancestor A is False; only B's value decides D
                                    "dependency_chain": ["flag-a", "flag-b"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        self.assertEqual(client.get_feature_flag("flag-a", "user-1"), False)
        self.assertEqual(client.get_feature_flag("flag-b", "user-1"), True)
        self.assertEqual(client.get_feature_flag("flag-d", "user-1"), True)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_inactive_base_evaluates_to_false(
        self, patch_get, patch_flags
    ):
        """An inactive base flag caches False, so `flag_evaluates_to: false` matches."""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": False,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": False,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        self.assertEqual(client.get_feature_flag("dependent-flag", "user-1"), True)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_inconclusive_base_falls_back(
        self, patch_get, patch_flags
    ):
        """An inconclusive base (missing person properties) is distinct from False and falls back to /flags."""
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "operator": "icontains",
                                    "value": "@example.com",
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": False,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # No person properties => base is inconclusive (None), not False
        result = client.get_feature_flag("dependent-flag", "user-1")
        self.assertIsNone(result)
        self.assertEqual(patch_flags.call_count, 1)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_null_value_no_match_locally(
        self, patch_get, patch_flags
    ):
        """A malformed `value: null` condition is a definitive local no-match (False), never falling back to /flags."""
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": None,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # The malformed condition does not match, so the only group fails and the
        # flag resolves to False locally - no billable /flags fallback.
        result = client.get_feature_flag("dependent-flag", "user-1")
        self.assertFalse(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_missing_key_no_match_locally(
        self, patch_get, patch_flags
    ):
        """A dependency condition with an empty/missing `key` is a definitive local no-match (False)."""
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        result = client.get_feature_flag("dependent-flag", "user-1")
        self.assertFalse(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_wrong_operator_no_match_locally(
        self, patch_get, patch_flags
    ):
        """A dependency condition with the wrong operator is a definitive local no-match (False)."""
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "exact",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        result = client.get_feature_flag("dependent-flag", "user-1")
        self.assertFalse(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_malformed_condition_warns_once(
        self, patch_get, patch_flags
    ):
        """A malformed dependency condition warns on first eval, then stays quiet (dedup)."""
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 2,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": None,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # First evaluation emits exactly one warning naming the malformed flag.
        with self.assertLogs("posthog", level="WARNING") as logs:
            self.assertFalse(client.get_feature_flag("dependent-flag", "user-1"))
        self.assertEqual(len(logs.records), 1)
        self.assertIn("base-flag", logs.output[0])
        self.assertIn("malformed", logs.output[0])

        # Second evaluation of the same malformed condition stays silent (dedup).
        # assertLogs fails if nothing is logged, so log a sentinel to prove the
        # malformed-dependency warning itself did not fire again.
        with self.assertLogs("posthog", level="WARNING") as logs:
            self.assertFalse(client.get_feature_flag("dependent-flag", "user-2"))
            posthog.feature_flags.log.warning("sentinel")
        self.assertEqual(len(logs.records), 1)
        self.assertIn("sentinel", logs.output[0])

        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_flag_dependencies_malformed_condition_falls_through_to_other_group(
        self, patch_get, patch_flags
    ):
        """A malformed dependency condition no-matches its group, but a second matching group still resolves the flag locally."""
        patch_flags.return_value = {"featureFlags": {}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Base Flag",
                "key": "base-flag",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            # Only condition is the malformed dependency -> resolves to False locally.
            {
                "id": 2,
                "name": "Malformed Only Flag",
                "key": "malformed-only-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": None,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            # Malformed dependency group no-matches, but the second group matches.
            {
                "id": 3,
                "name": "Malformed Plus Matching Flag",
                "key": "malformed-plus-matching-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "base-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": None,
                                    "type": "flag",
                                    "dependency_chain": ["base-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        },
                        {"properties": [], "rollout_percentage": 100},
                    ],
                },
            },
        ]

        self.assertFalse(client.get_feature_flag("malformed-only-flag", "user-1"))
        self.assertTrue(
            client.get_feature_flag("malformed-plus-matching-flag", "user-1")
        )
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_multi_level_multivariate_dependency_chain(self, patch_get, patch_flags):
        """Test multi-level multivariate dependency chain: dependent-flag -> intermediate-flag -> leaf-flag"""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            # Leaf flag: multivariate with "control" and "test" variants using person property overrides
            {
                "id": 1,
                "name": "Leaf Flag",
                "key": "leaf-flag",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "control@example.com",
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "control",
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "test@example.com",
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "test",
                        },
                        {
                            "rollout_percentage": 50,
                            "variant": "control",
                        },  # Default fallback
                    ],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "control",
                                "name": "Control",
                                "rollout_percentage": 50,
                            },
                            {"key": "test", "name": "Test", "rollout_percentage": 50},
                        ]
                    },
                },
            },
            # Intermediate flag: multivariate with "blue" and "green" variants, depends on leaf-flag="control"
            {
                "id": 2,
                "name": "Intermediate Flag",
                "key": "intermediate-flag",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "leaf-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": "control",
                                    "type": "flag",
                                    "dependency_chain": ["leaf-flag"],
                                },
                                {
                                    "key": "variant_type",
                                    "type": "person",
                                    "value": "blue",
                                    "operator": "exact",
                                },
                            ],
                            "rollout_percentage": 100,
                            "variant": "blue",
                        },
                        {
                            "properties": [
                                {
                                    "key": "leaf-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": "control",
                                    "type": "flag",
                                    "dependency_chain": ["leaf-flag"],
                                },
                                {
                                    "key": "variant_type",
                                    "type": "person",
                                    "value": "green",
                                    "operator": "exact",
                                },
                            ],
                            "rollout_percentage": 100,
                            "variant": "green",
                        },
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "blue", "name": "Blue", "rollout_percentage": 50},
                            {"key": "green", "name": "Green", "rollout_percentage": 50},
                        ]
                    },
                },
            },
            # Dependent flag: boolean flag that depends on intermediate-flag="blue"
            {
                "id": 3,
                "name": "Dependent Flag",
                "key": "dependent-flag",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "intermediate-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": "blue",
                                    "type": "flag",
                                    "dependency_chain": [
                                        "leaf-flag",
                                        "intermediate-flag",
                                    ],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]

        # Test using person properties and variant overrides to ensure predictable variants

        # Test 1: Make sure the leaf flag evaluates to the variant we expect using email overrides
        self.assertEqual(
            "control",
            client.get_feature_flag(
                "leaf-flag",
                "any-user",
                person_properties={"email": "control@example.com"},
            ),
        )
        self.assertEqual(
            "test",
            client.get_feature_flag(
                "leaf-flag",
                "any-user",
                person_properties={"email": "test@example.com"},
            ),
        )

        # Test 2: Make sure the intermediate flag evaluates to the expected variants when dependency is satisfied
        self.assertEqual(
            "blue",
            client.get_feature_flag(
                "intermediate-flag",
                "any-user",
                person_properties={
                    "email": "control@example.com",
                    "variant_type": "blue",
                },
            ),
        )

        self.assertEqual(
            "green",
            client.get_feature_flag(
                "intermediate-flag",
                "any-user",
                person_properties={
                    "email": "control@example.com",
                    "variant_type": "green",
                },
            ),
        )

        # Test 3: Make sure the intermediate flag evaluates to false when leaf dependency fails
        self.assertEqual(
            False,
            client.get_feature_flag(
                "intermediate-flag",
                "any-user",
                person_properties={
                    "email": "test@example.com",  # This makes leaf-flag="test", breaking dependency
                    "variant_type": "blue",
                },
            ),
        )

        # Test 4: When leaf-flag="control", intermediate="blue", dependent should be true
        self.assertEqual(
            True,
            client.get_feature_flag(
                "dependent-flag",
                "any-user",
                person_properties={
                    "email": "control@example.com",
                    "variant_type": "blue",
                },
            ),
        )

        # Test 5: When leaf-flag="control", intermediate="green", dependent should be false
        self.assertEqual(
            False,
            client.get_feature_flag(
                "dependent-flag",
                "any-user",
                person_properties={
                    "email": "control@example.com",
                    "variant_type": "green",
                },
            ),
        )

        # Test 6: When leaf-flag="test", intermediate is False, dependent should be false
        self.assertEqual(
            False,
            client.get_feature_flag(
                "dependent-flag",
                "any-user",
                person_properties={"email": "test@example.com", "variant_type": "blue"},
            ),
        )

    def test_matches_dependency_value(self):
        """Test the matches_dependency_value function logic"""
        from posthog.feature_flags import matches_dependency_value

        # String variant matches string exactly (case-sensitive)
        self.assertTrue(matches_dependency_value("control", "control"))
        self.assertTrue(matches_dependency_value("Control", "Control"))
        self.assertFalse(matches_dependency_value("control", "Control"))
        self.assertFalse(matches_dependency_value("Control", "CONTROL"))
        self.assertFalse(matches_dependency_value("control", "test"))

        # String variant matches boolean true (any variant is truthy)
        self.assertTrue(matches_dependency_value(True, "control"))
        self.assertTrue(matches_dependency_value(True, "test"))
        self.assertFalse(matches_dependency_value(False, "control"))

        # Boolean matches boolean exactly
        self.assertTrue(matches_dependency_value(True, True))
        self.assertTrue(matches_dependency_value(False, False))
        self.assertFalse(matches_dependency_value(False, True))
        self.assertFalse(matches_dependency_value(True, False))

        # Empty string doesn't match
        self.assertFalse(matches_dependency_value(True, ""))
        self.assertFalse(matches_dependency_value("control", ""))

        # Type mismatches
        self.assertFalse(matches_dependency_value(123, "control"))
        self.assertFalse(matches_dependency_value("control", True))

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_production_style_multivariate_dependency_chain(
        self, patch_get, patch_flags
    ):
        """Test production-style multivariate dependency chain: multivariate-root-flag -> multivariate-intermediate-flag -> multivariate-leaf-flag"""
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            # Leaf flag: multivariate with fruit variants
            {
                "id": 451,
                "name": "Multivariate Leaf Flag (Base)",
                "key": "multivariate-leaf-flag",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": ["pineapple@example.com"],
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "pineapple",
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": ["mango@example.com"],
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "mango",
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": ["papaya@example.com"],
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "papaya",
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": ["kiwi@example.com"],
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "kiwi",
                        },
                        {
                            "properties": [],
                            "rollout_percentage": 0,  # Force default to false for unknown emails
                        },
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "pineapple", "rollout_percentage": 25},
                            {"key": "mango", "rollout_percentage": 25},
                            {"key": "papaya", "rollout_percentage": 25},
                            {"key": "kiwi", "rollout_percentage": 25},
                        ]
                    },
                },
            },
            # Intermediate flag: multivariate with color variants, depends on fruit
            {
                "id": 467,
                "name": "Multivariate Intermediate Flag (Depends on fruit)",
                "key": "multivariate-intermediate-flag",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "multivariate-leaf-flag",
                                    "type": "flag",
                                    "value": "pineapple",
                                    "operator": "flag_evaluates_to",
                                    "dependency_chain": ["multivariate-leaf-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "blue",
                        },
                        {
                            "properties": [
                                {
                                    "key": "multivariate-leaf-flag",
                                    "type": "flag",
                                    "value": "mango",
                                    "operator": "flag_evaluates_to",
                                    "dependency_chain": ["multivariate-leaf-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "red",
                        },
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "blue", "rollout_percentage": 100},
                            {"key": "red", "rollout_percentage": 0},
                            {"key": "green", "rollout_percentage": 0},
                            {"key": "black", "rollout_percentage": 0},
                        ]
                    },
                },
            },
            # Root flag: multivariate with show variants, depends on color
            {
                "id": 468,
                "name": "Multivariate Root Flag (Depends on color)",
                "key": "multivariate-root-flag",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "multivariate-intermediate-flag",
                                    "type": "flag",
                                    "value": "blue",
                                    "operator": "flag_evaluates_to",
                                    "dependency_chain": [
                                        "multivariate-leaf-flag",
                                        "multivariate-intermediate-flag",
                                    ],
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "breaking-bad",
                        },
                        {
                            "properties": [
                                {
                                    "key": "multivariate-intermediate-flag",
                                    "type": "flag",
                                    "value": "red",
                                    "operator": "flag_evaluates_to",
                                    "dependency_chain": [
                                        "multivariate-leaf-flag",
                                        "multivariate-intermediate-flag",
                                    ],
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "the-wire",
                        },
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "breaking-bad", "rollout_percentage": 100},
                            {"key": "the-wire", "rollout_percentage": 0},
                            {"key": "game-of-thrones", "rollout_percentage": 0},
                            {"key": "the-expanse", "rollout_percentage": 0},
                        ]
                    },
                },
            },
        ]

        # Test successful pineapple -> blue -> breaking-bad chain
        leaf_result = client.get_feature_flag(
            "multivariate-leaf-flag",
            "test-user",
            person_properties={"email": "pineapple@example.com"},
        )
        intermediate_result = client.get_feature_flag(
            "multivariate-intermediate-flag",
            "test-user",
            person_properties={"email": "pineapple@example.com"},
        )
        root_result = client.get_feature_flag(
            "multivariate-root-flag",
            "test-user",
            person_properties={"email": "pineapple@example.com"},
        )

        self.assertEqual(leaf_result, "pineapple")
        self.assertEqual(intermediate_result, "blue")
        self.assertEqual(root_result, "breaking-bad")

        # Test successful mango -> red -> the-wire chain
        mango_leaf_result = client.get_feature_flag(
            "multivariate-leaf-flag",
            "test-user",
            person_properties={"email": "mango@example.com"},
        )
        mango_intermediate_result = client.get_feature_flag(
            "multivariate-intermediate-flag",
            "test-user",
            person_properties={"email": "mango@example.com"},
        )
        mango_root_result = client.get_feature_flag(
            "multivariate-root-flag",
            "test-user",
            person_properties={"email": "mango@example.com"},
        )

        self.assertEqual(mango_leaf_result, "mango")
        self.assertEqual(mango_intermediate_result, "red")
        self.assertEqual(mango_root_result, "the-wire")

        # Test broken chain - user without matching email gets default/false results
        unknown_leaf_result = client.get_feature_flag(
            "multivariate-leaf-flag",
            "test-user",
            person_properties={"email": "unknown@example.com"},
        )
        unknown_intermediate_result = client.get_feature_flag(
            "multivariate-intermediate-flag",
            "test-user",
            person_properties={"email": "unknown@example.com"},
        )
        unknown_root_result = client.get_feature_flag(
            "multivariate-root-flag",
            "test-user",
            person_properties={"email": "unknown@example.com"},
        )

        self.assertEqual(
            unknown_leaf_result, False
        )  # No matching email -> null variant -> false
        self.assertEqual(unknown_intermediate_result, False)  # Dependency not satisfied
        self.assertEqual(unknown_root_result, False)  # Chain broken

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags(self, patch_get, patch_poll):
        patch_get.return_value = GetResponse(
            data={
                "flags": [
                    {
                        "id": 1,
                        "name": "Beta Feature",
                        "key": "beta-feature",
                        "active": True,
                    },
                    {
                        "id": 2,
                        "name": "Alpha Feature",
                        "key": "alpha-feature",
                        "active": False,
                    },
                ],
                "group_type_mapping": {"0": "company"},
                "cohorts": {},
            },
            etag='"abc123"',
        )
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        with freeze_time("2020-01-01T12:01:00.0000Z"):
            client.load_feature_flags()
        self.assertEqual(len(client.feature_flags), 2)
        self.assertEqual(client.feature_flags[0]["key"], "beta-feature")
        self.assertEqual(client.group_type_mapping, {"0": "company"})
        self.assertEqual(
            client._last_feature_flag_poll.isoformat(), "2020-01-01T12:01:00+00:00"
        )
        self.assertEqual(patch_poll.call_count, 1)
        # Verify ETag is stored
        self.assertEqual(client._flags_etag, '"abc123"')

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_sends_etag_on_subsequent_requests(
        self, patch_get, patch_poll
    ):
        """Test that the ETag is sent in If-None-Match header on subsequent requests"""
        patch_get.return_value = GetResponse(
            data={
                "flags": [{"id": 1, "key": "beta-feature", "active": True}],
                "group_type_mapping": {},
                "cohorts": {},
            },
            etag='"initial-etag"',
        )
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.load_feature_flags()

        # First call should have no etag
        first_call_kwargs = patch_get.call_args_list[0][1]
        self.assertIsNone(first_call_kwargs.get("etag"))

        # Simulate second call
        client._load_feature_flags()

        # Second call should have the etag
        second_call_kwargs = patch_get.call_args_list[1][1]
        self.assertEqual(second_call_kwargs.get("etag"), '"initial-etag"')

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_304_not_modified(self, patch_get, patch_poll):
        """Test that 304 Not Modified responses skip flag processing"""
        # First response with flags
        initial_response = GetResponse(
            data={
                "flags": [{"id": 1, "key": "beta-feature", "active": True}],
                "group_type_mapping": {"0": "company"},
                "cohorts": {},
            },
            etag='"test-etag"',
        )
        # Second response is 304 Not Modified
        not_modified_response = GetResponse(
            data=None,
            etag='"updated-etag"',
            not_modified=True,
        )
        patch_get.side_effect = [initial_response, not_modified_response]

        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.load_feature_flags()

        # Verify initial flags are loaded
        self.assertEqual(len(client.feature_flags), 1)
        self.assertEqual(client.feature_flags[0]["key"], "beta-feature")
        self.assertEqual(client.group_type_mapping, {"0": "company"})

        # Second call with 304
        client._load_feature_flags()

        # Flags should still be the same (not cleared)
        self.assertEqual(len(client.feature_flags), 1)
        self.assertEqual(client.feature_flags[0]["key"], "beta-feature")
        self.assertEqual(client.group_type_mapping, {"0": "company"})
        self.assertEqual(client._flags_etag, '"updated-etag"')

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_etag_updated_on_new_response(
        self, patch_get, patch_poll
    ):
        """Test that ETag is updated when flags change"""
        patch_get.side_effect = [
            GetResponse(
                data={
                    "flags": [{"id": 1, "key": "flag-v1", "active": True}],
                    "group_type_mapping": {},
                    "cohorts": {},
                },
                etag='"etag-v1"',
            ),
            GetResponse(
                data={
                    "flags": [{"id": 1, "key": "flag-v2", "active": True}],
                    "group_type_mapping": {},
                    "cohorts": {},
                },
                etag='"etag-v2"',
            ),
        ]

        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.load_feature_flags()
        self.assertEqual(client._flags_etag, '"etag-v1"')

        client._load_feature_flags()
        self.assertEqual(client._flags_etag, '"etag-v2"')
        self.assertEqual(client.feature_flags[0]["key"], "flag-v2")

    @mock.patch("posthog.client.get")
    def test_load_feature_flags_ignores_older_response_that_finishes_last(
        self, patch_get
    ):
        first_request_started = threading.Event()
        release_first_request = threading.Event()
        second_load_finished = threading.Event()
        call_count_lock = threading.Lock()
        call_count = 0

        old_response = GetResponse(
            data={
                "flags": [{"id": 1, "key": "old-flag", "active": True}],
                "group_type_mapping": {"0": "old-group"},
                "cohorts": {"old": {"properties": []}},
                "minimal_flag_called_events": False,
            },
            etag='"old-etag"',
        )
        new_response = GetResponse(
            data={
                "flags": [{"id": 2, "key": "new-flag", "active": True}],
                "group_type_mapping": {"0": "new-group"},
                "cohorts": {"new": {"properties": []}},
                "minimal_flag_called_events": True,
            },
            etag='"new-etag"',
        )

        def get_with_reversed_completion(*args, **kwargs):
            nonlocal call_count
            with call_count_lock:
                request_number = call_count
                call_count += 1

            if request_number == 0:
                first_request_started.set()
                release_first_request.wait(timeout=5)
                return old_response

            return new_response

        patch_get.side_effect = get_with_reversed_completion
        client = Client(FAKE_TEST_API_KEY, secret_key="test", send=False)

        def load_second_response():
            client._load_feature_flags()
            second_load_finished.set()

        first_thread = threading.Thread(target=client._load_feature_flags)
        second_thread = threading.Thread(target=load_second_response)

        first_thread.start()
        self.assertTrue(first_request_started.wait(timeout=5))
        second_thread.start()
        try:
            self.assertTrue(second_load_finished.wait(timeout=5))
        finally:
            release_first_request.set()

        first_thread.join(timeout=5)
        second_thread.join(timeout=5)
        self.assertFalse(first_thread.is_alive())
        self.assertFalse(second_thread.is_alive())
        self.assertEqual(client.feature_flags[0]["key"], "new-flag")
        self.assertEqual(client.group_type_mapping, {"0": "new-group"})
        self.assertEqual(client.cohorts, {"new": {"properties": []}})
        self.assertTrue(client._minimal_flag_called_events)
        self.assertEqual(client._flags_etag, '"new-etag"')

    @mock.patch("posthog.client.get")
    def test_load_feature_flags_accepted_304_suppresses_older_in_flight_update(
        self, patch_get
    ):
        first_request_started = threading.Event()
        second_load_finished = threading.Event()
        call_count_lock = threading.Lock()
        call_count = 0

        initial_response = GetResponse(
            data={
                "flags": [{"id": 1, "key": "old-flag", "active": True}],
                "group_type_mapping": {},
                "cohorts": {},
            },
            etag='"etag-a"',
        )
        changed_response = GetResponse(
            data={
                "flags": [{"id": 2, "key": "new-flag", "active": True}],
                "group_type_mapping": {},
                "cohorts": {},
            },
            etag='"etag-b"',
        )
        not_modified_response = GetResponse(
            data=None,
            etag='"etag-a"',
            not_modified=True,
        )

        def get_304_before_changed_response(*args, **kwargs):
            nonlocal call_count
            with call_count_lock:
                request_number = call_count
                call_count += 1

            if request_number == 0:
                return initial_response
            if request_number == 1:
                first_request_started.set()
                second_load_finished.wait(timeout=5)
                return changed_response
            return not_modified_response

        patch_get.side_effect = get_304_before_changed_response
        client = Client(FAKE_TEST_API_KEY, secret_key="test", send=False)
        client._load_feature_flags()

        def load_not_modified_response():
            client._load_feature_flags()
            second_load_finished.set()

        first_thread = threading.Thread(target=client._load_feature_flags)
        second_thread = threading.Thread(target=load_not_modified_response)
        first_thread.start()
        self.assertTrue(first_request_started.wait(timeout=5))
        second_thread.start()
        first_thread.join(timeout=5)
        second_thread.join(timeout=5)

        self.assertFalse(first_thread.is_alive())
        self.assertFalse(second_thread.is_alive())
        self.assertEqual(client.feature_flags[0]["key"], "old-flag")
        self.assertEqual(client._flags_etag, '"etag-a"')

    @mock.patch("posthog.client.get")
    def test_load_feature_flags_ignores_304_for_superseded_etag(self, patch_get):
        first_request_started = threading.Event()
        second_request_started = threading.Event()
        first_load_finished = threading.Event()
        call_count_lock = threading.Lock()
        call_count = 0

        changed_response = GetResponse(
            data={
                "flags": [{"id": 2, "key": "new-flag", "active": True}],
                "group_type_mapping": {"0": "new-group"},
                "cohorts": {},
            },
            etag='"etag-b"',
        )
        stale_not_modified_response = GetResponse(
            data=None,
            etag='"etag-a"',
            not_modified=True,
        )

        def get_changed_then_delayed_304(*args, **kwargs):
            nonlocal call_count
            with call_count_lock:
                request_number = call_count
                call_count += 1

            if request_number == 0:
                first_request_started.set()
                second_request_started.wait(timeout=5)
                return changed_response

            second_request_started.set()
            first_load_finished.wait(timeout=5)
            return stale_not_modified_response

        patch_get.side_effect = get_changed_then_delayed_304
        client = Client(FAKE_TEST_API_KEY, secret_key="test", send=False)
        client._flags_etag = '"etag-a"'

        def load_changed_response():
            client._load_feature_flags()
            first_load_finished.set()

        first_thread = threading.Thread(target=load_changed_response)
        second_thread = threading.Thread(target=client._load_feature_flags)

        first_thread.start()
        self.assertTrue(first_request_started.wait(timeout=5))
        second_thread.start()
        first_thread.join(timeout=5)
        second_thread.join(timeout=5)

        self.assertFalse(first_thread.is_alive())
        self.assertFalse(second_thread.is_alive())
        self.assertEqual(client.feature_flags[0]["key"], "new-flag")
        self.assertEqual(client.group_type_mapping, {"0": "new-group"})
        self.assertEqual(client._flags_etag, '"etag-b"')

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_clears_etag_when_server_stops_sending(
        self, patch_get, patch_poll
    ):
        """Test that ETag is cleared when server stops sending it"""
        patch_get.side_effect = [
            GetResponse(
                data={
                    "flags": [{"id": 1, "key": "flag-v1", "active": True}],
                    "group_type_mapping": {},
                    "cohorts": {},
                },
                etag='"etag-v1"',
            ),
            GetResponse(
                data={
                    "flags": [{"id": 1, "key": "flag-v2", "active": True}],
                    "group_type_mapping": {},
                    "cohorts": {},
                },
                etag=None,  # Server stopped sending ETag
            ),
        ]

        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.load_feature_flags()
        self.assertEqual(client._flags_etag, '"etag-v1"')

        client._load_feature_flags()
        self.assertIsNone(client._flags_etag)
        self.assertEqual(client.feature_flags[0]["key"], "flag-v2")

    @parameterized.expand([401, 402])
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_refetches_after_state_reset(self, status, patch_get):
        patch_get.side_effect = [
            GetResponse(
                data={
                    "flags": [{"id": 1, "key": "old-flag", "active": True}],
                    "group_type_mapping": {},
                    "cohorts": {},
                },
                etag='"old-etag"',
            ),
            APIError(status, "reset flag definitions"),
            GetResponse(
                data={
                    "flags": [{"id": 2, "key": "new-flag", "active": True}],
                    "group_type_mapping": {},
                    "cohorts": {},
                },
                etag='"new-etag"',
            ),
        ]
        client = Client(FAKE_TEST_API_KEY, secret_key="test", send=False)

        client._load_feature_flags()
        client._load_feature_flags()
        self.assertEqual(client.feature_flags, [])
        self.assertIsNone(client._flags_etag)

        client._load_feature_flags()

        self.assertIsNone(patch_get.call_args_list[2].kwargs["etag"])
        self.assertEqual(client.feature_flags[0]["key"], "new-flag")
        self.assertEqual(client._flags_etag, '"new-etag"')

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_wrong_key(self, patch_get, _patch_poll):
        patch_get.side_effect = APIError(401, "Unauthorized")
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        with self.assertLogs("posthog", level="ERROR") as logs:
            client.load_feature_flags()
            self.assertIn("Unauthorized", logs.output[0])
            self.assertIn("project_api_key", logs.output[0])
            self.assertIn("secret_key", logs.output[0])
        client.debug = True
        with self.assertRaisesRegex(APIError, "Unauthorized"):
            client.load_feature_flags()

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_enabled_simple(self, patch_get, patch_flags):
        client = Client(FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            }
        ]
        self.assertTrue(client.feature_enabled("beta-feature", "distinct_id"))
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_enabled_simple_is_false(self, patch_get, patch_flags):
        client = Client(FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 0,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 0,
                        }
                    ]
                },
            }
        ]
        self.assertFalse(client.feature_enabled("beta-feature", "distinct_id"))
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_feature_enabled_simple_is_true_when_rollout_is_undefined(
        self, patch_get, patch_flags
    ):
        client = Client(FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": None,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": None,
                        }
                    ]
                },
            }
        ]
        self.assertTrue(client.feature_enabled("beta-feature", "distinct_id"))
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.get")
    def test_feature_enabled_simple_with_project_api_key(self, patch_get):
        client = Client(project_api_key=FAKE_TEST_API_KEY, on_error=self.set_fail)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            }
        ]
        self.assertTrue(client.feature_enabled("beta-feature", "distinct_id"))

    @mock.patch("posthog.client.flags")
    def test_feature_enabled_request_multi_variate(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "variant-1"}}
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ]
                },
            }
        ]
        self.assertTrue(client.feature_enabled("beta-feature", "distinct_id"))
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.get")
    def test_feature_enabled_simple_without_rollout_percentage(self, patch_get):
        client = Client(FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                        }
                    ]
                },
            }
        ]
        self.assertTrue(client.feature_enabled("beta-feature", "distinct_id"))

    @mock.patch("posthog.client.flags")
    def test_get_feature_flag(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "variant-1"}}
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "variant-1", "rollout_percentage": 50},
                            {"key": "variant-2", "rollout_percentage": 50},
                        ]
                    },
                },
            }
        ]
        self.assertEqual(
            client.get_feature_flag("beta-feature", "distinct_id"), "variant-1"
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.flags")
    def test_feature_enabled_doesnt_exist(self, patch_flags, patch_poll):
        client = Client(FAKE_TEST_API_KEY)
        client.feature_flags = []

        patch_flags.return_value = {"featureFlags": {}}
        self.assertFalse(client.feature_enabled("doesnt-exist", "distinct_id"))

        patch_flags.side_effect = APIError(401, "flags error")
        self.assertIsNone(client.feature_enabled("doesnt-exist", "distinct_id"))

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.flags")
    def test_personal_api_key_doesnt_exist(self, patch_flags, patch_poll):
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = []

        patch_flags.return_value = {"featureFlags": {"feature-flag": True}}

        self.assertTrue(client.feature_enabled("feature-flag", "distinct_id"))

    @mock.patch("posthog.client.Poller")
    @mock.patch("posthog.client.get")
    def test_load_feature_flags_error(self, patch_get, patch_poll):
        def raise_effect():
            raise Exception("http exception")

        patch_get.return_value.raiseError.side_effect = raise_effect
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = []

        self.assertFalse(client.feature_enabled("doesnt-exist", "distinct_id"))

    @mock.patch("posthog.client.flags")
    def test_get_feature_flag_with_variant_overrides(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "variant-1"}}
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "test@posthog.com",
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "second-variant",
                        },
                        {"rollout_percentage": 50, "variant": "first-variant"},
                    ],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "first-variant",
                                "name": "First Variant",
                                "rollout_percentage": 50,
                            },
                            {
                                "key": "second-variant",
                                "name": "Second Variant",
                                "rollout_percentage": 25,
                            },
                            {
                                "key": "third-variant",
                                "name": "Third Variant",
                                "rollout_percentage": 25,
                            },
                        ]
                    },
                },
            }
        ]
        self.assertEqual(
            client.get_feature_flag(
                "beta-feature",
                "test_id",
                person_properties={"email": "test@posthog.com"},
            ),
            "second-variant",
        )
        self.assertEqual(
            client.get_feature_flag("beta-feature", "example_id"), "first-variant"
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_flag_with_clashing_variant_overrides(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "variant-1"}}
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "test@posthog.com",
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "second-variant",
                        },
                        # since second-variant comes first in the list, it will be the one that gets picked
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "test@posthog.com",
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "first-variant",
                        },
                        {"rollout_percentage": 50, "variant": "first-variant"},
                    ],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "first-variant",
                                "name": "First Variant",
                                "rollout_percentage": 50,
                            },
                            {
                                "key": "second-variant",
                                "name": "Second Variant",
                                "rollout_percentage": 25,
                            },
                            {
                                "key": "third-variant",
                                "name": "Third Variant",
                                "rollout_percentage": 25,
                            },
                        ]
                    },
                },
            }
        ]
        self.assertEqual(
            client.get_feature_flag(
                "beta-feature",
                "test_id",
                person_properties={"email": "test@posthog.com"},
            ),
            "second-variant",
        )
        self.assertEqual(
            client.get_feature_flag(
                "beta-feature",
                "example_id",
                person_properties={"email": "test@posthog.com"},
            ),
            "second-variant",
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_flag_with_invalid_variant_overrides(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"beta-feature": "variant-1"}}
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "beta-feature",
                "active": True,
                "rollout_percentage": 100,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "test@posthog.com",
                                    "operator": "exact",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "second???",
                        },
                        {"rollout_percentage": 50, "variant": "first??"},
                    ],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "first-variant",
                                "name": "First Variant",
                                "rollout_percentage": 50,
                            },
                            {
                                "key": "second-variant",
                                "name": "Second Variant",
                                "rollout_percentage": 25,
                            },
                            {
                                "key": "third-variant",
                                "name": "Third Variant",
                                "rollout_percentage": 25,
                            },
                        ]
                    },
                },
            }
        ]
        self.assertEqual(
            client.get_feature_flag(
                "beta-feature",
                "test_id",
                person_properties={"email": "test@posthog.com"},
            ),
            "third-variant",
        )
        self.assertEqual(
            client.get_feature_flag("beta-feature", "example_id"), "second-variant"
        )
        # /flags is not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_conditions_evaluated_in_order(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"order-test": "server-variant"}}
        client = Client(FAKE_TEST_API_KEY, secret_key="test")
        client.feature_flags = [
            {
                "id": 1,
                "name": "Order Test Flag",
                "key": "order-test",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "rollout_percentage": 100,
                        },
                        {
                            "properties": [
                                {
                                    "key": "email",
                                    "type": "person",
                                    "value": "@vip.com",
                                    "operator": "icontains",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "vip-variant",
                        },
                    ],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "control",
                                "name": "Control",
                                "rollout_percentage": 100,
                            },
                            {
                                "key": "vip-variant",
                                "name": "VIP Variant",
                                "rollout_percentage": 0,
                            },
                        ]
                    },
                },
            }
        ]

        # Even though user@vip.com would match the second condition with variant override,
        # they should match the first condition and get control
        result = client.get_feature_flag(
            "order-test",
            "user123",
            person_properties={"email": "user@vip.com"},
        )
        self.assertEqual(result, "control")

        # server not called because this can be evaluated locally
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_boolean_feature_flag_payloads_local(self, patch_flags):
        basic_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "person-flag",
            "active": True,
            "filters": {
                "groups": [
                    {
                        "properties": [
                            {
                                "key": "region",
                                "operator": "exact",
                                "value": ["USA"],
                                "type": "person",
                            }
                        ],
                        "rollout_percentage": 100,
                    }
                ],
                "payloads": {"true": 300, "false": 400},
            },
        }
        self.client.feature_flags = [basic_flag]
        self.client.flag_cache = FlagCache()

        self.assertEqual(
            self.client.get_feature_flag_payload(
                "person-flag", "some-distinct-id", person_properties={"region": "USA"}
            ),
            300,
        )

        self.assertEqual(
            self.client.get_feature_flag_payload(
                "person-flag",
                "some-distinct-id",
                match_value=True,
                person_properties={"region": "USA"},
            ),
            300,
        )

        # A false override must take precedence over a locally evaluated true value.
        self.assertEqual(
            self.client.get_feature_flag_payload(
                "person-flag",
                "some-distinct-id",
                match_value=False,
                person_properties={"region": "USA"},
            ),
            400,
        )

        cached_result = self.client.flag_cache.get_stale_cached_flag(
            "some-distinct-id", "person-flag"
        )
        assert cached_result is not None
        self.assertIs(cached_result.get_value(), True)
        self.assertEqual(cached_result.payload, 300)

        # Locally evaluated false values use the lowercase "false" payload key.
        self.assertEqual(
            self.client.get_feature_flag_payload(
                "person-flag",
                "some-distinct-id",
                person_properties={"region": "Canada"},
            ),
            400,
        )
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_boolean_feature_flag_payload_decide(self, patch_flags, patch_capture):
        patch_flags.return_value = {
            "featureFlags": {"person-flag": True},
            "featureFlagPayloads": {"person-flag": 300},
        }
        self.assertEqual(
            self.client.get_feature_flag_payload(
                "person-flag", "some-distinct-id", person_properties={"region": "USA"}
            ),
            300,
        )

        self.assertEqual(
            self.client.get_feature_flag_payload(
                "person-flag",
                "some-distinct-id",
                match_value=True,
                person_properties={"region": "USA"},
                send_feature_flag_events=True,
            ),
            300,
        )
        self.assertEqual(patch_flags.call_count, 2)
        self.assertEqual(patch_capture.call_count, 1)
        patch_capture.reset_mock()

    @mock.patch("posthog.client.flags")
    def test_multivariate_feature_flag_payloads(self, patch_flags):
        multivariate_flag = {
            "id": 1,
            "name": "Beta Feature",
            "key": "beta-feature",
            "active": True,
            "rollout_percentage": 100,
            "filters": {
                "groups": [
                    {
                        "properties": [
                            {
                                "key": "email",
                                "type": "person",
                                "value": "test@posthog.com",
                                "operator": "exact",
                            }
                        ],
                        "rollout_percentage": 100,
                        "variant": "second???",
                    },
                    {"rollout_percentage": 50, "variant": "first??"},
                ],
                "multivariate": {
                    "variants": [
                        {
                            "key": "first-variant",
                            "name": "First Variant",
                            "rollout_percentage": 50,
                        },
                        {
                            "key": "second-variant",
                            "name": "Second Variant",
                            "rollout_percentage": 25,
                        },
                        {
                            "key": "third-variant",
                            "name": "Third Variant",
                            "rollout_percentage": 25,
                        },
                    ]
                },
                "payloads": {
                    "first-variant": '"some-payload"',
                    "third-variant": '{"a": "json"}',
                },
            },
        }
        self.client.feature_flags = [multivariate_flag]

        self.assertEqual(
            self.client.get_feature_flag_payload(
                "beta-feature",
                "test_id",
                person_properties={"email": "test@posthog.com"},
            ),
            {"a": "json"},
        )
        self.assertEqual(
            self.client.get_feature_flag_payload(
                "beta-feature",
                "test_id",
                match_value="third-variant",
                person_properties={"email": "test@posthog.com"},
            ),
            {"a": "json"},
        )

        # Force different match value
        self.assertEqual(
            self.client.get_feature_flag_payload(
                "beta-feature",
                "test_id",
                match_value="first-variant",
                person_properties={"email": "test@posthog.com"},
            ),
            "some-payload",
        )
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    @mock.patch("posthog.client.get")
    def test_fallback_to_api_when_flag_has_static_cohort_in_multi_condition(
        self, patch_get, patch_flags
    ):
        """
        When a flag has multiple conditions and one contains a static cohort,
        the SDK should fallback to API for the entire flag, not just skip that
        condition and evaluate the next one locally.

        This prevents returning wrong variants when later conditions could match
        locally but the user is actually in the static cohort.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # Mock the local flags response - cohort 999 is NOT in cohorts map (static cohort)
        client.feature_flags = [
            {
                "id": 1,
                "key": "multi-condition-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {"key": "id", "value": 999, "type": "cohort"}
                            ],
                            "rollout_percentage": 100,
                            "variant": "set-1",
                        },
                        {
                            "properties": [
                                {
                                    "key": "$geoip_country_code",
                                    "operator": "exact",
                                    "value": ["DE"],
                                    "type": "person",
                                }
                            ],
                            "rollout_percentage": 100,
                            "variant": "set-8",
                        },
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "set-1", "rollout_percentage": 50},
                            {"key": "set-8", "rollout_percentage": 50},
                        ]
                    },
                },
            }
        ]
        client.cohorts = {}  # Note: cohort 999 is NOT here - it's a static cohort

        # Mock the API response - user is in the static cohort
        patch_flags.return_value = {"featureFlags": {"multi-condition-flag": "set-1"}}

        result = client.get_feature_flag(
            "multi-condition-flag",
            "test-distinct-id",
            person_properties={"$geoip_country_code": "DE"},
        )

        # Should return the API result (set-1), not local evaluation (set-8)
        self.assertEqual(result, "set-1")

        # Verify API was called (fallback occurred)
        self.assertEqual(patch_flags.call_count, 1)

    @mock.patch("posthog.client.flags")
    def test_device_id_bucketing_uses_device_id_for_hash(self, patch_flags):
        """
        When a flag has bucketing_identifier: "device_id", the device_id should be
        used for hashing instead of distinct_id.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # This flag uses device_id for bucketing
        client.feature_flags = [
            {
                "id": 1,
                "key": "device-bucketed-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        # Same distinct_id with different device_ids should produce different results
        # (based on rollout percentage, we check consistency)
        result1 = client.get_feature_flag(
            "device-bucketed-flag", "user-123", device_id="device-A"
        )
        result2 = client.get_feature_flag(
            "device-bucketed-flag", "user-123", device_id="device-A"
        )

        # Same device_id should give consistent results
        self.assertEqual(result1, result2)

        # No API fallback should occur
        self.assertEqual(patch_flags.call_count, 0)

    def test_match_feature_flag_properties_without_bucketing_value_is_deprecated(
        self,
    ):
        """
        match_feature_flag_properties should preserve backward compatibility when
        bucketing_value is omitted, while warning about deprecation.
        """
        from posthog.feature_flags import match_feature_flag_properties

        flag = {
            "id": 1,
            "key": "device-bucketed-flag",
            "active": True,
            "filters": {
                "bucketing_identifier": "device_id",
                "groups": [
                    {
                        "properties": [],
                        "rollout_percentage": 100,
                    }
                ],
            },
        }

        with self.assertWarnsRegex(
            DeprecationWarning, "without bucketing_value is deprecated"
        ):
            result = match_feature_flag_properties(
                flag,
                "user-123",
                {},
                device_id="device-123",
            )

        self.assertTrue(result)

    @mock.patch("posthog.client.flags")
    def test_device_id_bucketing_same_device_different_users_same_result(
        self, patch_flags
    ):
        """
        When a flag uses device_id bucketing, different distinct_ids with the same
        device_id should get the same result.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "device-bucketed-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 50,
                        }
                    ],
                },
            }
        ]

        # Different distinct_ids with the same device_id should get the same result
        result1 = client.get_feature_flag(
            "device-bucketed-flag", "user-A", device_id="shared-device"
        )
        result2 = client.get_feature_flag(
            "device-bucketed-flag", "user-B", device_id="shared-device"
        )
        result3 = client.get_feature_flag(
            "device-bucketed-flag", "user-C", device_id="shared-device"
        )

        # All should be the same since device_id is the same
        self.assertEqual(result1, result2)
        self.assertEqual(result2, result3)

        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_device_id_bucketing_fallback_when_device_id_missing(self, patch_flags):
        """
        When a flag requires device_id for bucketing but none is provided,
        it should fallback to server evaluation.
        """
        patch_flags.return_value = {"featureFlags": {"device-bucketed-flag": True}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "device-bucketed-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        # No device_id provided - should fallback to API
        result = client.get_feature_flag("device-bucketed-flag", "user-123")

        self.assertTrue(result)
        # API should have been called
        self.assertEqual(patch_flags.call_count, 1)

    @mock.patch("posthog.client.flags")
    def test_device_id_bucketing_returns_none_when_only_evaluate_locally_and_no_device_id(
        self, patch_flags
    ):
        """
        When only_evaluate_locally=True and device_id is required but missing,
        should return None instead of falling back to API.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "device-bucketed-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        # No device_id + only_evaluate_locally should return None
        result = client.get_feature_flag(
            "device-bucketed-flag", "user-123", only_evaluate_locally=True
        )

        self.assertIsNone(result)
        # API should NOT have been called
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_default_bucketing_identifier_uses_distinct_id(self, patch_flags):
        """
        When bucketing_identifier is not set or is 'distinct_id', should use
        distinct_id for hashing (default behavior).
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # Flag without bucketing_identifier (defaults to distinct_id)
        client.feature_flags = [
            {
                "id": 1,
                "key": "normal-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 50,
                        }
                    ],
                },
            }
        ]

        # Different distinct_ids should potentially produce different results
        # but same distinct_id should produce same result
        result1 = client.get_feature_flag("normal-flag", "user-A")
        result2 = client.get_feature_flag("normal-flag", "user-A")

        self.assertEqual(result1, result2)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_device_id_bucketing_with_multivariate_flag(self, patch_flags):
        """
        Multivariate flag variant selection should use device_id when
        bucketing_identifier is set to device_id.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "multivariate-device-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                    "multivariate": {
                        "variants": [
                            {"key": "control", "rollout_percentage": 50},
                            {"key": "test", "rollout_percentage": 50},
                        ]
                    },
                },
            }
        ]

        # Same device_id should give same variant
        result1 = client.get_feature_flag(
            "multivariate-device-flag", "user-A", device_id="device-1"
        )
        result2 = client.get_feature_flag(
            "multivariate-device-flag", "user-B", device_id="device-1"
        )

        # Both should get the same variant because device_id is the same
        self.assertEqual(result1, result2)
        self.assertIn(result1, ["control", "test"])

        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_device_id_bucketing_from_context(self, patch_flags):
        """
        When device_id is not passed as a parameter but is set in the context,
        it should be resolved from context.
        """
        from posthog.contexts import new_context, set_context_device_id

        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "device-bucketed-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        # Set device_id in context
        with new_context():
            set_context_device_id("context-device-id")
            result = client.get_feature_flag("device-bucketed-flag", "user-123")

        # Should evaluate locally using the context device_id
        self.assertTrue(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_group_flags_ignore_bucketing_identifier(self, patch_flags):
        """
        Group flags should continue to use the group identifier for hashing,
        regardless of the bucketing_identifier setting.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "group-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "bucketing_identifier": "device_id",  # Should be ignored for group flags
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]
        client.group_type_mapping = {"0": "company"}

        # Even with bucketing_identifier set to device_id, group flag should use group identifier
        result = client.get_feature_flag(
            "group-flag",
            "user-123",
            groups={"company": "acme-inc"},
            device_id="some-device",
        )

        self.assertTrue(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_group_flag_dependency_receives_device_id(self, patch_flags):
        """
        Group flag dependency evaluation should receive device_id so dependent
        device_id-bucketed flags can be evaluated locally.
        """
        patch_flags.return_value = {"featureFlags": {"group-parent-flag": "from-api"}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "device-dependent-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "key": "group-parent-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "device-dependent-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["device-dependent-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]
        client.group_type_mapping = {"0": "company"}

        result = client.get_feature_flag(
            "group-parent-flag",
            "user-123",
            groups={"company": "acme-inc"},
            device_id="device-123",
        )

        self.assertTrue(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_group_flag_dependency_ignores_device_id_bucketing_identifier(
        self, patch_flags
    ):
        """
        Group flag dependencies should keep bucketing by group key, even when
        the dependent group flag has bucketing_identifier set to device_id.
        """
        patch_flags.return_value = {"featureFlags": {"parent-group-flag": "from-api"}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "child-group-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "bucketing_identifier": "device_id",
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
            {
                "id": 2,
                "key": "parent-group-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": 0,
                    "groups": [
                        {
                            "properties": [
                                {
                                    "key": "child-group-flag",
                                    "operator": "flag_evaluates_to",
                                    "value": True,
                                    "type": "flag",
                                    "dependency_chain": ["child-group-flag"],
                                }
                            ],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            },
        ]
        client.group_type_mapping = {"0": "company"}

        result = client.get_feature_flag(
            "parent-group-flag",
            "user-123",
            groups={"company": "acme-inc"},
        )

        self.assertTrue(result)
        self.assertEqual(patch_flags.call_count, 0)

    MIXED_FLAG = {
        "id": 1,
        "key": "mixed-flag",
        "active": True,
        "filters": {
            "aggregation_group_type_index": None,
            "groups": [
                {
                    "aggregation_group_type_index": 0,
                    "properties": [
                        {
                            "key": "plan",
                            "value": "enterprise",
                            "operator": "exact",
                            "type": "group",
                            "group_type_index": 0,
                        }
                    ],
                    "rollout_percentage": 100,
                },
                {
                    "aggregation_group_type_index": None,
                    "properties": [
                        {
                            "key": "email",
                            "value": "test@example.com",
                            "operator": "exact",
                            "type": "person",
                        }
                    ],
                    "rollout_percentage": 100,
                },
            ],
        },
    }

    @parameterized.expand(
        [
            (
                "person_condition_matches",
                {"person_properties": {"email": "test@example.com"}},
                True,
            ),
            (
                "group_condition_matches",
                {
                    "groups": {"company": "acme"},
                    "group_properties": {"company": {"plan": "enterprise"}},
                },
                True,
            ),
            (
                "no_match",
                {
                    "person_properties": {"email": "wrong@example.com"},
                    "groups": {"company": "acme"},
                    "group_properties": {"company": {"plan": "free"}},
                },
                False,
            ),
        ]
    )
    @mock.patch("posthog.client.flags")
    def test_mixed_targeting(self, _name, call_kwargs, expected, patch_flags):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [self.MIXED_FLAG]
        client.group_type_mapping = {"0": "company"}

        result = client.get_feature_flag("mixed-flag", "user-123", **call_kwargs)
        self.assertEqual(bool(result), expected)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_mixed_targeting_only_group_conditions_no_groups_passed(self, patch_flags):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "key": "mixed-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": None,
                    "groups": [
                        {
                            "aggregation_group_type_index": 0,
                            "properties": [],
                            "rollout_percentage": 100,
                        },
                    ],
                },
            }
        ]
        client.group_type_mapping = {"0": "company"}

        # No groups passed, no person condition — all conditions skip, returns False
        result = client.get_feature_flag(
            "mixed-flag",
            "user-123",
        )
        self.assertFalse(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_mixed_targeting_rollout_uses_correct_bucketing(self, patch_flags):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "key": "mixed-flag",
                "active": True,
                "filters": {
                    "aggregation_group_type_index": None,
                    "groups": [
                        {
                            "aggregation_group_type_index": 0,
                            "properties": [],
                            "rollout_percentage": 100,
                        },
                        {
                            "aggregation_group_type_index": None,
                            "properties": [],
                            "rollout_percentage": 0,
                        },
                    ],
                },
            }
        ]
        client.group_type_mapping = {"0": "company"}

        # Group condition at 100% matches, person condition at 0% doesn't matter
        result = client.get_feature_flag(
            "mixed-flag",
            "user-123",
            groups={"company": "acme"},
            group_properties={"company": {}},
        )
        self.assertTrue(result)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_get_all_flags_with_device_id_bucketing(self, patch_flags):
        """
        get_all_flags_and_payloads should properly handle flags with device_id bucketing.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "normal-flag",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            },
            {
                "id": 2,
                "key": "device-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            },
        ]

        # With device_id provided, both flags should be evaluated locally
        result = client.get_all_flags("user-123", device_id="my-device")

        self.assertEqual(result["normal-flag"], True)
        self.assertEqual(result["device-flag"], True)
        self.assertEqual(patch_flags.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_get_all_flags_fallback_when_device_id_missing_for_some_flags(
        self, patch_flags
    ):
        """
        When some flags require device_id but it's not provided, those flags
        should trigger fallback while others can be evaluated locally.
        """
        patch_flags.return_value = {
            "featureFlags": {"normal-flag": True, "device-flag": "from-api"}
        }
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "key": "normal-flag",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            },
            {
                "id": 2,
                "key": "device-flag",
                "active": True,
                "filters": {
                    "bucketing_identifier": "device_id",
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            },
        ]

        # Without device_id, device-flag can't be evaluated locally
        client.get_all_flags("user-123")

        # Should fallback to API for all flags when any can't be evaluated locally
        self.assertEqual(patch_flags.call_count, 1)


class TestMatchProperties(unittest.TestCase):
    def property(self, key, value, operator=None):
        result = {"key": key, "value": value}
        if operator is not None:
            result.update({"operator": operator})

        return result

    def test_every_supported_operator_has_a_dispatch_branch(self):
        # PROPERTY_OPERATORS gates local evaluation, but match_property dispatches
        # on a hand-written if-chain. An operator listed in the tuple but missing a
        # branch falls through to the "unreachable" raise at the end of the function,
        # silently pushing the flag back to remote evaluation.
        for operator in PROPERTY_OPERATORS:
            prop = self.property(key="key", value="1.0.0", operator=operator)
            try:
                match_property(prop, {"key": "1.0.0"})
            except InconclusiveMatchError as error:
                self.assertNotIn(_UNHANDLED_OPERATOR_MESSAGE, str(error), operator)

    def test_match_properties_exact(self):
        property_a = self.property(key="key", value="value")

        self.assertTrue(match_property(property_a, {"key": "value"}))

        self.assertFalse(match_property(property_a, {"key": "value2"}))
        self.assertFalse(match_property(property_a, {"key": ""}))
        self.assertFalse(match_property(property_a, {"key": None}))

        with self.assertRaises(InconclusiveMatchError):
            match_property(property_a, {"key2": "value"})
            match_property(property_a, {})

        property_b = self.property(key="key", value="value", operator="exact")
        self.assertTrue(match_property(property_b, {"key": "value"}))

        self.assertFalse(match_property(property_b, {"key": "value2"}))

        property_c = self.property(
            key="key", value=["value1", "value2", "value3"], operator="exact"
        )
        self.assertTrue(match_property(property_c, {"key": "value1"}))
        self.assertTrue(match_property(property_c, {"key": "value2"}))
        self.assertTrue(match_property(property_c, {"key": "value3"}))

        self.assertFalse(match_property(property_c, {"key": "value4"}))

        with self.assertRaises(InconclusiveMatchError):
            match_property(property_c, {"key2": "value"})

    @parameterized.expand(
        [
            ("non_ascii_case_variant", "Ä", "ä", True),
            ("float_stringification", "323.0", 323.0, True),
            ("casefold_expansion", "ß", "ss", False),
            ("single_final_sigma", "Σ", "ς", False),
            ("word_final_sigma", "ΟΔΟΣ", "οδος", True),
            ("word_medial_sigma", "ΟΔΟΣ", "οδοσ", False),
            ("dotted_capital_i", "İ", "i\u0307", True),
            ("plain_i", "İ", "i", False),
        ]
    )
    def test_match_properties_exact_uses_unicode_lowercase(
        self, _name, filter_value, property_value, expected
    ):
        exact = self.property("key", filter_value, "exact")
        is_not = self.property("key", filter_value, "is_not")
        self.assertEqual(expected, match_property(exact, {"key": property_value}))
        self.assertEqual(not expected, match_property(is_not, {"key": property_value}))

    def test_match_properties_exact_array_uses_unicode_lowercase(self):
        exact_array = self.property("key", ["free", "Ä"], "exact")
        is_not_array = self.property("key", ["free", "Ä"], "is_not")
        self.assertTrue(match_property(exact_array, {"key": "ä"}))
        self.assertFalse(match_property(is_not_array, {"key": "ä"}))
        self.assertFalse(match_property(exact_array, {"key": "paid"}))
        self.assertTrue(match_property(is_not_array, {"key": "paid"}))

    @parameterized.expand(
        [
            ("false_matches_non_truthy_string", False, "banana", True),
            ("false_string_matches_zero", "false", 0, True),
            ("false_array_matches_null", ["false"], None, True),
            ("mixed_boolean_array_rejects_true", ["true", "false"], "true", False),
            ("mixed_boolean_array_matches_non_truthy", ["true", "false"], "pro", True),
            ("empty_array_matches_true", [], True, True),
            ("empty_array_matches_empty_array", [], [], True),
            ("empty_array_rejects_false", [], False, False),
            ("ordinary_array_uses_any", ["FREE", "PRO"], "pro", True),
        ]
    )
    def test_match_properties_exact_uses_backend_boolean_precedence(
        self, _name, filter_value, property_value, expected
    ):
        exact = self.property("key", filter_value, "exact")
        is_not = self.property("key", filter_value, "is_not")
        self.assertEqual(expected, match_property(exact, {"key": property_value}))
        self.assertEqual(not expected, match_property(is_not, {"key": property_value}))

    @parameterized.expand(
        [
            ("compact_array", "[1,2]", [1, 2], True),
            ("python_array_spelling", "[1, 2]", [1, 2], False),
            (
                "sorted_object",
                '{"a":1,"b":2}',
                {"b": 2, "a": 1},
                True,
            ),
            (
                "recursive_sorting",
                '{"a":"x","z":[{"a":2,"b":1}]}',
                {"z": [{"b": 1, "a": 2}], "a": "x"},
                True,
            ),
        ]
    )
    def test_match_properties_exact_uses_backend_json_stringification(
        self, _name, filter_value, property_value, expected
    ):
        exact = self.property("key", filter_value, "exact")
        is_not = self.property("key", filter_value, "is_not")
        self.assertEqual(expected, match_property(exact, {"key": property_value}))
        self.assertEqual(not expected, match_property(is_not, {"key": property_value}))

    @parameterized.expand(
        [
            ("integral_float", "323.0", 323.0, True),
            ("negative_zero", "-0.0", -0.0, True),
            ("small_exponent", "1e-7", 1e-7, True),
            ("large_exponent", "1e+16", 1e16, True),
            ("fixed_small_decimal", "0.00001", 1e-5, True),
            ("fixed_small_decimal_fraction", "0.000099", 9.9e-5, True),
            ("python_padded_exponent", "1e-07", 1e-7, False),
        ]
    )
    def test_match_properties_exact_uses_backend_float_stringification(
        self, _name, filter_value, property_value, expected
    ):
        exact = self.property("key", filter_value, "exact")
        is_not = self.property("key", filter_value, "is_not")
        self.assertEqual(expected, match_property(exact, {"key": property_value}))
        self.assertEqual(not expected, match_property(is_not, {"key": property_value}))

    @parameterized.expand(
        [
            ("nan", "value", float("nan")),
            ("positive_infinity", "value", float("inf")),
            ("negative_infinity", "value", float("-inf")),
            ("boolean_filter_with_nan", False, float("nan")),
        ]
    )
    def test_match_properties_exact_non_json_numbers_are_inconclusive(
        self, _name, filter_value, property_value
    ):
        exact = self.property("key", filter_value, "exact")
        with self.assertRaises(InconclusiveMatchError):
            match_property(exact, {"key": property_value})

    def test_match_properties_not_in(self):
        property_a = self.property(key="key", value="value", operator="is_not")
        self.assertTrue(match_property(property_a, {"key": "value2"}))
        self.assertTrue(match_property(property_a, {"key": ""}))
        self.assertTrue(match_property(property_a, {"key": None}))

        property_c = self.property(
            key="key", value=["value1", "value2", "value3"], operator="is_not"
        )
        self.assertTrue(match_property(property_c, {"key": "value4"}))
        self.assertTrue(match_property(property_c, {"key": "value5"}))
        self.assertTrue(match_property(property_c, {"key": "value6"}))
        self.assertTrue(match_property(property_c, {"key": ""}))
        self.assertTrue(match_property(property_c, {"key": None}))

        self.assertFalse(match_property(property_c, {"key": "value2"}))
        self.assertFalse(match_property(property_c, {"key": "value3"}))
        self.assertFalse(match_property(property_c, {"key": "value1"}))

        with self.assertRaises(InconclusiveMatchError):
            match_property(property_a, {"key2": "value"})
            match_property(property_c, {"key2": "value1"})  # overrides don't have 'key'

    @parameterized.expand(
        [
            ("is_set_none", "is_set", None, True),
            ("is_set_false", "is_set", False, True),
            ("is_set_zero", "is_set", 0, True),
            ("is_set_empty_string", "is_set", "", True),
            ("is_set_empty_list", "is_set", [], True),
            ("is_set_empty_dict", "is_set", {}, True),
            ("is_not_set_none", "is_not_set", None, False),
            ("is_not_set_false", "is_not_set", False, False),
            ("is_not_set_zero", "is_not_set", 0, False),
            ("is_not_set_empty_string", "is_not_set", "", False),
            ("is_not_set_empty_list", "is_not_set", [], False),
            ("is_not_set_empty_dict", "is_not_set", {}, False),
        ]
    )
    def test_match_properties_presence_operator_with_present_key(
        self, _name, operator, value, expected
    ):
        prop = self.property(key="key", value=operator, operator=operator)
        self.assertEqual(expected, match_property(prop, {"key": value}))

    @parameterized.expand([("is_set", "is_set"), ("is_not_set", "is_not_set")])
    def test_match_properties_presence_operator_with_omitted_key(self, _name, operator):
        prop = self.property(key="key", value=operator, operator=operator)
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {})

    def test_match_properties_icontains(self):
        property_a = self.property(key="key", value="valUe", operator="icontains")
        self.assertTrue(match_property(property_a, {"key": "value"}))
        self.assertTrue(match_property(property_a, {"key": "value2"}))
        self.assertTrue(match_property(property_a, {"key": "value3"}))
        self.assertTrue(match_property(property_a, {"key": "vaLue4"}))
        self.assertTrue(match_property(property_a, {"key": "343tfvalue5"}))

        self.assertFalse(match_property(property_a, {"key": "Alakazam"}))
        self.assertFalse(match_property(property_a, {"key": 123}))

        property_b = self.property(key="key", value="3", operator="icontains")
        self.assertTrue(match_property(property_b, {"key": "3"}))
        self.assertTrue(match_property(property_b, {"key": 323}))
        self.assertTrue(match_property(property_b, {"key": "val3"}))

        self.assertFalse(match_property(property_b, {"key": "three"}))

    @parameterized.expand(
        [
            (
                "starts_with",
                "Val",
                ["value", "VALUE", "vaLue4"],
                ["prevalue", "Alakazam", 123],
            ),
            ("starts_with", "3", ["3", 323], [123, "val3"]),
            (
                "ends_with",
                "lUe",
                ["value", "VALUE", "343tfvalue"],
                ["value2", "Alakazam", 123],
            ),
            ("ends_with", "3", ["3", 323, 13], [321, "3val"]),
        ]
    )
    def test_match_properties_starts_with_and_ends_with(
        self, operator, flag_value, matching, non_matching
    ):
        prop = self.property(key="key", value=flag_value, operator=operator)
        for value in matching:
            self.assertTrue(match_property(prop, {"key": value}), value)
        for value in non_matching:
            self.assertFalse(match_property(prop, {"key": value}), value)

        # For non-None values, the negated operator is the exact inverse.
        negated = self.property(key="key", value=flag_value, operator=f"not_{operator}")
        for value in matching:
            self.assertFalse(match_property(negated, {"key": value}), value)
        for value in non_matching:
            self.assertTrue(match_property(negated, {"key": value}), value)

        # A missing key is inconclusive rather than a non-match.
        for missing_properties in ({"other_key": "value"}, {}):
            with self.assertRaises(InconclusiveMatchError):
                match_property(prop, missing_properties)

    @parameterized.expand(
        [
            ("icontains", "prefixÄsuffix"),
            ("starts_with", "Äsuffix"),
            ("ends_with", "prefixÄ"),
        ]
    )
    def test_string_operators_use_ascii_only_case_folding(self, operator, value):
        positive = self.property("key", "ä", operator)
        negative = self.property("key", "ä", f"not_{operator}")
        self.assertFalse(match_property(positive, {"key": value}))
        self.assertTrue(match_property(negative, {"key": value}))

    @parameterized.expand(
        [
            ("icontains_integral_float", "icontains", ".0", 323.0),
            ("starts_with_integral_float", "starts_with", "323", 323.0),
            ("ends_with_integral_float", "ends_with", ".0", 323.0),
            ("small_exponent", "ends_with", "e-7", 1e-7),
            ("fixed_small_decimal", "starts_with", "0.00001", 1e-5),
        ]
    )
    def test_string_operators_preserve_float_stringification(
        self, _name, operator, value, property_value
    ):
        prop = self.property("key", value, operator)
        self.assertTrue(match_property(prop, {"key": property_value}))

    def test_match_properties_regex(self):
        property_a = self.property(key="key", value=r"\.com$", operator="regex")
        self.assertTrue(match_property(property_a, {"key": "value.com"}))
        self.assertTrue(match_property(property_a, {"key": "value2.com"}))
        self.assertFalse(match_property(property_a, {"key": "value2com"}))

        self.assertFalse(match_property(property_a, {"key": ".com343tfvalue5"}))
        self.assertFalse(match_property(property_a, {"key": "Alakazam"}))
        self.assertFalse(match_property(property_a, {"key": 123}))
        self.assertFalse(match_property(property_a, {"key": "valuecom"}))
        self.assertFalse(match_property(property_a, {"key": r"value\com"}))

        property_b = self.property(key="key", value="3", operator="regex")
        self.assertTrue(match_property(property_b, {"key": "3"}))
        self.assertTrue(match_property(property_b, {"key": 323}))
        self.assertTrue(match_property(property_b, {"key": "val3"}))

        self.assertFalse(match_property(property_b, {"key": "three"}))

        # invalid regex
        property_c = self.property(key="key", value="?*", operator="regex")
        self.assertFalse(match_property(property_c, {"key": "value"}))
        self.assertFalse(match_property(property_c, {"key": "value2"}))

        # non string value
        property_d = self.property(key="key", value=4, operator="regex")
        self.assertTrue(match_property(property_d, {"key": "4"}))
        self.assertTrue(match_property(property_d, {"key": 4}))

        self.assertFalse(match_property(property_d, {"key": "value"}))

    def test_match_properties_math_operators(self):
        property_a = self.property(key="key", value=1, operator="gt")
        self.assertTrue(match_property(property_a, {"key": 2}))
        self.assertTrue(match_property(property_a, {"key": 3}))

        self.assertFalse(match_property(property_a, {"key": 0}))
        self.assertFalse(match_property(property_a, {"key": -1}))
        # now we handle type mismatches so this should be true
        self.assertTrue(match_property(property_a, {"key": "23"}))

        property_b = self.property(key="key", value=1, operator="lt")
        self.assertTrue(match_property(property_b, {"key": 0}))
        self.assertTrue(match_property(property_b, {"key": -1}))
        self.assertTrue(match_property(property_b, {"key": -3}))

        self.assertFalse(match_property(property_b, {"key": 1}))
        self.assertFalse(match_property(property_b, {"key": "1"}))
        self.assertFalse(match_property(property_b, {"key": "3"}))

        property_c = self.property(key="key", value=1, operator="gte")
        self.assertTrue(match_property(property_c, {"key": 1}))
        self.assertTrue(match_property(property_c, {"key": 2}))

        self.assertFalse(match_property(property_c, {"key": 0}))
        self.assertFalse(match_property(property_c, {"key": -1}))
        # now we handle type mismatches so this should be true
        self.assertTrue(match_property(property_c, {"key": "3"}))

        property_d = self.property(key="key", value="43", operator="lte")
        self.assertTrue(match_property(property_d, {"key": "41"}))
        self.assertTrue(match_property(property_d, {"key": "42"}))
        self.assertTrue(match_property(property_d, {"key": "43"}))

        self.assertFalse(match_property(property_d, {"key": "44"}))
        self.assertFalse(match_property(property_d, {"key": 44}))
        self.assertTrue(match_property(property_d, {"key": 42}))

        property_e = self.property(key="key", value="30", operator="lt")
        self.assertTrue(match_property(property_e, {"key": "29"}))

        # depending on the type of override, we adjust type comparison
        self.assertTrue(match_property(property_e, {"key": "100"}))
        self.assertFalse(match_property(property_e, {"key": 100}))

        property_f = self.property(key="key", value="123aloha", operator="gt")
        self.assertFalse(match_property(property_f, {"key": "123"}))
        self.assertFalse(match_property(property_f, {"key": 122}))

        # this turns into a string comparison
        self.assertTrue(match_property(property_f, {"key": 129}))

    def test_match_property_date_operators(self):
        property_a = self.property(
            key="key", value="2022-05-01", operator="is_date_before"
        )
        self.assertTrue(match_property(property_a, {"key": "2022-03-01"}))
        self.assertTrue(match_property(property_a, {"key": "2022-04-30"}))
        self.assertTrue(match_property(property_a, {"key": datetime.date(2022, 4, 30)}))
        self.assertTrue(
            match_property(property_a, {"key": datetime.datetime(2022, 4, 30, 1, 2, 3)})
        )
        self.assertTrue(
            match_property(
                property_a,
                {
                    "key": datetime.datetime(
                        2022,
                        4,
                        30,
                        1,
                        2,
                        3,
                        tzinfo=ZoneInfo("Europe/Madrid"),
                    )
                },
            )
        )
        self.assertTrue(
            match_property(
                property_a, {"key": datetime.datetime.fromisoformat("2022-04-30")}
            )
        )
        self.assertFalse(match_property(property_a, {"key": "2022-05-30"}))

        # Can't be a number
        with self.assertRaises(InconclusiveMatchError):
            match_property(property_a, {"key": 1})

        # can't be invalid string
        with self.assertRaises(InconclusiveMatchError):
            match_property(property_a, {"key": "abcdef"})

        property_b = self.property(
            key="key", value="2022-05-01", operator="is_date_after"
        )
        self.assertTrue(match_property(property_b, {"key": "2022-05-02"}))
        self.assertTrue(match_property(property_b, {"key": "2022-05-30"}))
        self.assertTrue(
            match_property(property_b, {"key": datetime.datetime(2022, 5, 30)})
        )
        self.assertTrue(
            match_property(
                property_b, {"key": datetime.datetime.fromisoformat("2022-05-30")}
            )
        )
        self.assertFalse(match_property(property_b, {"key": "2022-04-30"}))

        # can't be invalid string
        with self.assertRaises(InconclusiveMatchError):
            match_property(property_b, {"key": "abcdef"})

        # Invalid flag property
        property_c = self.property(key="key", value=1234, operator="is_date_before")

        with self.assertRaises(InconclusiveMatchError):
            match_property(property_c, {"key": 1})

        # Timezone aware property
        property_d = self.property(
            key="key", value="2022-04-05 12:34:12 +01:00", operator="is_date_before"
        )
        self.assertFalse(match_property(property_d, {"key": "2022-05-30"}))

        self.assertTrue(match_property(property_d, {"key": "2022-03-30"}))
        self.assertTrue(
            match_property(property_d, {"key": "2022-04-05 12:34:11 +01:00"})
        )
        self.assertTrue(
            match_property(property_d, {"key": "2022-04-05 12:34:11 +01:00"})
        )

        self.assertFalse(
            match_property(property_d, {"key": "2022-04-05 12:34:13 +01:00"})
        )

        self.assertTrue(
            match_property(property_d, {"key": "2022-04-05 11:34:11 +00:00"})
        )
        self.assertFalse(
            match_property(property_d, {"key": "2022-04-05 11:34:13 +00:00"})
        )

    @freeze_time("2022-05-01")
    def test_match_property_relative_date_operators(self):
        property_a = self.property(key="key", value="-6h", operator="is_date_before")
        self.assertTrue(match_property(property_a, {"key": "2022-03-01"}))
        self.assertTrue(match_property(property_a, {"key": "2022-04-30"}))
        self.assertTrue(
            match_property(property_a, {"key": datetime.datetime(2022, 4, 30, 1, 2, 3)})
        )
        # false because date comparison, instead of datetime, so reduces to same date
        self.assertFalse(
            match_property(property_a, {"key": datetime.date(2022, 4, 30)})
        )

        self.assertFalse(
            match_property(
                property_a, {"key": datetime.datetime(2022, 4, 30, 19, 2, 3)}
            )
        )
        self.assertTrue(
            match_property(
                property_a,
                {
                    "key": datetime.datetime(
                        2022,
                        4,
                        30,
                        1,
                        2,
                        3,
                        tzinfo=ZoneInfo("Europe/Madrid"),
                    )
                },
            )
        )
        self.assertTrue(
            match_property(
                property_a, {"key": datetime.datetime.fromisoformat("2022-04-30")}
            )
        )
        self.assertFalse(match_property(property_a, {"key": "2022-05-30"}))

        # Can't be a number
        with self.assertRaises(InconclusiveMatchError):
            match_property(property_a, {"key": 1})

        # can't be invalid string
        with self.assertRaises(InconclusiveMatchError):
            match_property(property_a, {"key": "abcdef"})

        property_b = self.property(key="key", value="1h", operator="is_date_after")
        self.assertTrue(match_property(property_b, {"key": "2022-05-02"}))
        self.assertTrue(match_property(property_b, {"key": "2022-05-30"}))
        self.assertTrue(
            match_property(property_b, {"key": datetime.datetime(2022, 5, 30)})
        )
        self.assertTrue(
            match_property(
                property_b, {"key": datetime.datetime.fromisoformat("2022-05-30")}
            )
        )
        self.assertFalse(match_property(property_b, {"key": "2022-04-30"}))

        # can't be invalid string
        with self.assertRaises(InconclusiveMatchError):
            self.assertFalse(match_property(property_b, {"key": "abcdef"}))

        # Invalid flag property
        property_c = self.property(key="key", value=1234, operator="is_date_after")

        with self.assertRaises(InconclusiveMatchError):
            self.assertFalse(match_property(property_c, {"key": 1}))

        # parsed as 1234-05-01 for some reason?
        self.assertTrue(match_property(property_c, {"key": "2022-05-30"}))

        # # Timezone aware property
        property_d = self.property(key="key", value="12d", operator="is_date_before")
        self.assertFalse(match_property(property_d, {"key": "2022-05-30"}))

        self.assertTrue(match_property(property_d, {"key": "2022-03-30"}))
        self.assertTrue(
            match_property(property_d, {"key": "2022-04-05 12:34:11+01:00"})
        )
        self.assertTrue(
            match_property(property_d, {"key": "2022-04-19 01:34:11+02:00"})
        )

        self.assertFalse(
            match_property(property_d, {"key": "2022-04-19 02:00:01+02:00"})
        )

        # Try all possible relative dates
        property_e = self.property(key="key", value="1h", operator="is_date_before")
        self.assertFalse(match_property(property_e, {"key": "2022-05-01 00:00:00"}))
        self.assertTrue(match_property(property_e, {"key": "2022-04-30 22:00:00"}))

        property_f = self.property(key="key", value="-1d", operator="is_date_before")
        self.assertTrue(match_property(property_f, {"key": "2022-04-29 23:59:00"}))
        self.assertFalse(match_property(property_f, {"key": "2022-04-30 00:00:01"}))

        property_g = self.property(key="key", value="1w", operator="is_date_before")
        self.assertTrue(match_property(property_g, {"key": "2022-04-23 00:00:00"}))
        self.assertFalse(match_property(property_g, {"key": "2022-04-24 00:00:00"}))
        self.assertFalse(match_property(property_g, {"key": "2022-04-24 00:00:01"}))

        property_h = self.property(key="key", value="1m", operator="is_date_before")
        self.assertTrue(match_property(property_h, {"key": "2022-03-01 00:00:00"}))
        self.assertFalse(match_property(property_h, {"key": "2022-04-05 00:00:00"}))

        property_i = self.property(key="key", value="1y", operator="is_date_before")
        self.assertTrue(match_property(property_i, {"key": "2021-04-28 00:00:00"}))
        self.assertFalse(match_property(property_i, {"key": "2021-05-01 00:00:01"}))

        property_j = self.property(key="key", value="122h", operator="is_date_after")
        self.assertTrue(match_property(property_j, {"key": "2022-05-01 00:00:00"}))
        self.assertFalse(match_property(property_j, {"key": "2022-04-23 01:00:00"}))

        property_k = self.property(key="key", value="2d", operator="is_date_after")
        self.assertTrue(match_property(property_k, {"key": "2022-05-01 00:00:00"}))
        self.assertTrue(match_property(property_k, {"key": "2022-04-29 00:00:01"}))
        self.assertFalse(match_property(property_k, {"key": "2022-04-29 00:00:00"}))

        property_l = self.property(key="key", value="-02w", operator="is_date_after")
        self.assertTrue(match_property(property_l, {"key": "2022-05-01 00:00:00"}))
        self.assertFalse(match_property(property_l, {"key": "2022-04-16 00:00:00"}))

        property_m = self.property(key="key", value="1m", operator="is_date_after")
        self.assertTrue(match_property(property_m, {"key": "2022-04-01 00:00:01"}))
        self.assertFalse(match_property(property_m, {"key": "2022-04-01 00:00:00"}))

        property_n = self.property(key="key", value="1y", operator="is_date_after")
        self.assertTrue(match_property(property_n, {"key": "2022-05-01 00:00:00"}))
        self.assertTrue(match_property(property_n, {"key": "2021-05-01 00:00:01"}))
        self.assertFalse(match_property(property_n, {"key": "2021-05-01 00:00:00"}))
        self.assertFalse(match_property(property_n, {"key": "2021-04-30 00:00:00"}))
        self.assertFalse(match_property(property_n, {"key": "2021-03-01 12:13:00"}))

    def test_none_property_value_with_all_operators(self):
        property_a = self.property(key="key", value="none", operator="is_not")
        self.assertTrue(match_property(property_a, {"key": None}))
        self.assertTrue(match_property(property_a, {"key": "non"}))

        exact_null = self.property(key="key", value="null", operator="exact")
        self.assertTrue(match_property(exact_null, {"key": None}))

        property_c = self.property(key="key", value="no", operator="icontains")
        self.assertFalse(match_property(property_c, {"key": None}))
        self.assertFalse(match_property(property_c, {"key": "smh"}))

        property_d = self.property(key="key", value="No", operator="regex")
        self.assertFalse(match_property(property_d, {"key": None}))

        property_d_lower_case = self.property(key="key", value="no", operator="regex")
        self.assertFalse(match_property(property_d_lower_case, {"key": None}))

        property_e = self.property(key="key", value=1, operator="gt")
        self.assertFalse(match_property(property_e, {"key": None}))

        property_f = self.property(key="key", value=1, operator="lt")
        self.assertFalse(match_property(property_f, {"key": None}))

        property_g = self.property(key="key", value="xyz", operator="gte")
        self.assertFalse(match_property(property_g, {"key": None}))

        property_h = self.property(key="key", value="Oo", operator="lte")
        self.assertFalse(match_property(property_h, {"key": None}))

        property_i = self.property(
            key="key", value="2022-05-01", operator="is_date_before"
        )
        self.assertFalse(match_property(property_i, {"key": None}))

        property_j = self.property(
            key="key", value="2022-05-01", operator="is_date_after"
        )
        self.assertFalse(match_property(property_j, {"key": None}))

        property_k = self.property(
            key="key", value="2022-05-01", operator="is_date_before"
        )
        with self.assertRaises(InconclusiveMatchError):
            self.assertFalse(match_property(property_k, {"key": "random"}))

    def test_match_properties_semver_eq(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_eq")
        self.assertTrue(match_property(prop, {"version": "1.2.3"}))
        self.assertFalse(match_property(prop, {"version": "1.2.4"}))
        self.assertFalse(match_property(prop, {"version": "1.2.2"}))
        self.assertFalse(match_property(prop, {"version": "2.0.0"}))

        # Pre-release suffix is stripped for comparison
        self.assertTrue(match_property(prop, {"version": "1.2.3-alpha.1"}))

        # Partial versions default missing parts to 0
        prop_partial = self.property(key="version", value="1.2", operator="semver_eq")
        self.assertTrue(match_property(prop_partial, {"version": "1.2.0"}))
        self.assertFalse(match_property(prop_partial, {"version": "1.2.1"}))

    def test_match_properties_semver_neq(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_neq")
        self.assertFalse(match_property(prop, {"version": "1.2.3"}))
        self.assertTrue(match_property(prop, {"version": "1.2.4"}))
        self.assertTrue(match_property(prop, {"version": "2.0.0"}))

    def test_match_properties_semver_gt(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_gt")
        self.assertTrue(match_property(prop, {"version": "1.2.4"}))
        self.assertTrue(match_property(prop, {"version": "1.3.0"}))
        self.assertTrue(match_property(prop, {"version": "2.0.0"}))
        self.assertFalse(match_property(prop, {"version": "1.2.3"}))
        self.assertFalse(match_property(prop, {"version": "1.2.2"}))
        self.assertFalse(match_property(prop, {"version": "0.9.0"}))

    def test_match_properties_semver_gte(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_gte")
        self.assertTrue(match_property(prop, {"version": "1.2.3"}))
        self.assertTrue(match_property(prop, {"version": "1.2.4"}))
        self.assertTrue(match_property(prop, {"version": "2.0.0"}))
        self.assertFalse(match_property(prop, {"version": "1.2.2"}))
        self.assertFalse(match_property(prop, {"version": "0.9.0"}))

    def test_match_properties_semver_lt(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_lt")
        self.assertTrue(match_property(prop, {"version": "1.2.2"}))
        self.assertTrue(match_property(prop, {"version": "1.1.0"}))
        self.assertTrue(match_property(prop, {"version": "0.9.0"}))
        self.assertFalse(match_property(prop, {"version": "1.2.3"}))
        self.assertFalse(match_property(prop, {"version": "1.2.4"}))
        self.assertFalse(match_property(prop, {"version": "2.0.0"}))

    def test_match_properties_semver_lte(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_lte")
        self.assertTrue(match_property(prop, {"version": "1.2.3"}))
        self.assertTrue(match_property(prop, {"version": "1.2.2"}))
        self.assertTrue(match_property(prop, {"version": "0.9.0"}))
        self.assertFalse(match_property(prop, {"version": "1.2.4"}))
        self.assertFalse(match_property(prop, {"version": "2.0.0"}))

    def test_match_properties_semver_tilde(self):
        # ~1.2.3 means >=1.2.3 <1.3.0
        prop = self.property(key="version", value="1.2.3", operator="semver_tilde")
        self.assertTrue(match_property(prop, {"version": "1.2.3"}))
        self.assertTrue(match_property(prop, {"version": "1.2.5"}))
        self.assertTrue(match_property(prop, {"version": "1.2.99"}))
        self.assertFalse(match_property(prop, {"version": "1.3.0"}))
        self.assertFalse(match_property(prop, {"version": "1.2.2"}))
        self.assertFalse(match_property(prop, {"version": "2.0.0"}))

    def test_match_properties_semver_caret(self):
        # ^1.2.3 means >=1.2.3 <2.0.0
        prop = self.property(key="version", value="1.2.3", operator="semver_caret")
        self.assertTrue(match_property(prop, {"version": "1.2.3"}))
        self.assertTrue(match_property(prop, {"version": "1.9.0"}))
        self.assertTrue(match_property(prop, {"version": "1.99.99"}))
        self.assertFalse(match_property(prop, {"version": "2.0.0"}))
        self.assertFalse(match_property(prop, {"version": "1.2.2"}))
        self.assertFalse(match_property(prop, {"version": "0.9.0"}))

        # ^0.2.3 means >=0.2.3 <0.3.0 (leftmost non-zero is minor)
        prop_zero_major = self.property(
            key="version", value="0.2.3", operator="semver_caret"
        )
        self.assertTrue(match_property(prop_zero_major, {"version": "0.2.3"}))
        self.assertTrue(match_property(prop_zero_major, {"version": "0.2.9"}))
        self.assertFalse(match_property(prop_zero_major, {"version": "0.3.0"}))
        self.assertFalse(match_property(prop_zero_major, {"version": "1.0.0"}))

        # ^0.0.3 means >=0.0.3 <0.0.4 (leftmost non-zero is patch)
        prop_zero_minor = self.property(
            key="version", value="0.0.3", operator="semver_caret"
        )
        self.assertTrue(match_property(prop_zero_minor, {"version": "0.0.3"}))
        self.assertFalse(match_property(prop_zero_minor, {"version": "0.0.4"}))
        self.assertFalse(match_property(prop_zero_minor, {"version": "0.1.0"}))

    def test_match_properties_semver_wildcard(self):
        # 1.2.* means >=1.2.0 <1.3.0
        prop = self.property(key="version", value="1.2.*", operator="semver_wildcard")
        self.assertTrue(match_property(prop, {"version": "1.2.0"}))
        self.assertTrue(match_property(prop, {"version": "1.2.5"}))
        self.assertTrue(match_property(prop, {"version": "1.2.99"}))
        self.assertFalse(match_property(prop, {"version": "1.3.0"}))
        self.assertFalse(match_property(prop, {"version": "1.1.9"}))
        self.assertFalse(match_property(prop, {"version": "2.0.0"}))

        # 1.* means >=1.0.0 <2.0.0
        prop_major = self.property(
            key="version", value="1.*", operator="semver_wildcard"
        )
        self.assertTrue(match_property(prop_major, {"version": "1.0.0"}))
        self.assertTrue(match_property(prop_major, {"version": "1.99.99"}))
        self.assertFalse(match_property(prop_major, {"version": "2.0.0"}))
        self.assertFalse(match_property(prop_major, {"version": "0.9.0"}))

    def test_match_properties_semver_with_prerelease(self):
        # Pre-release suffixes are stripped before comparison
        prop = self.property(key="version", value="1.2.3", operator="semver_gt")
        self.assertTrue(match_property(prop, {"version": "1.3.0-beta.1"}))
        self.assertFalse(match_property(prop, {"version": "1.2.2-rc.1"}))

        # Flag value can also have pre-release suffix
        prop_pre = self.property(
            key="version", value="1.2.3-alpha", operator="semver_gte"
        )
        self.assertTrue(match_property(prop_pre, {"version": "1.2.3"}))
        self.assertTrue(match_property(prop_pre, {"version": "2.0.0"}))
        self.assertFalse(match_property(prop_pre, {"version": "1.2.2"}))

    def test_match_properties_semver_edge_cases(self):
        """Test semver parsing handles v-prefix, whitespace, and other common formats."""
        prop = self.property(key="version", value="1.2.3", operator="semver_eq")

        # v-prefix: "v1.2.3" -> extracts "1.2.3"
        self.assertTrue(match_property(prop, {"version": "v1.2.3"}))

        # Leading space: " 1.2.3" -> extracts "1.2.3"
        self.assertTrue(match_property(prop, {"version": " 1.2.3"}))

        # Trailing space: "1.2.3 " -> extracts "1.2.3"
        self.assertTrue(match_property(prop, {"version": "1.2.3 "}))

        # Flag value with v-prefix
        prop_v = self.property(key="version", value="v1.2.3", operator="semver_eq")
        self.assertTrue(match_property(prop_v, {"version": "1.2.3"}))

        # 0.0.0 minimal version
        prop_min = self.property(key="version", value="0.0.0", operator="semver_eq")
        self.assertTrue(match_property(prop_min, {"version": "0.0.0"}))

        prop_gt_min = self.property(key="version", value="0.0.0", operator="semver_gt")
        self.assertTrue(match_property(prop_gt_min, {"version": "0.0.1"}))
        self.assertFalse(match_property(prop_gt_min, {"version": "0.0.0"}))

        # 4-part version: regex extracts "1.2.3.4" -> takes first 3 parts
        prop_four = self.property(key="version", value="1.2.3", operator="semver_eq")
        self.assertTrue(match_property(prop_four, {"version": "1.2.3.4"}))

        # Truly invalid values raise InconclusiveMatchError
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"version": "abc"})

        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"version": ""})

        # Leading dot: ".1.2.3" -> invalid, empty first component
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"version": ".1.2.3"})

        # Caret with v-prefix in flag value
        prop_caret_v = self.property(
            key="version", value="v1.2.3", operator="semver_caret"
        )
        self.assertTrue(match_property(prop_caret_v, {"version": "1.5.0"}))
        self.assertFalse(match_property(prop_caret_v, {"version": "2.0.0"}))

        # Wildcard with v-prefix in property value
        prop_wild = self.property(
            key="version", value="1.2.*", operator="semver_wildcard"
        )
        self.assertTrue(match_property(prop_wild, {"version": "v1.2.5"}))
        self.assertFalse(match_property(prop_wild, {"version": "v1.3.0"}))

    def test_match_properties_semver_invalid_values(self):
        prop = self.property(key="version", value="1.2.3", operator="semver_eq")

        # Invalid person property value
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"version": "not-a-version"})

        # Missing key
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"other_key": "1.2.3"})

        # None override value returns False (handled before semver logic)
        self.assertFalse(match_property(prop, {"version": None}))

        # Invalid flag value
        prop_bad = self.property(key="version", value="not-valid", operator="semver_gt")
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop_bad, {"version": "1.2.3"})

    # Semver 2.0.0 §2: numeric identifiers MUST NOT include leading zeros.
    @parameterized.expand(
        [
            ("major", "01.2.3"),
            ("minor", "1.02.3"),
            ("patch", "1.2.03"),
            ("all_components", "01.02.03"),
            ("two_digit_minor", "1.07.3"),
            ("triple_zero_major", "001.2.3"),
        ]
    )
    def test_match_properties_semver_rejects_leading_zero_override_value(
        self, _name, bad_value
    ):
        prop = self.property(key="version", value="1.2.3", operator="semver_eq")
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"version": bad_value})

    @parameterized.expand(
        [
            ("zero_major", "0.1.0"),
            ("zero_patch", "1.0.0"),
            ("all_zero", "0.0.0"),
        ]
    )
    def test_match_properties_semver_literal_zero_components_match(self, _name, value):
        prop = self.property(key="version", value=value, operator="semver_eq")
        self.assertTrue(match_property(prop, {"version": value}))

    @parameterized.expand(
        [
            ("semver_gt", "01.2.3"),
            ("semver_caret", "1.07.0"),
            ("semver_tilde", "1.07.0"),
            ("semver_wildcard", "01.*"),
        ]
    )
    def test_match_properties_semver_rejects_leading_zero_flag_value(
        self, operator, flag_value
    ):
        prop = self.property(key="version", value=flag_value, operator=operator)
        with self.assertRaises(InconclusiveMatchError):
            match_property(prop, {"version": "1.2.0"})

    def test_unknown_operator(self):
        property_a = self.property(key="key", value="2022-05-01", operator="is_unknown")
        with self.assertRaises(InconclusiveMatchError) as exception_context:
            match_property(property_a, {"key": "random"})
        self.assertEqual(
            str(exception_context.exception), "Unknown operator is_unknown"
        )


class TestDateParsing(unittest.TestCase):
    @parameterized.expand(
        [
            ("iso_date", "2022-05-01"),
            ("iso_datetime_Z", "2022-04-05T12:34:12Z"),
            ("iso_datetime_utc", "2022-04-05 12:34:12 UTC"),
            ("iso_datetime_offset", "2022-04-05 12:34:12 +01:00"),
        ]
    )
    def test_parse_datetime_matches_dateutil_for_supported_formats(self, _name, value):
        assert parse_datetime(value) == parser.parse(value)

    def test_parse_datetime_year_only_matches_previous_dateutil_behavior(self):
        with freeze_time("2020-04-03T00:00:00"):
            assert parse_datetime("1234") == parser.parse("1234")


class TestRelativeDateParsing(unittest.TestCase):
    def test_invalid_input(self):
        with freeze_time("2020-01-01T12:01:20.1340Z"):
            assert relative_date_parse_for_feature_flag_matching("1") is None
            assert relative_date_parse_for_feature_flag_matching("1x") is None
            assert relative_date_parse_for_feature_flag_matching("1.2y") is None
            assert relative_date_parse_for_feature_flag_matching("1z") is None
            assert relative_date_parse_for_feature_flag_matching("1s") is None
            assert (
                relative_date_parse_for_feature_flag_matching("123344000.134m") is None
            )
            assert relative_date_parse_for_feature_flag_matching("bazinga") is None
            assert relative_date_parse_for_feature_flag_matching("000bello") is None
            assert relative_date_parse_for_feature_flag_matching("000hello") is None

            assert relative_date_parse_for_feature_flag_matching("000h") is not None
            assert relative_date_parse_for_feature_flag_matching("1000h") is not None

    def test_overflow(self):
        assert relative_date_parse_for_feature_flag_matching("1000000h") is None
        assert relative_date_parse_for_feature_flag_matching("9999y") is None
        assert (
            relative_date_parse_for_feature_flag_matching("100000000000000000y") is None
        )

    def test_hour_parsing(self):
        with freeze_time("2020-01-01T12:01:20.1340Z"):
            assert relative_date_parse_for_feature_flag_matching(
                "1h"
            ) == datetime.datetime(
                2020, 1, 1, 11, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "2h"
            ) == datetime.datetime(
                2020, 1, 1, 10, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "24h"
            ) == datetime.datetime(
                2019, 12, 31, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "30h"
            ) == datetime.datetime(
                2019, 12, 31, 6, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "48h"
            ) == datetime.datetime(
                2019, 12, 30, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )

            assert relative_date_parse_for_feature_flag_matching(
                "24h"
            ) == relative_date_parse_for_feature_flag_matching("1d")
            assert relative_date_parse_for_feature_flag_matching(
                "48h"
            ) == relative_date_parse_for_feature_flag_matching("2d")

    def test_day_parsing(self):
        with freeze_time("2020-01-01T12:01:20.1340Z"):
            assert relative_date_parse_for_feature_flag_matching(
                "1d"
            ) == datetime.datetime(
                2019, 12, 31, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "2d"
            ) == datetime.datetime(
                2019, 12, 30, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "7d"
            ) == datetime.datetime(
                2019, 12, 25, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "14d"
            ) == datetime.datetime(
                2019, 12, 18, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "30d"
            ) == datetime.datetime(
                2019, 12, 2, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )

            assert relative_date_parse_for_feature_flag_matching(
                "7d"
            ) == relative_date_parse_for_feature_flag_matching("1w")

    def test_week_parsing(self):
        with freeze_time("2020-01-01T12:01:20.1340Z"):
            assert relative_date_parse_for_feature_flag_matching(
                "1w"
            ) == datetime.datetime(
                2019, 12, 25, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "2w"
            ) == datetime.datetime(
                2019, 12, 18, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "4w"
            ) == datetime.datetime(
                2019, 12, 4, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "8w"
            ) == datetime.datetime(
                2019, 11, 6, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )

            assert relative_date_parse_for_feature_flag_matching(
                "1m"
            ) == datetime.datetime(
                2019, 12, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "4w"
            ) != relative_date_parse_for_feature_flag_matching("1m")

    def test_month_parsing(self):
        with freeze_time("2020-01-01T12:01:20.1340Z"):
            assert relative_date_parse_for_feature_flag_matching(
                "1m"
            ) == datetime.datetime(
                2019, 12, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "2m"
            ) == datetime.datetime(
                2019, 11, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "4m"
            ) == datetime.datetime(
                2019, 9, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "8m"
            ) == datetime.datetime(
                2019, 5, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )

            assert relative_date_parse_for_feature_flag_matching(
                "1y"
            ) == datetime.datetime(
                2019, 1, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "12m"
            ) == relative_date_parse_for_feature_flag_matching("1y")

        with freeze_time("2020-04-03T00:00:00"):
            assert relative_date_parse_for_feature_flag_matching(
                "1m"
            ) == datetime.datetime(2020, 3, 3, 0, 0, 0, tzinfo=datetime.timezone.utc)
            assert relative_date_parse_for_feature_flag_matching(
                "2m"
            ) == datetime.datetime(2020, 2, 3, 0, 0, 0, tzinfo=datetime.timezone.utc)
            assert relative_date_parse_for_feature_flag_matching(
                "4m"
            ) == datetime.datetime(2019, 12, 3, 0, 0, 0, tzinfo=datetime.timezone.utc)
            assert relative_date_parse_for_feature_flag_matching(
                "8m"
            ) == datetime.datetime(2019, 8, 3, 0, 0, 0, tzinfo=datetime.timezone.utc)

            assert relative_date_parse_for_feature_flag_matching(
                "1y"
            ) == datetime.datetime(2019, 4, 3, 0, 0, 0, tzinfo=datetime.timezone.utc)
            assert relative_date_parse_for_feature_flag_matching(
                "12m"
            ) == relative_date_parse_for_feature_flag_matching("1y")

    def test_month_parsing_clamps_to_target_month_end(self):
        for value in ("2020-03-31T00:00:00Z", "2021-03-31T00:00:00Z"):
            with freeze_time(value):
                now = datetime.datetime.now(datetime.timezone.utc)
                assert relative_date_parse_for_feature_flag_matching(
                    "1m"
                ) == now - relativedelta(months=1)

    def test_year_parsing_clamps_to_target_month_end(self):
        with freeze_time("2020-02-29T00:00:00Z"):
            now = datetime.datetime.now(datetime.timezone.utc)
            assert relative_date_parse_for_feature_flag_matching(
                "1y"
            ) == now - relativedelta(years=1)

    def test_year_parsing(self):
        with freeze_time("2020-01-01T12:01:20.1340Z"):
            assert relative_date_parse_for_feature_flag_matching(
                "1y"
            ) == datetime.datetime(
                2019, 1, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "2y"
            ) == datetime.datetime(
                2018, 1, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "4y"
            ) == datetime.datetime(
                2016, 1, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )
            assert relative_date_parse_for_feature_flag_matching(
                "8y"
            ) == datetime.datetime(
                2012, 1, 1, 12, 1, 20, 134000, tzinfo=datetime.timezone.utc
            )


class TestCaptureCalls(unittest.TestCase):
    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_capture_is_called(self, patch_flags, patch_capture):
        patch_flags.return_value = {"featureFlags": {"flags-flag": "flags-value"}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "complex-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "region", "value": "USA"}],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        self.assertTrue(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id",
                person_properties={"region": "USA", "name": "Aloha"},
            )
        )
        self.assertEqual(patch_capture.call_count, 1)
        patch_capture.assert_called_with(
            "$feature_flag_called",
            distinct_id="some-distinct-id",
            properties={
                "$feature_flag": "complex-flag",
                "$feature_flag_response": True,
                "locally_evaluated": True,
                "$feature/complex-flag": True,
            },
            groups={},
            disable_geoip=None,
        )
        patch_capture.reset_mock()

        # called again for same user, shouldn't call capture again
        self.assertTrue(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id",
                person_properties={"region": "USA", "name": "Aloha"},
            )
        )
        self.assertEqual(patch_capture.call_count, 0)
        patch_capture.reset_mock()

        # called for different user, should call capture again
        self.assertTrue(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id2",
                person_properties={"region": "USA", "name": "Aloha"},
            )
        )
        self.assertEqual(patch_capture.call_count, 1)
        patch_capture.assert_called_with(
            "$feature_flag_called",
            distinct_id="some-distinct-id2",
            properties={
                "$feature_flag": "complex-flag",
                "$feature_flag_response": True,
                "locally_evaluated": True,
                "$feature/complex-flag": True,
            },
            groups={},
            disable_geoip=None,
        )
        patch_capture.reset_mock()

        # called for different user, but send configuration is false, so should NOT call capture again
        self.assertTrue(
            client.get_feature_flag(
                "complex-flag",
                "some-distinct-id345",
                person_properties={"region": "USA", "name": "Aloha"},
                send_feature_flag_events=False,
            )
        )
        self.assertEqual(patch_capture.call_count, 0)
        patch_capture.reset_mock()

        # called for different flag, falls back to /flags, should call capture again
        self.assertEqual(
            client.get_feature_flag(
                "flags-flag",
                "some-distinct-id2",
                person_properties={"region": "USA", "name": "Aloha"},
                groups={"organization": "org1"},
            ),
            "flags-value",
        )
        self.assertEqual(patch_flags.call_count, 1)
        self.assertEqual(patch_capture.call_count, 1)
        patch_capture.assert_called_with(
            "$feature_flag_called",
            distinct_id="some-distinct-id2",
            properties={
                "$feature_flag": "flags-flag",
                "$feature_flag_response": "flags-value",
                "locally_evaluated": False,
                "$feature/flags-flag": "flags-value",
            },
            groups={"organization": "org1"},
            disable_geoip=None,
        )

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_capture_is_called_with_flag_details(self, patch_flags, patch_capture):
        patch_flags.return_value = {
            "flags": {
                "flags-flag": {
                    "key": "flags-flag",
                    "enabled": True,
                    "variant": "flags-variant",
                    "reason": {
                        "description": "Matched condition set 1",
                    },
                    "metadata": {
                        "id": 23,
                        "version": 42,
                    },
                },
                "false-flag": {
                    "key": "false-flag",
                    "enabled": False,
                    "variant": None,
                    "reason": {
                        "code": "no_matching_condition",
                        "description": "No matching condition",
                        "condition_index": None,
                    },
                    "metadata": {
                        "id": 1,
                        "version": 2,
                    },
                },
            },
            "requestId": "18043bf7-9cf6-44cd-b959-9662ee20d371",
            "evaluatedAt": 1234567890,
        }
        client = Client(FAKE_TEST_API_KEY)

        self.assertEqual(
            client.get_feature_flag("flags-flag", "some-distinct-id"), "flags-variant"
        )
        self.assertEqual(patch_capture.call_count, 1)
        patch_capture.assert_called_with(
            "$feature_flag_called",
            distinct_id="some-distinct-id",
            properties={
                "$feature_flag": "flags-flag",
                "$feature_flag_response": "flags-variant",
                "locally_evaluated": False,
                "$feature/flags-flag": "flags-variant",
                "$feature_flag_reason": "Matched condition set 1",
                "$feature_flag_id": 23,
                "$feature_flag_version": 42,
                "$feature_flag_request_id": "18043bf7-9cf6-44cd-b959-9662ee20d371",
                "$feature_flag_evaluated_at": 1234567890,
            },
            groups={},
            disable_geoip=None,
        )

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_capture_is_called_with_flag_details_and_payload(
        self, patch_flags, patch_capture
    ):
        patch_flags.return_value = {
            "flags": {
                "flags-flag-with-payload": {
                    "key": "flags-flag-with-payload",
                    "enabled": True,
                    "variant": None,
                    "reason": {
                        "code": "matched_condition",
                        "condition_index": 0,
                        "description": "Matched condition set 1",
                    },
                    "metadata": {
                        "id": 23,
                        "version": 42,
                        "payload": '{"foo": "bar"}',
                    },
                }
            },
            "requestId": "18043bf7-9cf6-44cd-b959-9662ee20d371",
        }
        client = Client(FAKE_TEST_API_KEY)

        self.assertEqual(
            client.get_feature_flag_payload(
                "flags-flag-with-payload",
                "some-distinct-id",
                send_feature_flag_events=True,
            ),
            {"foo": "bar"},
        )
        self.assertEqual(patch_capture.call_count, 1)
        patch_capture.assert_called_with(
            "$feature_flag_called",
            distinct_id="some-distinct-id",
            properties={
                "$feature_flag": "flags-flag-with-payload",
                "$feature_flag_response": True,
                "locally_evaluated": False,
                "$feature/flags-flag-with-payload": True,
                "$feature_flag_reason": "Matched condition set 1",
                "$feature_flag_id": 23,
                "$feature_flag_version": 42,
                "$feature_flag_request_id": "18043bf7-9cf6-44cd-b959-9662ee20d371",
                "$feature_flag_payload": {"foo": "bar"},
            },
            groups={},
            disable_geoip=None,
        )

    @mock.patch("posthog.client.flags")
    def test_capture_is_called_but_does_not_add_all_flags(self, patch_flags):
        patch_flags.return_value = {"featureFlags": {"flags-flag": "flags-value"}}
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "complex-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "region", "value": "USA"}],
                            "rollout_percentage": 100,
                        },
                    ],
                },
            },
            {
                "id": 2,
                "name": "Gamma Feature",
                "key": "simple-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        },
                    ],
                },
            },
        ]

        self.assertTrue(
            client.get_feature_flag(
                "complex-flag", "some-distinct-id", person_properties={"region": "USA"}
            )
        )

        # Grab the capture message that was just added to the queue
        msg = client.queue.get(block=False)
        assert msg["event"] == "$feature_flag_called"
        assert msg["properties"]["$feature_flag"] == "complex-flag"
        assert msg["properties"]["$feature_flag_response"] is True
        assert msg["properties"]["locally_evaluated"] is True
        assert msg["properties"]["$feature/complex-flag"] is True
        assert "$feature/simple-flag" not in msg["properties"]
        assert "$active_feature_flags" not in msg["properties"]

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_get_feature_flag_payload_does_not_send_feature_flag_called_events(
        self, patch_flags, patch_capture
    ):
        """Test that get_feature_flag_payload does NOT send $feature_flag_called events"""
        patch_flags.return_value = {
            "featureFlags": {"person-flag": True},
            "featureFlagPayloads": {"person-flag": 300},
        }
        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "person-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "region", "value": "USA"}],
                            "rollout_percentage": 100,
                        }
                    ],
                    "payloads": {"true": '"payload"'},
                },
            }
        ]

        payload = client.get_feature_flag_payload(
            key="person-flag",
            distinct_id="some-distinct-id",
            person_properties={"region": "USA", "name": "Aloha"},
        )
        self.assertIsNotNone(payload)
        self.assertEqual(patch_capture.call_count, 0)

    @mock.patch("posthog.client.flags")
    def test_fallback_to_api_in_get_feature_flag_payload_when_flag_has_static_cohort(
        self, patch_flags
    ):
        """
        Test that get_feature_flag_payload falls back to API when evaluating
        a flag with static cohorts, similar to get_feature_flag behavior.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # Mock the local flags response - cohort 999 is NOT in cohorts map (static cohort)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Multi-condition Flag",
                "key": "multi-condition-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [
                                {"key": "id", "value": 999, "type": "cohort"}
                            ],
                            "rollout_percentage": 100,
                            "variant": "variant-1",
                        }
                    ],
                    "multivariate": {
                        "variants": [{"key": "variant-1", "rollout_percentage": 100}]
                    },
                    "payloads": {"variant-1": '{"message": "local-payload"}'},
                },
            }
        ]
        client.cohorts = {}  # Note: cohort 999 is NOT here - it's a static cohort

        # Mock the API response - user is in the static cohort
        patch_flags.return_value = {
            "featureFlags": {"multi-condition-flag": "variant-1"},
            "featureFlagPayloads": {"multi-condition-flag": '{"message": "from-api"}'},
        }

        # Call get_feature_flag_payload without match_value to trigger evaluation
        result = client.get_feature_flag_payload(
            "multi-condition-flag",
            "test-distinct-id",
        )

        # Should return the API payload, not local payload
        self.assertEqual(result, {"message": "from-api"})

        # Verify API was called (fallback occurred)
        self.assertEqual(patch_flags.call_count, 1)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_disable_geoip_get_flag_capture_call(self, patch_flags, patch_capture):
        patch_flags.return_value = {"featureFlags": {"flags-flag": "flags-value"}}
        client = Client(
            FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY, disable_geoip=True
        )
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "complex-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [{"key": "region", "value": "USA"}],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        client.get_feature_flag(
            "complex-flag",
            "some-distinct-id",
            person_properties={"region": "USA", "name": "Aloha"},
            disable_geoip=False,
        )

        patch_capture.assert_called_with(
            "$feature_flag_called",
            distinct_id="some-distinct-id",
            properties={
                "$feature_flag": "complex-flag",
                "$feature_flag_response": True,
                "locally_evaluated": True,
                "$feature/complex-flag": True,
            },
            groups={},
            disable_geoip=False,
        )

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_capture_fires_per_group_context(self, patch_flags, patch_capture):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Group flag",
                "key": "group-scoped-flag",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            }
        ]

        # Same user, same flag, same response — but two different group contexts.
        client.get_feature_flag(
            "group-scoped-flag", "user-1", groups={"company": "org-a"}
        )
        client.get_feature_flag(
            "group-scoped-flag", "user-1", groups={"company": "org-b"}
        )

        flag_called_groups = [
            call.kwargs.get("groups")
            for call in patch_capture.call_args_list
            if call.args and call.args[0] == "$feature_flag_called"
        ]
        self.assertEqual(len(flag_called_groups), 2)
        self.assertIn({"company": "org-a"}, flag_called_groups)
        self.assertIn({"company": "org-b"}, flag_called_groups)

    @parameterized.expand(
        [
            (
                "same_context",
                {"company": "org-a"},
                {"company": "org-a"},
            ),
            (
                "different_key_order",
                {"company": "org-a", "team": "red"},
                {"team": "red", "company": "org-a"},
            ),
        ]
    )
    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_capture_dedupes_repeated_calls_under_same_group_context(
        self, _name, first_groups, second_groups, patch_flags, patch_capture
    ):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "name": "Group flag",
                "key": "group-scoped-flag",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            }
        ]

        client.get_feature_flag("group-scoped-flag", "user-1", groups=first_groups)
        client.get_feature_flag("group-scoped-flag", "user-1", groups=second_groups)

        flag_called_count = sum(
            1
            for call in patch_capture.call_args_list
            if call.args and call.args[0] == "$feature_flag_called"
        )
        self.assertEqual(flag_called_count, 1)

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_capture_multiple_users_doesnt_out_of_memory(
        self, patch_flags, patch_capture
    ):
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        # Set on the instance to avoid relying on module-constant patching behavior
        # across Python/runtime implementations.
        client.distinct_ids_feature_flags_reported.max_size = 100
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "complex-flag",
                "active": True,
                "filters": {
                    "groups": [
                        {
                            "properties": [],
                            "rollout_percentage": 100,
                        }
                    ],
                },
            }
        ]

        with pytest.warns(DeprecationWarning, match="get_feature_flag.*deprecated"):
            for i in range(1000):
                distinct_id = f"some-distinct-id{i}"
                client.get_feature_flag(
                    "complex-flag",
                    distinct_id,
                    person_properties={"region": "USA", "name": "Aloha"},
                )
                patch_capture.assert_called_with(
                    "$feature_flag_called",
                    distinct_id=distinct_id,
                    properties={
                        "$feature_flag": "complex-flag",
                        "$feature_flag_response": True,
                        "locally_evaluated": True,
                        "$feature/complex-flag": True,
                    },
                    groups={},
                    disable_geoip=None,
                )

                self.assertEqual(
                    len(client.distinct_ids_feature_flags_reported), min(i + 1, 100)
                )

    @mock.patch.object(Client, "capture")
    @mock.patch("posthog.client.flags")
    def test_flag_called_dedupe_survives_tracker_capacity_pressure(
        self, patch_flags, patch_capture
    ):
        """Hitting the tracker's capacity must not re-open dedupe for every user.

        Evicting only the oldest entry keeps the still-tracked users deduped; clearing
        the whole tracker would make each of them emit a duplicate
        `$feature_flag_called` on their next read.
        """
        client = Client(FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.distinct_ids_feature_flags_reported.max_size = 3
        client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "complex-flag",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            }
        ]

        def flag_called_count_for(distinct_id):
            return sum(
                1
                for call in patch_capture.call_args_list
                if call.args
                and call.args[0] == "$feature_flag_called"
                and call.kwargs.get("distinct_id") == distinct_id
            )

        # Fill the tracker, then push one more user through to force an eviction.
        for i in range(4):
            client.get_feature_flag_result("complex-flag", f"user-{i}")

        self.assertEqual(len(client.distinct_ids_feature_flags_reported), 3)
        self.assertNotIn("user-0", client.distinct_ids_feature_flags_reported)

        # Users still in the tracker stay deduped across the eviction.
        for i in range(1, 4):
            client.get_feature_flag_result("complex-flag", f"user-{i}")
            self.assertEqual(flag_called_count_for(f"user-{i}"), 1)

        # The evicted user is treated as unseen again, which is the expected cost.
        client.get_feature_flag_result("complex-flag", "user-0")
        self.assertEqual(flag_called_count_for("user-0"), 2)


class TestConsistency(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # This ensures no real HTTP POST requests are made
        cls.capture_patch = mock.patch.object(Client, "capture")
        cls.capture_patch.start()

    @classmethod
    def tearDownClass(cls):
        cls.capture_patch.stop()

    def set_fail(self, e, batch):
        """Mark the failure handler"""
        print("FAIL", e, batch)  # noqa: T201
        self.failed = True

    def setUp(self):
        self.failed = False
        self.client = Client(FAKE_TEST_API_KEY, on_error=self.set_fail)
        # Reset the process-wide malformed-dependency warning dedup set so tests
        # asserting on the warning stay order-independent.
        posthog.feature_flags._warned_malformed_flag_dependencies.clear()

    @mock.patch("posthog.client.get")
    def test_simple_flag_consistency(self, patch_get):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "simple-flag",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 45}],
                },
            }
        ]

        results = [
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            True,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            True,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            False,
            False,
            True,
            True,
            False,
            True,
            True,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            False,
            False,
            False,
            False,
            True,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
            False,
            False,
            True,
            True,
            True,
            False,
            True,
            False,
            False,
            True,
            True,
            False,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            False,
            True,
            True,
            True,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            True,
            False,
            False,
            True,
            False,
            False,
            True,
            False,
            True,
            True,
        ]

        with pytest.warns(DeprecationWarning, match="feature_enabled.*deprecated"):
            for i in range(1000):
                distinctID = f"distinct_id_{i}"

                feature_flag_match = self.client.feature_enabled(
                    "simple-flag", distinctID
                )

                if results[i]:
                    self.assertTrue(feature_flag_match)
                else:
                    self.assertFalse(feature_flag_match)

    @mock.patch("posthog.client.get")
    def test_multivariate_flag_consistency(self, patch_get):
        self.client.feature_flags = [
            {
                "id": 1,
                "name": "Beta Feature",
                "key": "multivariate-flag",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 55}],
                    "multivariate": {
                        "variants": [
                            {
                                "key": "first-variant",
                                "name": "First Variant",
                                "rollout_percentage": 50,
                            },
                            {
                                "key": "second-variant",
                                "name": "Second Variant",
                                "rollout_percentage": 20,
                            },
                            {
                                "key": "third-variant",
                                "name": "Third Variant",
                                "rollout_percentage": 20,
                            },
                            {
                                "key": "fourth-variant",
                                "name": "Fourth Variant",
                                "rollout_percentage": 5,
                            },
                            {
                                "key": "fifth-variant",
                                "name": "Fifth Variant",
                                "rollout_percentage": 5,
                            },
                        ],
                    },
                },
            }
        ]

        results = [
            "second-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            "second-variant",
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "third-variant",
            False,
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            "fourth-variant",
            "first-variant",
            False,
            "third-variant",
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            False,
            "third-variant",
            "second-variant",
            "first-variant",
            False,
            "third-variant",
            False,
            False,
            "first-variant",
            "second-variant",
            False,
            "first-variant",
            "first-variant",
            "second-variant",
            False,
            "first-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            "second-variant",
            "second-variant",
            "third-variant",
            "second-variant",
            "first-variant",
            False,
            "first-variant",
            "second-variant",
            "fourth-variant",
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "second-variant",
            False,
            "third-variant",
            False,
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "fifth-variant",
            False,
            "second-variant",
            "first-variant",
            "second-variant",
            False,
            "third-variant",
            "third-variant",
            False,
            False,
            False,
            False,
            "third-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            "third-variant",
            "third-variant",
            False,
            "third-variant",
            "second-variant",
            "third-variant",
            False,
            False,
            "second-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            False,
            "second-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            "second-variant",
            "second-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            "third-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            "fifth-variant",
            "second-variant",
            False,
            "second-variant",
            False,
            "first-variant",
            "third-variant",
            "first-variant",
            "fifth-variant",
            "third-variant",
            False,
            False,
            "fourth-variant",
            False,
            False,
            False,
            False,
            "third-variant",
            False,
            False,
            "third-variant",
            False,
            "first-variant",
            "second-variant",
            "second-variant",
            "second-variant",
            False,
            "first-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            False,
            False,
            False,
            "second-variant",
            False,
            False,
            "first-variant",
            False,
            "first-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            "first-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            "third-variant",
            "third-variant",
            False,
            "second-variant",
            "first-variant",
            False,
            "second-variant",
            "first-variant",
            False,
            "first-variant",
            False,
            False,
            "first-variant",
            "fifth-variant",
            "first-variant",
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "second-variant",
            False,
            "second-variant",
            "third-variant",
            "third-variant",
            False,
            "first-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            "third-variant",
            "first-variant",
            False,
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "second-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            False,
            "second-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            "third-variant",
            False,
            "first-variant",
            False,
            "third-variant",
            False,
            "third-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            "third-variant",
            "first-variant",
            "second-variant",
            "fifth-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            "third-variant",
            False,
            "second-variant",
            "first-variant",
            False,
            False,
            False,
            False,
            "third-variant",
            False,
            False,
            "third-variant",
            False,
            False,
            "first-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            "fourth-variant",
            "fourth-variant",
            "third-variant",
            "second-variant",
            "first-variant",
            "third-variant",
            "fifth-variant",
            False,
            "first-variant",
            "fifth-variant",
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "second-variant",
            "fifth-variant",
            "second-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            False,
            False,
            "third-variant",
            False,
            "second-variant",
            "fifth-variant",
            False,
            "third-variant",
            "first-variant",
            False,
            False,
            "fourth-variant",
            False,
            False,
            "second-variant",
            False,
            False,
            "first-variant",
            "fourth-variant",
            "first-variant",
            "second-variant",
            False,
            False,
            False,
            "first-variant",
            "third-variant",
            "third-variant",
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            False,
            "first-variant",
            "third-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            "second-variant",
            "second-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "fifth-variant",
            "first-variant",
            False,
            False,
            False,
            "second-variant",
            "third-variant",
            "first-variant",
            "fourth-variant",
            "first-variant",
            "third-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            "third-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            False,
            "fourth-variant",
            "fifth-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            "first-variant",
            "second-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            False,
            "first-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            "third-variant",
            "third-variant",
            "first-variant",
            False,
            False,
            "second-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "second-variant",
            "first-variant",
            False,
            "first-variant",
            "third-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "third-variant",
            "third-variant",
            False,
            False,
            False,
            False,
            "third-variant",
            "fourth-variant",
            "fourth-variant",
            "first-variant",
            "second-variant",
            False,
            "first-variant",
            False,
            "second-variant",
            "first-variant",
            "third-variant",
            False,
            "third-variant",
            False,
            "first-variant",
            "first-variant",
            "third-variant",
            False,
            False,
            False,
            "fourth-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            "fourth-variant",
            False,
            "first-variant",
            "third-variant",
            "first-variant",
            False,
            False,
            "third-variant",
            False,
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            "third-variant",
            "second-variant",
            "fourth-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            "second-variant",
            "first-variant",
            "second-variant",
            False,
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            "second-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "third-variant",
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            "fifth-variant",
            "fourth-variant",
            "first-variant",
            "second-variant",
            False,
            "fourth-variant",
            False,
            False,
            False,
            "fourth-variant",
            False,
            False,
            "third-variant",
            False,
            False,
            False,
            "first-variant",
            "third-variant",
            "third-variant",
            "second-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            "second-variant",
            False,
            False,
            "first-variant",
            False,
            "second-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            "second-variant",
            False,
            False,
            "fifth-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "second-variant",
            "third-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            "third-variant",
            "first-variant",
            False,
            False,
            False,
            False,
            "fourth-variant",
            "first-variant",
            False,
            False,
            False,
            "third-variant",
            False,
            False,
            "second-variant",
            "first-variant",
            False,
            False,
            "second-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            False,
            "second-variant",
            "third-variant",
            "second-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            "first-variant",
            False,
            "second-variant",
            False,
            False,
            False,
            False,
            "first-variant",
            False,
            "third-variant",
            False,
            "first-variant",
            False,
            False,
            "second-variant",
            "third-variant",
            "second-variant",
            "fourth-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            False,
            "second-variant",
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            False,
            "second-variant",
            False,
            False,
            False,
            False,
            "second-variant",
            False,
            "first-variant",
            False,
            "third-variant",
            False,
            False,
            "first-variant",
            "third-variant",
            False,
            "third-variant",
            False,
            False,
            "second-variant",
            False,
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            "second-variant",
            False,
            False,
            "first-variant",
            "third-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "second-variant",
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "fifth-variant",
            False,
            False,
            False,
            "first-variant",
            False,
            "third-variant",
            False,
            False,
            "second-variant",
            False,
            False,
            False,
            False,
            False,
            "fourth-variant",
            "second-variant",
            "first-variant",
            "second-variant",
            False,
            "second-variant",
            False,
            "second-variant",
            False,
            "first-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            "second-variant",
            False,
            "first-variant",
            False,
            "fifth-variant",
            False,
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            False,
            "first-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            False,
            "fifth-variant",
            False,
            False,
            "third-variant",
            False,
            "third-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            "third-variant",
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            "second-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            "fifth-variant",
            "first-variant",
            False,
            False,
            "fourth-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            "fourth-variant",
            "first-variant",
            False,
            "second-variant",
            "third-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "third-variant",
            "third-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            "second-variant",
            False,
            False,
            "second-variant",
            False,
            "third-variant",
            "first-variant",
            "second-variant",
            "fifth-variant",
            "first-variant",
            "first-variant",
            False,
            "first-variant",
            "fifth-variant",
            False,
            False,
            False,
            "third-variant",
            "first-variant",
            "first-variant",
            "second-variant",
            "fourth-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            False,
            False,
            False,
            "second-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            "third-variant",
            False,
            "first-variant",
            False,
            "third-variant",
            "third-variant",
            "first-variant",
            "first-variant",
            False,
            "second-variant",
            False,
            "second-variant",
            "first-variant",
            False,
            False,
            False,
            "second-variant",
            False,
            "third-variant",
            False,
            "first-variant",
            "fifth-variant",
            "first-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "fourth-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "fifth-variant",
            False,
            False,
            False,
            "second-variant",
            False,
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            "second-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            "third-variant",
            "first-variant",
            False,
            "second-variant",
            False,
            False,
            "third-variant",
            "second-variant",
            "third-variant",
            False,
            "first-variant",
            "third-variant",
            "second-variant",
            "first-variant",
            "third-variant",
            False,
            False,
            "first-variant",
            "first-variant",
            False,
            False,
            False,
            "first-variant",
            "third-variant",
            "second-variant",
            "first-variant",
            "first-variant",
            "first-variant",
            False,
            "third-variant",
            "second-variant",
            "third-variant",
            False,
            False,
            "third-variant",
            "first-variant",
            False,
            "first-variant",
        ]

        with pytest.warns(DeprecationWarning, match="get_feature_flag.*deprecated"):
            for i in range(1000):
                distinctID = f"distinct_id_{i}"
                feature_flag_match = self.client.get_feature_flag(
                    "multivariate-flag", distinctID
                )

                if results[i]:
                    self.assertEqual(feature_flag_match, results[i])
                else:
                    self.assertFalse(feature_flag_match)

    @mock.patch("posthog.client.flags")
    def test_feature_flag_case_sensitive(self, mock_flags):
        mock_flags.return_value = {
            "featureFlags": {}
        }  # Ensure /flags returns empty flags

        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "key": "Beta-Feature",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                },
            }
        ]

        # Test that flag evaluation is case-sensitive
        self.assertTrue(client.feature_enabled("Beta-Feature", "user1"))
        self.assertFalse(client.feature_enabled("beta-feature", "user1"))
        self.assertFalse(client.feature_enabled("BETA-FEATURE", "user1"))

    @mock.patch("posthog.client.flags")
    def test_feature_flag_payload_case_sensitive(self, mock_flags):
        mock_flags.return_value = {
            "featureFlags": {"Beta-Feature": True},
            "featureFlagPayloads": {"Beta-Feature": {"some": "value"}},
        }

        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "key": "Beta-Feature",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                    "payloads": {
                        "true": {"some": "value"},
                    },
                },
            }
        ]

        # Test that payload retrieval is case-sensitive
        self.assertEqual(
            client.get_feature_flag_payload("Beta-Feature", "user1"), {"some": "value"}
        )
        self.assertIsNone(client.get_feature_flag_payload("beta-feature", "user1"))
        self.assertIsNone(client.get_feature_flag_payload("BETA-FEATURE", "user1"))

    @mock.patch("posthog.client.flags")
    def test_feature_flag_case_sensitive_consistency(self, mock_flags):
        mock_flags.return_value = {
            "featureFlags": {"Beta-Feature": True},
            "featureFlagPayloads": {"Beta-Feature": {"some": "value"}},
        }

        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)
        client.feature_flags = [
            {
                "id": 1,
                "key": "Beta-Feature",
                "active": True,
                "filters": {
                    "groups": [{"properties": [], "rollout_percentage": 100}],
                    "payloads": {
                        "true": {"some": "value"},
                    },
                },
            }
        ]

        # Test that flag evaluation and payload retrieval are consistently case-sensitive
        # Only exact match should work
        self.assertTrue(client.feature_enabled("Beta-Feature", "user1"))
        self.assertEqual(
            client.get_feature_flag_payload("Beta-Feature", "user1"), {"some": "value"}
        )

        # Different cases should not match
        test_cases = ["beta-feature", "BETA-FEATURE", "bEtA-FeAtUrE"]
        for case in test_cases:
            self.assertFalse(client.feature_enabled(case, "user1"))

    @mock.patch("posthog.client.flags")
    def test_get_all_flags_with_flag_keys_to_evaluate(self, mock_flags):
        """Test that get_all_flags with flag_keys_to_evaluate only evaluates specified flags"""
        mock_flags.return_value = {
            "featureFlags": {
                "flag1": "value1",
                "flag2": True,
            }
        }

        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # Call get_all_flags with flag_keys_to_evaluate
        result = client.get_all_flags(
            "user123",
            flag_keys_to_evaluate=["flag1", "flag2"],
            person_properties={"region": "USA"},
        )

        # Verify flags() was called with flag_keys_to_evaluate
        mock_flags.assert_called_once()
        call_args = mock_flags.call_args[1]
        self.assertEqual(call_args["flag_keys_to_evaluate"], ["flag1", "flag2"])
        self.assertEqual(call_args["person_properties"], {"region": "USA"})

        # Check the result
        self.assertEqual(result, {"flag1": "value1", "flag2": True})

    @mock.patch("posthog.client.flags")
    def test_get_all_flags_and_payloads_with_flag_keys_to_evaluate(self, mock_flags):
        """Test that get_all_flags_and_payloads with flag_keys_to_evaluate only evaluates specified flags"""
        mock_flags.return_value = {
            "featureFlags": {
                "flag1": "variant1",
                "flag3": True,
            },
            "featureFlagPayloads": {
                "flag1": {"data": "payload1"},
                "flag3": {"data": "payload3"},
            },
        }

        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # Call get_all_flags_and_payloads with flag_keys_to_evaluate
        result = client.get_all_flags_and_payloads(
            "user123",
            flag_keys_to_evaluate=["flag1", "flag3"],
            person_properties={"subscription": "pro"},
        )

        # Verify flags() was called with flag_keys_to_evaluate
        mock_flags.assert_called_once()
        call_args = mock_flags.call_args[1]
        self.assertEqual(call_args["flag_keys_to_evaluate"], ["flag1", "flag3"])
        self.assertEqual(
            call_args["person_properties"],
            {"subscription": "pro"},
        )

        # Check the result
        self.assertEqual(result["featureFlags"], {"flag1": "variant1", "flag3": True})
        self.assertEqual(
            result["featureFlagPayloads"],
            {"flag1": {"data": "payload1"}, "flag3": {"data": "payload3"}},
        )

    def test_get_all_flags_locally_with_flag_keys_to_evaluate(self):
        """Test that local evaluation with flag_keys_to_evaluate only evaluates specified flags"""
        client = Client(project_api_key=FAKE_TEST_API_KEY, secret_key=FAKE_TEST_API_KEY)

        # Set up multiple flags
        client.feature_flags = [
            {
                "id": 1,
                "key": "flag1",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 2,
                "key": "flag2",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
            {
                "id": 3,
                "key": "flag3",
                "active": True,
                "filters": {"groups": [{"properties": [], "rollout_percentage": 100}]},
            },
        ]

        # Call get_all_flags with flag_keys_to_evaluate
        result = client.get_all_flags(
            "user123",
            flag_keys_to_evaluate=["flag1", "flag3"],
            only_evaluate_locally=True,
        )

        # Should only return flag1 and flag3
        self.assertEqual(result, {"flag1": True, "flag3": True})
        self.assertNotIn("flag2", result)
