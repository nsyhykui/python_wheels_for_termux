"""Tests for the PostHogMCP custom-dispatcher client (Milestone 3)."""

from types import SimpleNamespace
from unittest import mock

import pytest
from mcp.types import Tool

from posthog.capture_mode import CaptureMode
from posthog.mcp import PostHogMCP
from posthog.test.mcp._helpers import (
    events_named as _events,
    flush_background as _flush,
)
from posthog.version import VERSION


def make_client(**kwargs):
    client = PostHogMCP("phc_test", host="https://us.i.posthog.com", **kwargs)
    captured = []
    # Intercept the inherited Client.capture so nothing is sent over the network.
    client.capture = lambda event, **kwargs: captured.append({"event": event, **kwargs})
    return client, captured


async def test_capture_tool_call_success():
    client, captured = make_client()
    client.capture_tool_call(
        "search_docs",
        intent="finding the install guide",
        intent_source="context_parameter",
        duration_ms=42,
        distinct_id="user_1",
        groups={"organization": "org_1"},
    )
    await _flush()

    calls = _events(captured, "$mcp_tool_call")
    assert len(calls) == 1
    props = calls[0]["properties"]
    assert props["$mcp_tool_name"] == "search_docs"
    assert props["$mcp_intent"] == "finding the install guide"
    assert props["$mcp_is_error"] is False
    assert props["$mcp_duration_ms"] == 42
    assert props["$groups"] == {"organization": "org_1"}
    assert calls[0]["distinct_id"] == "user_1"


async def test_capture_tool_call_error_fans_out_exception():
    client, captured = make_client()
    client.capture_tool_call(
        "broken", is_error=True, error=RuntimeError("kaboom"), distinct_id="u"
    )
    await _flush()

    assert _events(captured, "$mcp_tool_call")[0]["properties"]["$mcp_is_error"] is True
    exc = _events(captured, "$exception")
    assert exc and exc[0]["properties"]["$exception_list"][0]["value"] == "kaboom"


async def test_mcp_events_use_mcp_library_identity():
    captured = []

    def before_send(event):
        captured.append(event)
        return event

    client = PostHogMCP(
        "phc_test",
        host="https://us.i.posthog.com",
        send=False,
        before_send=before_send,
    )
    client.capture_tool_call("broken", is_error=True, error=RuntimeError("kaboom"))
    await _flush()

    assert {event["event"] for event in captured} == {"$mcp_tool_call", "$exception"}
    assert all(
        event["properties"]["$lib"] == "posthog-python-mcp"
        and event["properties"]["$lib_version"] == VERSION
        for event in captured
    )


def test_mcp_library_identity_reaches_capture_v0_header():
    response = mock.Mock(status_code=200)
    client = PostHogMCP("phc_test", sync_mode=True)

    with mock.patch("posthog.request._session.post", return_value=response) as post:
        client.capture("$mcp_custom")

    assert post.call_args.kwargs["headers"]["User-Agent"] == (
        f"posthog-python-mcp/{VERSION}"
    )


def test_mcp_library_identity_reaches_capture_v1_header():
    client = PostHogMCP("phc_test", sync_mode=True, capture_mode=CaptureMode.V1)
    with mock.patch("posthog.client._send_v1_batch") as send:
        client.capture("$mcp_custom")

    assert send.call_args.kwargs["sdk_info"] == f"posthog-python-mcp/{VERSION}"
    event = send.call_args.args[2][0]
    assert event["properties"]["$lib"] == "posthog-python-mcp"
    assert event["properties"]["$lib_version"] == VERSION


def test_mcp_library_identity_reaches_feature_flag_requests():
    response = mock.Mock(status_code=200)
    response.json.return_value = {"flags": {}}
    client = PostHogMCP("phc_test", send=False)

    with mock.patch(
        "posthog.request._flags_session.post", return_value=response
    ) as post:
        client.evaluate_flags("user_1")

    assert post.call_args.kwargs["headers"]["User-Agent"] == (
        f"posthog-python-mcp/{VERSION}"
    )


def test_mcp_library_identity_reaches_feature_flag_definition_requests():
    response = mock.Mock(status_code=200, headers={})
    response.json.return_value = {"flags": [], "group_type_mapping": {}, "cohorts": {}}
    client = PostHogMCP(
        "phc_test",
        secret_key="phs_test",
        send=False,
        enable_local_evaluation=False,
    )

    with mock.patch("posthog.request._session.get", return_value=response) as get:
        client.load_feature_flags()

    assert get.call_args.kwargs["headers"]["User-Agent"] == (
        f"posthog-python-mcp/{VERSION}"
    )
    client.shutdown()


def test_mcp_library_identity_reaches_remote_config_requests():
    response = mock.Mock(status_code=200, headers={})
    response.json.return_value = "payload"
    client = PostHogMCP("phc_test", secret_key="phs_test", send=False)

    with mock.patch("posthog.request._session.get", return_value=response) as get:
        assert client.get_remote_config_payload("flag-key") == "payload"

    assert get.call_args.kwargs["headers"]["User-Agent"] == (
        f"posthog-python-mcp/{VERSION}"
    )


async def test_capture_initialize_and_tools_list():
    client, captured = make_client()
    client.capture_initialize(
        client_name="claude-code", client_version="1.2.3", distinct_id="u"
    )
    client.capture_tools_list(tool_names=["a", "b"], distinct_id="u")
    await _flush()

    init = _events(captured, "$mcp_initialize")
    assert init and init[0]["properties"]["$mcp_client_name"] == "claude-code"
    listed = _events(captured, "$mcp_tools_list")
    assert listed and listed[0]["properties"]["$mcp_listed_tool_names"] == ["a", "b"]


async def test_capture_missing_capability():
    client, captured = make_client()
    client.capture_missing_capability(
        context="wanted a tool to export to CSV", distinct_id="u"
    )
    await _flush()

    missing = _events(captured, "$mcp_missing_capability")
    assert (
        missing
        and missing[0]["properties"]["$mcp_intent"] == "wanted a tool to export to CSV"
    )


def test_prepare_tool_call_extracts_intent_and_strips_context():
    client, _ = make_client()
    prepared = client.prepare_tool_call(
        "search", {"q": "x", "context": "looking up the answer"}
    )
    assert prepared.intent == "looking up the answer"
    assert prepared.intent_source == "context_parameter"
    assert prepared.args == {"q": "x"}
    assert prepared.is_missing_capability is False

    prepared_missing = client.prepare_tool_call(
        "get_more_tools", {"context": "need something else"}
    )
    assert prepared_missing.is_missing_capability is True


def test_prepare_tool_list_injects_context_into_dicts():
    client, _ = make_client()
    tools = [
        {
            "name": "search",
            "inputSchema": {"type": "object", "properties": {"q": {"type": "string"}}},
        }
    ]
    prepared = client.prepare_tool_list(tools)
    assert "context" in prepared[0]["inputSchema"]["properties"]
    # original tool dict is untouched
    assert "context" not in tools[0]["inputSchema"]["properties"]


def test_prepare_tool_list_can_be_disabled():
    client, _ = make_client()
    tools = [{"name": "search", "inputSchema": {"type": "object", "properties": {}}}]
    prepared = client.prepare_tool_list(tools, context=False)
    assert "context" not in prepared[0]["inputSchema"]["properties"]


@pytest.mark.parametrize(
    "options", [{"capture_model": True}, {"capture_model": False}, {}]
)
async def test_prepare_and_capture_model(options: dict[str, bool]) -> None:
    client, captured = make_client(**options)
    enabled = options.get("capture_model", False)
    tools = [
        {
            "name": "search",
            "inputSchema": {"type": "object", "properties": {"q": {"type": "string"}}},
        }
    ]

    prepared_tools = client.prepare_tool_list(tools)
    schema = prepared_tools[0]["inputSchema"]
    assert ("llm_model" in schema["properties"]) == enabled
    assert ("llm_model" in schema.get("required", [])) == enabled

    call = client.prepare_tool_call(
        "search",
        {"q": "docs", "llm_model": "claude-opus-4-8"},
        request_meta={"x-codex-turn-metadata": {"model": "gpt-5.6-sol"}},
    )
    assert call.args == (
        {"q": "docs"} if enabled else {"q": "docs", "llm_model": "claude-opus-4-8"}
    )
    assert call.llm_model == ("gpt-5.6-sol" if enabled else None)
    assert call.llm_model_source == ("client_metadata" if enabled else None)

    client.capture_tool_call(
        "search",
        llm_model=call.llm_model,
        llm_model_source=call.llm_model_source,
    )
    await _flush()

    props = _events(captured, "$mcp_tool_call")[0]["properties"]
    assert props.get("$mcp_llm_model") == ("gpt-5.6-sol" if enabled else None)
    assert props.get("$mcp_llm_model_source") == (
        "client_metadata" if enabled else None
    )


@pytest.mark.parametrize("sdk_tool", [False, True])
@pytest.mark.parametrize("pass_original_tool", [False, True])
def test_prepare_model_preserves_object_tool_ownership(
    sdk_tool: bool, pass_original_tool: bool
) -> None:
    client, _ = make_client(capture_model=True)
    schema = {"type": "object", "properties": {"q": {"type": "string"}}}
    tool = (
        Tool(name="search", inputSchema=schema)
        if sdk_tool
        else SimpleNamespace(name="search", input_schema=schema)
    )
    schema_attribute = (
        "input_schema" if hasattr(tool, "input_schema") else "inputSchema"
    )
    for _ in range(2):
        prepared = client.prepare_tool_list([tool], context=False)
        assert "llm_model" in getattr(prepared[0], schema_attribute)["properties"]
        call = client.prepare_tool_call(
            "search",
            {"q": "docs", "llm_model": "example-model"},
            original_tool=tool if pass_original_tool else None,
        )
        assert call.args == {"q": "docs"}
        assert (call.llm_model, call.llm_model_source) == (
            "example-model",
            "self_reported",
        )
        assert "llm_model" not in getattr(tool, schema_attribute)["properties"]


def test_prepare_tool_call_preserves_application_owned_model_argument():
    client, _ = make_client(capture_model=True)
    tool = {
        "name": "route",
        "inputSchema": {
            "type": "object",
            "properties": {"llm_model": {"type": "string"}},
            "required": ["llm_model"],
        },
    }
    client.prepare_tool_list([tool])

    call = client.prepare_tool_call(
        "route", {"llm_model": "application-owned"}, original_tool=tool
    )
    assert call.args == {"llm_model": "application-owned"}
    assert call.llm_model is None


def test_prepare_tool_list_fails_closed_for_duplicate_tool_names():
    client, _ = make_client(capture_model=True)
    tools = [
        {"name": "route", "inputSchema": {"type": "object", "properties": {}}},
        {
            "name": "route",
            "inputSchema": {
                "type": "object",
                "properties": {"llm_model": {"type": "string"}},
            },
        },
    ]

    prepared = client.prepare_tool_list(tools)
    assert "llm_model" not in prepared[0]["inputSchema"]["properties"]
    assert prepared[1]["inputSchema"]["properties"]["llm_model"] == {"type": "string"}
    call = client.prepare_tool_call("route", {"llm_model": "application-owned"})
    assert call.args == {"llm_model": "application-owned"}
    assert call.llm_model is None
