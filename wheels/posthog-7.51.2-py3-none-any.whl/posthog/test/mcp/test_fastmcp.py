"""End-to-end tests for the FastMCP adapter (Milestone 2)."""

import asyncio
from types import SimpleNamespace

import pytest

import mcp.types as mcp_types
from mcp.server.fastmcp import FastMCP

from posthog.mcp import instrument
from posthog.mcp.types import MCPAnalyticsOptions, UserIdentity
from posthog.test.mcp._helpers import (
    FakeClient,
    events_named as _events,
    flush_background as _flush,
)


def make_server():
    server = FastMCP("test-server")

    @server.tool()
    def add(a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    @server.tool()
    def boom() -> str:
        raise ValueError("explode")

    return server


async def _list_tools(server):
    handler = server._mcp_server.request_handlers[mcp_types.ListToolsRequest]
    return await handler(mcp_types.ListToolsRequest(method="tools/list"))


# --- tools/list --------------------------------------------------------------


async def test_list_tools_injects_context_and_captures():
    server = make_server()
    client = FakeClient()
    instrument(server, client)

    result = await _list_tools(server)
    await _flush()

    tools = result.root.tools
    add_tool = next(t for t in tools if t.name == "add")
    assert "context" in add_tool.inputSchema["properties"]
    assert "context" in add_tool.inputSchema["required"]

    listed = _events(client, "$mcp_tools_list")
    assert listed
    assert set(listed[0]["properties"]["$mcp_listed_tool_names"]) == {"add", "boom"}


async def test_context_injection_can_be_disabled():
    server = make_server()
    client = FakeClient()
    instrument(server, client, MCPAnalyticsOptions(context=False))

    result = await _list_tools(server)
    add_tool = next(t for t in result.root.tools if t.name == "add")
    assert "context" not in add_tool.inputSchema.get("properties", {})


async def test_list_tools_injects_model_into_real_and_virtual_tools():
    server = make_server()
    client = FakeClient()
    instrument(
        server,
        client,
        MCPAnalyticsOptions(capture_model=True, report_missing=True),
    )

    result = await _list_tools(server)
    tools = {tool.name: tool for tool in result.root.tools}

    for name in ("add", "boom", "get_more_tools"):
        assert "llm_model" in tools[name].inputSchema["properties"]
        assert "llm_model" in tools[name].inputSchema["required"]


# --- tools/call --------------------------------------------------------------


async def test_tool_call_captures_intent_and_strips_context():
    server = make_server()
    client = FakeClient()
    instrument(server, client)

    # Prime the listing metadata used by the shared call lifecycle.
    await _list_tools(server)

    received = {}
    original_add = server._tool_manager.get_tool("add").fn

    def spy_add(a: int, b: int) -> int:
        received["args"] = {"a": a, "b": b}
        return original_add(a, b)

    server._tool_manager.get_tool("add").fn = spy_add

    await server._tool_manager.call_tool(
        "add", {"a": 2, "b": 3, "context": "summing two numbers for the user's report"}
    )
    await _flush()

    # the injected `context` never reached the tool implementation
    assert received["args"] == {"a": 2, "b": 3}

    calls = _events(client, "$mcp_tool_call")
    assert len(calls) == 1
    props = calls[0]["properties"]
    assert props["$mcp_tool_name"] == "add"
    assert props["$mcp_tool_description"] == "Add two numbers."
    assert props["$mcp_intent"] == "summing two numbers for the user's report"
    assert props["$mcp_intent_source"] == "context_parameter"
    assert props["$mcp_is_error"] is False
    assert "$mcp_duration_ms" in props
    # context is stripped from captured parameters too
    assert "context" not in props["$mcp_parameters"]["request"]["params"]["arguments"]


async def test_tool_call_captures_client_model_without_prior_listing():
    server = make_server()
    client = FakeClient()
    instrument(server, client, MCPAnalyticsOptions(capture_model=True))

    context = SimpleNamespace(
        request_context=SimpleNamespace(
            meta={"x-codex-turn-metadata": {"model": "gpt-5.6-sol"}}
        )
    )
    result = await server._tool_manager.call_tool(
        "add",
        {"a": 2, "b": 3, "llm_model": "claude-opus-4-8"},
        context=context,
    )
    await _flush()

    assert result == 5
    props = _events(client, "$mcp_tool_call")[0]["properties"]
    assert props["$mcp_llm_model"] == "gpt-5.6-sol"
    assert props["$mcp_llm_model_source"] == "client_metadata"
    assert "llm_model" not in props["$mcp_parameters"]["request"]["params"]["arguments"]


async def test_analytics_flush_drains_its_own_captures():
    async def slow_before_send(event):
        await asyncio.sleep(0.05)
        return event

    server = make_server()
    client = FakeClient()
    analytics = instrument(
        server, client, MCPAnalyticsOptions(before_send=slow_before_send)
    )

    await server._tool_manager.call_tool(
        "add", {"a": 2, "b": 3, "context": "summing two numbers"}
    )
    assert _events(client, "$mcp_tool_call") == []

    await analytics.flush()

    assert len(_events(client, "$mcp_tool_call")) == 1


async def test_initialize_emitted_once_per_session():
    server = make_server()
    client = FakeClient()
    instrument(server, client)

    await server._tool_manager.call_tool(
        "add", {"a": 1, "b": 1, "context": "first call to warm up"}
    )
    await server._tool_manager.call_tool(
        "add", {"a": 2, "b": 2, "context": "second call for the total"}
    )
    await _flush()

    assert len(_events(client, "$mcp_initialize")) == 1
    assert len(_events(client, "$mcp_tool_call")) == 2


async def test_tool_call_error_is_captured_and_reraised():
    server = make_server()
    client = FakeClient()
    instrument(server, client)

    with pytest.raises(Exception):
        await server._tool_manager.call_tool(
            "boom", {"context": "attempting the risky operation"}
        )
    await _flush()

    calls = _events(client, "$mcp_tool_call")
    assert calls and calls[0]["properties"]["$mcp_is_error"] is True
    exceptions = _events(client, "$exception")
    assert exceptions
    # Canonical order: the caught/outermost exception (fastmcp's ToolError
    # wrapper) is first, the root cause last.
    exception_list = exceptions[0]["properties"]["$exception_list"]
    assert exception_list[0]["value"] == "Error executing tool boom: explode"
    assert exception_list[-1]["value"] == "explode"


async def test_identify_sets_distinct_id_and_groups():
    server = make_server()
    client = FakeClient()
    instrument(
        server,
        client,
        MCPAnalyticsOptions(
            identify=lambda request, extra: UserIdentity(
                distinct_id="user_42",
                properties={"plan": "pro"},
                groups={"organization": "org_7"},
            )
        ),
    )

    await server._tool_manager.call_tool(
        "add", {"a": 1, "b": 2, "context": "checking identity flows through"}
    )
    await _flush()

    calls = _events(client, "$mcp_tool_call")
    assert calls[0]["distinct_id"] == "user_42"
    assert calls[0]["properties"]["$groups"] == {"organization": "org_7"}
    assert "$process_person_profile" not in calls[0]["properties"]
    # an $identify event was emitted
    assert _events(client, "$identify")


async def test_instrument_is_idempotent():
    server = make_server()
    client = FakeClient()
    instrument(server, client)
    wrapped_call = server._tool_manager.call_tool
    instrument(server, client)
    assert server._tool_manager.call_tool is wrapped_call  # not double-wrapped


async def test_unsupported_server_returns_noop_handle():
    handle = instrument(object(), FakeClient())
    # graceful no-op: capture and flush do nothing and do not raise
    await handle.capture("anything")
    await handle.flush()


async def test_callbacks_can_read_headers_through_the_helper():
    """Same callback body as the v2 lane's equivalent test: `extra["ctx"]` is the
    SDK's own per-request context on both majors, read via `get_request_headers`."""
    from types import SimpleNamespace

    from posthog.mcp import get_request_headers

    server = make_server()
    client = FakeClient()
    seen = {}

    def identify(request, extra):
        seen["headers"] = get_request_headers(extra)
        return None

    instrument(server, client, MCPAnalyticsOptions(identify=identify))

    # FastMCP hands the tool a Context whose .request_context carries the request.
    context = SimpleNamespace(
        request_context=SimpleNamespace(
            request=SimpleNamespace(headers={"Authorization": "Bearer t0ken"}),
            session=SimpleNamespace(client_params=None),
        )
    )
    await server._tool_manager.call_tool(
        "add", {"a": 1, "b": 1, "context": "header read"}, context=context
    )
    await _flush()

    assert seen["headers"] == {"authorization": "Bearer t0ken"}


async def test_public_call_tool_entrypoint_still_works_outside_a_request():
    """`FastMCP.call_tool()` is public API for in-process invocation, where there
    is no request context. `Context.request_context` *raises* there, so reading
    it unguarded would push an analytics error into the customer's tool path."""
    server = make_server()
    instrument(server, FakeClient())

    result = await server.call_tool("add", {"a": 2, "b": 3, "context": "no request"})
    await _flush()

    text_blocks = [c.text for c in result[0] if getattr(c, "type", None) == "text"]
    assert "5" in text_blocks
