import calendar
import datetime
import hashlib
import json
import logging
import math
import re
import warnings
from decimal import Decimal
from enum import Enum
from typing import Optional

from posthog import utils as utils
from posthog.types import FlagValue
from posthog.utils import convert_to_datetime_aware, is_valid_regex

__LONG_SCALE__ = float(0xFFFFFFFFFFFFFFF)

log = logging.getLogger("posthog")

# Tracks (flag_key, reason) pairs already warned about for malformed flag
# dependency conditions, so the warning fires at most once per process instead
# of on every get_feature_flag call. A plain set is safe under the GIL; a rare
# duplicate warning from a race is acceptable.
_warned_malformed_flag_dependencies: set = set()

NONE_VALUES_ALLOWED_OPERATORS = ["is_not"]


def _warn_malformed_flag_dependency_once(flag_key, reason):
    """Emit a throttled warning for a malformed flag dependency condition.

    Mirrors the server-side Rust evaluator, which logs before treating the
    condition as not matching, so customers can discover broken flag
    definitions locally. Deduplicated on (flag_key, reason) to avoid spamming
    hot evaluation paths.
    """
    key = (flag_key, reason)
    if key in _warned_malformed_flag_dependencies:
        return
    _warned_malformed_flag_dependencies.add(key)
    log.warning(
        f"Flag dependency condition on '{flag_key or 'unknown'}' is malformed "
        f"({reason}); treating as not matching during local evaluation. "
        f"Fix this condition in the PostHog UI."
    )


class ConditionMatch(Enum):
    """Outcome of evaluating a single condition group.

    OUT_OF_ROLLOUT_BOUND means the group's property filters matched (or there were none)
    but the rollout percentage excluded the user — the only case that triggers a flag's
    ``early_exit`` short-circuit. Mirrors the server-side (Rust) engine's match cases.
    """

    MATCH = "match"
    NO_MATCH = "no_match"
    OUT_OF_ROLLOUT_BOUND = "out_of_rollout_bound"


# All operators supported by match_property, grouped by category.
EQUALITY_OPERATORS = ("exact", "is_not", "is_set", "is_not_set")
STRING_OPERATORS = (
    "icontains",
    "not_icontains",
    "regex",
    "not_regex",
    "starts_with",
    "not_starts_with",
    "ends_with",
    "not_ends_with",
)
NUMERIC_OPERATORS = ("gt", "gte", "lt", "lte")
DATE_OPERATORS = ("is_date_before", "is_date_after")
SEMVER_COMPARISON_OPERATORS = (
    "semver_eq",
    "semver_neq",
    "semver_gt",
    "semver_gte",
    "semver_lt",
    "semver_lte",
)
SEMVER_RANGE_OPERATORS = ("semver_tilde", "semver_caret", "semver_wildcard")
SEMVER_OPERATORS = SEMVER_COMPARISON_OPERATORS + SEMVER_RANGE_OPERATORS

PROPERTY_OPERATORS = (
    EQUALITY_OPERATORS
    + STRING_OPERATORS
    + NUMERIC_OPERATORS
    + DATE_OPERATORS
    + SEMVER_OPERATORS
)


class InconclusiveMatchError(Exception):
    pass


class RequiresServerEvaluation(Exception):
    """
    Raised when feature flag evaluation requires server-side data that is not
    available locally (e.g., static cohorts, experience continuity).

    This error should propagate immediately to trigger API fallback, unlike
    InconclusiveMatchError which allows trying other conditions.
    """

    pass


# This function takes a bucketing value and a feature flag key and returns a float between 0 and 1.
# Given the same bucketing value and key, it'll always return the same float. These floats are
# uniformly distributed between 0 and 1, so if we want to show this feature to 20% of traffic
# we can do _hash(key, bucketing_value) < 0.2
def _hash(key: str, bucketing_value: str, salt: str = "") -> float:
    hash_key = f"{key}.{bucketing_value}{salt}"
    hash_val = int(hashlib.sha1(hash_key.encode("utf-8")).hexdigest()[:15], 16)
    return hash_val / __LONG_SCALE__


def get_matching_variant(flag, bucketing_value):
    hash_value = _hash(flag["key"], bucketing_value, salt="variant")
    for variant in variant_lookup_table(flag):
        if hash_value >= variant["value_min"] and hash_value < variant["value_max"]:
            return variant["key"]
    return None


def variant_lookup_table(feature_flag):
    lookup_table = []
    value_min = 0
    multivariates = ((feature_flag.get("filters") or {}).get("multivariate") or {}).get(
        "variants"
    ) or []
    for variant in multivariates:
        value_max = value_min + variant["rollout_percentage"] / 100
        lookup_table.append(
            {"value_min": value_min, "value_max": value_max, "key": variant["key"]}
        )
        value_min = value_max
    return lookup_table


def evaluate_flag_dependency(
    property,
    flags_by_key,
    evaluation_cache,
    distinct_id,
    properties,
    cohort_properties,
    device_id=None,
):
    """
    Evaluate a flag dependency condition under local evaluation.

    The dependency_chain only establishes the order in which flags are evaluated
    and cached (the referenced flag itself is always the last member). The
    outcome is decided solely by comparing the referenced flag's evaluated value
    against the condition's expected value; ancestors influence it only through
    the referenced flag's own recursive evaluation.

    Args:
        property: Flag property with type="flag" and dependency_chain
        flags_by_key: Dictionary of all flags by their key
        evaluation_cache: Cache for storing evaluation results
        distinct_id: The distinct ID being evaluated
        properties: Person properties for evaluation
        cohort_properties: Cohort properties for evaluation
        device_id: The device ID for bucketing (optional)

    Returns:
        bool: Whether the referenced flag's evaluated value matches the
            condition's expected value. A malformed condition shape (wrong
            operator, missing key, or missing value) is a definitive local
            no-match and returns False, mirroring the server-side evaluator.

    Raises:
        InconclusiveMatchError: If the chain cannot be conclusively evaluated
            locally (referenced flag missing, an inconclusive dependency,
            circular dependency, or missing evaluation context).
    """
    if flags_by_key is None or evaluation_cache is None:
        # Cannot evaluate flag dependencies without required context
        raise InconclusiveMatchError(
            f"Cannot evaluate flag dependency on '{property.get('key', 'unknown')}' without flags_by_key and evaluation_cache"
        )

    # Validate the condition shape before walking the chain. A malformed shape
    # is a definitive no-match (return False), mirroring the server-side Rust
    # evaluator (match_flag_value_to_flag_filter). Raising InconclusiveMatchError
    # here would force a billable /flags network fallback on every evaluation of
    # the affected flag. Test `is None`, not truthiness: `False` is a valid
    # expected value (the case flag dependencies exist for).
    flag_key = property.get("key")
    expected_value = property.get("value")
    operator = property.get("operator", "exact")

    if operator != "flag_evaluates_to":
        _warn_malformed_flag_dependency_once(flag_key, f"invalid operator '{operator}'")
        return False
    if not flag_key or expected_value is None:
        _warn_malformed_flag_dependency_once(flag_key, "missing key or value")
        return False

    # Check if dependency_chain is present - it should always be provided for flag dependencies
    if "dependency_chain" not in property:
        # Missing dependency_chain indicates malformed server data
        raise InconclusiveMatchError(
            f"Flag dependency property for '{property.get('key', 'unknown')}' is missing required 'dependency_chain' field"
        )

    dependency_chain = property["dependency_chain"]

    # Handle circular dependency (empty chain means circular)
    if len(dependency_chain) == 0:
        log.debug(f"Circular dependency detected for flag: {property.get('key')}")
        raise InconclusiveMatchError(
            f"Circular dependency detected for flag '{property.get('key', 'unknown')}'"
        )

    # Evaluate and cache each flag in the chain; members already cached are
    # skipped. This does not decide the outcome — it only populates the cache.
    for dep_flag_key in dependency_chain:
        if dep_flag_key in evaluation_cache:
            continue

        dep_flag = flags_by_key.get(dep_flag_key)
        if not dep_flag:
            # Missing flag dependency - cannot evaluate locally
            evaluation_cache[dep_flag_key] = None
            raise InconclusiveMatchError(
                f"Cannot evaluate flag dependency '{dep_flag_key}' - flag not found in local flags"
            )

        # Check if the flag is active (same check as in client._compute_flag_locally)
        if not dep_flag.get("active"):
            evaluation_cache[dep_flag_key] = False
            continue

        # Recursively evaluate the dependency
        try:
            dep_flag_filters = dep_flag.get("filters") or {}
            dep_aggregation_group_type_index = dep_flag_filters.get(
                "aggregation_group_type_index"
            )
            if dep_aggregation_group_type_index is not None:
                # Group flags should continue bucketing by the group key
                # from the current evaluation context.
                dep_bucketing_value = distinct_id
            else:
                dep_bucketing_value = resolve_bucketing_value(
                    dep_flag, distinct_id, device_id
                )
            dep_result = match_feature_flag_properties(
                dep_flag,
                distinct_id,
                properties,
                cohort_properties=cohort_properties,
                flags_by_key=flags_by_key,
                evaluation_cache=evaluation_cache,
                device_id=device_id,
                bucketing_value=dep_bucketing_value,
            )
            evaluation_cache[dep_flag_key] = dep_result
        except InconclusiveMatchError as e:
            # If we can't evaluate a dependency, store None and propagate the error
            evaluation_cache[dep_flag_key] = None
            raise InconclusiveMatchError(
                f"Cannot evaluate flag dependency '{dep_flag_key}': {e}"
            ) from e

    # The condition matches iff the referenced flag's value matches the expected
    # value. None means inconclusive or not evaluated — distinct from a
    # definitive False, which must be allowed to match `expected_value=False`.
    actual_value = evaluation_cache.get(flag_key)
    if actual_value is None:
        raise InconclusiveMatchError(
            f"Flag dependency '{flag_key}' was inconclusive or not evaluated"
        )
    return matches_dependency_value(expected_value, actual_value)


def matches_dependency_value(expected_value, actual_value):
    """
    Check if the actual flag value matches the expected dependency value.

    This follows the same logic as the C# MatchesDependencyValue function:
    - String variant case: check for exact match or boolean true
    - Boolean case: must match expected boolean value

    Args:
        expected_value: The expected value from the property
        actual_value: The actual value returned by the flag evaluation

    Returns:
        bool: True if the values match according to flag dependency rules
    """
    # String variant case - check for exact match or boolean true
    if isinstance(actual_value, str) and len(actual_value) > 0:
        if isinstance(expected_value, bool):
            # Any variant matches boolean true
            return expected_value
        elif isinstance(expected_value, str):
            # variants are case-sensitive, hence our comparison is too
            return actual_value == expected_value
        else:
            return False

    # Boolean case - must match expected boolean value
    elif isinstance(actual_value, bool) and isinstance(expected_value, bool):
        return actual_value == expected_value

    # Default case
    return False


def resolve_bucketing_value(flag, distinct_id, device_id=None):
    """Resolve the bucketing value for a flag based on its bucketing_identifier setting.

    Returns:
        The appropriate identifier string to use for hashing/bucketing.

    Raises:
        InconclusiveMatchError: If the flag requires device_id but none was provided.
    """
    flag_filters = flag.get("filters") or {}
    bucketing_identifier = flag.get("bucketing_identifier") or flag_filters.get(
        "bucketing_identifier"
    )
    if bucketing_identifier == "device_id":
        if not device_id:
            raise InconclusiveMatchError(
                "Flag requires device_id for bucketing but none was provided"
            )
        return device_id
    return distinct_id


def match_feature_flag_properties(
    flag,
    distinct_id,
    properties,
    *,
    cohort_properties=None,
    flags_by_key=None,
    evaluation_cache=None,
    device_id=None,
    bucketing_value=None,
    group_type_mapping=None,
    groups=None,
    group_properties=None,
) -> FlagValue:
    if bucketing_value is None:
        warnings.warn(
            "Calling match_feature_flag_properties() without bucketing_value is deprecated. "
            "Pass bucketing_value explicitly. This fallback will be removed in a future major release.",
            DeprecationWarning,
            stacklevel=2,
        )
        bucketing_value = resolve_bucketing_value(flag, distinct_id, device_id)

    flag_filters = flag.get("filters") or {}
    flag_conditions = flag_filters.get("groups") or []
    flag_aggregation = flag_filters.get("aggregation_group_type_index")
    early_exit_enabled = flag_filters.get("early_exit")
    is_inconclusive = False
    cohort_properties = cohort_properties or {}
    groups = groups or {}
    group_properties = group_properties or {}
    group_type_mapping = group_type_mapping or {}
    # Some filters can be explicitly set to null, which require accessing variants like so
    flag_variants = (flag_filters.get("multivariate") or {}).get("variants") or []
    valid_variant_keys = [variant["key"] for variant in flag_variants]

    for condition in flag_conditions:
        try:
            # Per-condition aggregation overrides only when the condition explicitly
            # sets its own aggregation_group_type_index (mixed targeting).
            # When absent, use the properties/bucketing already resolved by the caller.
            condition_aggregation = condition.get(
                "aggregation_group_type_index", flag_aggregation
            )

            # Mixed-override path: condition-level aggregation differs from flag-level.
            # This assumes flag-level aggregation is None for mixed flags.
            if condition_aggregation != flag_aggregation:
                if condition_aggregation is not None:
                    group_name = group_type_mapping.get(str(condition_aggregation))
                    if not group_name or group_name not in groups:
                        log.debug(
                            "Skipping group condition for flag '%s': group type index %s not available",
                            flag.get("key", ""),
                            condition_aggregation,
                        )
                        continue
                    if group_name not in group_properties:
                        is_inconclusive = True
                        continue
                    effective_properties = group_properties[group_name]
                    effective_bucketing = groups[group_name]
                else:
                    effective_properties = properties
                    effective_bucketing = bucketing_value
            else:
                effective_properties = properties
                effective_bucketing = bucketing_value

            match_result = is_condition_match(
                flag,
                distinct_id,
                condition,
                effective_properties,
                cohort_properties,
                flags_by_key,
                evaluation_cache,
                bucketing_value=effective_bucketing,
                device_id=device_id,
            )
            if match_result == ConditionMatch.MATCH:
                variant_override = condition.get("variant")
                if variant_override and variant_override in valid_variant_keys:
                    variant = variant_override
                else:
                    variant = get_matching_variant(flag, effective_bucketing)
                return variant or True
            elif (
                early_exit_enabled
                and match_result == ConditionMatch.OUT_OF_ROLLOUT_BOUND
            ):
                # The condition's property filters (if any) matched and only the rollout check
                # failed, so re-evaluating later groups can't change the outcome. If an earlier
                # condition was inconclusive, stop here but preserve that result for fallback.
                if is_inconclusive:
                    break
                return False
        except RequiresServerEvaluation:
            # Static cohort or other missing server-side data - must fallback to API
            raise
        except InconclusiveMatchError:
            # Evaluation error (bad regex, invalid date, missing property, etc.)
            # Track that we had an inconclusive match, but try other conditions
            is_inconclusive = True

    if is_inconclusive:
        raise InconclusiveMatchError(
            "Can't determine if feature flag is enabled or not with given properties"
        )

    # We can only return False when either all conditions are False, or
    # no condition was inconclusive.
    return False


def is_condition_match(
    feature_flag,
    distinct_id,
    condition,
    properties,
    cohort_properties,
    flags_by_key=None,
    evaluation_cache=None,
    *,
    bucketing_value,
    device_id=None,
) -> ConditionMatch:
    rollout_percentage = condition.get("rollout_percentage")
    if len(condition.get("properties") or []) > 0:
        for prop in condition.get("properties"):
            property_type = prop.get("type")
            if property_type == "cohort":
                matches = match_cohort(
                    prop,
                    properties,
                    cohort_properties,
                    flags_by_key,
                    evaluation_cache,
                    distinct_id,
                    device_id=device_id,
                )
            elif property_type == "flag":
                matches = evaluate_flag_dependency(
                    prop,
                    flags_by_key,
                    evaluation_cache,
                    distinct_id,
                    properties,
                    cohort_properties,
                    device_id=device_id,
                )
            else:
                matches = match_property(prop, properties)
            if not matches:
                return ConditionMatch.NO_MATCH

        if rollout_percentage is None:
            return ConditionMatch.MATCH

    # Property filters (if any) matched; only the rollout check remains. A failure here means
    # the user was targeted but excluded by rollout — the server-side engine's OutOfRolloutBound.
    if rollout_percentage is not None and _hash(
        feature_flag["key"], bucketing_value
    ) > (rollout_percentage / 100):
        return ConditionMatch.OUT_OF_ROLLOUT_BOUND

    return ConditionMatch.MATCH


# Raised when an operator passes the PROPERTY_OPERATORS gate but has no dispatch
# branch in match_property. Distinct from the unknown-operator rejection at the top
# of the function so the dispatch-completeness test can tell the two apart.
_UNHANDLED_OPERATOR_MESSAGE = "has no match_property branch"
_ASCII_LOWER_TRANSLATION = str.maketrans(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"
)


def _format_json_float(value: float) -> str:
    if not math.isfinite(value):
        raise InconclusiveMatchError(
            "Non-finite property values cannot be represented by the flags service"
        )

    representation = repr(value)
    if "e" not in representation:
        return representation

    mantissa, exponent_text = representation.split("e")
    exponent = int(exponent_text)
    if -6 < exponent < 0:
        return format(Decimal(representation), "f")

    sign = "+" if exponent >= 0 else ""
    return f"{mantissa}e{sign}{exponent}"


def _json_value_to_string(value) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return _format_json_float(value)
    if isinstance(value, list):
        return "[" + ",".join(_json_value_to_string(item) for item in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise InconclusiveMatchError(
                "Property object keys must be strings for local evaluation"
            )
        items = (
            f"{json.dumps(key, ensure_ascii=False)}:{_json_value_to_string(value[key])}"
            for key in sorted(value)
        )
        return "{" + ",".join(items) + "}"

    raise InconclusiveMatchError(
        f"Property value of type {type(value).__name__} is not JSON-compatible"
    )


def _value_to_string(value) -> str:
    if isinstance(value, str):
        return value
    return _json_value_to_string(value)


def _ascii_lower(value) -> str:
    return _value_to_string(value).translate(_ASCII_LOWER_TRANSLATION)


def _is_truthy_or_falsy_property_value(value) -> bool:
    if isinstance(value, bool):
        return True
    if isinstance(value, str):
        return value.lower() in ("true", "false")
    if isinstance(value, list):
        return all(_is_truthy_or_falsy_property_value(item) for item in value)
    return False


def _is_truthy_property_value(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() == "true"
    if isinstance(value, list):
        return all(_is_truthy_property_value(item) for item in value)
    return False


def match_property(property, property_values) -> bool:
    # only looks for matches where key exists in override_property_values
    key = property.get("key")
    operator = property.get("operator") or "exact"
    value = property.get("value")

    if operator not in PROPERTY_OPERATORS:
        raise InconclusiveMatchError(f"Unknown operator {operator}")

    if key not in property_values:
        raise InconclusiveMatchError(
            "can't match properties without a given property value"
        )

    if operator in ("is_set", "is_not_set"):
        return operator == "is_set"

    override_value = property_values[key]

    if (
        operator not in NONE_VALUES_ALLOWED_OPERATORS
        and operator != "exact"
        and override_value is None
    ):
        return False

    if operator in ("exact", "is_not"):

        def compute_exact_match(value, override_value):
            override_string = _value_to_string(override_value).lower()
            if _is_truthy_or_falsy_property_value(value):
                return _is_truthy_property_value(value) == _is_truthy_property_value(
                    override_value
                )

            if isinstance(value, list):
                return override_string in [
                    _value_to_string(candidate).lower() for candidate in value
                ]
            return _value_to_string(value).lower() == override_string

        if operator == "exact":
            return compute_exact_match(value, override_value)
        else:
            return not compute_exact_match(value, override_value)

    if operator in (
        "icontains",
        "not_icontains",
        "starts_with",
        "not_starts_with",
        "ends_with",
        "not_ends_with",
    ):
        property_string = _ascii_lower(override_value)
        filter_string = _ascii_lower(value)

        if operator in ("icontains", "not_icontains"):
            matched = filter_string in property_string
        elif operator in ("starts_with", "not_starts_with"):
            matched = property_string.startswith(filter_string)
        else:
            matched = property_string.endswith(filter_string)

        if operator.startswith("not_"):
            return not matched
        return matched

    if operator == "regex":
        return (
            is_valid_regex(str(value))
            and re.compile(str(value)).search(str(override_value)) is not None
        )

    if operator == "not_regex":
        return (
            is_valid_regex(str(value))
            and re.compile(str(value)).search(str(override_value)) is None
        )

    if operator in ("gt", "gte", "lt", "lte"):
        # :TRICKY: We adjust comparison based on the override value passed in,
        # to make sure we handle both numeric and string comparisons appropriately.
        def compare(lhs, rhs, operator):
            if operator == "gt":
                return lhs > rhs
            elif operator == "gte":
                return lhs >= rhs
            elif operator == "lt":
                return lhs < rhs
            elif operator == "lte":
                return lhs <= rhs
            else:
                raise ValueError(f"Invalid operator: {operator}")

        parsed_value = None
        try:
            parsed_value = float(value)
        except Exception:
            pass

        if parsed_value is not None and override_value is not None:
            if isinstance(override_value, str):
                return compare(override_value, str(value), operator)
            else:
                return compare(override_value, parsed_value, operator)
        else:
            return compare(str(override_value), str(value), operator)

    if operator in ["is_date_before", "is_date_after"]:
        try:
            parsed_date = relative_date_parse_for_feature_flag_matching(str(value))

            if not parsed_date:
                parsed_date = parse_datetime(str(value))
                parsed_date = convert_to_datetime_aware(parsed_date)
        except Exception as e:
            raise InconclusiveMatchError(
                "The date set on the flag is not a valid format"
            ) from e

        if not parsed_date:
            raise InconclusiveMatchError(
                "The date set on the flag is not a valid format"
            )

        if isinstance(override_value, datetime.datetime):
            override_date = convert_to_datetime_aware(override_value)
            if operator == "is_date_before":
                return override_date < parsed_date
            else:
                return override_date > parsed_date
        elif isinstance(override_value, datetime.date):
            if operator == "is_date_before":
                return override_value < parsed_date.date()
            else:
                return override_value > parsed_date.date()
        elif isinstance(override_value, str):
            try:
                override_date = parse_datetime(override_value)
                override_date = convert_to_datetime_aware(override_date)
                if operator == "is_date_before":
                    return override_date < parsed_date
                else:
                    return override_date > parsed_date
            except Exception:
                raise InconclusiveMatchError("The date provided is not a valid format")
        else:
            raise InconclusiveMatchError(
                "The date provided must be a string or date object"
            )

    if operator in SEMVER_OPERATORS:
        try:
            override_parsed = parse_semver(override_value)
        except (ValueError, TypeError):
            raise InconclusiveMatchError(
                f"Person property value '{override_value}' is not a valid semver"
            )

        if operator in SEMVER_COMPARISON_OPERATORS:
            try:
                flag_parsed = parse_semver(value)
            except (ValueError, TypeError):
                raise InconclusiveMatchError(
                    f"Flag semver value '{value}' is not a valid semver"
                )

            if operator == "semver_eq":
                return override_parsed == flag_parsed
            elif operator == "semver_neq":
                return override_parsed != flag_parsed
            elif operator == "semver_gt":
                return override_parsed > flag_parsed
            elif operator == "semver_gte":
                return override_parsed >= flag_parsed
            elif operator == "semver_lt":
                return override_parsed < flag_parsed
            elif operator == "semver_lte":
                return override_parsed <= flag_parsed

        elif operator == "semver_tilde":
            try:
                lower, upper = _tilde_bounds(str(value))
            except (ValueError, TypeError):
                raise InconclusiveMatchError(
                    f"Flag semver value '{value}' is not valid for tilde operator"
                )
            return lower <= override_parsed < upper

        elif operator == "semver_caret":
            try:
                lower, upper = _caret_bounds(str(value))
            except (ValueError, TypeError):
                raise InconclusiveMatchError(
                    f"Flag semver value '{value}' is not valid for caret operator"
                )
            return lower <= override_parsed < upper

        elif operator == "semver_wildcard":
            try:
                lower, upper = _wildcard_bounds(str(value))
            except (ValueError, TypeError):
                raise InconclusiveMatchError(
                    f"Flag semver value '{value}' is not valid for wildcard operator"
                )
            return lower <= override_parsed < upper

    # Unreachable: all operators in PROPERTY_OPERATORS are handled above,
    # and unknown operators are rejected at the top of this function.
    raise InconclusiveMatchError(f"Operator {operator} {_UNHANDLED_OPERATOR_MESSAGE}")


def match_cohort(
    property,
    property_values,
    cohort_properties,
    flags_by_key=None,
    evaluation_cache=None,
    distinct_id=None,
    device_id=None,
) -> bool:
    # Cohort properties are in the form of property groups like this:
    # {
    #     "cohort_id": {
    #         "type": "AND|OR",
    #         "values": [{
    #            "key": "property_name", "value": "property_value"
    #        }]
    #     }
    # }
    cohort_id = str(property.get("value"))
    if cohort_id not in cohort_properties:
        raise RequiresServerEvaluation(
            f"cohort {cohort_id} not found in local cohorts - likely a static cohort that requires server evaluation"
        )

    property_group = cohort_properties[cohort_id]
    matches = match_property_group(
        property_group,
        property_values,
        cohort_properties,
        flags_by_key,
        evaluation_cache,
        distinct_id,
        device_id=device_id,
    )

    operator = property.get("operator") or "exact"
    if operator in ("exact", "in"):
        return matches
    if operator == "not_in":
        return not matches
    raise InconclusiveMatchError(f"Unsupported cohort operator: {operator}")


def match_property_group(
    property_group,
    property_values,
    cohort_properties,
    flags_by_key=None,
    evaluation_cache=None,
    distinct_id=None,
    device_id=None,
) -> bool:
    # The backend serializes its canonical empty PropertyGroup as {}.
    if property_group == {}:
        return True
    if not isinstance(property_group, dict):
        raise RequiresServerEvaluation("Cohort property group must be an object")

    property_group_type = property_group.get("type")
    if property_group_type not in ("AND", "OR"):
        raise RequiresServerEvaluation("Cohort property group type must be AND or OR")
    is_and = property_group_type == "AND"
    properties = property_group.get("values")
    if not isinstance(properties, list):
        raise RequiresServerEvaluation("Cohort property group values must be a list")
    if not properties:
        return True

    decisive_result = None
    error_matching_locally = False

    for prop in properties:
        try:
            if not isinstance(prop, dict):
                raise RequiresServerEvaluation(
                    "Cohort property group entry must be an object"
                )

            if prop == {} or "values" in prop or prop.get("type") in ("AND", "OR"):
                matches = match_property_group(
                    prop,
                    property_values,
                    cohort_properties,
                    flags_by_key,
                    evaluation_cache,
                    distinct_id,
                    device_id=device_id,
                )
                negation = False
            elif prop.get("type") == "cohort":
                matches = match_cohort(
                    prop,
                    property_values,
                    cohort_properties,
                    flags_by_key,
                    evaluation_cache,
                    distinct_id,
                    device_id=device_id,
                )
                negation = prop.get("negation", False)
            elif prop.get("type") == "flag":
                matches = evaluate_flag_dependency(
                    prop,
                    flags_by_key,
                    evaluation_cache,
                    distinct_id,
                    property_values,
                    cohort_properties,
                    device_id=device_id,
                )
                negation = prop.get("negation", False)
            else:
                matches = match_property(prop, property_values)
                negation = prop.get("negation", False)

            effective_match = matches != bool(negation)
            if is_and and not effective_match:
                decisive_result = False
            elif not is_and and effective_match:
                decisive_result = True
        except RequiresServerEvaluation:
            # Static/missing cohorts and malformed definitions always require server evaluation,
            # even when another branch would otherwise resolve the group locally.
            raise
        except InconclusiveMatchError as e:
            log.debug(f"Failed to compute property {prop} locally: {e}")
            error_matching_locally = True

    if decisive_result is not None:
        return decisive_result
    if error_matching_locally:
        raise InconclusiveMatchError(
            "Can't match cohort without a given cohort property value"
        )

    # AND: every entry matched. OR: none matched.
    return is_and


def parse_datetime(value: str) -> datetime.datetime:
    text = value.strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    elif text.upper().endswith(" UTC"):
        text = text[:-4] + "+00:00"
    elif re.fullmatch(r"\d{4}", text):
        now = datetime.datetime.now()
        return datetime.datetime(int(text), now.month, now.day)

    text = re.sub(r" ([+-]\d{2}:\d{2})$", r"\1", text)
    return datetime.datetime.fromisoformat(text)


# Python's stdlib doesn't provide a calendar-aware month/year delta.
# Clamp the day to the target month's end to match dateutil.relativedelta behavior.
def _subtract_months(dt: datetime.datetime, months: int) -> Optional[datetime.datetime]:
    month_index = dt.year * 12 + dt.month - 1 - months
    year = month_index // 12
    month = month_index % 12 + 1
    if not 1 <= year <= 9999:
        return None
    day = min(dt.day, calendar.monthrange(year, month)[1])
    return dt.replace(year=year, month=month, day=day)


def _subtract_years(dt: datetime.datetime, years: int) -> Optional[datetime.datetime]:
    year = dt.year - years
    if not 1 <= year <= 9999:
        return None
    day = min(dt.day, calendar.monthrange(year, dt.month)[1])
    return dt.replace(year=year, day=day)


def relative_date_parse_for_feature_flag_matching(
    value: str,
) -> Optional[datetime.datetime]:
    regex = r"^-?(?P<number>[0-9]+)(?P<interval>[a-z])$"
    match = re.search(regex, value)
    parsed_dt = datetime.datetime.now(datetime.timezone.utc)
    if match:
        number = int(match.group("number"))

        if number >= 10_000:
            # Guard against overflow, disallow numbers greater than 10_000
            return None

        interval = match.group("interval")
        if interval == "h":
            parsed_dt = parsed_dt - datetime.timedelta(hours=number)
        elif interval == "d":
            parsed_dt = parsed_dt - datetime.timedelta(days=number)
        elif interval == "w":
            parsed_dt = parsed_dt - datetime.timedelta(weeks=number)
        elif interval == "m":
            return _subtract_months(parsed_dt, number)
        elif interval == "y":
            return _subtract_years(parsed_dt, number)
        else:
            return None

        return parsed_dt
    else:
        return None


def _semver_numeric_identifier(part: str) -> int:
    # Semver 2.0.0 §2: numeric identifiers MUST NOT include leading zeros.
    if not part or not part.isdigit():
        raise ValueError(f"Invalid semver numeric identifier: '{part}'")
    if len(part) > 1 and part[0] == "0":
        raise ValueError(f"Semver numeric identifier has leading zero: '{part}'")
    return int(part)


def parse_semver(value: str) -> tuple:
    """Parse a semver string into a comparable (major, minor, patch) integer tuple.

    Matches the behavior of the sortableSemver HogQL function:
    - Handles v-prefix, whitespace, pre-release suffixes
    - Defaults missing components to 0 (e.g., 1.2 -> 1.2.0)
    - Rejects numeric identifiers with leading zeros per semver 2.0.0 §2
    Raises ValueError if parsing fails.
    """
    text = str(value).strip().lstrip("vV")
    # Strip pre-release/build metadata suffix
    text = text.split("-")[0].split("+")[0]
    parts = text.split(".")

    if not parts or not parts[0]:
        raise ValueError("Invalid semver format")

    major = _semver_numeric_identifier(parts[0])
    minor = _semver_numeric_identifier(parts[1]) if len(parts) > 1 and parts[1] else 0
    patch = _semver_numeric_identifier(parts[2]) if len(parts) > 2 and parts[2] else 0

    return (major, minor, patch)


def _tilde_bounds(value: str) -> tuple:
    """~1.2.3 means >=1.2.3 <1.3.0 (allows patch-level changes)."""
    major, minor, patch = parse_semver(value)
    return (major, minor, patch), (major, minor + 1, 0)


def _caret_bounds(value: str) -> tuple:
    """Caret follows semver spec:
    ^1.2.3 means >=1.2.3 <2.0.0
    ^0.2.3 means >=0.2.3 <0.3.0
    ^0.0.3 means >=0.0.3 <0.0.4
    """
    major, minor, patch = parse_semver(value)
    lower = (major, minor, patch)

    if major > 0:
        upper = (major + 1, 0, 0)
    elif minor > 0:
        upper = (0, minor + 1, 0)
    else:
        upper = (0, 0, patch + 1)

    return lower, upper


def _wildcard_bounds(value: str) -> tuple:
    """Wildcard matching:
    1.* means >=1.0.0 <2.0.0
    1.2.* means >=1.2.0 <1.3.0
    """
    cleaned = str(value).strip().lstrip("vV").replace("*", "").rstrip(".")
    if not cleaned:
        raise ValueError("Invalid wildcard pattern")

    parts = [p for p in cleaned.split(".") if p]
    if not parts:
        raise ValueError("Invalid wildcard pattern")

    if len(parts) == 1:
        major = _semver_numeric_identifier(parts[0])
        return (major, 0, 0), (major + 1, 0, 0)
    elif len(parts) == 2:
        major, minor = (
            _semver_numeric_identifier(parts[0]),
            _semver_numeric_identifier(parts[1]),
        )
        return (major, minor, 0), (major, minor + 1, 0)
    else:
        major = _semver_numeric_identifier(parts[0])
        minor = _semver_numeric_identifier(parts[1])
        patch = _semver_numeric_identifier(parts[2])
        return (major, minor, patch), (major, minor, patch + 1)
