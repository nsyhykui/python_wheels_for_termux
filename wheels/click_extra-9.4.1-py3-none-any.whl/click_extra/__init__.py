# Copyright Kevin Deldycke <kevin@deldycke.com> and contributors.
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
"""Expose package-wide elements."""

from __future__ import annotations

TYPE_CHECKING = False
# Mypy override: the `from click import *` / `from cloup import *` star imports
# below make mypy resolve these re-implemented names to the click or cloup base class,
# which hides click-extra's own attributes. Declaring the correct types here first,
# before the star imports, makes mypy treat the later bindings as no-redefs and keeps
# click-extra's subclasses canonical for consumers of this package.
# The .test_suite and .testing entries have no runtime counterpart: those
# symbols are served lazily by the module __getattr__ hook at the bottom of
# this file, so this block is also what keeps them visible to type checkers.
if TYPE_CHECKING:
    from typing import Any

    from .commands import Command, Group
    from .context import Context, pass_context
    from .highlight import HelpFormatter
    from .parameters import Argument, Option
    from .styling import Style
    from .test_suite import (
        DEFAULT_TEST_SUITE,
        SUITE_FORMATS,
        CLITestCase,
        SkippedTest,
        cases_from_data,
        load_test_suite,
        parse_test_suite,
        run_test_suite,
    )
    from .testing import CliRunner, Result
    from .theme import HelpTheme

import warnings

# Import all click's module-level content to allow for drop-in replacement.
# XXX Star import is really badly supported by mypy for now and leads to lots of
# "Module 'XXX' has no attribute 'YYY'". See: https://github.com/python/mypy/issues/4930
# The ignore mirrors the cloup star import below: the names pre-declared in the
# TYPE_CHECKING block above are re-implemented by click-extra, so click's originals
# arrive here as incompatible redefinitions.
from click import *  # type: ignore[assignment]
from click._utils import UNSET
from click.core import ParameterSource

# custom_version_option (PR pallets/click#3581) is a Click 8.5.0 addition, absent
# on the earlier releases click-extra still supports. Import it only when present
# so click-extra mirrors Click's own public surface; the matching __all__ entry is
# trimmed below when it is missing.
try:
    from click import custom_version_option

    _HAS_CLICK_8_5_EXPORTS = True
except ImportError:  # Click < 8.5.0.
    _HAS_CLICK_8_5_EXPORTS = False

# Overrides click helpers with cloup's. Cloup 4.0.0 lists Click's deprecated
# names in its `__all__` and serves them through its own `__getattr__`, so this
# star import resolves each of them and Click warns: silence that here, then drop
# the bindings further down, where _DEPRECATED_CLICK_EXPORTS takes them over.
with warnings.catch_warnings():
    warnings.simplefilter("ignore", DeprecationWarning)
    from cloup import *  # type: ignore[no-redef, assignment]

# ArgumentKwargs and OptionKwargs are cloup 4.0.0 additions, absent on the cloup
# 3.x releases click-extra still supports. Import them only when present; their
# __all__ entries are trimmed below when they are missing. Type checking against
# cloup 3.x finds neither name, hence the ignore.
try:
    from cloup import (  # type: ignore[attr-defined, unused-ignore]
        ArgumentKwargs,
        OptionKwargs,
    )

    _HAS_CLOUP_4_EXPORTS = True
except ImportError:  # Cloup < 4.0.0.
    _HAS_CLOUP_4_EXPORTS = False

# Imported for its registration side effect: defining the module registers the
# `carapace` shell completion class (see click_extra.carapace.CarapaceComplete),
# so dynamic Carapace completion resolves in any CLI that imports click_extra.
from . import (
    carapace as carapace,
    context,
)
from .accessibility import AccessibleOption, clear, echo_via_pager
from .color import (
    ColorOption,
    NoColorOption,
)
from .columns import (
    ColumnSpec,
    render_columns_markdown_table,
    select_columns,
    select_row,
)
from .command_doc import (
    HELP_FORMATS,
    INSTALLABLE_FORMATS,
    CommandDoc,
    HelpFormat,
    HelpFormatOption,
    ManOption,
    format_manpage,
    install_manpages,
    read_manpage,
    render_help,
    render_manpage,
    render_manpages,
    write_manpages,
)
from .commands import (
    Command,
    ExtraOptionGroup,
    Group,
    HelpCommand,
    LazyGroup,
    LazySubcommand,
)
from .config import (
    CONFIG_PATH_METADATA_KEY,
    DEFAULT_SUBCOMMANDS_KEY,
    EXTENSION_METADATA_KEY,
    NO_CONFIG,
    NORMALIZE_KEYS_METADATA_KEY,
    PREPEND_SUBCOMMANDS_KEY,
    VCS,
    ConfigFormat,
    ConfigOption,
    ConfigValidator,
    ExportConfigOption,
    NoConfigOption,
    SchemaFieldInfo,
    ValidateConfigOption,
    ValidationError,
    ValidationReport,
    config_table_to_flags,
    field_docstrings,
    flatten_config_keys,
    format_from_mime,
    format_from_path,
    get_tool_config,
    make_schema_callable,
    normalize_config_keys,
    parse_content,
    read_file,
    run_config_validation,
    schema_field_infos,
    serialize_content,
)
from .context import Context, pass_context
from .decorators import (  # type: ignore[no-redef]
    accessible_option,
    argument,
    color_option,
    columns_option,
    command,
    config_option,
    debug_option,
    export_config_option,
    group,
    help_format_option,
    help_option,
    jobs_option,
    lazy_group,
    man_option,
    multicall_group,
    no_color_option,
    no_config_option,
    option,
    progress_option,
    quiet_option,
    show_params_option,
    sort_by_option,
    table_format_option,
    telemetry_option,
    theme_option,
    timer_option,
    tree_option,
    validate_config_option,
    verbose_option,
    verbosity_option,
    version_option,
    zero_exit_option,
)
from .execution import (
    CPU_COUNT,
    DEFAULT_JOBS,
    JobsOption,
    TimerOption,
    ZeroExitOption,
    args_cleanup,
    format_cli_prompt,
    highlight_bin_name,
    install_interrupt_handler,
    resolve_jobs,
    run_cli,
    run_jobs,
    run_lanes,
    terminate_live_processes,
)
from .highlight import (
    HelpFormatter,
    HelpKeywords,
)
from .humanize import format_duration, format_size
from .layout import wrap_ansi
from .logging import (
    DebugOption,
    Formatter,
    LogLevel,
    QuietOption,
    StreamHandler,
    VerboseOption,
    VerbosityOption,
    basicConfig,
    new_logger,
)
from .multicall import MulticallGroup
from .myst_converter import (
    convert_directory,
    convert_file,
    convert_source,
    detect_source_package,
)
from .output import STDOUT_SENTINEL, is_stdout, prep_path
from .parameters import (
    Argument,
    ExtraOption,
    Option,
    ParamStructure,
    ShowParamsOption,
    format_param_row,
    get_param_spec,
    last_param,
    require_sibling_param,
    search_params,
)
from .rst_to_myst import (
    convert_apidoc_rst_to_myst,
    convert_rst_files_in_directory,
)
from .spinner import (  # type: ignore[no-redef]
    SPINNERS,
    OperationTrail,
    ProgressOption,
    Spinner,
    SpinnerPreset,
    progressbar,
)

# `Style` shadows the `cloup.Style` bound by the star import above with
# click-extra's enhanced subclass; relative imports always follow the cloup
# star import, so the override needs no special placement.
from .styling import (
    Style,
    ansi_to_html,
    ansi_to_jira,
    ansi_to_latex,
    ansi_to_textile,
    open_ansi,
    render_ansi,
    split_ansi,
)
from .table import (
    ColumnsOption,
    SortByOption,
    TableFormat,
    TableFormatOption,
    column_sort_key,
    corner_header,
    print_data,
    print_table,
    render_table,
    serialize_data,
)
from .telemetry import TelemetryOption

# The test tooling (.testing, .test_suite) is deliberately NOT imported here:
# click_extra.testing imports click.testing, whose module-level `import pdb`
# drags asyncio and the _pyrepl machinery (Python 3.13+) into every program
# that merely imports click_extra. That debugger stack is pure dead weight in
# production CLIs, and Nuitka bundles it into every compiled binary. The
# symbols stay in __all__ and resolve on first access through the module
# __getattr__ hook below; see _LAZY_TEST_TOOLING.
from .theme import (
    BUILTIN_THEMES,
    HelpTheme,
    ThemeOption,
    get_current_theme,
    get_default_theme,
    register_theme,
    set_default_theme,
    theme_registry,
)
from .tree import TreeOption, render_command_tree
from .types import (
    ChoiceSource,
    Duration,
    EnumChoice,
    MultiChoice,
    parse_duration,
    parse_friendly_duration,
    parse_iso8601_duration,
)
from .version import VersionOption

__all__ = [
    "BOOL",
    "BUILTIN_THEMES",
    "CONFIG_PATH_METADATA_KEY",
    "CPU_COUNT",
    "DEFAULT_JOBS",
    "DEFAULT_SUBCOMMANDS_KEY",
    "DEFAULT_TEST_SUITE",
    "EXTENSION_METADATA_KEY",
    "FLOAT",
    "HELP_FORMATS",
    "INSTALLABLE_FORMATS",
    "INT",
    "NORMALIZE_KEYS_METADATA_KEY",
    "NO_CONFIG",
    "PREPEND_SUBCOMMANDS_KEY",
    "SPINNERS",
    "STDOUT_SENTINEL",
    "STRING",
    "SUITE_FORMATS",
    "UNPROCESSED",
    "UNSET",
    "UUID",
    "VCS",
    "Abort",
    "AccessibleOption",
    "Argument",
    "ArgumentKwargs",
    "BadArgumentUsage",
    "BadOptionUsage",
    "BadParameter",
    "CLITestCase",
    "Choice",
    "ChoiceSource",
    "CliRunner",
    "ClickException",
    "Color",
    "ColorOption",
    "ColumnSpec",
    "ColumnsOption",
    "Command",
    "CommandCollection",
    "CommandDoc",
    "ConfigFormat",
    "ConfigOption",
    "ConfigValidator",
    "ConstraintMixin",
    "Context",
    "DateTime",
    "DebugOption",
    "Duration",
    "EnumChoice",
    "ExportConfigOption",
    "ExtraOption",
    "ExtraOptionGroup",
    "File",
    "FileError",
    "FloatRange",
    "Formatter",
    "Group",
    "HelpCommand",
    "HelpFormat",
    "HelpFormatOption",
    "HelpFormatter",
    "HelpKeywords",
    "HelpSection",
    "HelpTheme",
    "IntRange",
    "JobsOption",
    "LazyGroup",
    "LazySubcommand",
    "LogLevel",
    "ManOption",
    "MissingParameter",
    "MultiChoice",
    "MulticallGroup",
    "NoColorOption",
    "NoConfigOption",
    "NoSuchCommand",
    "NoSuchOption",
    "OperationTrail",
    "Option",
    "OptionGroup",
    "OptionGroupMixin",
    "OptionKwargs",
    "ParamStructure",
    "ParamType",
    "Parameter",
    "ParameterSource",
    "Path",
    "ProgressOption",
    "QuietOption",
    "Result",
    "SchemaFieldInfo",
    "Section",
    "SectionMixin",
    "ShowParamsOption",
    "SkippedTest",
    "SortByOption",
    "Spinner",
    "SpinnerPreset",
    "StreamHandler",
    "Style",
    "TableFormat",
    "TableFormatOption",
    "TelemetryOption",
    "ThemeOption",
    "TimerOption",
    "TreeOption",
    "Tuple",
    "UsageError",
    "ValidateConfigOption",
    "ValidationError",
    "ValidationReport",
    "VerboseOption",
    "VerbosityOption",
    "VersionOption",
    "ZeroExitOption",
    "accessible_option",
    "ansi_to_html",
    "ansi_to_jira",
    "ansi_to_latex",
    "ansi_to_textile",
    "args_cleanup",
    "argument",
    "basicConfig",
    "cases_from_data",
    "clear",
    "color_option",
    "column_sort_key",
    "columns_option",
    "command",
    "config_option",
    "config_table_to_flags",
    "confirm",
    "confirmation_option",
    "constrained_params",
    "constraint",
    "context",
    "convert_apidoc_rst_to_myst",
    "convert_directory",
    "convert_file",
    "convert_rst_files_in_directory",
    "convert_source",
    "corner_header",
    "custom_version_option",
    "debug_option",
    "detect_source_package",
    "dir_path",
    "echo",
    "echo_via_pager",
    "edit",
    "export_config_option",
    "field_docstrings",
    "file_path",
    "flatten_config_keys",
    "format_cli_prompt",
    "format_duration",
    "format_filename",
    "format_from_mime",
    "format_from_path",
    "format_manpage",
    "format_param_row",
    "format_size",
    "get_app_dir",
    "get_binary_stream",
    "get_current_context",
    "get_current_theme",
    "get_default_theme",
    "get_pager_file",
    "get_param_spec",
    "get_text_stream",
    "get_tool_config",
    "getchar",
    "group",
    "help_format_option",
    "help_option",
    "highlight_bin_name",
    "install_interrupt_handler",
    "install_manpages",
    "is_stdout",
    "jobs_option",
    "last_param",
    "launch",
    "lazy_group",
    "load_test_suite",
    "make_pass_decorator",
    "make_schema_callable",
    "man_option",
    "multicall_group",
    "new_logger",
    "no_color_option",
    "no_config_option",
    "normalize_config_keys",
    "open_ansi",
    "open_file",
    "option",
    "option_group",
    "parse_content",
    "parse_duration",
    "parse_friendly_duration",
    "parse_iso8601_duration",
    "parse_test_suite",
    "pass_context",
    "pass_obj",
    "password_option",
    "path",
    "pause",
    "prep_path",
    "print_data",
    "print_table",
    "progress_option",
    "progressbar",
    "prompt",
    "quiet_option",
    "read_file",
    "read_manpage",
    "register_theme",
    "render_ansi",
    "render_columns_markdown_table",
    "render_command_tree",
    "render_help",
    "render_manpage",
    "render_manpages",
    "render_table",
    "require_sibling_param",
    "resolve_jobs",
    "run_cli",
    "run_config_validation",
    "run_jobs",
    "run_lanes",
    "run_test_suite",
    "schema_field_infos",
    "search_params",
    "secho",
    "select_columns",
    "select_row",
    "serialize_content",
    "serialize_data",
    "set_default_theme",
    "show_params_option",
    "sort_by_option",
    "split_ansi",
    "style",
    "table_format_option",
    "telemetry_option",
    "terminate_live_processes",
    "theme_option",
    "theme_registry",
    "timer_option",
    "tree_option",
    "unstyle",
    "validate_config_option",
    "verbose_option",
    "verbosity_option",
    "version_option",
    "wrap_ansi",
    "wrap_text",
    "write_manpages",
    "zero_exit_option",
]
"""Expose all of Click, Cloup and Click Extra.

```{note}
The content of `__all__` is checked for completeness by unittests: it covers
click's and cloup's public members, every public binding of this namespace is
declared here, every declared name resolves, and no foreign module leaks in.
Sorting is enforced by `ruff` via
[RUF022](https://docs.astral.sh/ruff/rules/unsorted-dunder-all/).
```
"""

# custom_version_option is only re-exported on Click >= 8.5.0 (see the guarded
# import above). Drop it from the public API on older Click so `__all__` matches
# the names actually bound in this module. That same release moved the two stream
# getters behind Click's module `__getattr__`, so a star import of Click stops
# binding them: drop them too, or `from click_extra import *` would fetch each
# through _DEPRECATED_CLICK_EXPORTS and set off Click's deprecation warning.
if _HAS_CLICK_8_5_EXPORTS:
    __all__.remove("get_binary_stream")
    __all__.remove("get_text_stream")
else:
    __all__.remove("custom_version_option")
del _HAS_CLICK_8_5_EXPORTS

# ArgumentKwargs and OptionKwargs are only re-exported on cloup >= 4.0.0 (see the
# note under the cloup star import). Drop them from the public API on cloup 3.x.
if not _HAS_CLOUP_4_EXPORTS:
    __all__.remove("ArgumentKwargs")
    __all__.remove("OptionKwargs")
del _HAS_CLOUP_4_EXPORTS

# Scrub namespace artifacts that are not part of the public API: `annotations`
# is this module's own `from __future__ import annotations` binding (deleting
# it does not affect postponed evaluation, which is settled at compile time).
del annotations


def _scrub_foreign_modules() -> None:
    """Drop the module objects the star imports above leaked into this namespace.

    click ships no `__all__`, so `from click import *` copies every submodule
    its own `__init__` binds (`click.core`, `click.globals`, `click.termui`,
    ...), and cloup 3.x's `__all__` exports its own `warnings` and `_version`
    submodules, the first of which shadows the stdlib name (reported at
    [janluke/cloup#204](https://github.com/janluke/cloup/issues/204#issuecomment-5600674392)).
    These bindings are traps: `click_extra.core.Group` would resolve to
    click's original class instead of click-extra's override, and `globals`
    even shadows the builtin. The package's genuine submodules, bound by the
    relative imports above, are kept. The scrub outlives any fix upstream,
    since click declares no `__all__` at all. A unittest checks none of this
    regresses.
    """
    import sys
    from types import ModuleType

    namespace = vars(sys.modules[__name__])
    for name in [
        module_id
        for module_id, value in namespace.items()
        if isinstance(value, ModuleType)
        and not value.__name__.startswith(f"{__name__}.")
    ]:
        del namespace[name]


_scrub_foreign_modules()
del _scrub_foreign_modules


__version__ = "9.4.1"
__git_branch__ = ""
__git_date__ = ""
__git_long_hash__ = ""
__git_short_hash__ = ""
__git_tag__ = ""
__git_tag_sha__ = "51e1203c647eb776d96932a09af33843adbe162c"


_LAZY_TEST_TOOLING = {
    "CLITestCase": "test_suite",
    "CliRunner": "testing",
    "DEFAULT_TEST_SUITE": "test_suite",
    "Result": "testing",
    "SUITE_FORMATS": "test_suite",
    "SkippedTest": "test_suite",
    "cases_from_data": "test_suite",
    "load_test_suite": "test_suite",
    "parse_test_suite": "test_suite",
    "run_test_suite": "test_suite",
}
"""Test-tooling symbols served lazily by `__getattr__`, keyed to their module.

Keeps `import click_extra` free of `click.testing` and the pdb/asyncio/_pyrepl
debugger stack it pulls in (see the note above the `.theme` import). The names
remain listed in `__all__`: plain attribute access and
`from click_extra import ...` resolve them on first use, and a star-import
materializes them all, at the cost of loading the test tooling.
"""


_DEPRECATED_CLICK_EXPORTS = frozenset({
    "BaseCommand",
    "MultiCommand",
    "OptionParser",
    "get_binary_stream",
    "get_text_stream",
})
"""Click symbols deprecated for removal in Click `9.0`, forwarded on access instead.

Click serves these only through its own module `__getattr__`: the first three
since Click `8.2.0`, the two stream getters since Click `8.5.0`. A star import
never consults that hook, so `from click import *` binds none of them. Cloup
`4.0.0` lists all five in its own `__all__`, whose star import resolves each one:
the bindings it leaves are deleted right below. Forwarding each access keeps
click-extra a drop-in for as long as Click serves them, and warns exactly when
Click does: the value is never cached, so every access reaches Click's shim.
"""

for _name in _DEPRECATED_CLICK_EXPORTS:
    globals().pop(_name, None)
del _name


def __getattr__(name: str) -> Any:
    """Resolve lazy top-level symbols via PEP 562.

    Test-tooling names registered in {data}`_LAZY_TEST_TOOLING` are imported
    from their hosting module on first access, then cached in the module
    namespace so later accesses bypass this hook. Names in
    {data}`_DEPRECATED_CLICK_EXPORTS` are forwarded to Click on every access,
    uncached. Fires only for names not defined in this module, so live exports
    stay zero-overhead.
    """
    if name in _DEPRECATED_CLICK_EXPORTS:
        # Imported here rather than at module level: the star imports above bind
        # no `click` name, and _scrub_foreign_modules() would drop one anyway.
        import click

        # Never cached, so each access reaches Click's own deprecation shim.
        return getattr(click, name)

    lazy_module = _LAZY_TEST_TOOLING.get(name)
    if lazy_module:
        from importlib import import_module

        value = getattr(import_module(f"{__name__}.{lazy_module}"), name)
        # Cache the symbol on the module so later accesses bypass this hook.
        globals()[name] = value
        return value

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__() -> list[str]:
    """Expose every name `__getattr__` serves to `dir()` before its first access."""
    return sorted(set(globals()) | set(_LAZY_TEST_TOOLING) | _DEPRECATED_CLICK_EXPORTS)
